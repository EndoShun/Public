/*****************************************************************************
* Poll1.c - �|�[�����O�̂��߂̃��W���[�� Poll1
\*****************************************************************************/

extern "C" {
#include <rt.h>
#include <comm.h>
}

#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "RangefinderControl.h"
#include "RtSharedMemory.h"

static const char* COMM_NAME = "COM1";
static constexpr int32_t BUFFER_SIZE = 256;

enum class CommandError {
	OK,
	NACK,
	Timeout,
	UnexpectedResponse,
	ChecksumError,
	CommError
};

enum class OperatingMode {
	StandByMode,
	NormalOperatingMode
};

const char* CommandErrorToStr(CommandError commandError) {
	if (commandError == CommandError::OK) {
		return "OK";
	}
	else if (commandError == CommandError::NACK) {
		return "NACK";
	}
	else if (commandError == CommandError::Timeout) {
		return "Timeout";
	}
	else if (commandError == CommandError::UnexpectedResponse) {
		return "UnexpectedResponse";
	}
	else if (commandError == CommandError::ChecksumError) {
		return "ChecksumError";
	}
	else if (commandError == CommandError::CommError) {
		return "CommError";
	}
	else{
		return "Undefined error";
	}
}

int32_t asciiToUint8(uint8_t hsb, uint8_t lsb, uint8_t* result) {
	if (!(('0' <= hsb && hsb <= '9') || ('A' <= hsb && hsb <= 'F'))) {
		return -1;
	}
	if (!(('0' <= lsb && lsb <= '9') || ('A' <= lsb && lsb <= 'F'))) {
		return -1;
	}

	if ('0' <= hsb && hsb <= '9') {
		*result = (hsb - '0') << 4;
	}
	else {
		*result = (hsb - 'A' + 10) << 4;
	}

	if ('0' <= lsb && lsb <= '9') {
		*result |= lsb - '0';
	}
	else {
		*result |= lsb - 'A' + 10;
	}
	return 0;
}

int32_t checkChecksum(uint8_t* buffer, int32_t length) {
	uint8_t checksum = 0;
	for (int i = 1; i < length - 4; i++) {
		checksum += buffer[i];
	}

	uint8_t sentChecksum;
	if (asciiToUint8(buffer[length - 3], buffer[length - 2], &sentChecksum) < 0) {
		return -1;
	}

	if (checksum != sentChecksum) {
		return -1;
	}
	else {
		return 0;
	}
}

CommandError rangefinderRw(COMMHANDLE comm, const char* command, uint32_t commandLength, uint8_t* buffer, int32_t expectedResponceLength) {
	DWORD bytesWritten;
	if (WriteComm(comm, (LPVOID)command, commandLength, &bytesWritten, 0) == 0) {
		fprintf(stderr, "Comm write fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}

	if (bytesWritten != commandLength) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}

	DWORD bytesRead;
	if (ReadComm(comm, buffer, 3, &bytesRead, 0) == 0) {
		fprintf(stderr, "Comm read fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}

	if (bytesRead != 3) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::Timeout;
	}


	////////////////////////////////////////////
	// Check "AC" of ACK
	////////////////////////////////////////////
	buffer[bytesRead] = 0;
	if (strncmp((const char*)buffer, ">AC", 3) != 0) {
		if (strncmp((const char*)buffer, ">NA", 3) == 0) {
			if (ReadComm(comm, buffer, 7, &bytesRead, 0) == 0) {
				fprintf(stderr,"Comm read fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
				PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
				return CommandError::CommError;
			}
			
			if (bytesRead != 7) {
				PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
				return CommandError::Timeout;
			}
				
			if (buffer[1] == '0') {
				fprintf(stderr, "Message checksum error\n");

			}
			else if (buffer[1] == '1') {
				fprintf(stderr, "Message is not supported/implemented\n");
			}
			else if (buffer[1] == '2') {
				fprintf(stderr, "Invalid parameters(s)\n");
			}
			else if (buffer[1] == '3') {
				fprintf(stderr, "Serial interface Rx Parity bit error\n");
			}
			else if (buffer[1] == '4') {
				fprintf(stderr, "Serial interface Rx overflow error\n");
			}
			else if (buffer[1] == '5') {
				fprintf(stderr, "other command error\n");
			}
			else{
				fprintf(stderr, "Unexpected NACK response\n");
			}

			PurgeComm(comm,PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::NACK;
		}
	}


	////////////////////////////////////////////
	// Check "*84<CR>" of ACK
	////////////////////////////////////////////
	if (ReadComm(comm, buffer, 4, &bytesRead, 0) == 0) {
		fprintf(stderr, "Comm read fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}

	if (bytesRead != 4) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::Timeout;
	}
	
	if (strncmp((const char*)buffer,"*84\r",4) != 0) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}


	if (expectedResponceLength == 0) {
		////////////////////////////////////////////
		// Read Response -- no response command
		////////////////////////////////////////////
		if (ReadComm(comm, buffer, 1, &bytesRead, 0) == 0) {
			fprintf(stderr, "Comm read fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
			PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::CommError;
		}

		if (bytesRead != 1) {
			PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::Timeout;
		}

		if (strncmp((const char*)buffer, "<", 1) != 0) {
			PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::UnexpectedResponse;
		}

		return CommandError::OK;
	}
	else {
		////////////////////////////////////////////
		// Read Response
		////////////////////////////////////////////
		if (ReadComm(comm, buffer, expectedResponceLength+1, &bytesRead, 0) == 0) {
			fprintf(stderr, "Comm read fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
			PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::CommError;
		}

		if (bytesRead != expectedResponceLength+1) {
			PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::Timeout;
		}

		if (checkChecksum(buffer,expectedResponceLength) < 0) {
			PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
			return CommandError::ChecksumError;
		}
	}

	return CommandError::OK;
}

CommandError pbit(COMMHANDLE comm,uint8_t* buffer,uint8_t* bitResult1,uint8_t* bitResult2) {
	CommandError commandError = rangefinderRw(comm, ">LM,Tb,2*D9\r", 12, buffer, 21);
	if (commandError != CommandError::OK) {
		return commandError;
	}

	if (strncmp((const char*)buffer, ">LM,Tb,PBIT,",12) != 0) {
		return CommandError::UnexpectedResponse;
	}

	if (asciiToUint8(buffer[12], buffer[13], bitResult1) < 0) {
		return CommandError::UnexpectedResponse;
	}
	
	if (asciiToUint8(buffer[15], buffer[16], bitResult2) < 0) {
		return CommandError::UnexpectedResponse;
	}

	return CommandError::OK;
}

CommandError ibit(COMMHANDLE comm, uint8_t* buffer,double* temp,uint8_t* bitResult) {
	CommandError commandError = rangefinderRw(comm, ">LM,Tb,1*D8\r", 12, buffer, 26);
	if (commandError != CommandError::OK) {
		return commandError;
	}
	//>LM,Tb,IBIT,T+29.75,FF*37\r
	if (strncmp((const char*)buffer, ">LM,Tb,IBIT,T", 13) != 0) {
		return CommandError::UnexpectedResponse;
	}

	buffer[19] = 0;
	*temp = atof((const char*)(&buffer[13]));

	if (asciiToUint8(buffer[20], buffer[21], bitResult) < 0) {
		return CommandError::UnexpectedResponse;
	}

	return CommandError::OK;
}

CommandError resetRangefinder(COMMHANDLE comm, uint8_t* buffer) {
	CommandError commandError = rangefinderRw(comm, ">LM,Rd*7B\r", 10, buffer, 0);
	//>AC*84\r
	//<

	return commandError;
}

CommandError setOperationMode(COMMHANDLE comm, uint8_t* buffer, OperatingMode operatingMode) {
	CommandError commandError;
	if (operatingMode == OperatingMode::NormalOperatingMode) {
		commandError = rangefinderRw(comm, ">LM,Op,2*E2\r", 12,buffer, 0);
	}
	else {//stand-by mode
		commandError = rangefinderRw(comm, ">LM,Op,1*E1\r", 12, buffer, 0);
	}

	return commandError;
}

CommandError measureDistance(COMMHANDLE comm, uint8_t* buffer, uint16_t* mmX100_Distance) {
	CommandError commandError = rangefinderRw(comm, ">LM,Md,3*D5\r", 12, buffer, 37);
	//>LM,Md,v0006091,R000E301,R000E301*46\r

	if (strncmp((const char*)buffer, ">LM,Md,", 7) != 0) {
		return CommandError::UnexpectedResponse;
	}

	int32_t distance0, distance1, distance2;
	if (buffer[7] == 'v') {
		buffer[15] = 0;
		distance0 = atoi((const char*)&buffer[8]);
	}
	else {
		distance0 = -1;
	}

	if (buffer[16] == 'v') {
		buffer[24] = 0;
		distance1 = atoi((const char*)&buffer[17]);
	}
	else {
		distance1 = -1;
	}

	if (buffer[25] == 'v') {
		buffer[33] = 0;
		distance2 = atoi((const char*)&buffer[26]);
	}
	else {
		distance2 = -1;
	}

	if (distance0 >= 0) {
		*mmX100_Distance = distance0 / 10;
	}
	else if (distance1 >= 0) {
		*mmX100_Distance = distance1 / 10;
	}
	else if (distance2 >= 0) {
		*mmX100_Distance = distance2 / 10;
	}
	else {
		*mmX100_Distance = 65535;
	}

	return CommandError::OK;
}

/*****************************************************************************
* FUNCTION:		Poll1
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll1
\*****************************************************************************/
void				PollRangefinderControl(
	void*				param)
{

	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollRangefinderContrrol	= GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollRangefinderContrrol, (LPSTR)"Rangefinder");

	LPCSTR tmp = COMM_NAME;
	COMMHANDLE comm = OpenComm(COMM_NAME, 0);
	if (comm == INVALID_COMM_HANDLE) {
		printf("Rangefinder comm port open fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<RangefinderCommand> rangefinderCommand;
	RtSharedMemory<RangefinderStatus> rangefinderStatus;


	while (!gInit.bShutdown && rangefinderCommand.setup(BOOT_PARAMETER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && rangefinderCommand.setup(RANGEFINDER_COMMAND_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && rangefinderStatus.setup(RANGEFINDER_STATUS_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	/////////////////////////////////////////////////
	// Wait for boot parameter
	/////////////////////////////////////////////////

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);

		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}

	OperationMode operationMode = bootParameters.getBuf()->operationMode;


	COMMCONFIG config;
	config.dwSize = sizeof(config);
	config.wVersion = 1;
	config.wReserved = 0;
	config.dwProviderSubType = PST_RS232;
	config.dwProviderOffset = 0;
	config.dwProviderSize = 0;
	config.wcProviderData[0] = 0;
	config.dcb.DCBlength = sizeof(config.dcb);
	config.dcb.BaudRate = CBR_57600;
	config.dcb.fBinary = TRUE;
	config.dcb.fParity = FALSE;
	config.dcb.fOutxCtsFlow = FALSE;
	config.dcb.fOutxDsrFlow = FALSE;
	config.dcb.fDtrControl = DTR_CONTROL_DISABLE;
	config.dcb.fDsrSensitivity = FALSE;
	config.dcb.fTXContinueOnXoff = TRUE;
	config.dcb.fOutX = FALSE;
	config.dcb.fInX = FALSE;
	config.dcb.fErrorChar = FALSE;
	config.dcb.fNull = FALSE;
	config.dcb.fRtsControl = RTS_CONTROL_DISABLE;
	config.dcb.fAbortOnError = FALSE;
	config.dcb.wReserved = 0;
	config.dcb.XonLim = 255;
	config.dcb.ByteSize = 8;
	config.dcb.Parity = NOPARITY;
	config.dcb.StopBits = ONESTOPBIT;
	config.dcb.XonChar = FALSE;
	config.dcb.XoffChar = FALSE;
	config.dcb.ErrorChar = 0;
	config.dcb.EofChar = 0;
	config.dcb.EvtChar = 0;
	config.dcb.wReserved1 = 0;

	if(SetCommConfig(comm, &config, sizeof(config)) == 0 ){
		printf("Rangefinder config fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	if (SetupComm(comm, BUFFER_SIZE, BUFFER_SIZE) == 0) {
		printf("Rangefinder setup comm port fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	COMMTIMEOUTS timeouts;
	timeouts.ReadIntervalTimeout = 200;//[ms]
	timeouts.ReadTotalTimeoutMultiplier = 200;//[ms] x bytes to receive
	timeouts.ReadTotalTimeoutConstant = 200;//[ms]
	timeouts.WriteTotalTimeoutMultiplier = 200;//[ms]
	timeouts.WriteTotalTimeoutConstant = 200;//[ms]

	if (SetCommTimeouts(comm, &timeouts) == 0) {
		printf("Rangefinder set timeout fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	uint8_t readBuffer[BUFFER_SIZE];


	
	int32_t measurementStatus = 0;//0: Disable, 1:Enable, -1:Error
	int32_t rangefinderError = 0;
	uint16_t mmX100_Distance = 65535;

	CommandError ret = CommandError::Timeout;
	while (!gInit.bShutdown && ret != CommandError::OK) {
		ret = resetRangefinder(comm, readBuffer);
	}
	

	if (!gInit.bShutdown && operationMode == OperationMode::NORMAL) {
		double temp;
		uint8_t ibitResult;
		ret = ibit(comm, readBuffer, &temp, &ibitResult);
		if (ret != CommandError::OK) {
			printf("rangefinder command error: %s\n", CommandErrorToStr(ret));
			rangefinderError = 1;
		}

		uint8_t pbitResult1 = 0;
		uint8_t pbitResult2 = 0;
		ret = pbit(comm, readBuffer, &pbitResult1, &pbitResult2);
		if (ret != CommandError::OK) {
			printf("rangefinder command error: %s\n", CommandErrorToStr(ret));
			rangefinderError = 1;
		}

		ret = setOperationMode(comm, readBuffer, OperatingMode::NormalOperatingMode);
		if (ret != CommandError::OK) {
			printf("rangefinder command error: %s\n", CommandErrorToStr(ret));
			rangefinderError = 1; measurementStatus = -1;
		}

		if ((ibitResult & 0x01) == 0) {
			rangefinderError = 1;
		}
		if ((pbitResult2 & 0x01) == 0) {
			rangefinderError = 1;
		}
	}
	
	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(100000));

		rangefinderCommand.copySharedToLocal(10);

		if (operationMode == OperationMode::NORMAL) {
			if (rangefinderError) {
				rangefinderStatus.getBuf()->status = -2;
				rangefinderStatus.getBuf()->mmX100Range = 65535;
			}
			else if (rangefinderCommand.getBuf()->on) {
				uint16_t tmpMmX100_Distance;
				ret = measureDistance(comm, readBuffer, &tmpMmX100_Distance);

				if (ret != CommandError::OK) {
					printf("rangefinder command error: %s\n", CommandErrorToStr(ret));
					rangefinderStatus.getBuf()->status = -2;
					rangefinderStatus.getBuf()->mmX100Range = 65535;
				}
				else {
					rangefinderStatus.getBuf()->status = 1;
					rangefinderStatus.getBuf()->mmX100Range = tmpMmX100_Distance;
				}
			}
			else {
				rangefinderStatus.getBuf()->status = 0;
				rangefinderStatus.getBuf()->mmX100Range = 65535;
			}
		}
		else {
			rangefinderStatus.getBuf()->status = 1;
			rangefinderStatus.getBuf()->mmX100Range = 0;
		}

		rangefinderStatus.copyLocalToShared(10);
	}
	

	if (comm != INVALID_COMM_HANDLE) {
		CloseComm(comm);
	}

	

	// �{�X���b�h�̏I����ʒm
	gInit.htPollRangefinderContrrol = NULL_RTHANDLE;
}
