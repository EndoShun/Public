/*****************************************************************************
* Poll2.c - �|�[�����O�̂��߂̃��W���[�� Poll2
\*****************************************************************************/

#include <stdio.h>
#include <rt.h>

#include "INtimeAppBase.h"
#include "shm_data.h"

extern PMON_PARAM			pMonitorParam1;
extern PMON_PARAM			pMonitorParam2;

/*****************************************************************************/
void status_monitor(SHM_DATA* pShm)
{
#if 0
	struct tm ts;
	time_t t0 = time(NULL);
	localtime_s(&t0, &ts);

	if (pMonitorParam1 != NULL && pMonitorParam2 != NULL) {
		printf("//////////////////////////////////////////////////////////////////////////\n");
		printf("%04d/%02d/%02d %02d:%02d:%02d,pos,%d,%d,speed,%d,%d,trq,%d,%d,da,%.4f,%.4f\n",
			ts.tm_year + 1900, ts.tm_mon + 1, ts.tm_mday, ts.tm_hour, ts.tm_min, ts.tm_sec,
			pMonitorParam1->SV.cpos, pMonitorParam2->SV.cpos,
			pMonitorParam1->SV.fspd, pMonitorParam2->SV.fspd,
			pMonitorParam1->SV.trq, pMonitorParam2->SV.trq,
			pShm->dt_ctrl.da_out[0], pShm->dt_ctrl.da_out[1]);
		printf("//////////////////////////////////////////////////////////////////////////\n");
	}
#endif
}
/*****************************************************************************
* FUNCTION:		Poll2
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll2
\*****************************************************************************/
void				PollKey(
	void*				param)
{
	LOCATION        loc;
	RTHANDLE		hRProcess = NULL_RTHANDLE;
	RTHANDLE		hProcess = NULL_RTHANDLE;
	RTHANDLE        hShmProc;
	SHM_DATA* pShm;
#ifdef _DEBUG
	fprintf(stderr, "PollKey started\n");
#endif
	UCHAR k,axis=0;
	UCHAR cmd[64];
	int idx = 0;
	DIRECT_CTRL_DATA dt_ctrl;


	loc = GetRtNodeLocationByName("NodeLog");
	if (loc == BAD_LOCATION) {
		//SendErrMsg(0, "GetRtNodeLocationByName fail");
	}
	if (GetRtNodeStatus(loc) != E_OK) {
		//SendErrMsg(0, "GetRtNodeStatus fail");
	}
	//SendEvtMsg(0, "GetRemoteRootRtProcess");
	hRProcess = GetRemoteRootRtProcess(loc);
	if (BAD_RTHANDLE == hRProcess)
	{
		Fail("Cannot find data mailbox process");
		//SendErrMsg(0, "Cannot find data mailbox process");
		return;
	}

	hProcess = LookupRtHandle(hRProcess, "INtimeAppLog", WAIT_FOREVER);
	if (BAD_RTHANDLE == hProcess)
	{
		Fail("Cannot find data mailbox process");
		//SendErrMsg(0, "Cannot find data mailbox process");
		return;
	}
	hShmProc = LookupRtHandle(hProcess, "ShmLogServer", 0);
	if (hShmProc == BAD_RTHANDLE) {
		//SendErrMsg(0, "Cannot find shm data");
		return;
	}
	pShm = MapRtSharedMemory(hShmProc);

	if (!ValidateRtBuffer(pShm, sizeof(SHM_DATA), BUFFER_WRITABLE)) {
		printf("Mapped buffer not writable\n");
		return;
	}

	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollKey	= GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollKey, "TPollKey");
	memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));

	while (!gInit.bShutdown)
	{
		//RtSleep(1000);
		knRtSleep(UsecsToKticks(1000));
#ifdef _DEBUG
		fprintf(stderr, "PollKey waking up\n");
#endif
		// TODO:  1000 �~���b���ƂɌJ��Ԃ�������z�u���܂�
		status_monitor(pShm);
		printf("\n*** menu ***************************\n");
		printf("p:position ctrl\n");
		printf("t:torque ctrl\n");
		printf("v:velocity ctrl\n");
		printf("d:DA ctrl\n");
		printf("s:stop ctrl\n");
		printf("q:exit\n");
		printf("************************************\n");
		printf("Hit Enter key ......\n");
		printf("************************************\n");
		scanf("%s", cmd);
		if (strlen(cmd) > 0) k = cmd[0];
		else k = 0;



		status_monitor(pShm);
		if (k == 'd') {
			printf("input   DA (%.4lf,%.4lf):",dt_ctrl.da_out[0], dt_ctrl.da_out[1]);
			scanf("%lf,%lf", &dt_ctrl.da_out[0], &dt_ctrl.da_out[1]);
			if (dt_ctrl.da_out[0] < -1.0)dt_ctrl.da_out[0] = -1.0;
			else if (dt_ctrl.da_out[0] > 1.0)dt_ctrl.da_out[0] = 1.0;
			if (dt_ctrl.da_out[1] < -1.0)dt_ctrl.da_out[1] = -1.0;
			else if (dt_ctrl.da_out[1] > 1.0)dt_ctrl.da_out[1] = 1.0;
			printf("------------------------------------------------\n");
			printf("setting DA (%.4lf,%.4f)\n", dt_ctrl.da_out[0], dt_ctrl.da_out[1]);
			memcpy(&pShm->dt_ctrl, &dt_ctrl, sizeof(DIRECT_CTRL_DATA));
			status_monitor(pShm);
			pShm->dt_ctrl.wpos++;
		}
		if (k == 't') {
			printf("input   axis?(0,1):");
			scanf("%s", cmd);
			if (strlen(cmd) > 0) axis = cmd[0];
			printf("************************************\n");
			printf("setting axis:%c\n", axis);
			if (axis == '0') idx = 0;
			else if (axis == '1') idx = 1;
			else if (axis == '2') {
				idx = -1;
				pShm->dt_ctrl.tg_axis = 2;
			}
			else continue;
			printf("************************************\n");

			if (idx != -1) {
				pShm->dt_ctrl.tg_axis = idx;
				memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));
				printf("input   axis%d trqunit[%d],comtorque[%d],velocityLimit[%d]:", idx,
					pShm->dt_ctrl.trqunit[idx], pShm->dt_ctrl.comtorque[idx], pShm->dt_ctrl.velocityLimit[idx]);
				int sz = (int)scanf("%d,%d,%d", &dt_ctrl.trqunit[idx], &dt_ctrl.comtorque[idx], &dt_ctrl.velocityLimit[idx]);
				if (sz == 3) {
					printf("------------------------------------------------\n");
					printf("setting axis%d trqunit[%d],comtorque[%d],velocityLimit[%d]",
						idx,dt_ctrl.trqunit[idx],dt_ctrl.comtorque[idx], dt_ctrl.velocityLimit[idx]);
					status_monitor(pShm);
					memcpy(&pShm->dt_ctrl, &dt_ctrl, sizeof(DIRECT_CTRL_DATA));
					pShm->dt_ctrl.wpos++;
				}
			}
			else {
				printf("------------------------------------------------\n");
				idx = 0;
				printf("setting axis%d trqunit[%d],comtorque[%d],velocityLimit[%d]",
					idx, dt_ctrl.trqunit[idx], dt_ctrl.comtorque[idx], dt_ctrl.velocityLimit[idx]);
				idx = 1;
				printf("setting axis%d trqunit[%d],comtorque[%d],velocityLimit[%d]",
					idx, dt_ctrl.trqunit[idx], dt_ctrl.comtorque[idx], dt_ctrl.velocityLimit[idx]);
				status_monitor(pShm);
			}
		}
		if (k == 'v') {
			printf("input   axis?(0,1):");
			scanf("%s", cmd);
			if (strlen(cmd) > 0) axis = cmd[0];
			printf("************************************\n");

			printf("setting axis:%c\n", axis);
			if (axis == '0') idx = 0;
			else if (axis == '1') idx = 1;
			else if (axis == '2') {
				idx = -1;
				pShm->dt_ctrl.tg_axis = 2;
			}else continue;
			printf("************************************\n");

			if (idx != -1) {
				pShm->dt_ctrl.tg_axis = idx;
				memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));

				printf("input   axis%d velocityunit[%d],velocity[%d],trqunit[%d],trqff[%d],trqLimit[%d]:", idx,
					pShm->dt_ctrl.velocityunit[idx], pShm->dt_ctrl.velocity[idx], pShm->dt_ctrl.trqunit[idx],
					pShm->dt_ctrl.trqff[idx], pShm->dt_ctrl.trqLimit[idx]);
				int sz = (int)scanf("%d,%d,%d,%d,%d", &dt_ctrl.velocityunit[idx], &dt_ctrl.velocity[idx], &dt_ctrl.trqunit[idx],
					&dt_ctrl.trqff[idx], &dt_ctrl.trqLimit[idx]);
				if (sz == 5) {
					printf("------------------------------------------------\n");
					printf("setting axis%d  velocityunit[%d],velocity[%d],trqunit[%d],trqff[%d],trqLimit[%d]\n",
						idx,dt_ctrl.velocityunit[idx],dt_ctrl.velocity[idx],dt_ctrl.trqunit[idx], dt_ctrl.trqff[idx], dt_ctrl.trqLimit[idx]);
					status_monitor(pShm);
					memcpy(&pShm->dt_ctrl, &dt_ctrl, sizeof(DIRECT_CTRL_DATA));
					pShm->dt_ctrl.wpos++;
				}
			}
			else {
				printf("------------------------------------------------\n");
				idx = 0;
				printf("setting axis%d  velocityunit[%d],velocity[%d],trqunit[%d],trqff[%d],trqLimit[%d]\n",
					idx, dt_ctrl.velocityunit[idx], dt_ctrl.velocity[idx], dt_ctrl.trqunit[idx], dt_ctrl.trqff[idx], dt_ctrl.trqLimit[idx]);
				idx = 1;
				printf("setting axis%d  velocityunit[%d],velocity[%d],trqunit[%d],trqff[%d],trqLimit[%d]\n",
					idx, dt_ctrl.velocityunit[idx], dt_ctrl.velocity[idx], dt_ctrl.trqunit[idx], dt_ctrl.trqff[idx], dt_ctrl.trqLimit[idx]);
				status_monitor(pShm);

			}
			
		}
		if (k == 'p') {
			printf("input   axis?(0,1):");
			scanf("%s", cmd);
			if (strlen(cmd) > 0) axis = cmd[0];
			printf("************************************\n");

			printf("setting key:%c\n", axis);
			if (axis == '0') idx = 0;
			else if (axis == '1') idx = 1;
			else if (axis == '2') {
				idx = -1;
				pShm->dt_ctrl.tg_axis = 2;
			}
			else continue;
			printf("************************************\n");

			printf("input pos?(0),all?(1):");
			scanf("%s", cmd);
			if (strlen(cmd) > 0) axis = cmd[0];
			printf("************************************\n");

			if (idx != -1) {
				pShm->dt_ctrl.tg_axis = idx;
				memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));

				if (axis == '0') {
					printf("input   axis%d targetpos[%d]:", idx,
						pShm->dt_ctrl.targetpos[idx]);


					int sz = (int)scanf("%d",
						&dt_ctrl.targetpos[idx]);
					if (sz == 1) {
						printf("------------------------------------------------\n");
						printf("setting axis%d velocityunit[%d],accunit[%d],filtertype[%d],accel[%d],decel[%d],\n"
						       "               filtervalue[%d],psetwidth[%d],trqunit[%d],trqLimit[%d],velocity[%d],postype[%d],targetpos[%d]\n",
							idx,dt_ctrl.velocityunit[idx],dt_ctrl.accunit[idx],dt_ctrl.filtertype[idx],dt_ctrl.accel[idx],dt_ctrl.decel[idx],
							dt_ctrl.filtervalue[idx], dt_ctrl.psetwidth[idx],dt_ctrl.trqunit[idx],dt_ctrl.trqLimit[idx],dt_ctrl.velocity[idx],
							dt_ctrl.postype[idx],dt_ctrl.targetpos[idx]);
						status_monitor(pShm);
						memcpy(&pShm->dt_ctrl, &dt_ctrl, sizeof(DIRECT_CTRL_DATA));
						pShm->dt_ctrl.wpos++;
					}
				}
				else if (axis == '1') {
					printf("input   axis%d velocityunit[%d],accunit[%d],filtertype[%d],accel[%d],decel[%d],\n"
						   "        filtervalue[%d],psetwidth[%d],trqunit[%d],trqLimit[%d],velocity[%d],postype[%d],targetpos[%d]:", idx,
						pShm->dt_ctrl.velocityunit[idx], pShm->dt_ctrl.accunit[idx], pShm->dt_ctrl.filtertype[idx],
						pShm->dt_ctrl.accel[idx], pShm->dt_ctrl.decel[idx], pShm->dt_ctrl.filtervalue[idx],
						pShm->dt_ctrl.psetwidth[idx], pShm->dt_ctrl.trqunit[idx], pShm->dt_ctrl.trqLimit[idx],
						pShm->dt_ctrl.velocity[idx], pShm->dt_ctrl.postype[idx], pShm->dt_ctrl.targetpos[idx]);

					int sz = (int)scanf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d", &dt_ctrl.velocityunit[idx], &dt_ctrl.accunit[idx], &dt_ctrl.filtertype[idx],
						&dt_ctrl.accel[idx], &dt_ctrl.decel[idx], &dt_ctrl.filtervalue[idx],
						&dt_ctrl.psetwidth[idx], &dt_ctrl.trqunit[idx], &dt_ctrl.trqLimit[idx],
						&dt_ctrl.velocity[idx], &dt_ctrl.postype[idx], &dt_ctrl.targetpos[idx]);
					if (sz == 12) {
						printf("------------------------------------------------\n");
						printf("setting axis%d velocityunit[%d],accunit[%d],filtertype[%d],accel[%d],decel[%d],\n"
							"               filtervalue[%d],psetwidth[%d],trqunit[%d],trqLimit[%d],velocity[%d],postype[%d],targetpos[%d]\n",
							idx, dt_ctrl.velocityunit[idx], dt_ctrl.accunit[idx], dt_ctrl.filtertype[idx], dt_ctrl.accel[idx], dt_ctrl.decel[idx],
							dt_ctrl.filtervalue[idx], dt_ctrl.psetwidth[idx], dt_ctrl.trqunit[idx], dt_ctrl.trqLimit[idx], dt_ctrl.velocity[idx],
							dt_ctrl.postype[idx], dt_ctrl.targetpos[idx]);
						status_monitor(pShm);
						memcpy(&pShm->dt_ctrl, &dt_ctrl, sizeof(DIRECT_CTRL_DATA));
						pShm->dt_ctrl.wpos++;
					}
				}
			}
			else {
				printf("------------------------------------------------\n");
				idx = 0;
				printf("setting axis%d velocityunit[%d],accunit[%d],filtertype[%d],accel[%d],decel[%d],\n"
					"               filtervalue[%d],psetwidth[%d],trqunit[%d],trqLimit[%d],velocity[%d],postype[%d],targetpos[%d]\n",
					idx, dt_ctrl.velocityunit[idx], dt_ctrl.accunit[idx], dt_ctrl.filtertype[idx], dt_ctrl.accel[idx], dt_ctrl.decel[idx],
					dt_ctrl.filtervalue[idx], dt_ctrl.psetwidth[idx], dt_ctrl.trqunit[idx], dt_ctrl.trqLimit[idx], dt_ctrl.velocity[idx],
					dt_ctrl.postype[idx], dt_ctrl.targetpos[idx]);
				idx = 1;
				printf("------------------------------------------------\n");
				printf("setting axis%d velocityunit[%d],accunit[%d],filtertype[%d],accel[%d],decel[%d],\n"
					"               filtervalue[%d],psetwidth[%d],trqunit[%d],trqLimit[%d],velocity[%d],postype[%d],targetpos[%d]\n",
					idx, dt_ctrl.velocityunit[idx], dt_ctrl.accunit[idx], dt_ctrl.filtertype[idx], dt_ctrl.accel[idx], dt_ctrl.decel[idx],
					dt_ctrl.filtervalue[idx], dt_ctrl.psetwidth[idx], dt_ctrl.trqunit[idx], dt_ctrl.trqLimit[idx], dt_ctrl.velocity[idx],
					dt_ctrl.postype[idx], dt_ctrl.targetpos[idx]);
				status_monitor(pShm);

			}
		}

		if (k >= 0x20) {
			gKeyCode = k;
		}
		//gKeyCode = getchar();
		
		if (gKeyCode == 'q')break;

	}

	//printf("PollKey exit\n");
//	TerminateRtProcess(NULL, TRUE, 0);
	// �{�X���b�h�̏I����ʒm
	gInit.htPollKey	= NULL_RTHANDLE;

}
