/*****************************************************************************
* Poll1.c - �|�[�����O�̂��߂̃��W���[�� Poll1
\*****************************************************************************/
#include <stdio.h>
#include <rt.h>
#include "ymcSMTAPI.h"
#include <stdlib.h>
#include "MotorCtrl.h"
#include "LogMsgFunc.h"
#include "ShmData.h"
#include "INtimeAppBase.h"

UCHAR				Fin = FALSE;

void CtrlMonitor(void* param);
/*****************************************************************************
* FUNCTION:		Poll1
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll1
\*****************************************************************************/
void				PollCtrl(
	void*				param)
{
	ULONG ret;
	AXIS_INFO AxisInfo;
	int sw=0,res;
	int state = CTRL_WAIT_STAT,next_state= CTRL_WAIT_STAT;
	MOTION_DATA	MotionData[AXIS_NUM];
	MOVE_DATA	MoveData[AXIS_NUM];
	UCHAR kcode = 0;
	LONG comtorque1 = 10000;
	LONG comtorque2 = 1000;
	LONG velocity1 = 100000;
	LONG velocity2 = 10000;
	//LOCATION        loc;
	RTHANDLE		hRProcess = NULL_RTHANDLE;
	RTHANDLE		hProcess = NULL_RTHANDLE;
	//RTHANDLE        hShmProc;
	DIRECT_CTRL_DATA dt_ctrl;
	SHM_DATA* pShm;



#ifdef _DEBUG
	fprintf(stderr, "PollCtrl started\n");
#endif

	sprintf(err_msg.name, "CTRL");
	sprintf(evt_msg.name, "CTRL");

	LogMsgInit();

	pShm = ShmDataInit();
	
	if (pShm==NULL) {
		printf("Mapped buffer not writable\n");
		return;
	}
	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollCtrl	= GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollCtrl, "TPollCtrl");

	memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));

	SendEvtMsg(MSG_EVT_CODE, APP_VER_STR);
	SendEvtMsg(MSG_EVT_CODE, "Motor ctrl start");

	CtrlInit(0);
	CtrlReset(&AxisInfo);

	CtrlServoAlarmClear(&AxisInfo);
	CtrlServo(&AxisInfo,SERVO_ON);
	CtrlDaInit(&AxisInfo, &dt_ctrl);
	
	if (BAD_RTHANDLE == CreateRtThread(170, (LPPROC)CtrlMonitor, 4096, 0))
		Fail("Cannot create poll thread CtrlMonitor");
	if (BAD_RTHANDLE == CreateRtThread(170, (LPPROC)PollKey, 4096, 0))
		Fail("Cannot create poll thread PollKey");
	//printf("Motor ctrl start");

	while (!gInit.bShutdown)
	{
		//RtSleep(1000);
		//knRtSleep(UsecsToKticks(1000));
#if 1
		ret = ymcWaitCycleTime(&AxisInfo);
		if (ret != MP_SUCCESS)
		{
			//printf(" ymcWaitCycleTime fail. ret = 0x%.8x\n ", ret);
			SendErrMsg(ret, "ymcWaitCycleTime fail");
		}
#endif

#ifdef _DEBUG
		//fprintf(stderr, "PollCtrl waking up\n");
#endif
		{
			kcode = gKeyCode;
			if (kcode != 0) {

				//printf("key,%02x\n", kcode);
				if (kcode == 'p') {
					memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));
					next_state = CTRL_MOVE_SETTING_STAT;
					SendEvtMsg(REQ_EVT_CODE, "position setting");
				}
				else if (kcode == 'q') {
					next_state = CTRL_EXIT_STAT;
					SendEvtMsg(REQ_EVT_CODE, "exit req");
				}
				else if (kcode == 't') {
					memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));
					next_state = CTRL_TRQ_START_STAT;
					SendEvtMsg(REQ_EVT_CODE, "trq setting");
				}
				else if (kcode == 'v') {
					memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));
					next_state = CTRL_VELO_START_STAT;
					SendEvtMsg(REQ_EVT_CODE, "velocity setting");
				}
				else if (kcode == 's') {
					next_state = CTRL_STOP_START_STAT;
					SendEvtMsg(REQ_EVT_CODE, "stop");
				}
				else if (kcode == 'd') {
					memcpy(&dt_ctrl, &pShm->dt_ctrl, sizeof(DIRECT_CTRL_DATA));
					CtrlDA(&AxisInfo, dt_ctrl.da_out[0], dt_ctrl.da_out[1], dt_ctrl.d10v);
				}
				gKeyCode = 0;
			}

		}

		// TODO:  1000 �~���b���ƂɌJ��Ԃ�������z�u���܂�
		switch (state)
		{
		case CTRL_WAIT_STAT:
			break;
		case CTRL_MOVE_SETTING_STAT:
			res = CtrlPositionSetting(&AxisInfo, MotionData, MoveData, 0,
				dt_ctrl.velocityunit[0], dt_ctrl.accunit[0], dt_ctrl.filtertype[0],
				dt_ctrl.accel[0], dt_ctrl.decel[0], dt_ctrl.filtervalue[0], dt_ctrl.psetwidth[0],
				dt_ctrl.trqunit[0], dt_ctrl.trqLimit[0], dt_ctrl.velocity[0], dt_ctrl.postype[0], dt_ctrl.targetpos[0]);
			res = CtrlPositionSetting(&AxisInfo, MotionData, MoveData, 1,
				dt_ctrl.velocityunit[1], dt_ctrl.accunit[1], dt_ctrl.filtertype[1],
				dt_ctrl.accel[1], dt_ctrl.decel[1], dt_ctrl.filtervalue[1], dt_ctrl.psetwidth[1],
				dt_ctrl.trqunit[1], dt_ctrl.trqLimit[1], dt_ctrl.velocity[1], dt_ctrl.postype[1], dt_ctrl.targetpos[1]);
			next_state = CTRL_MOVE_START_STAT;
			break;
		case CTRL_MOVE_START_STAT:
			res = CtrlPosition(&AxisInfo, dt_ctrl.tg_axis, MotionData,MoveData);
			next_state = CTRL_MOVE_STAT;

			break;
		case CTRL_MOVE_STAT:
			res=CtrlPositionCompCheck(&AxisInfo, dt_ctrl.tg_axis);
			if (res == 1) {
				next_state = CTRL_WAIT_STAT;
			}
			break;
		case CTRL_TRQ_START_STAT:
			CtrlTorque(&AxisInfo,dt_ctrl.tg_axis, dt_ctrl.trqunit[0],dt_ctrl.comtorque[0],dt_ctrl.velocityLimit[0],
				dt_ctrl.trqunit[1],dt_ctrl.comtorque[1],dt_ctrl.velocityLimit[1]);
			next_state = CTRL_TRQ_STAT;
			break;
		case CTRL_TRQ_STAT:
			res = CtrlTrqCompCheck(&AxisInfo, dt_ctrl.tg_axis);
			if (res == 1) {
				next_state = CTRL_WAIT_STAT;
			}
			break;
		case CTRL_VELO_START_STAT:
			CtrlVelocity(&AxisInfo, dt_ctrl.tg_axis,
				dt_ctrl.velocityunit[0],dt_ctrl.velocity[0],dt_ctrl.trqunit[0],dt_ctrl.trqff[0],dt_ctrl.trqLimit[0] ,
				dt_ctrl.velocityunit[1],dt_ctrl.velocity[1],dt_ctrl.trqunit[1],dt_ctrl.trqff[1],dt_ctrl.trqLimit[1]);
			sw++;
			if (sw > 1)sw = 0;
			next_state = CTRL_VELO_STAT;
			break;
		case CTRL_VELO_STAT:
			res = CtrlVelocityCompCheck(&AxisInfo, dt_ctrl.tg_axis);
			if (res == 1) {
				next_state = CTRL_WAIT_STAT;
			}
			break;
		case CTRL_STOP_START_STAT:
			CtrlStop(&AxisInfo,STOP_SLOW);
			CtrlServoAlarmClear(&AxisInfo);
			next_state = CTRL_STOP_STAT;
			break;
		case CTRL_STOP_STAT:
			res = CtrlStopCompCheck(&AxisInfo);
			if (res == 1) {
				next_state = CTRL_WAIT_STAT;
			}
			break;
		case CTRL_EXIT_STAT:
			break;
		default:
			break;
		}
		if (state != next_state) {
			//printf("state:%d -> next_state:%d\n", state, next_state);
			state = next_state;
		}
		if (state == CTRL_EXIT_STAT) break;
	}
	CtrlStop(&AxisInfo, STOP_AND_SERVO_OFF);
	CtrlExit();

	printf("PollCtrl exit\n");
	TerminateRtProcess((RTHANDLE)NULL, TRUE, 0);
	// �{�X���b�h�̏I����ʒm
	gInit.htPollCtrl	= NULL_RTHANDLE;

}


/*****************************************************************************
* FUNCTION:		CtrlMonitor
* DESCRIPTION:
*   �|�[�����O�X���b�h CtrlMonitor
\*****************************************************************************/
void				CtrlMonitor(
	void* param)
{
#ifdef _DEBUG
	fprintf(stderr, "Ctrl Monitor started\n");
#endif
	LONG pos[AXIS_NUM] = { 0,0 };
	LONG fspd[AXIS_NUM] = { 0,0 };
	LONG trq[AXIS_NUM] = { 0,0 };
	double da[AXIS_NUM] = { 0.0,0.0 };
	int send_flg = FALSE;
	ULONG seq = 0;
	LOCATION        loc;
	RTHANDLE		hRProcess = NULL_RTHANDLE;
	RTHANDLE		hProcess = NULL_RTHANDLE;
	RTHANDLE        hShmProc;
	SHM_DATA* pShm;
	//PMON_PARAM axis1;
	//PMON_PARAM axis2;

	loc = GetRtNodeLocationByName("NodeLog");
	if (loc == BAD_LOCATION) {
		SendErrMsg(0, "GetRtNodeLocationByName fail");
	}
	if (GetRtNodeStatus(loc) != E_OK) {
		SendErrMsg(0, "GetRtNodeStatus fail");
	}
	hRProcess = GetRemoteRootRtProcess(loc);
	if (BAD_RTHANDLE == hRProcess)
	{
		Fail("Cannot find data mailbox process");
		SendErrMsg(0, "Cannot find data mailbox process");
		return;
	}

	hProcess = LookupRtHandle(hRProcess, "INtimeAppLog", WAIT_FOREVER);
	if (BAD_RTHANDLE == hProcess)
	{
		Fail("Cannot find data mailbox process");
		SendErrMsg(0, "Cannot find data mailbox process");
		return;
	}

	hShmProc = LookupRtHandle(hProcess, "ShmLogServer", 0);
	if (hShmProc == BAD_RTHANDLE) {
		SendErrMsg(0, "Cannot find shm data");
		return;
	}
	pShm = MapRtSharedMemory(hShmProc);

	if (!ValidateRtBuffer(pShm, sizeof(SHM_DATA), BUFFER_WRITABLE)) {
		printf("Mapped buffer not writable\n");
		return;
	}
	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htCtrlMonitor = GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htCtrlMonitor, "TCtrlMonitor");

	while (!gInit.bShutdown)
	{
		//RtSleep(1000);
		knRtSleep(UsecsToKticks(10000));
#ifdef _DEBUG
		//		fprintf(stderr, "PollKey waking up\n");
#endif
		//memcpy(&axis1, pMonitorParam1, sizeof(MON_PARAM));
		//memcpy(&axis2, pMonitorParam2, sizeof(MON_PARAM));
		if(pMonitorParam1!=NULL){
			memcpy(&pShm->axis1_param, pMonitorParam1, sizeof(MON_PARAM));
		}
		if(pMonitorParam2!=NULL){
			memcpy(&pShm->axis2_param, pMonitorParam2, sizeof(MON_PARAM));
		}
		// TODO:  1000 �~���b���ƂɌJ��Ԃ�������z�u���܂�
		if(pMonitorParam1!=NULL){
			if (pos[0] != pMonitorParam1->SV.cpos) {
				pos[0] = pMonitorParam1->SV.cpos;
				fspd[0] = pMonitorParam1->SV.fspd;
				trq[0] = pMonitorParam1->SV.trq;
				if(pMonitorParam2!=NULL){
					pos[1] = pMonitorParam2->SV.cpos;
					fspd[1] = pMonitorParam2->SV.fspd;
					trq[1] = pMonitorParam2->SV.trq;
				}
				da[0] = pShm->dt_ctrl.da_out[0];
				da[1] = pShm->dt_ctrl.da_out[1];
				send_flg = TRUE;
			}
		}
		if(pMonitorParam2!=NULL){
			if (pos[1] != pMonitorParam2->SV.cpos) {
				if(pMonitorParam1!=NULL){
					pos[0] = pMonitorParam1->SV.cpos;
					fspd[0] = pMonitorParam1->SV.fspd;
					trq[0] = pMonitorParam1->SV.trq;
				}
				pos[1] = pMonitorParam2->SV.cpos;
				fspd[1] = pMonitorParam2->SV.fspd;
				trq[1] = pMonitorParam2->SV.trq;
				da[0] = pShm->dt_ctrl.da_out[0];
				da[1] = pShm->dt_ctrl.da_out[1];
				send_flg = TRUE;
			}
		}
		if (da[0] != pShm->dt_ctrl.da_out[0]) {
			if(pMonitorParam1!=NULL){
				pos[0] = pMonitorParam1->SV.cpos;
				fspd[0] = pMonitorParam1->SV.fspd;
				trq[0] = pMonitorParam1->SV.trq;
			}
			if(pMonitorParam2!=NULL){
				pos[1] = pMonitorParam2->SV.cpos;
				fspd[1] = pMonitorParam2->SV.fspd;
				trq[1] = pMonitorParam2->SV.trq;
			}
			da[0] = pShm->dt_ctrl.da_out[0];
			da[1] = pShm->dt_ctrl.da_out[1];
			send_flg = TRUE;
		}
		if (da[1] != pShm->dt_ctrl.da_out[1]) {
			if(pMonitorParam1!=NULL){
				pos[0] = pMonitorParam1->SV.cpos;
				fspd[0] = pMonitorParam1->SV.fspd;
				trq[0] = pMonitorParam1->SV.trq;
			}
			if(pMonitorParam2!=NULL){
				pos[1] = pMonitorParam2->SV.cpos;
				fspd[1] = pMonitorParam2->SV.fspd;
				trq[1] = pMonitorParam2->SV.trq;
			}
			da[0] = pShm->dt_ctrl.da_out[0];
			da[1] = pShm->dt_ctrl.da_out[1];
			send_flg = TRUE;
		}
		if (send_flg == TRUE) {
			//printf("%d,%d\n", pShm->axis1_param.SV.cpos, pShm->axis2_param.SV.cpos);
			SendMonitorMsg(STAT_EVT_CODE,seq, pos[0], fspd[0], trq[0], pos[1], fspd[1], trq[1],da[0],da[1]);
			seq++;
		}
		else {
			if (pMonitorParam1 != NULL && pMonitorParam2 != NULL) {
				SendMonitorMsg(MONI_EVT_CODE, seq,
					pMonitorParam1->SV.cpos, pMonitorParam1->SV.fspd, pMonitorParam1->SV.trq,
					pMonitorParam2->SV.cpos, pMonitorParam2->SV.fspd, pMonitorParam2->SV.trq,
					da[0], da[1]);
			}
			else if (pMonitorParam1 != NULL) {
				SendMonitorMsg(MONI_EVT_CODE, seq, 
					pMonitorParam1->SV.cpos, pMonitorParam1->SV.fspd, pMonitorParam1->SV.trq,
					pos[1],fspd[1], trq[1],
					da[0], da[1]);
			}
			else if (pMonitorParam2 != NULL) {
				SendMonitorMsg(MONI_EVT_CODE, seq,
					pos[0], fspd[0], trq[0],
					pMonitorParam2->SV.cpos, pMonitorParam2->SV.fspd, pMonitorParam2->SV.trq,
					da[0], da[1]);
			}
			else {
				SendMonitorMsg(MONI_EVT_CODE, seq,
					pos[0], fspd[0], trq[0],
					pos[1], fspd[1], trq[1],
					da[0], da[1]);
			}

			seq++;
		}
		send_flg = FALSE;

		//		if (gKeyCode == 'q')break;

	}

	printf("CtrlMonitor exit\n");
	//	TerminateRtProcess(NULL, TRUE, 0);
		// �{�X���b�h�̏I����ʒm
	gInit.htCtrlMonitor = NULL_RTHANDLE;

}
