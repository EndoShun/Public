/*****************************************************************************
* Poll2.c - �|�[�����O�̂��߂̃��W���[�� Poll2
\*****************************************************************************/

#include <stdio.h>
#include <rt.h>

#include "INtimeAppUDPToImageProc.h"
#include "PollUDPToImgProc.h"
#include "UdpApi.h"
#include "RtSharedMemory.h"
#include "MyRtQueue.h"

void printTurretToImgProcCommand(TurretToImgProcCommand* turretToImgProcCommand) {
	printf("\n");
	printf("----------TurretToImgProcCommand--------------\n");
	printf("checksum: %d\n", turretToImgProcCommand->checksum);
	printf("packetLength: %d\n", turretToImgProcCommand->packetLength);
	printf("dataId: %d\n", turretToImgProcCommand->packetType);
	printf("aiMode: %d\n", turretToImgProcCommand->aiMode);
	printf("targetLock: %d\n", turretToImgProcCommand->targetLock);
	printf("pxTargetPos: (%d,%d)\n", turretToImgProcCommand->pxTargetPos[0], turretToImgProcCommand->pxTargetPos[1]);
	printf("pxTargetSize: (%d,%d)\n", turretToImgProcCommand->pxTargetSize[0], turretToImgProcCommand->pxTargetSize[1]);
	printf("nrad_x10CoarsePos: (%d,%d)\n", turretToImgProcCommand->nrad_x10CoarsePos[0], turretToImgProcCommand->nrad_x10CoarsePos[1]);
	printf("aimPointMode: %d\n", turretToImgProcCommand->aimPointMode);
	printf("pxAimPointOffset: (%d,%d)\n", turretToImgProcCommand->pxAimPointOffset[0], turretToImgProcCommand->pxAimPointOffset[1]);
	printf("camGainModeCommand: %d\n", turretToImgProcCommand->camGainModeCommand);
	printf("camGainCommand: %d\n", turretToImgProcCommand->camGainCommand);
	printf("expandModeCommand: %d\n", turretToImgProcCommand->expandModeCommand);
	printf("camIrisModeCommand: %d\n", turretToImgProcCommand->camIrisModeCommand);
	printf("camIrisCommand: %d\n", turretToImgProcCommand->camIrisCommand);
	printf("camFocusModeStatus: %d\n", turretToImgProcCommand->camFocusModeStatus);
	printf("mCamFocusStatus: %d\n", turretToImgProcCommand->mmX100CamFocusStatus);
	printf("tilStatus: %d\n", turretToImgProcCommand->bfTilStatus);
	printf("tilFocus: %d\n", turretToImgProcCommand->uradTilDivergence);
	printf("swingScanMode: %d\n", turretToImgProcCommand->swingScanMode);
	printf("scanZoneDesignateCommand: %d\n", turretToImgProcCommand->scanZoneDesignateCommand);
	printf("pxDesignatedScanZone: (%d,%d)\n", turretToImgProcCommand->pxDesignatedScanZone[0], turretToImgProcCommand->pxDesignatedScanZone[1]);
	printf("recCommand: %d\n", turretToImgProcCommand->recCommand);
	printf("recDecimationCommand: %d\n", turretToImgProcCommand->recDecimationCommand);
	printf("shootDownOverrideStatus: %d\n", turretToImgProcCommand->shootDownOverrideStatus);
	printf("shutdownRequest: %d\n", turretToImgProcCommand->shutdownRequest);
	printf("auxDisplayInfo: %d\n", turretToImgProcCommand->bfAuxDisplayInfo);
	printf("nrad_x10VehicleHeading: %d\n", turretToImgProcCommand->nrad_x10VehicleHeading);
	printf("armStatus: %d\n", turretToImgProcCommand->armStatus);
	printf("bfHelStatus: %d\n", turretToImgProcCommand->bfHelStatus);
	printf("soiCamId: %d\n", turretToImgProcCommand->soiCamId);
	printf("externalSensorTargetSelectionModeStatus: %d\n", turretToImgProcCommand->externalSensorTargetSelectionModeStatus);
	printf("sHelTimeout: %d\n", turretToImgProcCommand->sHelTimeout);
}

void printImgProcToTurretResponse(ImgProcToTurretResponse* res) {
	printf("-------ImgProcToTurretResponse---------\n");
	printf("checksum :%d\n", res->checksum);
	printf("packetLength: %d\n", res->packetLength);
	printf("dataId: %d\n", res->dataId);
	printf("aiMode: %d\n", res->aiMode);
	printf("aiValid: %d\n", res->aiValid);
	printf("aiId: %d\n", res->aiId);
	printf("trackingIndex: %d\n", res->trackingIndex);
	printf("reserved: %d\n", res->reserved);
	for (int i = 0; i < MAX_TARGETS; i++) {
		printf("aiClasses[%d]: %d\n", i, res->aiClasses[i]);
	}
	for (int i = 0; i < MAX_TARGETS; i++) {
		printf("pxAiPoses[%d]: (%d,%d)\n", i, res->pxAiPoses[i][0], res->pxAiPoses[i][1]);
	}
	for (int i = 0; i < MAX_TARGETS; i++) {
		printf("pxAiSizes[%d]: (%d,%d)\n", i, res->pxAiSizes[i][0], res->pxAiSizes[i][1]);
	}
	for (int i = 0; i < MAX_TARGETS; i++) {
		printf("aiScores[%d]: %d\n", i, res->aiScores[i]);
	}
	for (int i = 0; i < MAX_TARGETS; i++) {
		printf("targetIds[%d]: %d\n", i, res->targetIds[i]);
	}
	printf("matchValid: %d\n", res->matchValid);
	printf("matchId: %d\n", res->matchId);
	printf("matchBaseScore: %d\n", res->matchBaseScore);
	printf("pxMatchPos: (%d,%d)\n", res->pxMatchPos[0], res->pxMatchPos[1]);
	printf("pxMatchSize: (%d,%d)\n", res->pxMatchSize[0], res->pxMatchSize[1]);
	printf("matchScore: %d\n", res->matchScore);
	printf("camGainMode: %d\n", res->camGainMode);
	printf("camGain: %d\n", res->camGain);
	printf("binningStatus: %d\n", res->expandModeStatus);
	printf("recStatus: %d\n", res->recStatus);
	printf("recDecimation: %d\n", res->recDecimationStatus);
	printf("cpuTemp: %d\n", res->cpuTemp);
	printf("gpuTemp: %d\n", res->gpuTemp);
	printf("camStatus: %d\n", res->camErrorStatus);
	printf("MBx100DiskRemaining: %d\n", res->MBx100DiskRemaining);
}

uint8_t calcChecksum(TurretToImgProcCommand* packet) {
	uint8_t checksum = 0xFF;
	uint8_t* packetInUint8 = (uint8_t*)packet;

	for (int i = 1; i < sizeof(TurretToImgProcCommand); i++) {
		checksum ^= packetInUint8[i];
	}
	return checksum;
}

int32_t checkChecksum(ImgProcToTurretResponse* res) {
	uint8_t checksum = 0x00;
	uint8_t* packetInUint8 = (uint8_t*)res;
	for (unsigned int i = 0; i < sizeof(ImgProcToTurretResponse); i++) {
		checksum ^= packetInUint8[i];
	}
	if (checksum == 0xFF) {
		return 0;
	}
	else {
		return -1;
	}
}

void sendAndLog(TY_UDP_SOCK s,RtSharedMemory<TurretToImgProcCommand>& turretToImgProc, MyRtQueue<TurretToImgProcCommand>& t2ImLoggingQueue, MyRtQueue<MessageLog>& errorLoggingQueue, UdpParam* udpParam, int32_t threadId) {
	MySharedMemoryStatus shmStatus = turretToImgProc.copySharedToLocal(100);


	if (shmStatus == MySharedMemoryStatus::SEM_ERROR) {
		errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "Logging queue error at PollUDPSend thread %d\n", threadId);
	}
	else if (shmStatus == MySharedMemoryStatus::TIMEOUT) {
		printf("shared memory write timeout\n");
	}
	turretToImgProc.getBuf()->checksum = calcChecksum(turretToImgProc.getBuf());

	if (udpapi_send(&s, (unsigned char*)turretToImgProc.getBuf(), sizeof(TurretToImgProcCommand)) != 1) {
		printf("udp send fail at UdpToImgProc %d, addr: %s, port: %s\n", threadId, udpParam->ipaddr_str, udpParam->sendPort);
	}

	MyQueueStatus queueStatus = t2ImLoggingQueue.send(turretToImgProc.getBuf());

	if (queueStatus == MyQueueStatus::QUEUE_ERROR) {
		errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "Logging queue error at PollUDPSend thread %d\n", threadId);
	}
	else if (queueStatus == MyQueueStatus::FULL) {
		printf("Logging queue full.\n");
	}
}

/*****************************************************************************
* FUNCTION:		Poll2
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll2
\*****************************************************************************/
void				PollUDPSend(
	void*				param)
{
	TY_UDP_SOCK s;
	TIMEVALUE    tv;
#ifdef _DEBUG
	fprintf(stderr, "PollUDPSend1 started\n");
#endif

	////////////////////////////////////////////////
	// Initialize thread utilities
	////////////////////////////////////////////////
	UDPThreadParam* threadParam = (UDPThreadParam*)param;
	int32_t threadId = threadParam->threadId;

	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollUDPSend[threadId]	= GetRtThreadHandles(THIS_THREAD);

	char threadNameBuf[16];
	snprintf(threadNameBuf, 16, "UDPSend%d", threadId);
	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollUDPSend[threadId], threadNameBuf);


	////////////////////////////////////////////////
	// Setup shared resources
	////////////////////////////////////////////////
	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<TurretToImgProcCommand> turretToImgProc;
	MyRtQueue<TurretToImgProcCommand> t2ImLoggingQueue;
	MyRtQueue<MessageLog> errorLoggingQueue;

	while (!gInit.bShutdown && bootParameters.setup(BOOT_PARAMETER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	while (!gInit.bShutdown && turretToImgProc.setup(TURRET_TO_IMG_PROC_SHM_NAMES[threadId]) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	while (!gInit.bShutdown && t2ImLoggingQueue.setup(TURRET_TO_IMGPROC_LOG_QUEUE_NAME[threadId], NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && errorLoggingQueue.setup(ERROR_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	
	/////////////////////////////////////////////////
	// Wait for boot parameter
	/////////////////////////////////////////////////

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);

		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}

	/////////////////////////////////////////////////
	// Early exit if shutdown signal arrives.
	/////////////////////////////////////////////////
	if (gInit.bShutdown) {
		gInit.htPollUDPSend[threadId] = NULL_RTHANDLE;
		return;
	}

	/////////////////////////////////////////////////
	// Init UDP
	/////////////////////////////////////////////////
	UdpParam* udpParam = &bootParameters.getBuf()->systemParameters.imgProcUdpParam[threadId];

	udpapi_send_init(&s, udpParam->ipaddr_str, udpParam->sendPort);

	printf("ImgProc[%d] send Adress: %s, Port: %s\n",threadId,udpParam->ipaddr_str,udpParam->sendPort);


	int32_t decimationCount = 0;

	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(4000));

		sendAndLog(s,turretToImgProc,t2ImLoggingQueue,errorLoggingQueue,udpParam,threadId);

		decimationCount++;
	}

	sendAndLog(s,turretToImgProc, t2ImLoggingQueue, errorLoggingQueue, udpParam, threadId);	//�V���b�g�_�E���v�����M�̂��߁A�V���b�g�_�E���O�ɕK�����M

	printf("UdpSend to ImgProc[%d] exit\n",threadId);
	// �{�X���b�h�̏I����ʒm
	gInit.htPollUDPSend[threadId]	= NULL_RTHANDLE;
}

/*****************************************************************************
* FUNCTION:		Poll1
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll1
\*****************************************************************************/
void				PollUDPRecv(
	void* param)
{
	int ret;
	TY_UDP_SOCK s;
#ifdef _DEBUG
	fprintf(stderr, "PollUDPRecv1 started\n");
#endif

	////////////////////////////////////////////////
	// Initialize thread utilities
	////////////////////////////////////////////////
	UDPThreadParam* threadParam = (UDPThreadParam*)param;
	int32_t threadId = threadParam->threadId;
	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollUDPRecv[threadId] = GetRtThreadHandles(THIS_THREAD);

	char threadNameBuf[16];
	snprintf(threadNameBuf, 16, "TPollUDPRecv%d", threadId);
	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollUDPRecv[threadId], threadNameBuf);


	////////////////////////////////////////////////
	// Setup shared resources
	////////////////////////////////////////////////
	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<ImgProcToTurretResponse> imgProcToTurretResponse;
	MyRtQueue<ImgProcToTurretResponse> im2tLoggingQueue;
	MyRtQueue<MessageLog> errorLoggingQueue;

	while (!gInit.bShutdown && bootParameters.setup(BOOT_PARAMETER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && imgProcToTurretResponse.setup(IMG_PROC_TO_TURRET_SHM_NAMES[threadId]) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && im2tLoggingQueue.setup(IMGPROC_TO_TURRET_LOG_QUEUE_NAME[threadId],NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && errorLoggingQueue.setup(ERROR_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	/////////////////////////////////////////////////
	// Wait for boot parameter
	/////////////////////////////////////////////////

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);

		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}


	/////////////////////////////////////////////////
	// Early exit if shutdown signal arrives.
	/////////////////////////////////////////////////
	if (gInit.bShutdown) {
		gInit.htPollUDPRecv[threadId] = NULL_RTHANDLE;
		return;
	}


	/////////////////////////////////////////////////
	// Init UDP
	/////////////////////////////////////////////////
	UdpParam* udpParam = &bootParameters.getBuf()->systemParameters.imgProcUdpParam[threadId];
	udpapi_recv_init(&s, udpParam->recvPort);

	printf("ImgProc[%d] recv Port: %s\n", threadId, udpParam->recvPort);

	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(1000));

		ret = udpapi_recv(&s, (unsigned char*)imgProcToTurretResponse.getBuf(), sizeof(ImgProcToTurretResponse));
		if ((ret == sizeof(ImgProcToTurretResponse)) && (checkChecksum(imgProcToTurretResponse.getBuf()) == 0)) {
			MySharedMemoryStatus shmStatus = imgProcToTurretResponse.copyLocalToShared(100);

			if (shmStatus == MySharedMemoryStatus::SEM_ERROR) {
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR,"Shared memory error at PollUDPRecv thread %d\n",threadId);
			}
			else if (shmStatus == MySharedMemoryStatus::TIMEOUT) {
				printf("shared memory write timeout\n");
			}


			MyQueueStatus queueStatus = im2tLoggingQueue.send(imgProcToTurretResponse.getBuf());
			if (queueStatus == MyQueueStatus::QUEUE_ERROR) {
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "Logging queue error at PollUDPRecv thread %d\n", threadId);
			}

		}
		else {
			if (ret == sizeof(ImgProcToTurretResponse) && checkChecksum(imgProcToTurretResponse.getBuf()) != 0) {
				printf("checksum error at udpToImgProc[%d], RecivedChecksum:0x%02x, receivedLen:%d [bytes]\n", threadId, imgProcToTurretResponse.getBuf()->checksum, ret);
			}
			else if (ret != 0) {
				printf("data length error expected:%d received:%d\n", sizeof(ImgProcToTurretResponse), ret);
			}
		}

	}

	printf("UdpRecv from ImgProc[%d] exit\n", threadId);
	// �{�X���b�h�̏I����ʒm
	gInit.htPollUDPRecv[threadId] = NULL_RTHANDLE;
}
