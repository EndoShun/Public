#pragma once

#include "rt.h"
#include "stdint.h"
#include "CatalogNames.h"

enum class MySharedMemoryStatus {
	OK = 0,
	FIND_LOCATION_FAIL = -1,
	FIND_ROOTPROCESS_FAIL = -2,
	FIND_SHAREDMEMORY_FAIL = -3,
	MAP_SHAREDMEMORY_FAIL = -4,
	FIND_SEM_FAIL = -5,
	ALLOCATE_LOCALMEMORY_FAIL = -6,
	TIMEOUT = 7,
	SEM_ERROR = 8,
};

template<class T>
class RtSharedMemory{
private:
	static const int64_t SEC_GMT9_OFFSET = 9 * 60 * 60;

	struct SharedObject {
		int8_t updated;
		SYSTEMTIME updateTime;
		T data;
	};

	RTHANDLE memHandle;
	RTHANDLE sem;


	SharedObject* sharedBuffer;
	SharedObject* localBuffer;

public:

	RtSharedMemory();
	~RtSharedMemory();

	

	T* getBuf();
	SYSTEMTIME getUpdateTime();
	int8_t isUpdated();
	int32_t isOk();
	MySharedMemoryStatus setup(const SharedMemoryCatalogNames names);
	MySharedMemoryStatus copySharedToLocal(int32_t msWaitTime);
	MySharedMemoryStatus copyLocalToShared(int32_t msWaitTime);
	
};

