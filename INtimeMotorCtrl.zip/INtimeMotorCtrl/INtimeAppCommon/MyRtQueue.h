#pragma once

#include "rt.h"
#include "stdint.h"
#include "CatalogNames.h"
#include "IoStructs.h"

enum class MyQueueStatus {
	OK = 0,
	FULL = 1,
	TIMEOUT = 2,
	QUEUE_ERROR = -1,
	FIND_LOCATION_FAIL = -2,
	FIND_ROOTPROCESS_FAIL = -3,
	FIND_QUEUE_FAIL = -4,
};

template<typename T>
class MyRtQueue {
private:
	static const uint64_t SEC_GMT9_OFFSET = 9 * 60 * 60;

	#pragma pack(1)
	typedef struct {
		SYSTEMTIME sendTime;
		T data;
	}SharedObject;
	#pragma pack()


	RTHANDLE queue;
	SYSTEMTIME sendTime;
public:
	MyRtQueue();
	~MyRtQueue();
	MyQueueStatus setup(const char* queueHandleName, int32_t msWaitTime);
	MyQueueStatus send(const T* msg);
	MyQueueStatus recv(T* buf, int32_t msWaitTime);
	SYSTEMTIME getSendTime();
	int32_t isOk();

	template <typename ... Args>
	void log(const char* format, Args const& ... args);

	template <typename ... Args>
	void shutdownRequest(ShutdownRequest request, const char* format, Args const& ... args);
};

template<typename T>
template <typename ... Args>
void MyRtQueue<T>::log(const char* format, Args const& ... args) {
}

template <>
template <typename ... Args>
void MyRtQueue<MessageLog>::log(const char* format, Args const& ... args) {
	MessageLog message;
	snprintf(message.message, MESSAGE_LOG_LENGTH, format, args ...);
	message.shutdownRequset = ShutdownRequest::NORMAL_OPERATION;
	send(&message);
}

template <>
template <typename ... Args>
void MyRtQueue<MessageLog>::shutdownRequest(ShutdownRequest request, const char* format, Args const& ... args) {
	MessageLog message;
	snprintf(message.message, MESSAGE_LOG_LENGTH, format, args ...);
	message.shutdownRequset = request;
	send(&message);
}