#pragma once

#include "IoStructs.h"




#ifdef __cplusplus
extern "C" {
#endif
	static const char* MOTER_CTRL_NODE_NAME = "NodeCtrl";
	static const char* UDP_IMGPROC_NODE_NAME = "NodeUdpToImageProc";
	//static const char* UDP_MASTER_NODE_NAME = "NodeUdpToMaster";	//���@��
	static const char* UDP_MASTER_NODE_NAME = "NodeUdpToImageProc";	//���؊�
	static const char* RANGEFINDER_NODE_NAME = "NodeMisc";
	static const char* WIDE_CAM_LENS_CONTROL_NODE_NAME = "NodeMisc";

	static const char* INTIME_APPLOG_PROCESS_NAME = "INtimeAppLog";
	static const char* UDP_IMGPROC_PROCESS_NAME = "UDPImgProc";
	static const char* UDP_MASTER_PROCESS_NAME = "UDPMaster";
	static const char* MOTER_CTRL_PROCESS_NAME = "MotorCtrl";
	static const char* RANGEFINDER_PROCESS_NAME = "RangeFinder";
	static const char* WIDE_CAM_LENS_CONTROL_PROCESS_NAME = "WideLensCtrl";

	static const char* MOTER_CTRL_RTA_NAME = "INtimeMotorCtrl.rta";
	static const char* UDP_IMGPROC_RTA_NAME = "INtimeAppUDPToImageProc.rta";
	static const char* UDP_MASTER_RTA_NAME = "INtimeAppUDPToMaster.rta";
	static const char* RANGEFINDER_RTA_NAME = "RangefinderControl.rta";
	static const char* WIDE_CAM_LENS_CONTROL_RTA_NAME = "WideLensControl.rta";

#ifdef __cplusplus
}
//Catalog Names of Node for shared resources
inline static const char* SHARED_RESOURCE_NODE_NAME = "NodeCtrl";

struct SharedMemoryCatalogNames {
	char* SemName;
	char* MemName;
};

static constexpr struct SharedMemoryCatalogNames MASTER_TO_TURRET_SHM_NAMES = {
	(char*)"M2TSem",
	(char*)"M2TMem",
};
static constexpr struct SharedMemoryCatalogNames TURRET_TO_MASTER_SHM_NAMES = {
	(char*)"T2MSem",
	(char*)"T2MMem",
};
static constexpr struct SharedMemoryCatalogNames TURRET_TO_IMG_PROC_SHM_NAMES[2] = {
	{
		(char*)"T2IMSem0",
		(char*)"T2IMMem0",
	},
	{
		(char*)"T2IMSem1",
		(char*)"T2IMMem1",
	}
};
static constexpr struct SharedMemoryCatalogNames IMG_PROC_TO_TURRET_SHM_NAMES[2] = {
	{
		(char*)"IM2TSem0",
		(char*)"IM2TMem0",
	},
	{
		(char*)"IM2TSem1",
		(char*)"IM2TMem1",
	}
};
static constexpr struct SharedMemoryCatalogNames BOOT_PARAMETER_SHM_NAMES = {
	(char*)"BtPrmSem",
	(char*)"BtPrmMem",
};
static constexpr struct SharedMemoryCatalogNames RANGEFINDER_COMMAND_SHM_NAMES = {
	(char*)"RngFdrCmdSem",
	(char*)"RngFdrCmdMem",
};
static constexpr struct SharedMemoryCatalogNames RANGEFINDER_STATUS_SHM_NAMES = {
	(char*)"RngFdrStsSem",
	(char*)"RngFdrStsMem",
};
static constexpr struct SharedMemoryCatalogNames WIDE_LENS_COMMAND_SHM_NAMES = {
	(char*)"WdLensCmdSem",
	(char*)"WdLensCmdMem",
};
static constexpr struct SharedMemoryCatalogNames WIDE_LENS_STATUS_SHM_NAMES = {
	(char*)"WdLensStsSem",
	(char*)"WdLensStsMem",
};
static constexpr struct SharedMemoryCatalogNames LOG_STATUS_SHM_NAMES = {
	(char*)"LogStatusSem",
	(char*)"LogStatusMem",
};

inline static const char* MASTER_TO_TURRET_LOG_QUEUE_NAME = "M2TLogQueue";
inline static const char* TURRET_TO_MASTER_LOG_QUEUE_NAME = "T2MLogQueue";
inline static const char* IMGPROC_TO_TURRET_LOG_QUEUE_NAME[2] = { "IM2TLogQue0" , "IM2TLogQue1" };
inline static const char* TURRET_TO_IMGPROC_LOG_QUEUE_NAME[2] = { "T2IMLogQue0" , "T2IMLogQue1" };
inline static const char* CONTROL_LOG_QUEUE_NAME = "CTRLLogQueue";
inline static const char* EVENT_LOG_QUEUE_NAME = "EVTLogQueue";
inline static const char* ERROR_LOG_QUEUE_NAME = "ERRLogQueue";
inline static const char* SHUTDOWN_REQUEST_QUEUE_NAME = "ShutdownQue";
#endif