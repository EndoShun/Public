#pragma once

#include "stdint.h"
#include "stdlib.h"

#define MAX_TARGETS			16
#define NUM_JOINTS			5
#define NUM_CAMS			2
#define AXIS_NUM			3

#define NUM_FRIENDLIES		16
#define NUM_RESTRICT_AREA	24

#define MESSAGE_LOG_LENGTH 128

#define NUM_TELE_LENS_AXIS 1
//TODO: ���ۂ̎���(=4)�ɏC��

#ifdef __cplusplus
extern "C" {
#endif	/*__cplusplus*/




#pragma pack(1)

	/////////////////////////////////////////////
	// <-> ���������
	/////////////////////////////////////////////
	typedef struct {
		unsigned char year;
		unsigned char month;
		unsigned char day;
		unsigned char hour;
		unsigned char min;
		unsigned char sec;
		unsigned short msec;
	}Timestamp;


	typedef struct {
		uint8_t checksum;
		uint16_t packetLength;
		uint8_t packetType;
		uint8_t controlMode;
		int32_t manualCommand[2];
		uint8_t externalSensorType;
		uint8_t externalSensorTargetId;
		int64_t unixTimeExternalSensorTimestamp;
		int32_t mmExternalSensorPos[3];
		int32_t mmpsExternalSensorSpeed[3];
		int8_t targetLock[NUM_CAMS];
		uint16_t pxTargetPos[NUM_CAMS][2];
		uint16_t pxTargetSize[NUM_CAMS][2];
		uint8_t aiModes[NUM_CAMS];
		uint8_t aimPointMode;
		int16_t pxAimPointOffset[2];
		uint8_t fineMirrorMode;
		int32_t fineMirrorCommand[2];
		uint8_t rangeFinderCommand;
		int8_t camGainModeCommand[NUM_CAMS];
		int16_t dB1_10CamGainCommand[NUM_CAMS];
		int8_t camZoomModeCommand[NUM_CAMS];
		int16_t x1_1000CamZoomCommand[NUM_CAMS];
		uint8_t expandModeCommand[NUM_CAMS];
		int8_t camIrisModeCommand[NUM_CAMS];
		int16_t camIrisCommand[NUM_CAMS];
		int8_t camFocusModeCommand[NUM_CAMS];
		int16_t mmX100CamFocusCommand[NUM_CAMS];
		uint8_t tilStatus;
		uint16_t uradTilDivergence;
		uint8_t swingScanCommand;
		uint8_t scanZoneDesignateCommand[NUM_CAMS];
		uint16_t pxDesignatedScanZone[NUM_CAMS][2];
		uint8_t recCommand[NUM_CAMS];
		uint16_t recDecimationCommand[NUM_CAMS];
		uint8_t shootDownOverrideCommand;
		uint8_t shutdownRequest;
		uint8_t auxDisplayInfo;
		uint16_t bfFriendlyValid;
		int32_t nradx10FriendlyPos[NUM_FRIENDLIES][2];
		uint16_t mFriendlyDistance[NUM_FRIENDLIES];
		uint32_t bfLaserRestrictedAreaValid;
		int32_t nradx10LaserRestrictedAreaPan[NUM_RESTRICT_AREA][2];
		int32_t nradx10LaserRestrictedAreaTilt[NUM_RESTRICT_AREA][2];
		int16_t mLaserRestrictedAreaDistance[NUM_RESTRICT_AREA];
		int32_t nrad_x10VehicleAttitude[3];
		uint8_t armStatus;
		uint8_t bfHelStatus;
		int16_t mmX100HelFocus;
		uint8_t soiCamId;
		uint8_t externalSensorTargetSelectionModeStatus;
		int8_t sHelTimeout;
		uint8_t logFileId[1 + NUM_CAMS];
		uint8_t servoOn;
	}MasterToTurretCommand;

	typedef struct {
		uint8_t checksum;
		uint16_t packetSize;
		uint8_t packetType;
		int32_t nradx10CoarsePos[AXIS_NUM];
		int32_t nradx10ExternalSensorTargetPos[2];
		int32_t finePos[2];
		int32_t averageFinePos[2];
		int32_t nradx10psCoarseSpeed[AXIS_NUM];
		int8_t aiModes[NUM_CAMS];
		int8_t targetIds[NUM_CAMS][MAX_TARGETS];
		int8_t trackedTargetIndex[NUM_CAMS];
		uint8_t aiClasses[NUM_CAMS][MAX_TARGETS];
		int16_t pxAiPoses[NUM_CAMS][MAX_TARGETS][2];
		int16_t pxAiSizes[NUM_CAMS][MAX_TARGETS][2];
		int16_t pxJointPoses[NUM_CAMS][NUM_JOINTS][2];
		uint8_t selectedJoint;
		uint8_t matchValid[NUM_CAMS];
		int16_t pxMatchPoses[NUM_CAMS][2];
		int16_t pxMatchSizes[NUM_CAMS][2];
		int8_t rangeFinderModeStatus;
		uint16_t mRangeFinderDistance;
		int8_t camGainModeStatus[NUM_CAMS];
		int16_t dB1_10CamGainStatus[NUM_CAMS];
		int8_t camZoomModeStatus[NUM_CAMS];
		int16_t x1_1000CamZoomStatus[NUM_CAMS];
		uint16_t uradX100CamFov[NUM_CAMS];
		uint8_t expandModeStatus[NUM_CAMS];
		int8_t camIrisModeStatus[NUM_CAMS];
		int16_t camIrisStatus[NUM_CAMS];
		int8_t camFocusModeStatus[NUM_CAMS];
		int16_t mmX100CamFocusStatus[NUM_CAMS];
		int16_t uradTilDivergence;
		int16_t mmX100HelFocus;
		uint8_t trainingModeStatus[1 + NUM_CAMS];
		uint8_t swingScanStatus;
		int8_t recStatus[NUM_CAMS];
		uint16_t recDecimationStatus[NUM_CAMS];
		uint8_t coarseLimitActive;
		uint8_t laserRestrictedAreaStatus;
		uint16_t bfServoErrorStatus;
		uint8_t bfTilServoErrorStatus;
		uint8_t bfFineMirrorErrorStatus;
		uint8_t bfRs485ConverterErrorStatus;
		uint8_t bfTeleLensErrorStatus;
		uint8_t bfImageProcCommunicationStatus;
		int8_t turretCpuTemp;
		int8_t imageProcCpuTemp[NUM_CAMS];
		int8_t imageProcGpuTemp[NUM_CAMS];
		uint16_t MBx100DiskRemaining[1 + NUM_CAMS];
		uint8_t camErrorStatus;
		uint8_t parameterFileStatus[1 + NUM_CAMS];
		uint8_t logFileIdStatus[1 + NUM_CAMS];
		uint16_t mX10HelSafeDistance;
		uint16_t mX10TilSafeDistance;
		uint8_t servoOnStatus;
	}TurretToMasterResponse;

	/////////////////////////////////////////////
	// <-> �摜����PC
	/////////////////////////////////////////////

	typedef struct {
		uint8_t					checksum;
		uint16_t				packetLength;
		uint8_t					dataId;
		uint8_t					aiMode;
		uint8_t 	            aiValid;
		uint32_t                aiId;
		int8_t                  trackingIndex;
		uint8_t					reserved;
		uint8_t           	    aiClasses[MAX_TARGETS];
		int16_t           		pxAiPoses[MAX_TARGETS][2];
		int16_t           		pxAiSizes[MAX_TARGETS][2];
		uint16_t          		aiScores[MAX_TARGETS];
		int8_t					targetIds[MAX_TARGETS];
		int16_t           		pxJointPoses[NUM_JOINTS][2];
		uint8_t           		matchValid;
		uint32_t          		matchId;
		uint16_t          		matchBaseScore;
		uint16_t          		pxMatchPos[2];
		uint16_t          		pxMatchSize[2];
		uint16_t          		matchScore;
		int8_t					camGainMode;
		int16_t					camGain;
		uint8_t					expandModeStatus;
		int8_t					recStatus;
		uint16_t				recDecimationStatus;
		int8_t	    			cpuTemp;
		int8_t	    			gpuTemp;
		uint8_t           		camErrorStatus;
		uint16_t				MBx100DiskRemaining;
		uint8_t					trainingModeStatus;
		uint8_t				logFileIdStatus;
		uint8_t					parameterFileStatus;
	}ImgProcToTurretResponse;

	typedef struct {
		uint8_t                 checksum;
		uint16_t				packetLength;
		uint8_t					packetType;
		uint8_t                 aiMode;
		uint8_t                 targetLock;
		int16_t                 pxTargetPos[2];
		int16_t                 pxTargetSize[2];
		int32_t                 nrad_x10CoarsePos[2];
		int8_t                  aimPointMode;
		int16_t                 pxAimPointOffset[2];
		int32_t					nrad_x10RadarTargetPos[2];
		int16_t					mm_x100RadarTargetDistance;
		uint8_t					camGainModeCommand;
		int16_t                 camGainCommand;
		int8_t					camZoomModeStatus;
		int16_t					xCamZoomStatus;
		int16_t					uradX100VFov;
		uint8_t					expandModeCommand;
		uint8_t					camIrisModeCommand;
		int16_t                 camIrisCommand;
		uint8_t					camFocusModeStatus;
		int16_t 				mmX100CamFocusStatus;
		uint8_t					armStatus;
		int8_t					sHelTimeout;
		uint8_t					bfHelStatus;
		uint8_t					bfTilStatus;
		uint16_t				uradTilDivergence;
		int16_t					mmX100HelFocus;   
		int8_t					lrfStatus;
		uint16_t				mm_x100LrfDistance;
		uint8_t					bfIsInLaserRestrictArea;
		uint8_t					swingScanMode;
		uint8_t 				scanZoneDesignateCommand;
		uint16_t				pxDesignatedScanZone[2];
		uint16_t                mpsNeutralizationCriteria[2];	//0:min,1:max
		uint8_t					recCommand;
		uint16_t 				recDecimationCommand;
		uint8_t					shootDownOverrideStatus;
		uint8_t					shutdownRequest;
		uint8_t					bfAuxDisplayInfo;
		int32_t					nrad_x10VehicleHeading;
		int8_t					soiCamId;
		int8_t					trackingCamId;
		uint8_t                 externalSensorTargetSelectionModeStatus;
		int8_t					logFileId;
	}TurretToImgProcCommand;

	///////////////////////////////////////////////
	// Internal use
	///////////////////////////////////////////////

	typedef struct {
		struct {
			uint8_t mode;
			double nmTorque[AXIS_NUM];
			double rpsVelocity[AXIS_NUM];
			double radRadarReference[AXIS_NUM];
			uint8_t servoOnCommand;
		} control;
		struct {
			uint16_t bfAlarmFlag;
			uint16_t bfWarningFlag;
		} alarm;
	}ServoCommand;

	typedef struct {
		double radCoarsePos[AXIS_NUM];	//����]
		double rpsCoarseSpeed[AXIS_NUM];	//����]
		uint8_t coarseStatus[AXIS_NUM];
		uint16_t coarseParamErrorNo[AXIS_NUM];
		uint16_t coarseWarning[AXIS_NUM];
		uint32_t coarseAlarm[AXIS_NUM];
		uint16_t coarseDriverAlarmCode[AXIS_NUM];
		uint16_t bfControlModelWarningFlags;
		uint16_t bfControlModelAlarmFlags;
		uint8_t homingComplete;
		uint8_t servoOn;
	}ServoStatus;

	typedef struct {
		struct{
			uint8_t mode;                       // �������������͂����e�����u�̓��샂�[�h
			uint8_t servoOnCommand;
			uint8_t homingComplete;
			double radAngle[AXIS_NUM];
			double rpsVelocity[AXIS_NUM];
			double rpsVelocityLimit[AXIS_NUM];
			double radScanOffset[2];
		} command;
		struct {
			double radAngle[3];
			double rpsVelocity[3];
			double radVisionAngleError[2];
			uint8_t visionUpdateFlag;
			uint8_t validVision;
			double mPositionRadar[3];
			double mpsVelocityRadar[3];
		} sensor;
	} ControlModelInput;

	typedef struct {
		ControlModelInput controlModelInput;
		ServoCommand servoCommand;
		double radAngleReference[3];
		double rpsVelocityReference[3];
		double rpsVelocityFeedback[3];
		double nmDisturbance[3];
		double estReference[3];
		double maintenance[32];
	}ControlModelLog;

	typedef struct {
		double posX;
		double posY;
	}FineMirrorCommand;

	typedef struct {
		int8_t helEnable;	//0:�Ǝˋ֎~�A1:�Ǝˋ���
		int8_t tilEnable;	//0:�Ǝˋ֎~�A1:�Ǝˋ���
	}LaserEnableCommand;

	typedef struct {
		uint16_t alarmCode;
		uint16_t warningCode;
	}FineMirrorStatus;

	typedef struct {
		double radTilDivergence;
	}TilServoCommand;

	typedef struct {
		double radTilDivergence;
		//uint16_t warningCode;	//IAI�T�[�{�ɂ�Warning�����݂��Ȃ��B
		uint16_t alarmCode;
	}TilServoStatus;


	typedef struct {
		double xZoom;
		double iris;
		double mFocus;
		double mHelFocus;
	}TeleCamLensCommand;

	typedef struct {
		double xTeleCamZoom;
		double radTeleCamFov;
		double teleCamIris;
		double mTeleCamFocus;
		double mHelFocus;
		uint8_t bfErrorStatus[NUM_TELE_LENS_AXIS];	//bit1:Warning bit0:Error
		uint16_t alarmCode[NUM_TELE_LENS_AXIS];
		uint16_t warningCode[NUM_TELE_LENS_AXIS];
		uint16_t rs485ConverterWarningCode;
		uint16_t rs485ConverterAlarmCode;
	}TeleCamLensStatus;

	typedef struct {
		ServoCommand servoCommand;
		ControlModelInput controlModelInput;
		ServoStatus servoStatus;

		FineMirrorCommand fineMirrorCommand;
		LaserEnableCommand laserEnableCommand;
		FineMirrorStatus fineMirrorStatus;
		
		TeleCamLensCommand teleCamLensCommand;
		TeleCamLensStatus teleCamLensStatus;

		TilServoCommand tilServoCommand;
		TilServoStatus tilServoStatus;

		uint8_t logFileIdCommand;
	}ControlCommandAndStatus;

	typedef struct {
		uint8_t on;
	}RangefinderCommand;

	typedef struct {
		uint16_t mmX100Range;
		int8_t status;
	}RangefinderStatus;

	typedef struct {
		uint16_t zoom;
		uint16_t iris;
		uint16_t focus;
	}WideCamLensCommand;

	typedef struct {
		uint16_t zoom;
		uint16_t iris;
		uint16_t focus;
	}WideCamLensStatus;


	///////////////////////////////////////////////
	// Parameter from file
	///////////////////////////////////////////////

	typedef struct {
		double m[3][3];
	}FineMapperParam;

	typedef struct {
		struct {
			double nmToqrueLimit[3];
			double rpsVelocityLimit[3];
			double radAngleLimit[3][2];
		} all;
		struct {
			double rpsRateLimit[3];
			double rps2RateLimit[3][2];
		} reference;
		struct {
			double hzFVelecityFilter[3];
			double zetaVelocityFilter[3];
		} sensor;
		struct {
			double pGain[3];
			double iGain[3];
		} velocityControl;
		struct {
			double pGain[3];
			double iGain[3];
		} angleControl;
		struct {
			double pGain[3];
			double iGain[3];
			double dGain[3];
		} trackControl;
		struct {
			double hzF[3];
			double w[3];
			double d[3];
		} notch;
		struct {
			double hzFLag[3][2];
			double aLag[3][2];
			double hzFLead[3][2];
			double aLead[3][2];
		} phaseComp;
		struct {
			double gain[3];
			double kgm2Inertia[3];
			double hzF[3];
			double zeta[3];
			double gainDCDOB[3];
		}dob;
		struct {
			double kgm2Inertia[3];
			double hzF[3];
			double zeta[3];
		}inertialFF;
		struct {
			double mode[3];
			double nmFc[3][6];
			double nmFs[3][6];
			double nmsprViscocity[3];
			double nmprStiffness[3][6];
			double attractionParameter[3][6];
			double rpsStribeckVelocity[3][6];
		} frictionFF;
		struct {
			double gain[3];
			double pseudoInertiaMatrix[3][4][4];
		}decoupleFF;
		struct {
			double nmTorqueMax[3];
			double radPhase[3];
		} gravityFF;
		struct {
			double gain[3];
			double sTimeSet[3];
		} estimate;
	}ServoParameters;


#define IPADDR_STR_SZ (32)
#define PORT_STR_SZ (16)
	typedef struct {
		char ipaddr_str[IPADDR_STR_SZ];
		char sendPort[PORT_STR_SZ];
		char recvPort[PORT_STR_SZ];
	}UdpParam;

	typedef struct {
		char logDir[_MAX_FNAME];
		ServoParameters servoParam;
		FineMapperParam fineMapperParam;
		UdpParam masterUdpParam;
		UdpParam imgProcUdpParam[NUM_CAMS];
	}SystemParameters;

	typedef struct {
		double mAdccsSafetyMargin;
		double radSystemSafetyMargin;
		double radFixedAreaSafetyMargin;
		double mHelSafeDistance;
		double mTilSafeDistance;
		int16_t mpsFallSpeedCriteriaLow;
		int16_t mpsFallSpeedCriteriaHigh;
	}UserParameters;



#ifdef __cplusplus

	enum class ShutdownRequest {
		NORMAL_OPERATION = 0,
		EXIT_SHUTDOWN = 1,
		EXIT_REBOOT = 2,
		EXIT_NORMAL = 3
	};

	static const ShutdownRequest DEFAULT_ACTION_ON_ERROR = ShutdownRequest::EXIT_NORMAL;

	typedef struct {
		char message[MESSAGE_LOG_LENGTH];
		ShutdownRequest shutdownRequset;
	}MessageLog;

	enum class OperationMode {
		NORMAL = 0,
		TRAINING = 1,
		PARAMETER_ERROR = 2,
	};

	typedef struct {
		int32_t loadDone;
		OperationMode operationMode;
		SystemParameters systemParameters;
		UserParameters userParameters;
	}BootParameters;

	typedef struct {
		uint16_t MBx100DiskRemaining;
		uint8_t logFileIdStatus;
	}LogStatus;

}
#endif	/*__cplusplus*/


#pragma pack()