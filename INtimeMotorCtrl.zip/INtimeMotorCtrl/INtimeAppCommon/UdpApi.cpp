#include <stdio.h>
#include <rt.h>

#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

#include "UdpApi.h"

/// <summary>
/// UDP socket close
/// </summary>
void udpapi_socket_close(TY_UDP_SOCK* p)
{
	if (p->ai) {
		freeaddrinfo(p->ai);
		p->ai = NULL;
	}
	if (p->s != INVALID_SOCKET) {
		shutdown(p->s, SHUT_RDWR);
		close(p->s);
		p->s = INVALID_SOCKET;
	}
}

/// <summary>
/// UDP recv socket init
/// </summary>
int udpapi_recv_init(TY_UDP_SOCK* p,char *port)
{
	SOCKET s;
	struct addrinfo hints = { 0 };
	//struct addrinfo* ai = NULL;
	int error;

	p->s = INVALID_SOCKET;
	p->ai = NULL;

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_protocol = IPPROTO_UDP;
	hints.ai_flags = AI_PASSIVE;
	error = getaddrinfo(NULL, port, &hints, &p->ai);
	if (error)
	{
		printf("getaddrinfo: e=%u %s\n", error, gai_strerror(error));
		if (p->ai != NULL) {
			freeaddrinfo(p->ai);
			p->ai = NULL;
		}
		return FALSE;
	}

	s = socket(p->ai->ai_family, SOCK_DGRAM, IPPROTO_UDP);
	if (s == INVALID_SOCKET)
	{
		printf("socket error: errno=%u (%s)\n", errno, strerror(errno));
		freeaddrinfo(p->ai);
		p->ai = NULL;
		return FALSE;
	}

	if (bind(s, p->ai->ai_addr, p->ai->ai_addrlen) == -1)
	{
		printf("bind failed: errno=%u (%s)\n", errno, strerror(errno));
		freeaddrinfo(p->ai);
		close(s);
		p->ai = NULL;
		p->s = INVALID_SOCKET;
		return FALSE;
	}
	p->s = s;
	return TRUE;
}
/// <summary>
/// UDP send socket init
/// </summary>
int udpapi_send_init(TY_UDP_SOCK* p, char *ip,char *port)
{
	SOCKET s;
	struct addrinfo hints = { 0 };
	int error;

	p->s = INVALID_SOCKET;
	p->ai = NULL;
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_protocol = IPPROTO_UDP;
	hints.ai_flags = 0;
	error = getaddrinfo(ip, port, &hints, &p->ai);
	if (error)
	{
		printf("getaddrinfo: e=%u %s\n", error, gai_strerror(error));
		if (p->ai != NULL) {
			freeaddrinfo(p->ai);
			p->ai = NULL;
		}
		return FALSE;
	}

	s = socket(p->ai->ai_family, SOCK_DGRAM, IPPROTO_UDP);
	if (s == INVALID_SOCKET)
	{
		printf("socket error: errno=%u (%s)\n", errno, strerror(errno));
		freeaddrinfo(p->ai);
		p->ai = NULL;
		return FALSE;
	}

	p->s = s;
	return TRUE;
}

/// <summary>
/// UDP recv func
/// </summary>
int udpapi_recv(TY_UDP_SOCK *s,unsigned char *buf,int bufsz)
{
	fd_set rfds;
	int err;
	int n;
	struct timeval tv;

	if (s->s == INVALID_SOCKET) return FALSE;

	FD_ZERO(&rfds);
	FD_SET(s->s, &rfds);
	tv.tv_sec = 0;
	tv.tv_usec = 0;
	if ((n = select(s->s + 1, &rfds, NULL, NULL, &tv)) != 1)
	{
		return FALSE;
	}
	if (!FD_ISSET(s->s, &rfds))
		return FALSE;


	n = recv(s->s, buf, bufsz, 0);
	if(n<=0)
	{
		err = errno;
		if (err == ECONNRESET)
		{
			return FALSE;
		}
		printf("recv failed: %u %s\n", err, strerror(err));
		return -1;
	}
	return n;
}
/// <summary>
/// UDP send func
/// </summary>
int udpapi_send(TY_UDP_SOCK* s, unsigned char* buf, int bufsz)
{
	int err = 0;
	if (s->s == INVALID_SOCKET) return FALSE;
	if (sendto(s->s, (const char*)buf, bufsz, 0, s->ai->ai_addr, (int)s->ai->ai_addrlen) != bufsz)
	{
		err = errno;

		printf("sendto fail: %u %s\n", err,strerror(err));
		return FALSE;
	}

	return TRUE;
}
