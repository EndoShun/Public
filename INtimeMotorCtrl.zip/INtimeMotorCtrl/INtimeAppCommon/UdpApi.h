#pragma once
#include <stdio.h>
#include <rt.h>

#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

	typedef struct {
		SOCKET s;
		struct addrinfo* ai;
	}TY_UDP_SOCK;


	void udpapi_socket_close(TY_UDP_SOCK* p);
	int udpapi_recv_init(TY_UDP_SOCK* p, char* port);
	int udpapi_send_init(TY_UDP_SOCK* p, char* ip, char* port);
	int udpapi_recv(TY_UDP_SOCK* s, unsigned char* buf, int bufsz);
	int udpapi_send(TY_UDP_SOCK* s, unsigned char* buf, int bufsz);


#ifdef __cplusplus
}
#endif /*__cplusplus*/