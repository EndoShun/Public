#pragma once

#include "math.h"
#include "stdint.h"

static constexpr int32_t degToNradx10(const double degAngle) {
	return (int32_t)(degAngle * M_PI / 180 * 100000000);
}

static constexpr double nradx10ToDeg(int32_t nradx10Angle) {
	return nradx10Angle / M_PI * 180.0 / 100000000;
}

static constexpr int32_t radToNradx10(double radAngle) {
	return (int32_t)(radAngle * 100000000);
}

static constexpr double nradx10ToRad(int32_t nradx10Angle) {
	return nradx10Angle / 100000000.0;
}