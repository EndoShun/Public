
#include "MyRtQueue.h"
#include "stdio.h"
#include "string.h"

template<typename T>
MyRtQueue<T>::MyRtQueue() {
	this->queue = BAD_RTHANDLE;
}

template<typename T>
MyRtQueue<T>::~MyRtQueue() {
}

template<typename T>
MyQueueStatus MyRtQueue<T>::setup(const char* queueHandleName, int32_t msWaitTime) {
	MyQueueStatus status = MyQueueStatus::OK;

	LOCATION loc = GetRtNodeLocationByName(SHARED_RESOURCE_NODE_NAME);
	if (loc == BAD_LOCATION) {
		status = MyQueueStatus::FIND_LOCATION_FAIL;
	}

	RTHANDLE rootProcess;
	if (status == MyQueueStatus::OK) {
		rootProcess = GetRemoteRootRtProcess(loc);
		if (rootProcess == BAD_RTHANDLE) {
			status = MyQueueStatus::FIND_ROOTPROCESS_FAIL;
		}
	}

	RTHANDLE queueHandle;
	if (status == MyQueueStatus::OK) {
		queueHandle = LookupRtHandle(rootProcess, (LPSTR)queueHandleName, msWaitTime);
		if (queueHandle == BAD_RTHANDLE) {
			status = MyQueueStatus::FIND_QUEUE_FAIL;
		}
	}

	if (status == MyQueueStatus::OK) {
		this->queue = queueHandle;

		return MyQueueStatus::OK;
	}
	else {
		this->queue = BAD_RTHANDLE;

		return status;
	}
}

template<typename T>
MyQueueStatus MyRtQueue<T>::send(const T* msg) {
	SharedObject obj;
	memcpy(&obj.data, msg, sizeof(T));
	TIMEVALUE time;
	GetRtSystemTimeAsTimeValue(&time);
	time.qwSeconds += SEC_GMT9_OFFSET;
	TimeValueToSystemTime(&time, &obj.sendTime);

	BOOLEAN ret = SendRtShortDataMessage(queue, (LPVOID)&obj, sizeof(SharedObject));
	if (ret == TRUE) {
		return MyQueueStatus::OK;
	}
	else {
		DWORD error = GetLastRtError();
		if (error == E_LIMIT) {
			return MyQueueStatus::FULL;
		}
		else {
			return MyQueueStatus::QUEUE_ERROR;
		}
	}
}

template<typename T>
int32_t MyRtQueue<T>::isOk() {
	if (queue == BAD_RTHANDLE) {
		return 0;
	}
	else {
		return 1;
	}
}

template<typename T>
MyQueueStatus MyRtQueue<T>::recv(T* buf, int32_t msWaitTime) {
	DWORD bytesReceived;
	SharedObject obj;
	BOOLEAN ret = ReceiveRtDataMessage(queue, (LPVOID)&obj, sizeof(T), msWaitTime, &bytesReceived);
	if (ret == TRUE) {
		memcpy(buf, &obj.data, sizeof(T));
		sendTime = obj.sendTime;

		return MyQueueStatus::OK;
	}
	else {
		DWORD error = GetLastRtError();
		if (error == E_TIME) {
			return MyQueueStatus::TIMEOUT;
		}
		else {
			return MyQueueStatus::QUEUE_ERROR;
		}
	}
}

template<typename T>
SYSTEMTIME MyRtQueue<T>::getSendTime() {
	return sendTime;
}

template class MyRtQueue<MasterToTurretCommand>;
template class MyRtQueue<MasterToTurretCommand>;
template class MyRtQueue<TurretToMasterResponse>;
template class MyRtQueue<ImgProcToTurretResponse>;
template class MyRtQueue<TurretToImgProcCommand>;
template class MyRtQueue<ControlCommandAndStatus>;
template class MyRtQueue<MessageLog>;