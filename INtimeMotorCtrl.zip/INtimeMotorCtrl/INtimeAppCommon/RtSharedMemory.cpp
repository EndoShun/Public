
#include "RtSharedMemory.h"
#include "rt.h"
#include "stdio.h"
#include "string.h"
#include "IoStructs.h"

template <class T>
RtSharedMemory<T>::RtSharedMemory(){
	this->sem = BAD_RTHANDLE;
	this->memHandle = BAD_RTHANDLE;
	this->sharedBuffer = NULL;
	this->localBuffer = NULL;
}

template <class T>
RtSharedMemory<T>::~RtSharedMemory() {
	if (localBuffer != NULL) {
		FreeRtMemory(localBuffer);
	}
}

template <class T>
MySharedMemoryStatus RtSharedMemory<T>::setup(const SharedMemoryCatalogNames names) {
	MySharedMemoryStatus status = MySharedMemoryStatus::OK;

	LOCATION loc = GetRtNodeLocationByName(SHARED_RESOURCE_NODE_NAME);
	if (loc == BAD_LOCATION) {
		status = MySharedMemoryStatus::FIND_LOCATION_FAIL;
	}

	RTHANDLE hRProcess;
	if (status == MySharedMemoryStatus::OK) {
		hRProcess = GetRemoteRootRtProcess(loc);
		if (BAD_RTHANDLE == hRProcess)
		{
			status = MySharedMemoryStatus::FIND_ROOTPROCESS_FAIL;
		}
	}

	RTHANDLE memHandle;
	if (status == MySharedMemoryStatus::OK) {
		memHandle = LookupRtHandle(hRProcess, names.MemName, 0);
		if (memHandle == BAD_RTHANDLE) {
			status = MySharedMemoryStatus::FIND_SHAREDMEMORY_FAIL;
		}
	}

	SharedObject* mem;
	if (status == MySharedMemoryStatus::OK) {
		mem = (SharedObject*)MapRtSharedMemory(memHandle);
		if (mem == NULL) {
			status = MySharedMemoryStatus::MAP_SHAREDMEMORY_FAIL;
		}
	}

	RTHANDLE semHandle;
	if (status == MySharedMemoryStatus::OK) {
		semHandle = LookupRtHandle(hRProcess, names.SemName, 0);
		if (semHandle == BAD_RTHANDLE) {
			status = MySharedMemoryStatus::FIND_SEM_FAIL;
		}
	}

	SharedObject* localBuffer = NULL;
	if (status == MySharedMemoryStatus::OK) {
		localBuffer = (SharedObject*)AllocateRtMemory(sizeof(SharedObject));
		if (localBuffer == NULL) {
			status = MySharedMemoryStatus::ALLOCATE_LOCALMEMORY_FAIL;
		}
		else {
			memset(localBuffer,0,sizeof(SharedObject));
		}
	}
	

	if(status == MySharedMemoryStatus::OK) {
		this->sem = semHandle;
		this->memHandle = memHandle;
		this->sharedBuffer = mem;
		this->localBuffer = localBuffer;

		return MySharedMemoryStatus::OK;
	}
	else {
		if (localBuffer != NULL) {
			FreeRtMemory(localBuffer);
		}

		this->sem = BAD_RTHANDLE;
		this->memHandle = BAD_RTHANDLE;
		this->sharedBuffer = NULL;
		this->localBuffer = NULL;

		return status;
	}
}

template <class T>
int32_t RtSharedMemory<T>::isOk() {
	if (sem == BAD_RTHANDLE || memHandle == BAD_RTHANDLE || sharedBuffer == NULL || localBuffer == NULL) {
		return 0;
	}
	else {
		return 1;
	}
}

template <class T>
MySharedMemoryStatus RtSharedMemory<T>::copySharedToLocal(int32_t msWaitTime) {
	if (WaitForRtSemaphore(sem, 1, msWaitTime) == WAIT_FAILED) {
		if (GetLastRtError() == E_TIME) {
			return MySharedMemoryStatus::TIMEOUT;
		}
		else {
			return MySharedMemoryStatus::SEM_ERROR;
		}
	}
	
	memcpy(localBuffer,sharedBuffer,sizeof(SharedObject));
	sharedBuffer->updated = 0;
	
	ReleaseRtSemaphore(sem,1);
	
	return MySharedMemoryStatus::OK;
}

template <class T>
MySharedMemoryStatus RtSharedMemory<T>::copyLocalToShared(int32_t msWaitTime) {
	if (WaitForRtSemaphore(sem, 1, msWaitTime) == WAIT_FAILED) {
		if (GetLastRtError() == E_TIME) {
			return MySharedMemoryStatus::TIMEOUT;
		}
		else {
			return MySharedMemoryStatus::SEM_ERROR;
		}
	}
	
	memcpy(sharedBuffer, localBuffer, sizeof(SharedObject));
	sharedBuffer->updated = 1;
	TIMEVALUE time;
	GetRtSystemTimeAsTimeValue(&time);
	time.qwSeconds += SEC_GMT9_OFFSET;
	TimeValueToSystemTime(&time, &sharedBuffer->updateTime);
	
	ReleaseRtSemaphore(sem, 1);
	
	return MySharedMemoryStatus::OK;
}

template <class T>
T* RtSharedMemory<T>::getBuf() {
	return &localBuffer->data;
}

template <class T>
SYSTEMTIME RtSharedMemory<T>::getUpdateTime() {
	return localBuffer->updateTime;
}

template <class T>
int8_t RtSharedMemory<T>::isUpdated() {
	return localBuffer->updated;
}

template class RtSharedMemory<MasterToTurretCommand>;
template class RtSharedMemory<TurretToMasterResponse>;
template class RtSharedMemory<TurretToImgProcCommand>;
template class RtSharedMemory<ImgProcToTurretResponse>;
template class RtSharedMemory<BootParameters>;
template class RtSharedMemory<ShutdownRequest>;
template class RtSharedMemory<RangefinderCommand>;
template class RtSharedMemory<RangefinderStatus>;
template class RtSharedMemory<WideCamLensCommand>;
template class RtSharedMemory<WideCamLensStatus>;
template class RtSharedMemory<LogStatus>;