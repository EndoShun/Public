#pragma once

#include "ntx.h"
#include "stdint.h"
#include "NtxTime.h"
#include "CatalogNames.h"

enum class MyQueueStatus {
	OK = 0,
	FULL = 1,
	TIMEOUT = 2,
	QUEUE_ERROR = -1,
	FIND_LOCATION_FAIL = -2,
	FIND_ROOTPROCESS_FAIL = -3,
	FIND_QUEUE_FAIL = -4,
};

template<typename T>
class MyNtxQueue {
private:
	static constexpr int32_t BYTES_MSG_OVERHEAD = 30;

	#pragma pack(1)
	typedef struct {
		RT_SYSTEMTIME sendTime;
		T data;
	}SharedObject;
	#pragma pack()

	NTXHANDLE queue;
	RT_SYSTEMTIME sendTime;

public:
	MyNtxQueue(const char* queueHandleName, int32_t depth);
	~MyNtxQueue();
	MyQueueStatus send(const T* msg);
	MyQueueStatus recv(T* buf,int32_t msWaitTime);
	int32_t isOk();
	RT_SYSTEMTIME getSendTime();
};

