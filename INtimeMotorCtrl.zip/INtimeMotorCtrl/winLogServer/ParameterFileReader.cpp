#include "ParameterFileReader.h"
#include "stdio.h"

#define _USE_MATH_DEFINES
#include "math.h"

using json = nlohmann::json;

//Phase text for error message.
struct {
	const char* None = "None";
	const char* Logging_Path = "Logging/Path";
	const char* Network_MasterController_IP = "Network/MasterController/IP";
	const char* Network_MasterController_RecvPort = "Network/MasterController/RecvPort";
	const char* Network_MasterController_SendPort = "Network/MasterController/SendPort";
	const char* Network_ImgProcWide_IP = "Network/ImgProcWide/IP";
	const char* Network_ImgProcWide_SendPort = "Network/ImgProcWide/SendPort";
	const char* Network_ImgProcWide_RecvPort = "Network/ImgProcWide/RecvPort";
	const char* Network_ImgProcTele_IP = "Network/ImgProcTele/IP";
	const char* Network_ImgProcTele_SendPort = "Network/ImgProcTele/SendPort";
	const char* Network_ImgProcTele_RecvPort = "Network/ImgProcTele/RecvPort";
	const char* Servo_All_NmTorqueLimit = "Servo/All/NmTorqueLimit";
	const char* Servo_All_RpmVelocityLimit = "Servo/All/RpmVelocityLimit";
	const char* Servo_All_DegAngleLimit = "Servo/All/DegAngleLimit";
	const char* Servo_Reference_DegpsRateLimit = "Servo/Reference/DegpsRateLimit";
	const char* Servo_Reference_Degps2RateLimit = "Servo/Reference/Degps2RateLimit";
	const char* Servo_Sensor_HzFVelocityFilter = "Servo/Sensor/HzFVelocityFilter";
	const char* Servo_Sensor_ZetaVelocityFilter = "Servo/Sensor/ZetaVelocityFilter";
	const char* Servo_VelocityControl_PGain = "Servo/VelocityControl/PGain";
	const char* Servo_VelocityControl_IGain = "Servo/VelocityControl/IGain";
	const char* Servo_AngleControl_PGain = "Servo/AngleControl/PGain";
	const char* Servo_AngleControl_IGain = "Servo/AngleControl/IGain";
	const char* Servo_TrackControl_PGain = "Servo/TrackControl/PGain";
	const char* Servo_TrackControl_IGain = "Servo/TrackControl/IGain";
	const char* Servo_TrackControl_DGain = "Servo/TrackControl/DGain";
	const char* Servo_Notch_HzF = "Servo/Notch/HzF";
	const char* Servo_Notch_W = "Servo/Notch/W";
	const char* Servo_Notch_D = "Servo/Notch/D";
	const char* Servo_PhaseComp_HzFLag = "Servo/PhaseComp/HzFLag";
	const char* Servo_PhaseComp_ALag = "Servo/PhaseComp/ALag";
	const char* Servo_PhaseComp_HzFLead = "Servo/PhaseComp/HzFLead";
	const char* Servo_PhaseComp_ALead = "Servo/PhaseComp/ALead";
	const char* Servo_DOB_Gain = "Servo/DOB/Gain";
	const char* Servo_DOB_Kgm2Inertia = "Servo/DOB/Kgm2Inertia";
	const char* Servo_DOB_HzF = "Servo/DOB/HzF";
	const char* Servo_DOB_Zeta = "Servo/DOB/Zeta";
	const char* Servo_DOB_GainDCDOB = "Servo/DOB/GainDCDOB";
	const char* Servo_InertiaFF_Kgm2Inertia = "Servo/InertiaFF/Kgm2Inertia";
	const char* Servo_InertiaFF_HzF = "Servo/InertiaFF/HzF";
	const char* Servo_InertiaFF_Zeta = "Servo/InertiaFF/Zeta";
	const char* Servo_FrictionFF_Mode = "Servo/FrictionFF/Mode";
	const char* Servo_FrictionFF_NmFc = "Servo/FrictionFF/NmFc";
	const char* Servo_FrictionFF_NmFs = "Servo/FrictionFF/NmFs";
	const char* Servo_FrictionFF_NmsprViscocity = "Servo/FrictionFF/NmsprViscocity";
	const char* Servo_FrictionFF_NmprStiffness = "Servo/FrictionFF/NmprStiffness";
	const char* Servo_FrictionFF_AttractionParameter = "Servo/FrictionFF/AttractionParameter";
	const char* Servo_FrictionFF_RpsStribeckVelocity = "Servo/FrictionFF/RpsStribeckVelocity";
	const char* Servo_DecoupleFF_Gain = "Servo/DecoupleFF/Gain";
	const char* Servo_DecoupleFF_PsuedoInertiaMatrix = "Servo/DecoupleFF/PsuedoInertiaMatrix";
	const char* Servo_GravityFF_NmTorqueMax = "Servo/GravityFF/NmTorqueMax";
	const char* Servo_GravityFF_RadPhase = "Servo/GravityFF/RadPhase";
	const char* Servo_Estimate_Gain = "Servo/Estimate/Gain";
	const char* Servo_Estimate_STimeSet = "Servo/Estimate/STimeSet";
	const char* FineMapper_M = "FineMapper/M";

}SystemParameterParsePhase;

void ParameterFileReader::printSystemParameters(SystemParameters& param) {
	printf("\n");
	printf("============== LocalParameters ================\n");
	printf("Logging{\n");
	printf("    Path: %s\n", param.logDir);
	printf("}\n");
	printf("Network{\n");
	printf("    MasterController{\n");
	printf("        IP: %s\n", param.masterUdpParam.ipaddr_str);
	printf("        RecvPort: %s\n", param.masterUdpParam.recvPort);
	printf("        SendPort: %s\n", param.masterUdpParam.sendPort);
	printf("    }\n");
	printf("    ImgProcWide{\n");
	printf("        IP: %s\n", param.imgProcUdpParam[0].ipaddr_str);
	printf("        SendPort: %s\n", param.imgProcUdpParam[0].sendPort);
	printf("        RecvPort: %s\n", param.imgProcUdpParam[0].recvPort);
	printf("    }\n");
	printf("    ImgProcTele{\n");
	printf("        IP: %s\n", param.imgProcUdpParam[1].ipaddr_str);
	printf("        SendPort: %s\n", param.imgProcUdpParam[1].sendPort);
	printf("        RecvPort: %s\n", param.imgProcUdpParam[1].recvPort);
	printf("    }\n");
	printf("}\n");
	printf("Servo{\n");
	printf("    All{\n");
	printf("        nmTorqueLimit: %.2lf,%.2lf,%.2lf\n", param.servoParam.all.nmToqrueLimit[0], param.servoParam.all.nmToqrueLimit[1], param.servoParam.all.nmToqrueLimit[2]);
	printf("        rpsVelocityLimit: %.2lf,%.2lf,%.2lf\n", param.servoParam.all.rpsVelocityLimit[0], param.servoParam.all.rpsVelocityLimit[1], param.servoParam.all.rpsVelocityLimit[2]);
	printf("        radAngleLimit: ((%.2lf,%.2lf),\n", param.servoParam.all.radAngleLimit[0][0], param.servoParam.all.radAngleLimit[0][1]);
	printf("                        (%.2lf,%.2lf),\n", param.servoParam.all.radAngleLimit[1][0], param.servoParam.all.radAngleLimit[1][1]);
	printf("                        (%.2lf,%.2lf))\n", param.servoParam.all.radAngleLimit[2][0], param.servoParam.all.radAngleLimit[2][1]);
	printf("    }\n");
	printf("    Reference{\n");
	printf("        rpsRateLimit: %.2lf,%.2lf,%.2lf\n", param.servoParam.reference.rpsRateLimit[0], param.servoParam.reference.rpsRateLimit[1], param.servoParam.reference.rpsRateLimit[2]);
	printf("        rps2RateLimit: ((%.2lf,%.2lf),\n", param.servoParam.reference.rps2RateLimit[0][0], param.servoParam.reference.rps2RateLimit[0][1]);
	printf("                        (%.2lf,%.2lf),\n", param.servoParam.reference.rps2RateLimit[1][0], param.servoParam.reference.rps2RateLimit[1][1]);
	printf("                        (%.2lf,%.2lf))\n", param.servoParam.reference.rps2RateLimit[2][0], param.servoParam.reference.rps2RateLimit[2][1]);
	printf("    }\n");
	printf("    Sensor{\n");
	printf("        hzFVelocityFilter: %.2lf,%.2lf,%.2lf\n", param.servoParam.sensor.hzFVelecityFilter[0], param.servoParam.sensor.hzFVelecityFilter[1], param.servoParam.sensor.hzFVelecityFilter[2]);
	printf("        zetaVelocityFilter: %.2lf,%.2lf,%.2lf\n", param.servoParam.sensor.zetaVelocityFilter[0], param.servoParam.sensor.zetaVelocityFilter[1], param.servoParam.sensor.zetaVelocityFilter[2]);
	printf("    }\n");
	printf("    VelocityControl{\n");
	printf("        pGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.velocityControl.pGain[0], param.servoParam.velocityControl.pGain[1], param.servoParam.velocityControl.pGain[2]);
	printf("        iGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.velocityControl.iGain[0], param.servoParam.velocityControl.iGain[1], param.servoParam.velocityControl.iGain[2]);
	printf("    }\n");
	printf("    AngleControl{\n");
	printf("        pGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.angleControl.pGain[0], param.servoParam.angleControl.pGain[1], param.servoParam.angleControl.pGain[2]);
	printf("        iGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.angleControl.iGain[0], param.servoParam.angleControl.iGain[1], param.servoParam.angleControl.iGain[2]);
	printf("    }\n");
	printf("    TrackControl{\n");
	printf("        pGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.trackControl.pGain[0], param.servoParam.trackControl.pGain[1], param.servoParam.trackControl.pGain[2]);
	printf("        iGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.trackControl.iGain[0], param.servoParam.trackControl.iGain[1], param.servoParam.trackControl.iGain[2]);
	printf("        dGain: %.2lf,%.2lf,%.2lf\n", param.servoParam.trackControl.dGain[0], param.servoParam.trackControl.dGain[1], param.servoParam.trackControl.dGain[2]);
	printf("    }\n");
	printf("    Notch{\n");
	printf("        hzF: %.2lf,%.2lf,%.2lf\n", param.servoParam.notch.hzF[0], param.servoParam.notch.hzF[1], param.servoParam.notch.hzF[2]);
	printf("        w: %.2lf,%.2lf,%.2lf\n", param.servoParam.notch.w[0], param.servoParam.notch.w[1], param.servoParam.notch.w[2]);
	printf("        d: %.2lf,%.2lf,%.2lf\n", param.servoParam.notch.d[0], param.servoParam.notch.d[1], param.servoParam.notch.d[2]);
	printf("    }\n");
	printf("    PhaseComp{\n");
	printf("        hzFLag: ((%.2lf,%.2lf),(%.2lf,%.2lf),(%.2lf,%.2lf))\n", param.servoParam.phaseComp.hzFLag[0][0], param.servoParam.phaseComp.hzFLag[0][1], param.servoParam.phaseComp.hzFLag[1][0], param.servoParam.phaseComp.hzFLag[1][1], param.servoParam.phaseComp.hzFLag[2][0], param.servoParam.phaseComp.hzFLag[2][1]);
	printf("        aLag: ((%.2lf,%.2lf),(%.2lf,%.2lf),(%.2lf,%.2lf))\n", param.servoParam.phaseComp.aLag[0][0], param.servoParam.phaseComp.aLag[0][1], param.servoParam.phaseComp.aLag[1][0], param.servoParam.phaseComp.aLag[1][1], param.servoParam.phaseComp.aLag[2][0], param.servoParam.phaseComp.aLag[2][1]);
	printf("        hzFLead: ((%.2lf,%.2lf),(%.2lf,%.2lf),(%.2lf,%.2lf))\n", param.servoParam.phaseComp.hzFLead[0][0], param.servoParam.phaseComp.hzFLead[0][1], param.servoParam.phaseComp.hzFLead[1][0], param.servoParam.phaseComp.hzFLead[1][1], param.servoParam.phaseComp.hzFLead[2][0], param.servoParam.phaseComp.hzFLead[2][1]);
	printf("        aLead: ((%.2lf,%.2lf),(%.2lf,%.2lf),(%.2lf,%.2lf))\n", param.servoParam.phaseComp.aLead[0][0], param.servoParam.phaseComp.aLead[0][1], param.servoParam.phaseComp.aLead[1][0], param.servoParam.phaseComp.aLead[1][1], param.servoParam.phaseComp.aLead[2][0], param.servoParam.phaseComp.aLead[2][1]);
	printf("    }\n");
	printf("    DOB{\n");
	printf("        gain: %.2lf,%.2lf,%.2lf\n", param.servoParam.dob.gain[0], param.servoParam.dob.gain[1], param.servoParam.dob.gain[2]);
	printf("        kgm2Inertia: %.2lf,%.2lf,%.2lf\n", param.servoParam.dob.kgm2Inertia[0], param.servoParam.dob.kgm2Inertia[1], param.servoParam.dob.kgm2Inertia[2]);
	printf("        hzF: %.2lf,%.2lf,%.2lf\n", param.servoParam.dob.hzF[0], param.servoParam.dob.hzF[1], param.servoParam.dob.hzF[2]);
	printf("        zeta: %.2lf,%.2lf,%.2lf\n", param.servoParam.dob.zeta[0], param.servoParam.dob.zeta[1], param.servoParam.dob.zeta[2]);
	printf("        gainDCDOB: %.2lf,%.2lf,%.2lf\n", param.servoParam.dob.gainDCDOB[0], param.servoParam.dob.gainDCDOB[1], param.servoParam.dob.gainDCDOB[2]);
	printf("    }\n");
	printf("    InertiaFF{\n");
	printf("        kgm2Inertia: %.2lf,%.2lf,%.2lf\n", param.servoParam.inertialFF.kgm2Inertia[0], param.servoParam.inertialFF.kgm2Inertia[1], param.servoParam.inertialFF.kgm2Inertia[2]);
	printf("        hzF: %.2lf,%.2lf,%.2lf\n", param.servoParam.inertialFF.hzF[0], param.servoParam.inertialFF.hzF[1], param.servoParam.inertialFF.hzF[2]);
	printf("        zeta: %.2lf,%.2lf,%.2lf\n", param.servoParam.inertialFF.zeta[0], param.servoParam.inertialFF.zeta[1], param.servoParam.inertialFF.zeta[2]);
	printf("    }\n");
	printf("    FrictionFF{\n");
	printf("        mode: %.2lf,%.2lf,%.2lf\n", param.servoParam.frictionFF.mode[0], param.servoParam.frictionFF.mode[1], param.servoParam.frictionFF.mode[2]);
	printf("        nmFc: ((%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.nmFc[0][0], param.servoParam.frictionFF.nmFc[0][1], param.servoParam.frictionFF.nmFc[0][2],
																      param.servoParam.frictionFF.nmFc[0][3], param.servoParam.frictionFF.nmFc[0][4], param.servoParam.frictionFF.nmFc[0][5]);
	printf("               (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.nmFc[1][0], param.servoParam.frictionFF.nmFc[1][1], param.servoParam.frictionFF.nmFc[1][2],
																	  param.servoParam.frictionFF.nmFc[1][3], param.servoParam.frictionFF.nmFc[1][4], param.servoParam.frictionFF.nmFc[1][5]);
	printf("               (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf))\n", param.servoParam.frictionFF.nmFc[2][0], param.servoParam.frictionFF.nmFc[2][1], param.servoParam.frictionFF.nmFc[2][2],
																	  param.servoParam.frictionFF.nmFc[2][3], param.servoParam.frictionFF.nmFc[2][4], param.servoParam.frictionFF.nmFc[2][5]);
	printf("        nmFs: ((%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.nmFs[0][0], param.servoParam.frictionFF.nmFs[0][1], param.servoParam.frictionFF.nmFs[0][2],
																      param.servoParam.frictionFF.nmFs[0][3], param.servoParam.frictionFF.nmFs[0][4], param.servoParam.frictionFF.nmFs[0][5]);
	printf("               (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.nmFs[1][0], param.servoParam.frictionFF.nmFs[1][1], param.servoParam.frictionFF.nmFs[1][2],
																	  param.servoParam.frictionFF.nmFs[1][3], param.servoParam.frictionFF.nmFs[1][4], param.servoParam.frictionFF.nmFs[1][5]);
	printf("               (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf))\n", param.servoParam.frictionFF.nmFs[2][0], param.servoParam.frictionFF.nmFs[2][1], param.servoParam.frictionFF.nmFs[2][2],
																	  param.servoParam.frictionFF.nmFs[2][3], param.servoParam.frictionFF.nmFs[2][4], param.servoParam.frictionFF.nmFs[2][5]);
	printf("        nmsprViscocity: %.2lf,%.2lf,%.2lf\n", param.servoParam.frictionFF.nmsprViscocity[0], param.servoParam.frictionFF.nmsprViscocity[1], param.servoParam.frictionFF.nmsprViscocity[2]);
	printf("        nmprStiffness: ((%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.nmprStiffness[0][0], param.servoParam.frictionFF.nmprStiffness[0][1], param.servoParam.frictionFF.nmprStiffness[0][2],
																			   param.servoParam.frictionFF.nmprStiffness[0][3], param.servoParam.frictionFF.nmprStiffness[0][4], param.servoParam.frictionFF.nmprStiffness[0][5]);
	printf("                        (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.nmprStiffness[1][0], param.servoParam.frictionFF.nmprStiffness[1][1], param.servoParam.frictionFF.nmprStiffness[1][2],
																			   param.servoParam.frictionFF.nmprStiffness[1][3], param.servoParam.frictionFF.nmprStiffness[1][4], param.servoParam.frictionFF.nmprStiffness[1][5]);
	printf("                        (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf))\n", param.servoParam.frictionFF.nmprStiffness[2][0], param.servoParam.frictionFF.nmprStiffness[2][1], param.servoParam.frictionFF.nmprStiffness[2][2],
																			   param.servoParam.frictionFF.nmprStiffness[2][3], param.servoParam.frictionFF.nmprStiffness[2][4], param.servoParam.frictionFF.nmprStiffness[2][5]);
	printf("        attractionParameter: ((%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.attractionParameter[0][0], param.servoParam.frictionFF.attractionParameter[0][1], param.servoParam.frictionFF.attractionParameter[0][2],
																					 param.servoParam.frictionFF.attractionParameter[0][3], param.servoParam.frictionFF.attractionParameter[0][4], param.servoParam.frictionFF.attractionParameter[0][5]);
	printf("                              (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.attractionParameter[1][0], param.servoParam.frictionFF.attractionParameter[1][1], param.servoParam.frictionFF.attractionParameter[1][2],
																			         param.servoParam.frictionFF.attractionParameter[1][3], param.servoParam.frictionFF.attractionParameter[1][4], param.servoParam.frictionFF.attractionParameter[1][5]);
	printf("                              (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf))\n", param.servoParam.frictionFF.attractionParameter[2][0], param.servoParam.frictionFF.attractionParameter[2][1], param.servoParam.frictionFF.attractionParameter[2][2],
																					 param.servoParam.frictionFF.attractionParameter[2][3], param.servoParam.frictionFF.attractionParameter[2][4], param.servoParam.frictionFF.attractionParameter[2][5]);
	printf("        rpsStribeckVelocity: ((%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.rpsStribeckVelocity[0][0], param.servoParam.frictionFF.rpsStribeckVelocity[0][1], param.servoParam.frictionFF.rpsStribeckVelocity[0][2],
																					 param.servoParam.frictionFF.rpsStribeckVelocity[0][3], param.servoParam.frictionFF.rpsStribeckVelocity[0][4], param.servoParam.frictionFF.rpsStribeckVelocity[0][5]);
	printf("                              (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.frictionFF.rpsStribeckVelocity[1][0], param.servoParam.frictionFF.rpsStribeckVelocity[1][1], param.servoParam.frictionFF.rpsStribeckVelocity[1][2],
																					 param.servoParam.frictionFF.rpsStribeckVelocity[1][3], param.servoParam.frictionFF.rpsStribeckVelocity[1][4], param.servoParam.frictionFF.rpsStribeckVelocity[1][5]);
	printf("                              (%.2lf,%.2lf,%.2lf,%.2lf,%.2lf,%.2lf))\n", param.servoParam.frictionFF.rpsStribeckVelocity[2][0], param.servoParam.frictionFF.rpsStribeckVelocity[2][1], param.servoParam.frictionFF.rpsStribeckVelocity[2][2],
																					 param.servoParam.frictionFF.rpsStribeckVelocity[2][3], param.servoParam.frictionFF.rpsStribeckVelocity[2][4], param.servoParam.frictionFF.rpsStribeckVelocity[2][5]);
	printf("    }\n");
	printf("    DecoupleFF{\n");
	printf("        gain: %.2lf,%.2lf,%.2lf\n", param.servoParam.decoupleFF.gain[0], param.servoParam.decoupleFF.gain[1], param.servoParam.decoupleFF.gain[2]);
	printf("        psuedoInertiaMatrix: (((%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf)),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][3]);
	printf("                              ((%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf)),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][3]);
	printf("                              ((%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][3]);
	printf("                               (%.2lf,%.2lf,%.2lf,%.2lf))),\n", param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][3]);
	printf("    }\n");
	printf("    GravityFF{\n");
	printf("        nmTorqueMax: %.2lf,%.2lf,%.2lf\n", param.servoParam.gravityFF.nmTorqueMax[0], param.servoParam.gravityFF.nmTorqueMax[1], param.servoParam.gravityFF.nmTorqueMax[2]);
	printf("        radPhase: %.2lf,%.2lf,%.2lf\n", param.servoParam.gravityFF.radPhase[0], param.servoParam.gravityFF.radPhase[1], param.servoParam.gravityFF.radPhase[2]);
	printf("    }\n");
	printf("    Estimate{\n");
	printf("        gain: %.2lf,%.2lf,%.2lf\n", param.servoParam.estimate.gain[0], param.servoParam.estimate.gain[1], param.servoParam.estimate.gain[2]);
	printf("        sTimeSet: %.2lf,%.2lf,%.2lf\n", param.servoParam.estimate.sTimeSet[0], param.servoParam.estimate.sTimeSet[1], param.servoParam.estimate.sTimeSet[2]);
	printf("    }\n");
	printf("}\n");
	printf("FineMapper{\n");
	printf("    M00: %lf\n", param.fineMapperParam.m[0][0]);
	printf("    M01: %lf\n", param.fineMapperParam.m[0][1]);
	printf("    M02: %lf\n", param.fineMapperParam.m[0][2]);
	printf("    M10: %lf\n", param.fineMapperParam.m[1][0]);
	printf("    M11: %lf\n", param.fineMapperParam.m[1][1]);
	printf("    M12: %lf\n", param.fineMapperParam.m[1][2]);
	printf("    M20: %lf\n", param.fineMapperParam.m[2][0]);
	printf("    M21: %lf\n", param.fineMapperParam.m[2][1]);
	printf("    M22: %lf\n", param.fineMapperParam.m[2][2]);
	printf("}\n");
}

int ParameterFileReader::readString(const char* fieldName,const json field,char* dst,int32_t maxLen, uint8_t skipIfNull) {
	if (field.is_null() && skipIfNull) {
		return 0;
	}

	int errorFlag = 0;
	dst[0] = 0;
	try {
		std::string tmp;
		tmp = field.get<std::string>();
		int len = tmp.length() + 1;
		if (len > maxLen) {
			throw path_too_long(tmp.c_str());
		}
		snprintf(dst, maxLen, "%s", tmp.c_str());
	}
	catch (json::parse_error e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::invalid_iterator e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::type_error e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::out_of_range e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::other_error e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (path_too_long e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (std::exception e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}

	if (errorFlag) {
		return -1;
	}
	else {
		return 0;
	}
}

int ParameterFileReader::readDouble(const char* fieldName, const json field, double& dst, double factor, uint8_t skipIfNull) {
	if (field.is_null() && skipIfNull) {
		return 0;
	}

	int errorFlag = 0;
	try {
		dst = field.get<double>() * factor;
	}
	catch (json::parse_error e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::invalid_iterator e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::type_error e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::out_of_range e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::other_error e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (path_too_long e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (std::exception e) {
		fprintf(stderr, "aError at parsing %s, \n", fieldName);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}

	if (errorFlag) {
		return -1;
	}
	else {
		return 0;
	}
}

int ParameterFileReader::readSystemParameters(const char* filename, SystemParameters& param, uint8_t allowPartialRead) {
	std::ifstream ifs(filename, std::ios::in);
	if (ifs.fail()) {
		fprintf(stderr, "local parameter file %s not found\n", filename);
		return -1;
	}

	char* parsePhase = (char*)SystemParameterParsePhase.None;
	int32_t errorFlag = 0;
	std::string tmp;
	int32_t len;

	//TODO:�����l�ݒ�

	try {
		json j;
		ifs >> j;

		errorFlag |= readString((char*)SystemParameterParsePhase.Logging_Path, j["Logging"]["Path"], param.logDir, _MAX_FNAME, allowPartialRead);
		
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_MasterController_IP, j["Network"]["MasterController"]["IP"], param.masterUdpParam.ipaddr_str, IPADDR_STR_SZ, allowPartialRead);
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_MasterController_RecvPort, j["Network"]["MasterController"]["RecvPort"], param.masterUdpParam.recvPort, PORT_STR_SZ,allowPartialRead);
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_MasterController_SendPort, j["Network"]["MasterController"]["SendPort"], param.masterUdpParam.sendPort, PORT_STR_SZ, allowPartialRead);
		
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_ImgProcWide_IP, j["Network"]["ImgProcWide"]["IP"], param.imgProcUdpParam[0].ipaddr_str, IPADDR_STR_SZ, allowPartialRead);
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_ImgProcWide_SendPort, j["Network"]["ImgProcWide"]["SendPort"], param.imgProcUdpParam[0].sendPort, PORT_STR_SZ, allowPartialRead);
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_ImgProcWide_RecvPort, j["Network"]["ImgProcWide"]["RecvPort"], param.imgProcUdpParam[0].recvPort, PORT_STR_SZ, allowPartialRead);

		errorFlag |= readString((char*)SystemParameterParsePhase.Network_ImgProcTele_IP, j["Network"]["ImgProcTele"]["IP"], param.imgProcUdpParam[1].ipaddr_str, IPADDR_STR_SZ, allowPartialRead);
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_ImgProcTele_SendPort, j["Network"]["ImgProcTele"]["SendPort"], param.imgProcUdpParam[1].sendPort, PORT_STR_SZ, allowPartialRead);
		errorFlag |= readString((char*)SystemParameterParsePhase.Network_ImgProcTele_RecvPort, j["Network"]["ImgProcTele"]["RecvPort"], param.imgProcUdpParam[1].recvPort, PORT_STR_SZ, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_NmTorqueLimit, j["Servo"]["All"]["NmTorqueLimit"][0], param.servoParam.all.nmToqrueLimit[0],1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_NmTorqueLimit, j["Servo"]["All"]["NmTorqueLimit"][1], param.servoParam.all.nmToqrueLimit[1],1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_NmTorqueLimit, j["Servo"]["All"]["NmTorqueLimit"][2], param.servoParam.all.nmToqrueLimit[2],1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_RpmVelocityLimit, j["Servo"]["All"]["RpmVelocityLimit"][0], param.servoParam.all.rpsVelocityLimit[0], 1.0 / 60 * 2 * M_PI, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_RpmVelocityLimit, j["Servo"]["All"]["RpmVelocityLimit"][1], param.servoParam.all.rpsVelocityLimit[1], 1.0 / 60 * 2 * M_PI, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_RpmVelocityLimit, j["Servo"]["All"]["RpmVelocityLimit"][2], param.servoParam.all.rpsVelocityLimit[2], 1.0 / 60 * 2 * M_PI, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_DegAngleLimit, j["Servo"]["All"]["DegAngleLimit"][0][0], param.servoParam.all.radAngleLimit[0][0], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_DegAngleLimit, j["Servo"]["All"]["DegAngleLimit"][0][1], param.servoParam.all.radAngleLimit[0][1], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_DegAngleLimit, j["Servo"]["All"]["DegAngleLimit"][1][0], param.servoParam.all.radAngleLimit[1][0], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_DegAngleLimit, j["Servo"]["All"]["DegAngleLimit"][1][1], param.servoParam.all.radAngleLimit[1][1], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_DegAngleLimit, j["Servo"]["All"]["DegAngleLimit"][2][0], param.servoParam.all.radAngleLimit[2][0], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_All_DegAngleLimit, j["Servo"]["All"]["DegAngleLimit"][2][1], param.servoParam.all.radAngleLimit[2][1], M_PI / 180, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_DegpsRateLimit, j["Servo"]["Reference"]["DegpsRateLimit"][0], param.servoParam.reference.rpsRateLimit[0], M_PI/180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_DegpsRateLimit, j["Servo"]["Reference"]["DegpsRateLimit"][1], param.servoParam.reference.rpsRateLimit[1], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_DegpsRateLimit, j["Servo"]["Reference"]["DegpsRateLimit"][2], param.servoParam.reference.rpsRateLimit[2], M_PI / 180, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_Degps2RateLimit, j["Servo"]["Reference"]["Degps2RateLimit"][0][0], param.servoParam.reference.rps2RateLimit[0][0], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_Degps2RateLimit, j["Servo"]["Reference"]["Degps2RateLimit"][0][1], param.servoParam.reference.rps2RateLimit[0][1], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_Degps2RateLimit, j["Servo"]["Reference"]["Degps2RateLimit"][1][0], param.servoParam.reference.rps2RateLimit[1][0], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_Degps2RateLimit, j["Servo"]["Reference"]["Degps2RateLimit"][1][1], param.servoParam.reference.rps2RateLimit[1][1], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_Degps2RateLimit, j["Servo"]["Reference"]["Degps2RateLimit"][2][0], param.servoParam.reference.rps2RateLimit[2][0], M_PI / 180, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Reference_Degps2RateLimit, j["Servo"]["Reference"]["Degps2RateLimit"][2][1], param.servoParam.reference.rps2RateLimit[2][1], M_PI / 180, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Sensor_HzFVelocityFilter, j["Servo"]["Sensor"]["HzFVelocityFilter"][0], param.servoParam.sensor.hzFVelecityFilter[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Sensor_HzFVelocityFilter, j["Servo"]["Sensor"]["HzFVelocityFilter"][1], param.servoParam.sensor.hzFVelecityFilter[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Sensor_HzFVelocityFilter, j["Servo"]["Sensor"]["HzFVelocityFilter"][2], param.servoParam.sensor.hzFVelecityFilter[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Sensor_ZetaVelocityFilter, j["Servo"]["Sensor"]["ZetaVelocityFilter"][0], param.servoParam.sensor.zetaVelocityFilter[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Sensor_ZetaVelocityFilter, j["Servo"]["Sensor"]["ZetaVelocityFilter"][1], param.servoParam.sensor.zetaVelocityFilter[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Sensor_ZetaVelocityFilter, j["Servo"]["Sensor"]["ZetaVelocityFilter"][2], param.servoParam.sensor.zetaVelocityFilter[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_VelocityControl_PGain, j["Servo"]["VelocityControl"]["PGain"][0], param.servoParam.velocityControl.pGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_VelocityControl_PGain, j["Servo"]["VelocityControl"]["PGain"][1], param.servoParam.velocityControl.pGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_VelocityControl_PGain, j["Servo"]["VelocityControl"]["PGain"][2], param.servoParam.velocityControl.pGain[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_VelocityControl_IGain, j["Servo"]["VelocityControl"]["IGain"][0], param.servoParam.velocityControl.iGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_VelocityControl_IGain, j["Servo"]["VelocityControl"]["IGain"][1], param.servoParam.velocityControl.iGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_VelocityControl_IGain, j["Servo"]["VelocityControl"]["IGain"][2], param.servoParam.velocityControl.iGain[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_AngleControl_PGain, j["Servo"]["AngleControl"]["PGain"][0], param.servoParam.angleControl.pGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_AngleControl_PGain, j["Servo"]["AngleControl"]["PGain"][1], param.servoParam.angleControl.pGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_AngleControl_PGain, j["Servo"]["AngleControl"]["PGain"][2], param.servoParam.angleControl.pGain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_AngleControl_IGain, j["Servo"]["AngleControl"]["IGain"][0], param.servoParam.angleControl.iGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_AngleControl_IGain, j["Servo"]["AngleControl"]["IGain"][1], param.servoParam.angleControl.iGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_AngleControl_IGain, j["Servo"]["AngleControl"]["IGain"][2], param.servoParam.angleControl.iGain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_PGain, j["Servo"]["TrackControl"]["PGain"][0], param.servoParam.trackControl.pGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_PGain, j["Servo"]["TrackControl"]["PGain"][1], param.servoParam.trackControl.pGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_PGain, j["Servo"]["TrackControl"]["PGain"][2], param.servoParam.trackControl.pGain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_IGain, j["Servo"]["TrackControl"]["IGain"][0], param.servoParam.trackControl.iGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_IGain, j["Servo"]["TrackControl"]["IGain"][1], param.servoParam.trackControl.iGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_IGain, j["Servo"]["TrackControl"]["IGain"][2], param.servoParam.trackControl.iGain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_DGain, j["Servo"]["TrackControl"]["DGain"][0], param.servoParam.trackControl.dGain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_DGain, j["Servo"]["TrackControl"]["DGain"][1], param.servoParam.trackControl.dGain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_TrackControl_DGain, j["Servo"]["TrackControl"]["DGain"][2], param.servoParam.trackControl.dGain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_HzF, j["Servo"]["Notch"]["HzF"][0], param.servoParam.notch.hzF[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_HzF, j["Servo"]["Notch"]["HzF"][1], param.servoParam.notch.hzF[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_HzF, j["Servo"]["Notch"]["HzF"][2], param.servoParam.notch.hzF[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_W, j["Servo"]["Notch"]["W"][0], param.servoParam.notch.w[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_W, j["Servo"]["Notch"]["W"][1], param.servoParam.notch.w[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_W, j["Servo"]["Notch"]["W"][2], param.servoParam.notch.w[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_D, j["Servo"]["Notch"]["D"][0], param.servoParam.notch.d[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_D, j["Servo"]["Notch"]["D"][1], param.servoParam.notch.d[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Notch_D, j["Servo"]["Notch"]["D"][2], param.servoParam.notch.d[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLag, j["Servo"]["PhaseComp"]["HzFLag"][0][0], param.servoParam.phaseComp.hzFLag[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLag, j["Servo"]["PhaseComp"]["HzFLag"][0][1], param.servoParam.phaseComp.hzFLag[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLag, j["Servo"]["PhaseComp"]["HzFLag"][1][0], param.servoParam.phaseComp.hzFLag[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLag, j["Servo"]["PhaseComp"]["HzFLag"][1][1], param.servoParam.phaseComp.hzFLag[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLag, j["Servo"]["PhaseComp"]["HzFLag"][2][0], param.servoParam.phaseComp.hzFLag[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLag, j["Servo"]["PhaseComp"]["HzFLag"][2][1], param.servoParam.phaseComp.hzFLag[2][1], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALag, j["Servo"]["PhaseComp"]["ALag"][0][0], param.servoParam.phaseComp.aLag[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALag, j["Servo"]["PhaseComp"]["ALag"][0][1], param.servoParam.phaseComp.aLag[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALag, j["Servo"]["PhaseComp"]["ALag"][1][0], param.servoParam.phaseComp.aLag[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALag, j["Servo"]["PhaseComp"]["ALag"][1][1], param.servoParam.phaseComp.aLag[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALag, j["Servo"]["PhaseComp"]["ALag"][2][0], param.servoParam.phaseComp.aLag[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALag, j["Servo"]["PhaseComp"]["ALag"][2][1], param.servoParam.phaseComp.aLag[2][1], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLead, j["Servo"]["PhaseComp"]["HzFLead"][0][0], param.servoParam.phaseComp.hzFLead[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLead, j["Servo"]["PhaseComp"]["HzFLead"][0][1], param.servoParam.phaseComp.hzFLead[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLead, j["Servo"]["PhaseComp"]["HzFLead"][1][0], param.servoParam.phaseComp.hzFLead[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLead, j["Servo"]["PhaseComp"]["HzFLead"][1][1], param.servoParam.phaseComp.hzFLead[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLead, j["Servo"]["PhaseComp"]["HzFLead"][2][0], param.servoParam.phaseComp.hzFLead[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_HzFLead, j["Servo"]["PhaseComp"]["HzFLead"][2][1], param.servoParam.phaseComp.hzFLead[2][1], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALead, j["Servo"]["PhaseComp"]["ALead"][0][0], param.servoParam.phaseComp.aLead[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALead, j["Servo"]["PhaseComp"]["ALead"][0][1], param.servoParam.phaseComp.aLead[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALead, j["Servo"]["PhaseComp"]["ALead"][1][0], param.servoParam.phaseComp.aLead[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALead, j["Servo"]["PhaseComp"]["ALead"][1][1], param.servoParam.phaseComp.aLead[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALead, j["Servo"]["PhaseComp"]["ALead"][2][0], param.servoParam.phaseComp.aLead[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_PhaseComp_ALead, j["Servo"]["PhaseComp"]["ALead"][2][1], param.servoParam.phaseComp.aLead[2][1], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Gain, j["Servo"]["DOB"]["Gain"][0], param.servoParam.dob.gain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Gain, j["Servo"]["DOB"]["Gain"][1], param.servoParam.dob.gain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Gain, j["Servo"]["DOB"]["Gain"][2], param.servoParam.dob.gain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Kgm2Inertia, j["Servo"]["DOB"]["Kgm2Inertia"][0], param.servoParam.dob.kgm2Inertia[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Kgm2Inertia, j["Servo"]["DOB"]["Kgm2Inertia"][1], param.servoParam.dob.kgm2Inertia[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Kgm2Inertia, j["Servo"]["DOB"]["Kgm2Inertia"][2], param.servoParam.dob.kgm2Inertia[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_HzF, j["Servo"]["DOB"]["HzF"][0], param.servoParam.dob.hzF[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_HzF, j["Servo"]["DOB"]["HzF"][1], param.servoParam.dob.hzF[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_HzF, j["Servo"]["DOB"]["HzF"][2], param.servoParam.dob.hzF[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Zeta, j["Servo"]["DOB"]["Zeta"][0], param.servoParam.dob.zeta[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Zeta, j["Servo"]["DOB"]["Zeta"][1], param.servoParam.dob.zeta[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_Zeta, j["Servo"]["DOB"]["Zeta"][2], param.servoParam.dob.zeta[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_GainDCDOB, j["Servo"]["DOB"]["GainDCDOB"][0], param.servoParam.dob.gainDCDOB[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_GainDCDOB, j["Servo"]["DOB"]["GainDCDOB"][1], param.servoParam.dob.gainDCDOB[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DOB_GainDCDOB, j["Servo"]["DOB"]["GainDCDOB"][2], param.servoParam.dob.gainDCDOB[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_Kgm2Inertia, j["Servo"]["InertialFF"]["Kgm2Inertia"][0], param.servoParam.inertialFF.kgm2Inertia[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_Kgm2Inertia, j["Servo"]["InertialFF"]["Kgm2Inertia"][1], param.servoParam.inertialFF.kgm2Inertia[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_Kgm2Inertia, j["Servo"]["InertialFF"]["Kgm2Inertia"][2], param.servoParam.inertialFF.kgm2Inertia[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_HzF, j["Servo"]["InertialFF"]["HzF"][0], param.servoParam.inertialFF.hzF[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_HzF, j["Servo"]["InertialFF"]["HzF"][1], param.servoParam.inertialFF.hzF[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_HzF, j["Servo"]["InertialFF"]["HzF"][2], param.servoParam.inertialFF.hzF[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_Zeta, j["Servo"]["InertialFF"]["Zeta"][0], param.servoParam.inertialFF.zeta[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_Zeta, j["Servo"]["InertialFF"]["Zeta"][1], param.servoParam.inertialFF.zeta[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_InertiaFF_Zeta, j["Servo"]["InertialFF"]["Zeta"][2], param.servoParam.inertialFF.zeta[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_Mode, j["Servo"]["FrictionFF"]["Mode"][0], param.servoParam.frictionFF.mode[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_Mode, j["Servo"]["FrictionFF"]["Mode"][1], param.servoParam.frictionFF.mode[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_Mode, j["Servo"]["FrictionFF"]["Mode"][2], param.servoParam.frictionFF.mode[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][0][0], param.servoParam.frictionFF.nmFc[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][0][1], param.servoParam.frictionFF.nmFc[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][0][2], param.servoParam.frictionFF.nmFc[0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][0][3], param.servoParam.frictionFF.nmFc[0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][0][4], param.servoParam.frictionFF.nmFc[0][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][0][5], param.servoParam.frictionFF.nmFc[0][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][1][0], param.servoParam.frictionFF.nmFc[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][1][1], param.servoParam.frictionFF.nmFc[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][1][2], param.servoParam.frictionFF.nmFc[1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][1][3], param.servoParam.frictionFF.nmFc[1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][1][4], param.servoParam.frictionFF.nmFc[1][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][1][5], param.servoParam.frictionFF.nmFc[1][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][2][0], param.servoParam.frictionFF.nmFc[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][2][1], param.servoParam.frictionFF.nmFc[2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][2][2], param.servoParam.frictionFF.nmFc[2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][2][3], param.servoParam.frictionFF.nmFc[2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][2][4], param.servoParam.frictionFF.nmFc[2][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFc, j["Servo"]["FrictionFF"]["NmFc"][2][5], param.servoParam.frictionFF.nmFc[2][5], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][0][0], param.servoParam.frictionFF.nmFs[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][0][1], param.servoParam.frictionFF.nmFs[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][0][2], param.servoParam.frictionFF.nmFs[0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][0][3], param.servoParam.frictionFF.nmFs[0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][0][4], param.servoParam.frictionFF.nmFs[0][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][0][5], param.servoParam.frictionFF.nmFs[0][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][1][0], param.servoParam.frictionFF.nmFs[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][1][1], param.servoParam.frictionFF.nmFs[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][1][2], param.servoParam.frictionFF.nmFs[1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][1][3], param.servoParam.frictionFF.nmFs[1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][1][4], param.servoParam.frictionFF.nmFs[1][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][1][5], param.servoParam.frictionFF.nmFs[1][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][2][0], param.servoParam.frictionFF.nmFs[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][2][1], param.servoParam.frictionFF.nmFs[2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][2][2], param.servoParam.frictionFF.nmFs[2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][2][3], param.servoParam.frictionFF.nmFs[2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][2][4], param.servoParam.frictionFF.nmFs[2][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmFs, j["Servo"]["FrictionFF"]["NmFs"][2][5], param.servoParam.frictionFF.nmFs[2][5], 1, allowPartialRead);
	
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmsprViscocity, j["Servo"]["FrictionFF"]["NmsprViscocity"][0], param.servoParam.frictionFF.nmsprViscocity[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmsprViscocity, j["Servo"]["FrictionFF"]["NmsprViscocity"][1], param.servoParam.frictionFF.nmsprViscocity[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmsprViscocity, j["Servo"]["FrictionFF"]["NmsprViscocity"][2], param.servoParam.frictionFF.nmsprViscocity[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][0][0], param.servoParam.frictionFF.nmprStiffness[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][0][1], param.servoParam.frictionFF.nmprStiffness[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][0][2], param.servoParam.frictionFF.nmprStiffness[0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][0][3], param.servoParam.frictionFF.nmprStiffness[0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][0][4], param.servoParam.frictionFF.nmprStiffness[0][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][0][5], param.servoParam.frictionFF.nmprStiffness[0][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][1][0], param.servoParam.frictionFF.nmprStiffness[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][1][1], param.servoParam.frictionFF.nmprStiffness[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][1][2], param.servoParam.frictionFF.nmprStiffness[1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][1][3], param.servoParam.frictionFF.nmprStiffness[1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][1][4], param.servoParam.frictionFF.nmprStiffness[1][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][1][5], param.servoParam.frictionFF.nmprStiffness[1][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][2][0], param.servoParam.frictionFF.nmprStiffness[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][2][1], param.servoParam.frictionFF.nmprStiffness[2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][2][2], param.servoParam.frictionFF.nmprStiffness[2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][2][3], param.servoParam.frictionFF.nmprStiffness[2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][2][4], param.servoParam.frictionFF.nmprStiffness[2][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_NmprStiffness, j["Servo"]["FrictionFF"]["NmprStiffness"][2][5], param.servoParam.frictionFF.nmprStiffness[2][5], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][0][0], param.servoParam.frictionFF.attractionParameter[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][0][1], param.servoParam.frictionFF.attractionParameter[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][0][2], param.servoParam.frictionFF.attractionParameter[0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][0][3], param.servoParam.frictionFF.attractionParameter[0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][0][4], param.servoParam.frictionFF.attractionParameter[0][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][0][5], param.servoParam.frictionFF.attractionParameter[0][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][1][0], param.servoParam.frictionFF.attractionParameter[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][1][1], param.servoParam.frictionFF.attractionParameter[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][1][2], param.servoParam.frictionFF.attractionParameter[1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][1][3], param.servoParam.frictionFF.attractionParameter[1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][1][4], param.servoParam.frictionFF.attractionParameter[1][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][1][5], param.servoParam.frictionFF.attractionParameter[1][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][2][0], param.servoParam.frictionFF.attractionParameter[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][2][1], param.servoParam.frictionFF.attractionParameter[2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][2][2], param.servoParam.frictionFF.attractionParameter[2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][2][3], param.servoParam.frictionFF.attractionParameter[2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][2][4], param.servoParam.frictionFF.attractionParameter[2][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_AttractionParameter, j["Servo"]["FrictionFF"]["AttractionParameter"][2][5], param.servoParam.frictionFF.attractionParameter[2][5], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][0][0], param.servoParam.frictionFF.rpsStribeckVelocity[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][0][1], param.servoParam.frictionFF.rpsStribeckVelocity[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][0][2], param.servoParam.frictionFF.rpsStribeckVelocity[0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][0][3], param.servoParam.frictionFF.rpsStribeckVelocity[0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][0][4], param.servoParam.frictionFF.rpsStribeckVelocity[0][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][0][5], param.servoParam.frictionFF.rpsStribeckVelocity[0][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][1][0], param.servoParam.frictionFF.rpsStribeckVelocity[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][1][1], param.servoParam.frictionFF.rpsStribeckVelocity[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][1][2], param.servoParam.frictionFF.rpsStribeckVelocity[1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][1][3], param.servoParam.frictionFF.rpsStribeckVelocity[1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][1][4], param.servoParam.frictionFF.rpsStribeckVelocity[1][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][1][5], param.servoParam.frictionFF.rpsStribeckVelocity[1][5], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][2][0], param.servoParam.frictionFF.rpsStribeckVelocity[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][2][1], param.servoParam.frictionFF.rpsStribeckVelocity[2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][2][2], param.servoParam.frictionFF.rpsStribeckVelocity[2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][2][3], param.servoParam.frictionFF.rpsStribeckVelocity[2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][2][4], param.servoParam.frictionFF.rpsStribeckVelocity[2][4], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_FrictionFF_RpsStribeckVelocity, j["Servo"]["FrictionFF"]["RpsStribeckVelocity"][2][5], param.servoParam.frictionFF.rpsStribeckVelocity[2][5], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_Gain, j["Servo"]["DecoupleFF"]["Gain"][0], param.servoParam.decoupleFF.gain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_Gain, j["Servo"]["DecoupleFF"]["Gain"][1], param.servoParam.decoupleFF.gain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_Gain, j["Servo"]["DecoupleFF"]["Gain"][2], param.servoParam.decoupleFF.gain[2], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][0][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][0][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][0][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][0][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][1][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][1][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][1][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][1][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][2][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][2][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][2][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][2][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][3][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][3][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][3][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][0][3][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[0][3][3], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][0][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][0][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][0][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][0][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][1][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][1][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][1][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][1][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][2][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][2][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][2][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][2][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][3][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][3][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][3][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][1][3][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[1][3][3], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][0][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][0][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][0][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][0][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][0][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][1][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][1][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][1][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][1][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][1][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][2][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][2][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][2][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][2][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][2][3], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][3][0], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][3][1], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][3][2], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_DecoupleFF_PsuedoInertiaMatrix, j["Servo"]["DecoupleFF"]["PseudoInertiaMatrix"][2][3][3], param.servoParam.decoupleFF.pseudoInertiaMatrix[2][3][3], 1, allowPartialRead);

		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_GravityFF_NmTorqueMax, j["Servo"]["GravityFF"]["NmTorqueMax"][0], param.servoParam.gravityFF.nmTorqueMax[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_GravityFF_NmTorqueMax, j["Servo"]["GravityFF"]["NmTorqueMax"][1], param.servoParam.gravityFF.nmTorqueMax[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_GravityFF_NmTorqueMax, j["Servo"]["GravityFF"]["NmTorqueMax"][2], param.servoParam.gravityFF.nmTorqueMax[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_GravityFF_RadPhase, j["Servo"]["GravityFF"]["RadPhase"][0], param.servoParam.gravityFF.radPhase[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_GravityFF_RadPhase, j["Servo"]["GravityFF"]["RadPhase"][1], param.servoParam.gravityFF.radPhase[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_GravityFF_RadPhase, j["Servo"]["GravityFF"]["RadPhase"][2], param.servoParam.gravityFF.radPhase[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Estimate_Gain, j["Servo"]["Estimate"]["Gain"][0], param.servoParam.estimate.gain[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Estimate_Gain, j["Servo"]["Estimate"]["Gain"][1], param.servoParam.estimate.gain[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Estimate_Gain, j["Servo"]["Estimate"]["Gain"][2], param.servoParam.estimate.gain[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Estimate_STimeSet, j["Servo"]["Estimate"]["STimeSet"][0], param.servoParam.estimate.sTimeSet[0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Estimate_STimeSet, j["Servo"]["Estimate"]["STimeSet"][1], param.servoParam.estimate.sTimeSet[1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.Servo_Estimate_STimeSet, j["Servo"]["Estimate"]["STimeSet"][2], param.servoParam.estimate.sTimeSet[2], 1, allowPartialRead);
		
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][0][0], param.fineMapperParam.m[0][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][0][1], param.fineMapperParam.m[0][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][0][2], param.fineMapperParam.m[0][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][1][0], param.fineMapperParam.m[1][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][1][1], param.fineMapperParam.m[1][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][1][2], param.fineMapperParam.m[1][2], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][2][0], param.fineMapperParam.m[2][0], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][2][1], param.fineMapperParam.m[2][1], 1, allowPartialRead);
		errorFlag |= readDouble((char*)SystemParameterParsePhase.FineMapper_M, j["FineMapper"]["M"][2][2], param.fineMapperParam.m[2][2], 1, allowPartialRead);

	}
	catch (json::parse_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::invalid_iterator e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::type_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::out_of_range e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::other_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (path_too_long e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (std::exception e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}

	if (errorFlag) {
		return -1;
	}

	return 0;
}

//Phase text for error message.
struct {
	const char* None = "None";
	const char* Simulate = "SIMULATE";
}MasterModeParsePhase;

void ParameterFileReader::printBootMode(OperationMode& param) {
	printf("\n");
	printf("============ BootModeParameters ==============\n");
	printf("MODE: \n");
	printf("{\n");
	if (param == OperationMode::NORMAL) {
		printf("    NORMAL_OPERATION\n");
	}
	else if (param == OperationMode::TRAINING) {
		printf("    TRAINING\n");
	}
	else if (param == OperationMode::PARAMETER_ERROR) {
		printf("    PARAMETER_ERROR\n");
	}
	printf("}\n");
}

int ParameterFileReader::readOperationMode(const char* filename, OperationMode& param) {
	std::ifstream ifs(filename, std::ios::in);
	if (ifs.fail()) {
		fprintf(stderr, "local parameter file %s not found\n", filename);
		return -1;
	}

	char* parsePhase = (char*)MasterModeParsePhase.None;
	int32_t errorFlag = 0;
	std::string tmp;
	int32_t len;
	int32_t mode;

	try {
		json j;
		ifs >> j;
		parsePhase = (char*)MasterModeParsePhase.Simulate;
		mode = j["MODE"]["SIMULATE"].get<int>();
		if (mode == 0) {
			param = OperationMode::NORMAL;
		}
		else if(mode == 1) {
			param = OperationMode::TRAINING;
		}
		else {
			param = OperationMode::PARAMETER_ERROR;
		}
	}
	catch (json::parse_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::invalid_iterator e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::type_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::out_of_range e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::other_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (path_too_long e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (std::exception e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}

	if (errorFlag) {
		return -1;
	}

	return 0;
}

//Phase text for error message.
struct {
	const char* None = "None";
	const char* MAdccsSafetyMargin = "LaserSafety/FriendlyPosition/mAdccsSafetyMargin";
	const char* DegSystemSafetyMargin = "LaserSafety/FriendlyPosition/degSystemSafetyMargin";
	const char* DegFixedAreaSafetyMargin = "LaserSafety/FixedArea/degFixedAreaSafetyMargin";
	const char* MHelSafeDistance = "LaserSafety/mHelSafeDistance";
	const char* MTilSafeDistance = "LaserSafety/mTilSafeDistance";
	const char* MpsFallSpeedCriteriaLow = "NeutralizationEstimation/mpsFallSpeedCriteriaLow";
	const char* MpsFallSpeedCriteriaHigh = "NeutralizationEstimation/mpsFallSpeedCriteriaHigh";
}UserParameterParsePhase;

void ParameterFileReader::printUserParameters(UserParameters& param) {
	printf("\n");
	printf("============ UserParameters ==============\n");
	printf("LaserSafety: {\n");
	printf("    FriendlyPosition{\n");
	printf("        mAdccsSafetyMargin: %lf\n",param.mAdccsSafetyMargin);
	printf("        degSystemSafetyMargin: %lf\n",param.radSystemSafetyMargin/M_PI*180);
	printf("    }\n");
	printf("    FixedArea: {\n");
	printf("        degFixedAreaSafetyMargin: %lf\n",param.radFixedAreaSafetyMargin/M_PI*180);
	printf("    }\n");
	printf("    mHelSafeDistance: %lf\n",param.mHelSafeDistance);
	printf("    mTilSafeDistance: %lf\n",param.mTilSafeDistance);
	printf("}\n");
	printf("NeutralizationEstimation{\n");
	printf("    mpsFallSpeedCriteriaLow: %d\n", param.mpsFallSpeedCriteriaLow);
	printf("    mpsFallSpeedCriteriaHigh: %d\n", param.mpsFallSpeedCriteriaHigh);
	printf("}\n");
}
int ParameterFileReader::readUserParameters(const char* filename, UserParameters& param) {
	std::ifstream ifs(filename, std::ios::in);
	if (ifs.fail()) {
		fprintf(stderr, "local parameter file %s not found\n", filename);
		return -1;
	}

	char* parsePhase = (char*)SystemParameterParsePhase.None;
	int32_t errorFlag = 0;
	std::string tmp;
	int32_t len;
	int32_t mode;

	try {
		json j;
		ifs >> j;
		parsePhase = (char*)UserParameterParsePhase.MAdccsSafetyMargin;
		param.mAdccsSafetyMargin = j["LaserSafety"]["FriendlyPosition"]["mAdccsSafetyMargin"].get<double>();
		
		parsePhase = (char*)UserParameterParsePhase.DegSystemSafetyMargin;
		param.radSystemSafetyMargin = j["LaserSafety"]["FriendlyPosition"]["degSystemSafetyMargin"].get<double>() / 180 * M_PI;

		parsePhase = (char*)UserParameterParsePhase.DegFixedAreaSafetyMargin;
		param.radFixedAreaSafetyMargin = j["LaserSafety"]["FixedArea"]["degFixedAreaSafetyMargin"].get<double>() / 180 * M_PI;

		parsePhase = (char*)UserParameterParsePhase.MHelSafeDistance;
		param.mHelSafeDistance = j["LaserSafety"]["mHelSafeDistance"].get<double>();

		parsePhase = (char*)UserParameterParsePhase.MTilSafeDistance;
		param.mTilSafeDistance = j["LaserSafety"]["mTilSafeDistance"].get<double>();

		parsePhase = (char*)UserParameterParsePhase.MpsFallSpeedCriteriaLow;
		param.mpsFallSpeedCriteriaLow = j["NeutralizationEstimation"]["mpsFallSpeedCriteriaLow"].get<int16_t>();

		parsePhase = (char*)UserParameterParsePhase.MpsFallSpeedCriteriaHigh;
		param.mpsFallSpeedCriteriaHigh = j["NeutralizationEstimation"]["mpsFallSpeedCriteriaHigh"].get<int16_t>();
	}
	catch (json::parse_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::invalid_iterator e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::type_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::out_of_range e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (json::other_error e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (path_too_long e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}
	catch (std::exception e) {
		fprintf(stderr, "Error at parsing %s, \n", parsePhase);
		fprintf(stderr, "%s\n", e.what());
		errorFlag = 1;
	}

	if (errorFlag) {
		return -1;
	}

	return 0;
}