#pragma once

#include "stdint.h"
#include "ntx.h"

#pragma pack(1)

typedef struct {
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	DWORD dwMicroseconds;
}RT_SYSTEMTIME;

#pragma pack()
