#pragma once

#include "ntx.h"
#include "stdint.h"
#include "NtxTime.h"
#include "CatalogNames.h"

enum class MySharedMemoryStatus {
	OK = 0,
	FIND_LOCATION_FAIL = -1,
	FIND_ROOTPROCESS_FAIL = -2,
	FIND_SHAREDMEMORY_FAIL = -3,
	MAP_SHAREDMEMORY_FAIL = -4,
	FIND_SEM_FAIL = -5,
	ALLOCATE_LOCALMEMORY_FAIL = -6,
	TIMEOUT = 7,
	SEM_ERROR = 8,
};

template<typename T>
class NtxSharedMemory{
private:
	#pragma pack(1)

	struct SharedObject {
		int8_t updated;
		RT_SYSTEMTIME updateTime;
		T data;
	};

	#pragma pack()

	NTXHANDLE sem;
	NTXHANDLE memHandle;
	SharedObject* buffer;

	int8_t updated;
	RT_SYSTEMTIME updateTime;
public:
	NtxSharedMemory(const struct SharedMemoryCatalogNames names);
	~NtxSharedMemory();
	MySharedMemoryStatus copyFrom(T* dst, int32_t msWaitTime);
	MySharedMemoryStatus copyTo(T* src, int32_t msWaitTime);
	int32_t isOk();
	int8_t isUpdated();
	RT_SYSTEMTIME getUpdateTime();
};
