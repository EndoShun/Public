#pragma once

#include "IoStructs.h"
#include <fstream>
#include "nlohmann/json.hpp"

class path_too_long :std::exception {
private:
	const char* msg;
public:
	path_too_long(const char* msg) :msg(msg) {}
	const char* what() { return msg; }
};

class address_too_long :std::exception {
private:
	const char* msg;
public:
	address_too_long(const char* msg) :msg(msg) {}
	const char* what() { return msg; }
};

class port_too_long :std::exception {
private:
	const char* msg;
public:
	port_too_long(const char* msg) :msg(msg) {}
	const char* what() { return msg; }
};

class ParameterFileReader {
private:
	static constexpr int32_t MAX_LOG_PATH_LENGTH = 16;
	static int readString(const char* fieldName, const nlohmann::json field, char* dst, int32_t maxLen, uint8_t skipIfNull);
	static int readDouble(const char* fieldName, const nlohmann::json field, double& dst, double factor, uint8_t skipIfNull);
public:
	static void printSystemParameters(SystemParameters& param);
	static int readSystemParameters(const char* filename, SystemParameters& param, uint8_t allowPartialRead);
	static void printBootMode(OperationMode& param);
	static int readOperationMode(const char* filename, OperationMode& param);
	static void printUserParameters(UserParameters& param);
	static int readUserParameters(const char* filename, UserParameters& param);
};