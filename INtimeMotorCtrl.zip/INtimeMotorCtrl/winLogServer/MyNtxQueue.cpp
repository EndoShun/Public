
#include "MyNtxQueue.h"
#include "stdio.h"
#include "IoStructs.h"

template <class T>
MyNtxQueue<T>::MyNtxQueue(const char* queueHandleName, int32_t depth) {
	NTXHANDLE queueHandle = NTX_BAD_NTXHANDLE;
	try {
		NTXLOCATION loc = ntxGetLocationByName(SHARED_RESOURCE_NODE_NAME);
		if (loc == NTX_UNDEFINED_LOCATION) {
			printf("undefined location\n");
			throw 1;
		}
		if (ntxGetRtStatus(loc) != E_OK) {
			printf("bad location\n");
			throw 2;
		}

		NTXHANDLE rootProcess = ntxGetRootRtProcess(loc);
		if (rootProcess == NTX_BAD_NTXHANDLE) {
			printf("get root process fail\n");
			throw 3;
		}

		int32_t queueSize = depth * (sizeof(SharedObject) + BYTES_MSG_OVERHEAD);
		queueHandle = ntxCreateRtQueue(loc, queueSize, sizeof(SharedObject), 0);
		if (queueHandle == NTX_BAD_NTXHANDLE) {
			printf("creating queue fail\n"); 
			throw 4;
		}

		NTXSTATUS status = ntxCatalogNtxHandle(rootProcess, queueHandle, (LPSTR)queueHandleName);
		if (status != E_OK) {
			printf("catalog queue fail. 0x%04x\n", status);
			throw 5;
		}

		this->queue = queueHandle;
	}
	catch(int error){
		if (queueHandle != NTX_BAD_NTXHANDLE) {
			ntxDeleteRtQueue(queueHandle);
		}

		this->queue = NTX_BAD_NTXHANDLE;
	}
}

template <class T>
MyNtxQueue<T>::~MyNtxQueue() {
	printf("MyNtxQueue.cpp Destructor removes: 0x%x\n",queue);
	if (queue != NTX_BAD_NTXHANDLE) {
		ntxDeleteRtQueue(queue);
	}
}
template <class T>
MyQueueStatus MyNtxQueue<T>::send(const T* msg) {
	SharedObject obj;
	memcpy(&obj.data,msg,sizeof(T));
	SYSTEMTIME systemTime;
	GetLocalTime(&systemTime);
	obj.sendTime.wYear = systemTime.wYear;
	obj.sendTime.wMonth = systemTime.wMonth;
	obj.sendTime.wDayOfWeek = systemTime.wDayOfWeek;
	obj.sendTime.wDay = systemTime.wDay;
	obj.sendTime.wHour = systemTime.wHour;
	obj.sendTime.wMinute = systemTime.wMinute;
	obj.sendTime.wSecond = systemTime.wSecond;
	obj.sendTime.dwMicroseconds = systemTime.wMilliseconds * 1000;

	BOOLEAN ret = ntxSendRtShortDataMessage(queue, (LPVOID)&obj, sizeof(SharedObject));
	if (ret == TRUE) {
		return MyQueueStatus::OK;
	}
	else {
		DWORD error = ntxGetLastRtError();
		if (error == E_LIMIT) {
			return MyQueueStatus::FULL;
		}
		else {
			return MyQueueStatus::QUEUE_ERROR;
		}
	}
}

template <class T>
int32_t MyNtxQueue<T>::isOk() {
	if (queue == NTX_BAD_NTXHANDLE) {
		return 0;
	}
	else {
		return 1;
	}
}

template <class T>
MyQueueStatus MyNtxQueue<T>::recv(T* buf, int32_t msWaitTime) {
	DWORD bytesReceived;
	SharedObject obj;
	BOOLEAN ret = ntxReceiveRtDataMessage(queue, (LPVOID)&obj, sizeof(SharedObject),msWaitTime,&bytesReceived);

	memcpy(buf,&obj.data,sizeof(T));
	sendTime = obj.sendTime;

	if (ret == TRUE) {
		return MyQueueStatus::OK;
	}
	else {
		DWORD error = ntxGetLastRtError();
		if (error == E_TIME) {
			return MyQueueStatus::TIMEOUT;
		}
		else {
			printf("error code: 0x%04x\n",error);
			return MyQueueStatus::QUEUE_ERROR;
		}
	}
}

template <class T>
RT_SYSTEMTIME MyNtxQueue<T>::getSendTime() {
	return sendTime;
}

template class MyNtxQueue<MasterToTurretCommand>;
template class MyNtxQueue<TurretToMasterResponse>;
template class MyNtxQueue<ImgProcToTurretResponse>;
template class MyNtxQueue<TurretToImgProcCommand>;
template class MyNtxQueue<ControlCommandAndStatus>;
template class MyNtxQueue<MessageLog>;
