
#include "NtxSharedMemory.h"
#include "stdio.h"
#include "ntx.h"
#include "IoStructs.h"

template<typename T>
NtxSharedMemory<T>::NtxSharedMemory(const struct SharedMemoryCatalogNames names) {
	NTXHANDLE memHandle = NTX_BAD_NTXHANDLE;
	NTXHANDLE semHandle = NTX_BAD_NTXHANDLE;
	try {
		NTXLOCATION loc = ntxGetLocationByName(SHARED_RESOURCE_NODE_NAME);
		if (loc == NTX_UNDEFINED_LOCATION) {
			printf("undefined location\n");
			throw 1;
		}
		if (ntxGetRtStatus(loc) != E_OK) {
			printf("bad location\n");
			throw 2;
		}

		NTXHANDLE rootProcess = ntxGetRootRtProcess(loc);
		if (rootProcess == NTX_BAD_NTXHANDLE) {
			printf("get root process fail\n");
			throw 3;
		}

		memHandle = ntxAllocateRtMemory(loc, sizeof(SharedObject));
		if (memHandle == NTX_BAD_NTXHANDLE) {
			printf("allocate fail\n");
			throw 4;
		}

		SharedObject* mem = (SharedObject*)ntxMapRtSharedMemoryEx(memHandle, NTX_MAP_WRITE | NTX_MAP_UNALIGNED);
		if (mem == NULL) {
			printf("map shared memory fail\n");
			throw 5;
		}
		else {
			memset(mem, 0, sizeof(SharedObject));
		}


		NTXSTATUS status = ntxCatalogNtxHandle(rootProcess, memHandle, (LPSTR)names.MemName);
		if (status != E_OK) {
			printf("catalog shared memory fail. 0x%04x\n", status);
			throw 6;
		}

		semHandle = ntxCreateRtSemaphore(loc, 1, 1, NTX_FIFO_QUEUING);
		if (semHandle == NTX_BAD_NTXHANDLE) {
			printf("creating sem fail");
			throw 7;
		}

		status = ntxCatalogNtxHandle(rootProcess, semHandle, (LPSTR)names.SemName);
		if (status != E_OK) {
			printf("catalog shared memory fail. 0x%04x\n", status);
			throw 8;
		}


		this->sem = semHandle;
		this->memHandle = memHandle;
		this->buffer = mem;
		updated = 0;
		memset(&updateTime, 0, sizeof(RT_SYSTEMTIME));
	}
	catch (int error) {
		if (semHandle != NTX_BAD_NTXHANDLE) {
			ntxDeleteRtSemaphore(semHandle);
		}
		if (memHandle != NTX_BAD_NTXHANDLE) {
			ntxFreeRtMemory(memHandle);
		}

		this->sem = NTX_BAD_NTXHANDLE;
		this->memHandle = NTX_BAD_NTXHANDLE;
		this->buffer = NULL;
		updated = 0;
		memset(&updateTime, 0, sizeof(RT_SYSTEMTIME));
	}
}

template<typename T>
NtxSharedMemory<T>::~NtxSharedMemory() {
	printf("NtxSharedMemory.cpp destrutor 0x%x, 0x%x\n",sem,memHandle);

	if (sem != NTX_BAD_NTXHANDLE) {
		ntxDeleteRtSemaphore(sem);
	}
	if (memHandle != NTX_BAD_NTXHANDLE) {
		ntxFreeRtMemory(memHandle);
	}
}

template<typename T>
int32_t NtxSharedMemory<T>::isOk() {
	if (memHandle == NTX_BAD_NTXHANDLE || sem == NTX_BAD_NTXHANDLE || buffer == NULL) {
		return 0;
	}
	else {
		return 1;
	}
}

template<typename T>
MySharedMemoryStatus NtxSharedMemory<T>::copyFrom(T* dst, int32_t msWaitTime) {
	if (ntxWaitForRtSemaphore(sem, 1, msWaitTime) == NTX_ERROR) {
		if (ntxGetLastRtError() == E_TIME) {
			return MySharedMemoryStatus::TIMEOUT;
		}
		else {
			return MySharedMemoryStatus::SEM_ERROR;
		}
	}

	memcpy(dst, &buffer->data, sizeof(T));
	updated = buffer->updated;
	updateTime = buffer->updateTime;
	buffer->updated = 0;

	ntxReleaseRtSemaphore(sem,1);

	return MySharedMemoryStatus::OK;
}

template<typename T>
MySharedMemoryStatus NtxSharedMemory<T>::copyTo(T* src, int32_t msWaitTime) {
	if (ntxWaitForRtSemaphore(sem, 1, msWaitTime) == NTX_ERROR) {
		if (ntxGetLastRtError() == E_TIME) {
			return MySharedMemoryStatus::TIMEOUT;
		}
		else {
			return MySharedMemoryStatus::SEM_ERROR;
		}
	}
	
	memcpy(&buffer->data, src, sizeof(T));
	buffer->updated = 1;
	SYSTEMTIME systemTime;
	GetLocalTime(&systemTime);
	buffer->updateTime.wYear = systemTime.wYear;
	buffer->updateTime.wMonth = systemTime.wMonth;
	buffer->updateTime.wDayOfWeek = systemTime.wDayOfWeek;
	buffer->updateTime.wDay = systemTime.wDay;
	buffer->updateTime.wHour = systemTime.wHour;
	buffer->updateTime.wMinute = systemTime.wMinute;
	buffer->updateTime.wSecond = systemTime.wSecond;
	buffer->updateTime.dwMicroseconds = systemTime.wMilliseconds*1000;

	ntxReleaseRtSemaphore(sem, 1);

	return MySharedMemoryStatus::OK;
}
template<typename T>
int8_t NtxSharedMemory<T>::isUpdated() {
	return updated;
}

template<typename T>
RT_SYSTEMTIME NtxSharedMemory<T>::getUpdateTime() {
	return updateTime;
}

template class NtxSharedMemory<MasterToTurretCommand>;
template class NtxSharedMemory<MasterToTurretCommand>;
template class NtxSharedMemory<TurretToMasterResponse>;
template class NtxSharedMemory<TurretToImgProcCommand>;
template class NtxSharedMemory<ImgProcToTurretResponse>;
template class NtxSharedMemory<BootParameters>;
template class NtxSharedMemory<RangefinderCommand>;
template class NtxSharedMemory<RangefinderStatus>;
template class NtxSharedMemory<WideCamLensCommand>;
template class NtxSharedMemory<WideCamLensStatus>;
template class NtxSharedMemory<LogStatus>;