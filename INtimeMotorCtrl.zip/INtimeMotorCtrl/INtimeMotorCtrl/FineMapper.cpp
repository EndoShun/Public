#include "FineMapper.h"
#include "math.h"

FineMapper::FineMapper() {
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (i == j) {
				M[i][j] = 1.0;
			}
			else {
				M[i][j] = 0.0;
			}
			
		}
	}
}

FineMapper::FineMapper(double M00, double M01, double M02, double M10, double M11, double M12, double M20, double M21, double M22) {
	M[0][0] = M00;
	M[0][1] = M01;
	M[0][2] = M02;
	M[1][0] = M10;
	M[1][1] = M11;
	M[1][2] = M12;
	M[2][0] = M20;
	M[2][1] = M21;
	M[2][2] = M22;
}

FineMapper::FineMapper(FineMapperParam param) {
	M[0][0] = param.m[0][0];
	M[0][1] = param.m[0][1];
	M[0][2] = param.m[0][2];
	M[1][0] = param.m[1][0];
	M[1][1] = param.m[1][1];
	M[1][2] = param.m[1][2];
	M[2][0] = param.m[2][0];
	M[2][1] = param.m[2][1];
	M[2][2] = param.m[2][2];
}

//double FineMapper::mapX(double pxX, double pxY, int16_t pxOffsetX, int16_t pxOffsetY,int32_t lrFlip,double radRotationCorrection) {
//	if (lrFlip < 0) {
//		pxX = 1920 - pxX;
//	}
//	pxX += (cos(radRotationCorrection) * pxOffsetX + sin(radRotationCorrection) * pxOffsetY);
//	pxY -= -sin(radRotationCorrection) * pxOffsetX + cos(radRotationCorrection) * pxOffsetY;
//
//
//	double x = (M[0][0] * pxX + M[0][1] * pxY + M[0][2]) / (M[2][0] * pxX + M[2][1] * pxY + M[2][2]);
//	if (x < -1.0) {
//		x = -1.0;
//	}
//	else if (x > 1.0) {
//		x = 1.0;
//	}
//	return x;
//}
//double FineMapper::mapY(double pxX, double pxY, int16_t pxOffsetX, int16_t pxOffsetY,int32_t lrFlip,double radRotationCorrection) {
//	if (lrFlip < 0) {
//		pxX = 1920 - pxX;
//	}
//	pxX += (cos(radRotationCorrection) * pxOffsetX + sin(radRotationCorrection) * pxOffsetY) * lrFlip;
//	pxY -= -sin(radRotationCorrection) * pxOffsetX + cos(radRotationCorrection) * pxOffsetY;
//
//
//	double y = (M[1][0] * pxX + M[1][1] * pxY + M[1][2]) / (M[2][0] * pxX + M[2][1] * pxY + M[2][2]);
//	if (y < -1.0) {
//		y = -1.0;
//	}
//	else if (y > 1.0) {
//		y = 1.0;
//	}
//	return y;
//}

double FineMapper::mapX(double pxX, double pxY) {

	double x = (M[0][0] * pxX + M[0][1] * pxY + M[0][2]) / (M[2][0] * pxX + M[2][1] * pxY + M[2][2]);
	if (x < -1.0) {
		x = -1.0;
	}
	else if (x > 1.0) {
		x = 1.0;
	}
	return x;
}
double FineMapper::mapY(double pxX, double pxY) {

	double y = (M[1][0] * pxX + M[1][1] * pxY + M[1][2]) / (M[2][0] * pxX + M[2][1] * pxY + M[2][2]);
	if (y < -1.0) {
		y = -1.0;
	}
	else if (y > 1.0) {
		y = 1.0;
	}
	return y;
}

double FineMapper::mapX(double pxX, double pxY, double xZoom) {
	pxX *= xZoom / X_CALIBRATION_POINT;
	pxY *= xZoom / X_CALIBRATION_POINT;

	double x = (M[0][0] * pxX + M[0][1] * pxY + M[0][2]) / (M[2][0] * pxX + M[2][1] * pxY + M[2][2]);
	if (x < -1.0) {
		x = -1.0;
	}
	else if (x > 1.0) {
		x = 1.0;
	}
	return x;
}
double FineMapper::mapY(double pxX, double pxY, double xZoom) {
	pxX *= xZoom / X_CALIBRATION_POINT;
	pxY *= xZoom / X_CALIBRATION_POINT;
	
	double y = (M[1][0] * pxX + M[1][1] * pxY + M[1][2]) / (M[2][0] * pxX + M[2][1] * pxY + M[2][2]);
	if (y < -1.0) {
		y = -1.0;
	}
	else if (y > 1.0) {
		y = 1.0;
	}
	return y;
}