/*****************************************************************************
* Poll1.c - �|�[�����O�̂��߂̃��W���[�� Poll1
\*****************************************************************************/



#include <stdio.h>
#include <rt.h>
#include <math.h>
#include <string.h>
//#include "MotorCtrl.h"
#include "ServoController/ServoController.h"
#include "INtimeMotorCtrl.h"
#include <traceapi.h>
#include <time.h>
#include <sys/time.h>
#include "malloc.h"

#include "PacketGenerator.h"

#include "RtSharedMemory.h"
#include "MyRtQueue.h"

#include "WideCamLensUtils.h"

static const int32_t CYCLES_MASTER_RECEIVE_TIMEOUT = 500;
static const int32_t CYCLES_IMG_PROC_RECEIVE_TIMEOUT = 500;

MyRtQueue<MessageLog> eventLoggingQueue;	//TODO: ���[�J���ϐ��ɖ߂��B

long usCalcTimeDiff(struct timeval t0, struct timeval t1) {
	return (t1.tv_sec - t0.tv_sec) * 1000000 + t1.tv_usec - t0.tv_usec;
}

/*****************************************************************************
* FUNCTION:		PollMotorCtrl
* DESCRIPTION:
*   �|�[�����O�X���b�h PollMotorCtrl
\*****************************************************************************/
void				PollMotorCtrl(
	void*				param)
{
	ULONG ret;
	int res;
	AXIS_INFO AxisInfo;

	/////////////////////////////////////////////////
	// Initialize thread utilities
	/////////////////////////////////////////////////
	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollMotorCtrl = GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollMotorCtrl, "TPollMotorCtrl");

	
	/////////////////////////////////////////////////
	// Setup shared resources
	/////////////////////////////////////////////////
	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<MasterToTurretCommand> masterToTurret;
	RtSharedMemory<TurretToMasterResponse> turretToMaster;
	RtSharedMemory<ImgProcToTurretResponse> imgProcToTurret[NUM_CAMS];
	RtSharedMemory<TurretToImgProcCommand> turretToImgProc[NUM_CAMS];
	RtSharedMemory<RangefinderCommand> rangefinderCommand;
	RtSharedMemory<RangefinderStatus> rangefinderStatus;
	RtSharedMemory<WideCamLensCommand> wideCamLensCommand;
	RtSharedMemory<WideCamLensStatus> wideCamLensStatus;
	RtSharedMemory<LogStatus> logStatus;

	MyRtQueue<ControlCommandAndStatus> controlLoggingQueue;
	MyRtQueue<MessageLog> errorLoggingQueue;

	
	while (!gInit.bShutdown && bootParameters.setup(BOOT_PARAMETER_SHM_NAMES)  != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	
	while (!gInit.bShutdown && masterToTurret.setup(MASTER_TO_TURRET_SHM_NAMES)  != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && turretToMaster.setup(TURRET_TO_MASTER_SHM_NAMES)  != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	
	for (int i = 0; i < NUM_CAMS; i++) {
		while (!gInit.bShutdown && imgProcToTurret[i].setup(IMG_PROC_TO_TURRET_SHM_NAMES[i])  != MySharedMemoryStatus::OK) {
			knRtSleep(UsecsToKticks(100000));
		}
		while (!gInit.bShutdown && turretToImgProc[i].setup(TURRET_TO_IMG_PROC_SHM_NAMES[i])  != MySharedMemoryStatus::OK) {
			knRtSleep(UsecsToKticks(100000));
		}
	}

	while (!gInit.bShutdown && rangefinderCommand.setup(RANGEFINDER_COMMAND_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && rangefinderStatus.setup(RANGEFINDER_STATUS_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && wideCamLensCommand.setup(WIDE_LENS_COMMAND_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && wideCamLensStatus.setup(WIDE_LENS_STATUS_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && logStatus.setup(LOG_STATUS_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}


	while (!gInit.bShutdown && controlLoggingQueue.setup(CONTROL_LOG_QUEUE_NAME,NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && eventLoggingQueue.setup(EVENT_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && errorLoggingQueue.setup(ERROR_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}



	ImgProcToTurretResponse* imgProcToTurretBufPointers[NUM_CAMS];
	TurretToImgProcCommand* turretToImgProcBufPointers[NUM_CAMS];
	for (int i = 0; i < NUM_CAMS; i++) {
		imgProcToTurretBufPointers[i] = imgProcToTurret[i].getBuf();
		turretToImgProcBufPointers[i] = turretToImgProc[i].getBuf();
	}

	ControlCommandAndStatus* controlCommandAndStatus = (ControlCommandAndStatus*)AllocateRtMemory(sizeof(ControlCommandAndStatus));
	if (controlCommandAndStatus == NULL) {
		errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR,"Allocate memory fail\n");
	}


	/////////////////////////////////////////////////
	// Wait for boot parameter
	/////////////////////////////////////////////////

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);

		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}

	OperationMode operationMode = bootParameters.getBuf()->operationMode;

	eventLoggingQueue.log("load parameter done\n");

	/////////////////////////////////////////////////
	// Initialize WideLens etc.
	/////////////////////////////////////////////////
	wideCamLensCommand.getBuf()->zoom = WideCamLensUtils::xMagnificationToHex(1.0);
	wideCamLensCommand.getBuf()->focus = WideCamLensUtils::mFocusToHex(1200);
	wideCamLensCommand.getBuf()->iris = 0xFFFF;


	/////////////////////////////////////////////////
	// Initialize servo
	/////////////////////////////////////////////////
	eventLoggingQueue.log("Moter ctrl start\n");
	ServoController servoController(operationMode,&bootParameters.getBuf()->systemParameters.servoParam);
	ServoErrors::MotorInitSequence sequenceMarker = ServoErrors::MotorInitSequence::OK;
	ret = servoController.init(sequenceMarker);
	if (ret != MP_SUCCESS) {
		errorLoggingQueue.log("Servo init error at %s(%d). Error code: 0x%04x\n", ServoController::motorInitSequenceToStr(sequenceMarker), sequenceMarker, ret);
	}


	PacketGenerator packetGenerator = PacketGenerator(bootParameters.getBuf()->systemParameters.fineMapperParam);


	//start_RT_trace(1);
	struct timeval t0;
	struct timeval t1;
	struct timeval t1_1;
	struct timeval t2;
	struct timeval t3;
	struct timeval t4;
	struct timeval t5;
	struct timeval t6;
	struct timeval t7;

	
	
	int32_t masterReceiveTimeoutCounter = 0;
	int32_t imgProcReceiveTimeoutCounters[NUM_CAMS] = {
		0,
		0
	};
	int32_t isMasterAlive = 0;
	int32_t isImgProcAlive[2] = {0,0};

	int32_t frameCount = 0;


	long tmpShmReceiveTimeMax = 0;


	////////////////////////////////
	// Main Loop
	////////////////////////////////
	while (!gInit.bShutdown)
	{
		servoController.waitCycle();
		

		////////////////////////////////
		// Update Control Data
		////////////////////////////////
		gettimeofday(&t0, NULL);
		MySharedMemoryStatus m2tStatus = masterToTurret.copySharedToLocal(10);

		MySharedMemoryStatus i2tStatus[NUM_CAMS];
		for (int i = 0; i < NUM_CAMS; i++) {
			i2tStatus[i] = imgProcToTurret[i].copySharedToLocal(10);
		}

		MySharedMemoryStatus rngStsStatus = rangefinderStatus.copySharedToLocal(10);
		MySharedMemoryStatus wdCamStsStatus = wideCamLensStatus.copySharedToLocal(10);

		if (m2tStatus != MySharedMemoryStatus::OK) {
			if (m2tStatus == MySharedMemoryStatus::TIMEOUT) {
				errorLoggingQueue.log("MasterToTurret TIMEOUT\n");
			}
			errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "MasterToTurret SharedMemory error at MoterControl\n");
		}
		for (int i = 0; i < NUM_CAMS; i++) {
			if (i2tStatus[i] != MySharedMemoryStatus::OK) {
				if (i2tStatus[i] == MySharedMemoryStatus::TIMEOUT) {
					errorLoggingQueue.log("ImgProcToTurret[%d] TIMEOUT\n", i);
				}
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "ImgProcToTurret[%d] SharedMemory error at MoterControl\n",i);
			}
		}
		
		MySharedMemoryStatus rngCmdStatus = rangefinderCommand.copyLocalToShared(10);
		MySharedMemoryStatus wdCamCmdStatus = wideCamLensCommand.copyLocalToShared(10);

		MySharedMemoryStatus logShmStatus = logStatus.copySharedToLocal(10);


		servoController.readServoStatus(controlCommandAndStatus->servoStatus,controlCommandAndStatus->fineMirrorStatus,controlCommandAndStatus->teleCamLensStatus,controlCommandAndStatus->tilServoStatus);


		gettimeofday(&t1, NULL);

		////////////////////////////////
		// Control Data alive monitoring
		////////////////////////////////
		if (masterToTurret.isUpdated()) {
			masterReceiveTimeoutCounter = CYCLES_MASTER_RECEIVE_TIMEOUT;
		}
		else {
			if (masterReceiveTimeoutCounter > 0) {
				masterReceiveTimeoutCounter--;
			}
		}
		if (masterReceiveTimeoutCounter == 0) {
			isMasterAlive = 0;
		}
		else {
			isMasterAlive = 1;
		}

		for (int i = 0; i < NUM_CAMS; i++) {
			if (imgProcToTurret[i].isUpdated()) {
				imgProcReceiveTimeoutCounters[i] = CYCLES_IMG_PROC_RECEIVE_TIMEOUT;
			}
			else {
				if (imgProcReceiveTimeoutCounters[i] > 0) {
					imgProcReceiveTimeoutCounters[i]--;
				}
			}

			if (imgProcReceiveTimeoutCounters[i] == 0) {
				isImgProcAlive[i] = 0;
			}
			else {
				isImgProcAlive[i] = 1;
			}
		}

		gettimeofday(&t2, NULL);

		masterToTurret.getBuf()->externalSensorType = 1;
		masterToTurret.getBuf()->mmExternalSensorPos[0] = 100000;
		masterToTurret.getBuf()->mmExternalSensorPos[1] = 0;
		masterToTurret.getBuf()->mmExternalSensorPos[2] = 0;
		masterToTurret.getBuf()->camZoomModeCommand[0] = 0;
		masterToTurret.getBuf()->x1_1000CamZoomCommand[0] = 520;
		masterToTurret.getBuf()->camZoomModeCommand[1] = 0;
		masterToTurret.getBuf()->x1_1000CamZoomCommand[1] = 1000;
		

		////////////////////////////////
		// Distribute data
		////////////////////////////////
		int32_t ret = packetGenerator.generatePackets(
			isMasterAlive,
			isImgProcAlive,
			&bootParameters.getBuf()->operationMode,
			&bootParameters.getBuf()->userParameters,
			masterToTurret.getBuf(),          //��������킩��̏��
			turretToMaster.getBuf(),           //���������֑������n�̏�� 
			turretToImgProcBufPointers,     //�e�摜����PC�֑������n�̏��B�摜����PC�䐔���̍\���̂̔z��B
			imgProcToTurretBufPointers,                               //�e�摜����PC���痈��ڕW���B�摜����PC�䐔���̍\���̂̔z��B   						
			controlCommandAndStatus,			
			rangefinderCommand.getBuf(),
			rangefinderStatus.getBuf(),			
			wideCamLensCommand.getBuf(),
			wideCamLensStatus.getBuf(),
			logStatus.getBuf(),
			&errorLoggingQueue
		);

		//DEBUG print
		//eventLoggingQueue.log("%02x,%d,%d\n", turretToMaster.getBuf()->imageProcCommunicationStatus,isImgProcAlive[0],isImgProcAlive[1]);



		if (frameCount % 100 == 0) {
			//eventLoggingQueue.log("(%.2lf,%.2lf), mode=%d, rPos=(%.1lf,%.1lf,%.1lf), rVel=(%.1lf,%.1lf,%.1lf), modeOut=%d, torqueOut=(%.2lf,%.2lf,%.2lf)\n",
			//	controlCommandAndStatus->servoStatus.radCoarsePos[0]*180/M_PI, controlCommandAndStatus->servoStatus.radCoarsePos[1]*180/M_PI,
			//	controlCommandAndStatus->controlModelInput.command.mode,
			//	controlCommandAndStatus->controlModelInput.sensor.mPositionRadar[0], controlCommandAndStatus->controlModelInput.sensor.mPositionRadar[1], controlCommandAndStatus->controlModelInput.sensor.mPositionRadar[2],
			//	controlCommandAndStatus->controlModelInput.sensor.mpsVelocityRadar[0], controlCommandAndStatus->controlModelInput.sensor.mpsVelocityRadar[1], controlCommandAndStatus->controlModelInput.sensor.mpsVelocityRadar[2],
			//	controlCommandAndStatus->controlModelInput.command.radScanOffset[0], controlCommandAndStatus->controlModelInput.command.radScanOffset[1],
			//	controlCommandAndStatus->servoCommand.control.mode,
			//	controlCommandAndStatus->servoCommand.control.nmTorque[0], controlCommandAndStatus->servoCommand.control.nmTorque[1], controlCommandAndStatus->servoCommand.control.nmTorque[2]
			//	);
		}
		

		if (ret < 0) {
			errorLoggingQueue.log("InvalidControlMode: %d\n", masterToTurret.getBuf()->controlMode);
		}

		/////////////////////////////////////////
		// send messages
		/////////////////////////////////////////
		if (frameCount % 10 == 0) {
			MySharedMemoryStatus status;
			status = turretToMaster.copyLocalToShared(10);
			if (status != MySharedMemoryStatus::OK) {
				if (status == MySharedMemoryStatus::TIMEOUT) {
					errorLoggingQueue.log("TurretToMaster TIMEOUT\n");
				}
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "TurretToMaster SharedMemory error at MoterCtrl\n");
			}
		}
		if (frameCount % 2 == 0) {
			for (int i = 0; i < NUM_CAMS; i++) {
				MySharedMemoryStatus status;
				status = turretToImgProc[i].copyLocalToShared(10);
				if (status != MySharedMemoryStatus::OK) {
					if (status == MySharedMemoryStatus::TIMEOUT) {
						errorLoggingQueue.log("TurretToImgProc[%d] TIMEOUT\n", i);
					}
					errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "TurretToImgProc[%d] SharedMemory error at MoterCtrl\n",i);
				}
			}
		}
		if (frameCount % 10 == 0) {
			MyQueueStatus status;
			status = controlLoggingQueue.send(controlCommandAndStatus);
			if (status == MyQueueStatus::QUEUE_ERROR) {
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "ControlLog Logging queue error at MoterCtrl\n");
			}
		}

		////////////////////////////////////////
		// Handle Shutdown/Reboot request
		////////////////////////////////////////
		if (masterToTurret.getBuf()->shutdownRequest == 1) {
			eventLoggingQueue.shutdownRequest(ShutdownRequest::EXIT_SHUTDOWN, "Shutdown request arrived from MasterController\n");
		}
		else if (masterToTurret.getBuf()->shutdownRequest == 2) {
			eventLoggingQueue.shutdownRequest(ShutdownRequest::EXIT_REBOOT, "Reboot request arrived from MasterController\n");
		}

		//////////////////////////////////////////
		// Send control command
		//////////////////////////////////////////
		double pGain = masterToTurret.getBuf()->mLaserRestrictedAreaDistance[22] / 10.0;
		double dGain = masterToTurret.getBuf()->mLaserRestrictedAreaDistance[23] / 10.0;;
		ret = servoController.control(controlCommandAndStatus);
		if (ret != MP_SUCCESS) {
			errorLoggingQueue.log("Motor control error: 0x%02x\n",ret);
		}


		gettimeofday(&t7, NULL);

		long tDiff = usCalcTimeDiff(t1, t7);

		//if (tDiff > 100) {
		//	errorLoggingQueue.log("tDiff fail at count %d: %d[usec]\n", frameCount, tDiff);
		//}

		//tDiff = usCalcTimeDiff(t0, t1);
		//if (tDiff > tmpShmReceiveTimeMax) {
		//	tmpShmReceiveTimeMax = tDiff;
		//}
		//if (frameCount % 1000 == 0) {
		//	errorLoggingQueue.log("shm time max = %lf[ms]\n", tmpShmReceiveTimeMax/1000.0);
		//	tmpShmReceiveTimeMax = 0;
		//}


		frameCount++;
	}

	gInit.htPollMotorCtrl = NULL_RTHANDLE;
}
