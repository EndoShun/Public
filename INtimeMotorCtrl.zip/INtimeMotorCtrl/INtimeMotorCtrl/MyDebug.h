#pragma once

#include "MyRtQueue.h"

extern MyRtQueue<MessageLog> eventLoggingQueue;