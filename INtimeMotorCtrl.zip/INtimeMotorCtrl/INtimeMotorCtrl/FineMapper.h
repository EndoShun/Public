#pragma once

#include "stdint.h"
#include "IoStructs.h"

class FineMapper {
private:
	static constexpr double X_CALIBRATION_POINT = 4.0;

	double M[3][3];
public:
	FineMapper();
	FineMapper(double M00, double M01, double M02, double M10, double M11, double M12, double M20, double M21, double M22);
	FineMapper(FineMapperParam param);

	double mapX(double pxX, double pxY);
	double mapY(double pxX, double pxY);
	double mapX(double pxX, double pxY,double xZoom);
	double mapY(double pxX, double pxY,double xZoom);

	//double mapX(double pxX, double pxY, int16_t pxOffsetX, int16_t pxOffsetY,int32_t lrFlip, double radRotationCorrection);
	//double mapY(double pxX, double pxY, int16_t pxOffsetX, int16_t pxOffsetY,int32_t lrFlip, double radRotationCorrection);
};

