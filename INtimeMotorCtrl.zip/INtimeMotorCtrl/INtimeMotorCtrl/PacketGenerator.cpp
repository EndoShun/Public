#include "PacketGenerator.h"
#include "IoStructs.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include "stdio.h"
#include "stdlib.h"
#include "FineMapper.h"
#include "MyUtils.h"
#include "WideCamLensUtils.h"
#include "ServoController/ServoController.h"
#include "MyDebug.h"

#define CAM0_LRFLIP 1		//Flipped = -1, not flipped = 1
#define CAM1_LRFLIP 1

#define CAM0_USE_AIMPOINT 0
#define CAM1_USE_AIMPOINT 1

#define AIMPOINT_CENTERED 1				//0: TargetCenter Centered
//1: Aimpoint Centered


void PacketGenerator::pxOffsetToRadAngleError(const uint16_t pxPos[2], const int16_t jointOffset[2], const int16_t cameraResolution[2], double radPerPixel, double radRotationCorrection, const double pxCamCoordinateAimPointOffset[2], double outRadAngleError[2]) {
	double pxTrackPointErrorX;
	double pxTrackPointErrorY;

	if (AIMPOINT_CENTERED) {
		pxTrackPointErrorX = pxPos[0] + jointOffset[0] + pxCamCoordinateAimPointOffset[0] - cameraResolution[0] / 2;
		pxTrackPointErrorY = pxPos[1] + jointOffset[1] + pxCamCoordinateAimPointOffset[1] - cameraResolution[1] / 2;
	}
	else {
		pxTrackPointErrorX = pxPos[0] - cameraResolution[0] / 2;
		pxTrackPointErrorY = pxPos[1] - cameraResolution[1] / 2;
	}

	double radCameraCoordinateAngleErrorX = pxTrackPointErrorX * radPerPixel;
	double radCameraCoordinateAngleErrorY = -pxTrackPointErrorY * radPerPixel;

	outRadAngleError[0] = cos(radRotationCorrection) * radCameraCoordinateAngleErrorX + sin(radRotationCorrection) * radCameraCoordinateAngleErrorY;
	outRadAngleError[1] = -sin(radRotationCorrection) * radCameraCoordinateAngleErrorX + cos(radRotationCorrection) * radCameraCoordinateAngleErrorY;
}

PacketGenerator::PacketGenerator(FineMapperParam fineMapperParam) {
	//fineMapper = FineMapper(9.9238e-3, 1.0127e-3, -9.9656e+0,
	//							6.4431e-4, -7.1620e-3, 3.3437e+0,
	//							-1.4793e-5, -2.1799e-5, 1.0000e+0);
	fineMapper = FineMapper(fineMapperParam);

	for (int i = 0; i < NUM_CAMS; i++) {
		prevMatchIds[i] = 0;
	}

	scanCount = 0;
	debugCount = 0;
}

PacketGenerator::PacketGenerator() : PacketGenerator(FineMapperParam{ 1,0,0,0,1,0,0,0,1 }) {

}

int32_t PacketGenerator::isInArea(int32_t nradx10Pos, int32_t nradx10Limit0, int32_t nradx10Limit1, int32_t nradx10Margin, MyRtQueue<MessageLog>* errorLoggingQueue) {
	int32_t nradx10Limit0_Margin = nradx10Limit0 - nradx10Margin;
	if (nradx10Limit0_Margin < radToNradx10(-M_PI)) {
		nradx10Limit0_Margin += radToNradx10(2 * M_PI);
	}
	int32_t nradx10Limit1_Margin = nradx10Limit1 + nradx10Margin;
	if (nradx10Limit1_Margin > radToNradx10(M_PI)) {
		nradx10Limit1_Margin -= radToNradx10(2 * M_PI);
	}


	if (nradx10Limit0 == NRADX10_RESTRICTAREA_MIN && nradx10Limit1 == NRADX10_RESTRICTAREA_MAX) {	//-�΁`�΂̏ꍇ�S��
		return 1;
	}
	else if (nradx10Limit0 == nradx10Limit1) {	//�����l�̏ꍇ����
		return 0;
	}
	else if (nradx10Limit1 > nradx10Limit0 && nradx10Limit1 - nradx10Limit0 + 2 * nradx10Margin > radToNradx10(2 * M_PI)) {	//�͈�+�}�[�W����360���ȏ�̏ꍇ�S��(�ʏ�)
		return 1;
	}
	else if (nradx10Limit0 > nradx10Limit1 && nradx10Limit1 - nradx10Limit0 + radToNradx10(2 * M_PI) + 2 * nradx10Margin > radToNradx10(2 * M_PI)) {	//�͈�+�}�[�W����360���ȏ�̏ꍇ�S��(�w�ʕ������܂���)
		return 1;
	}
	else if (nradx10Limit1_Margin > nradx10Limit0_Margin) {	//�ʏ�
		if (nradx10Pos >= nradx10Limit0_Margin && nradx10Pos <= nradx10Limit1_Margin) {
			return 1;
		}
		else {
			return 0;
		}
	}
	else {	//�w�ʕ������܂���
		if (nradx10Pos <= nradx10Limit1_Margin || nradx10Pos >= nradx10Limit0_Margin) {
			return 1;
		}
		else {
			return 0;
		}
	}
}

uint8_t PacketGenerator::isInRestrictArea(const ServoStatus* servoStatus, const MasterToTurretCommand* masterToTurretCommand, const UserParameters* userParameters, MyRtQueue<MessageLog>* errorLoggingQueue) {
	//return value
	//  bit1: TIL restricted
	//  bit0: HEL restricted

	uint8_t restricted = 0;


	int32_t nradx10Pos[2];
	for (int i = 0; i < 2; i++) {	//+-180���A10nrad�P�ʂɕϊ�
		double radPos = fmod(servoStatus->radCoarsePos[i], 2 * M_PI);
		if (radPos > M_PI) {
			radPos -= 2 * M_PI;
		}
		else if (radPos < -M_PI) {
			radPos += 2 * M_PI;
		}

		nradx10Pos[i] = radToNradx10(radPos);
	}


	///////////////////////////////////////////////////////////
	// ���[�U�[���͏Ǝˋ֎~�G���A
	///////////////////////////////////////////////////////////
	for (int i = 0; i < NUM_RESTRICT_AREA; i++) {
		if (masterToTurretCommand->bfLaserRestrictedAreaValid & 1 << i) {
			if (isInArea(nradx10Pos[0], masterToTurretCommand->nradx10LaserRestrictedAreaPan[i][0], masterToTurretCommand->nradx10LaserRestrictedAreaPan[i][1] + 1, radToNradx10(userParameters->radFixedAreaSafetyMargin), errorLoggingQueue) &&
				isInArea(nradx10Pos[1], masterToTurretCommand->nradx10LaserRestrictedAreaTilt[i][0], masterToTurretCommand->nradx10LaserRestrictedAreaTilt[i][1] + 1, radToNradx10(userParameters->radFixedAreaSafetyMargin), errorLoggingQueue)) {
				if (masterToTurretCommand->mLaserRestrictedAreaDistance[i] <= userParameters->mHelSafeDistance) {
					restricted |= 0x01;
				}
				if (masterToTurretCommand->mLaserRestrictedAreaDistance[i] <= userParameters->mTilSafeDistance) {
					restricted |= 0x02;
				}
			}
		}
	}


	///////////////////////////////////////////////////////////
	// ADCCS�F�R���
	///////////////////////////////////////////////////////////
	for (int i = 0; i < NUM_FRIENDLIES; i++) {
		if (masterToTurretCommand->bfFriendlyValid & 1 << i) {

			double radAdccsPanSafetyMargin;
			double radAdccsTiltSafetyMargin;

			double tiltErrorDistanceRatio = userParameters->mAdccsSafetyMargin / masterToTurretCommand->mFriendlyDistance[i];
			if (tiltErrorDistanceRatio >= 1.0) {	//�F�R�@���}�[�W�����߂��ꍇ�A�S�����Ǝˋ֎~�Ƃ���
				radAdccsTiltSafetyMargin = 2 * M_PI;
			}
			else {
				radAdccsTiltSafetyMargin = asin(tiltErrorDistanceRatio);
			}

			double panErrorDistanceRatio = userParameters->mAdccsSafetyMargin / (masterToTurretCommand->mFriendlyDistance[i] * cos(nradx10ToRad(masterToTurretCommand->nradx10FriendlyPos[i][1])));
			if (panErrorDistanceRatio >= 1.0) {
				radAdccsPanSafetyMargin = 2 * M_PI;
			}
			else {
				radAdccsPanSafetyMargin = asin(panErrorDistanceRatio);
			}


			double radTiltTotalMargin = userParameters->radSystemSafetyMargin + radAdccsTiltSafetyMargin;
			double radPanTotalMargin = userParameters->radSystemSafetyMargin + radAdccsPanSafetyMargin;
			int32_t nradx10TiltTotalMargin = radToNradx10(radTiltTotalMargin);
			int32_t nradx10PanTotalMargin = radToNradx10(radPanTotalMargin);

			if (isInArea(nradx10Pos[0], masterToTurretCommand->nradx10FriendlyPos[i][0], masterToTurretCommand->nradx10FriendlyPos[i][0] + 1, nradx10PanTotalMargin, errorLoggingQueue) &&
				isInArea(nradx10Pos[1], masterToTurretCommand->nradx10FriendlyPos[i][1], masterToTurretCommand->nradx10FriendlyPos[i][1] + 1, nradx10TiltTotalMargin, errorLoggingQueue)
				) {
				if (masterToTurretCommand->mFriendlyDistance[i] <= userParameters->mHelSafeDistance) {
					restricted |= 0x01;
				}
				if (masterToTurretCommand->mFriendlyDistance[i] <= userParameters->mTilSafeDistance) {
					restricted |= 0x02;
				}
			}
		}
	}

	return restricted;
}

void PacketGenerator::generateScanPattern(int32_t swingScanCommand, double radRadialStep, double outRadScanOffset[2]) {
	if (swingScanCommand != 2) {
		scanCount = 0;
		outRadScanOffset[0] = 0.0;
		outRadScanOffset[1] = 0.0;
		return;
	}


	//TODO: �X�L�����Œ��S�ɖ߂��p�^�[��(�K�v�ł����)
	double a = radRadialStep * OVERRAP_RATE * sqrt(scanCount / (CYCLES_PER_SHOT * M_PI));
	double theta = 2 * sqrt(scanCount * M_PI / CYCLES_PER_SHOT);

	outRadScanOffset[0] = a * sin(theta);
	outRadScanOffset[1] = a * cos(theta);

	int32_t scanCountMax = CYCLES_PER_SHOT * 50 * pow(3.1 / radRadialStep, 2);
	scanCount = (scanCount + 1) % scanCountMax;
}

int32_t PacketGenerator::generatePackets(int32_t isMasterAlive, const int32_t isImgProcAlive[2], const OperationMode* operationMode, const UserParameters* userParameters,
	const MasterToTurretCommand* masterToTurretCommand, TurretToMasterResponse* turretToMasterResponse, TurretToImgProcCommand* turretToImgProcCommands[NUM_CAMS], ImgProcToTurretResponse* imgProcToTurretResponses[NUM_CAMS],
	ControlCommandAndStatus* controlCommandAndStatus,
	RangefinderCommand* rangefinderCommand, const RangefinderStatus* rangefinderStatus,
	WideCamLensCommand* wideCamLensCommand, const WideCamLensStatus* wideCamLensStatus,
	const LogStatus* logStatus, MyRtQueue<MessageLog>* errorLoggingQueue) {

	//////////////////////////////////////////////////////////
	//  setup common values
	//////////////////////////////////////////////////////////
	ServoCommand* servoCommand = &(controlCommandAndStatus->servoCommand);
	ControlModelInput* controlModelInput = &(controlCommandAndStatus->controlModelInput);
	ServoStatus* servoStatus = &(controlCommandAndStatus->servoStatus);
	FineMirrorCommand* fineMirrorCommand = &(controlCommandAndStatus->fineMirrorCommand);
	LaserEnableCommand* laserEnableCommand = &(controlCommandAndStatus->laserEnableCommand);
	FineMirrorStatus* fineMirrorStatus = &(controlCommandAndStatus->fineMirrorStatus);
	TeleCamLensCommand* teleCamLensCommand = &(controlCommandAndStatus->teleCamLensCommand);
	TeleCamLensStatus* teleCamLensStatus = &(controlCommandAndStatus->teleCamLensStatus);
	TilServoCommand* tilServoCommand = &(controlCommandAndStatus->tilServoCommand);
	TilServoStatus* tilServoStatus = &(controlCommandAndStatus->tilServoStatus);

	int32_t ret = 0;


	double xCurrentZoom[NUM_CAMS];
	xCurrentZoom[0] = WideCamLensUtils::hexToXMagnification(wideCamLensStatus->zoom);
	xCurrentZoom[1] = teleCamLensStatus->xTeleCamZoom;

	double radVFov[NUM_CAMS];
	radVFov[0] = WideCamLensUtils::xZoomToRadVFov(xCurrentZoom[0]);
	radVFov[1] = ServoController::xZoomToRadFov(xCurrentZoom[1]);

	double radPerPixel[NUM_CAMS];
	radPerPixel[0] = WideCamLensUtils::xZoomToRadPerPixel(xCurrentZoom[0]);
	radPerPixel[1] = ServoController::xZoomToRadPerPixel(xCurrentZoom[1]);

	double radTilDivergence = tilServoStatus->radTilDivergence;

	double radRotationCorrection = servoStatus->radCoarsePos[0] - servoStatus->radCoarsePos[1];
	double pxTeleCamCoordinateAimpointOffsets[2];
	pxTeleCamCoordinateAimpointOffsets[0] = (cos(radRotationCorrection) * masterToTurretCommand->pxAimPointOffset[0] + sin(radRotationCorrection) * masterToTurretCommand->pxAimPointOffset[1]);
	pxTeleCamCoordinateAimpointOffsets[1] = -(sin(radRotationCorrection) * masterToTurretCommand->pxAimPointOffset[0] + cos(radRotationCorrection) * masterToTurretCommand->pxAimPointOffset[1]);

	double pxWideCamCoordinateAimpointOffsets[2];
	pxWideCamCoordinateAimpointOffsets[0] = 0;
	pxWideCamCoordinateAimpointOffsets[1] = 0;

	int16_t jointOffset[2];
	if (masterToTurretCommand->aimPointMode >= 0 && masterToTurretCommand->aimPointMode < 5) {
		jointOffset[0] = imgProcToTurretResponses[1]->pxJointPoses[masterToTurretCommand->aimPointMode][0];
		jointOffset[1] = imgProcToTurretResponses[1]->pxJointPoses[masterToTurretCommand->aimPointMode][1];
	}
	else {
		jointOffset[0] = 0;
		jointOffset[1] = 0;
	}

	int16_t wideJointOffset[2];
	wideJointOffset[0] = 0;
	wideJointOffset[1] = 0;


	/////////////////////////////////////////////////////////////
	// �G���[�R�[�h -> �������M�p�G���[�X�e�[�^�X�Adegrade����
	/////////////////////////////////////////////////////////////
	uint16_t bfServoErrorStatus = 0;
	for (int i = 0; i < AXIS_NUM; i++) {
		if (servoStatus->coarseAlarm[i] || servoStatus->coarseDriverAlarmCode[i]) {
			bfServoErrorStatus |= 0x0001 << i;
		}
		if (servoStatus->coarseWarning[i] == 904 || (920 <= servoStatus->coarseWarning[i] && servoStatus->coarseWarning[i] <= 923)) {
			bfServoErrorStatus |= 0x0100 << i;
		}
		else if (servoStatus->coarseWarning[i]) {
			bfServoErrorStatus |= 0x1000 << i;
		}
	}
	if (servoStatus->bfControlModelAlarmFlags) {
		bfServoErrorStatus |= 0x0008;
	}

	uint8_t bfTilServoErrorStatus = 0;
	if (tilServoStatus->alarmCode) {
		bfTilServoErrorStatus |= 0x01;
	}

	uint8_t bfFineMirrorErrorStatus = 0;
	if (fineMirrorStatus->alarmCode) {
		bfFineMirrorErrorStatus |= 0x01;
	}
	if (fineMirrorStatus->warningCode) {
		bfFineMirrorErrorStatus |= 0x10;
	}

	uint8_t bfRs485ConverterErrorStatus = 0;
	if (teleCamLensStatus->rs485ConverterAlarmCode) {
		bfRs485ConverterErrorStatus |= 0x01;
	}
	if (teleCamLensStatus->rs485ConverterWarningCode) {
		bfRs485ConverterErrorStatus |= 0x10;
	}

	uint8_t bfTeleLensErrorStatus = 0;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		if (teleCamLensStatus->alarmCode[i]) {
			bfTeleLensErrorStatus |= 0x01 << i;
		}
		if (teleCamLensStatus->warningCode[i]) {
			bfTeleLensErrorStatus |= 0x10 << i;
		}
	}

	uint32_t degradeRequest;
	if ((bfServoErrorStatus & SERVO_ERROR_DEGRADE_MASK) || (bfTilServoErrorStatus & TIL_SERVO_ERROR_DEGRADE_MASK) || 
		(bfFineMirrorErrorStatus & FINE_MIRROR_ERROR_DEGRADE_MASK) || (bfRs485ConverterErrorStatus & RS485_CONVERTER_ERROR_DEGRADE_MASK) || (bfTeleLensErrorStatus & TELE_LENS_ERROR_DEGRADE_MASK) ||
		!isMasterAlive) {
		degradeRequest = 1;
	}
	else {
		degradeRequest = 0;
	}
	



	//////////////////////////////////////////////////////////
	//  setup outMasterControllerCommand
	//////////////////////////////////////////////////////////
	if (degradeRequest) {
		controlModelInput->command.mode = 0;
	}
	else if (masterToTurretCommand->controlMode == 0 ||
		masterToTurretCommand->controlMode == 1 ||
		masterToTurretCommand->controlMode == 10 ||
		masterToTurretCommand->controlMode == 11 ||
		masterToTurretCommand->controlMode == 12 ||
		masterToTurretCommand->controlMode == 20 ||
		masterToTurretCommand->controlMode == 21 ||
		masterToTurretCommand->controlMode == 22) {

		controlModelInput->command.mode = masterToTurretCommand->controlMode;
	}
	else {//Invalid control mode command. Force stop mode.
		controlModelInput->command.mode = 0;
	}

	controlModelInput->command.homingComplete = servoStatus->homingComplete;


	for (int i = 0; i < AXIS_NUM; i++) {
		//Default control values
		controlModelInput->command.radAngle[i] = servoStatus->radCoarsePos[i];	//���䃂�[�h�ؑ֎��Ƀ��[�g���~�b�^�ɑ傫�Ȓl������̂�h�����߁A
																				//�ʒu�w�߃��[�h�łȂ��ꍇ�͌��݈ʒu����͂���
		controlModelInput->command.rpsVelocity[i] = 0;
		controlModelInput->command.rpsVelocityLimit[i] = 0;	//TODO�@->���x����̓p�����[�^�ɂ����݂���B������͉�������Ηǂ����m�F

		controlModelInput->sensor.radAngle[i] = servoStatus->radCoarsePos[i];
		controlModelInput->sensor.rpsVelocity[i] = servoStatus->rpsCoarseSpeed[i];
	}

	controlModelInput->sensor.radVisionAngleError[0] = 0;
	controlModelInput->sensor.radVisionAngleError[1] = 0;
	controlModelInput->sensor.visionUpdateFlag = 0;
	controlModelInput->sensor.validVision = 0;

	if (masterToTurretCommand->externalSensorType != 0) {
		controlModelInput->sensor.mPositionRadar[0] = masterToTurretCommand->mmExternalSensorPos[0] / 1000.0;
		controlModelInput->sensor.mPositionRadar[1] = masterToTurretCommand->mmExternalSensorPos[1] / 1000.0;
		controlModelInput->sensor.mPositionRadar[2] = masterToTurretCommand->mmExternalSensorPos[2] / 1000.0;
		controlModelInput->sensor.mpsVelocityRadar[0] = masterToTurretCommand->mmpsExternalSensorSpeed[0] / 1000.0;
		controlModelInput->sensor.mpsVelocityRadar[1] = masterToTurretCommand->mmpsExternalSensorSpeed[1] / 1000.0;
		controlModelInput->sensor.mpsVelocityRadar[2] = masterToTurretCommand->mmpsExternalSensorSpeed[2] / 1000.0;
	}
	else {
		controlModelInput->sensor.mPositionRadar[0] = 0;
		controlModelInput->sensor.mPositionRadar[1] = 0;
		controlModelInput->sensor.mPositionRadar[2] = 0;
		controlModelInput->sensor.mpsVelocityRadar[0] = 0;
		controlModelInput->sensor.mpsVelocityRadar[1] = 0;
		controlModelInput->sensor.mpsVelocityRadar[2] = 0;
	}

	generateScanPattern(masterToTurretCommand->swingScanCommand, radTilDivergence, controlModelInput->command.radScanOffset);


	int8_t trackingCamId = -1;

	//Update controlvalues
	if (masterToTurretCommand->controlMode == 0) {
		//use default. do nothing.
	}
	else if (masterToTurretCommand->controlMode == 1) {//�ʒu����
		controlModelInput->command.radAngle[0] = masterToTurretCommand->manualCommand[0] / 100000000.0;	//0.01[urad] -> [rad]
		controlModelInput->command.radAngle[1] = masterToTurretCommand->manualCommand[1] / 100000000.0;	//0.01[urad] -> [rad]
		controlModelInput->command.radAngle[2] = controlModelInput->command.radAngle[1];
	}
	else if (masterToTurretCommand->controlMode == 10) {//���x����
		controlModelInput->command.rpsVelocity[0] = masterToTurretCommand->manualCommand[0] / 100000000.0;	//0.01[urad/s] -> [rad/s]
		controlModelInput->command.rpsVelocity[1] = masterToTurretCommand->manualCommand[1] / 100000000.0;	//0.01[urad/s] -> [rad/s]
		controlModelInput->command.rpsVelocity[2] = controlModelInput->command.rpsVelocity[1];
	}
	else if (masterToTurretCommand->controlMode == 11) {//�L�p�ǔ�
		if (imgProcToTurretResponses[0]->matchValid == 2) {
			pxOffsetToRadAngleError(imgProcToTurretResponses[0]->pxMatchPos, wideJointOffset, WideCamLensUtils::RESOLUTION, radPerPixel[0], 0, pxWideCamCoordinateAimpointOffsets, controlModelInput->sensor.radVisionAngleError);
			controlModelInput->sensor.visionUpdateFlag = (prevMatchIds[0] != imgProcToTurretResponses[0]->matchId);
			controlModelInput->sensor.validVision = 1;
			trackingCamId = 0;

		}
		else {
			controlModelInput->sensor.radVisionAngleError[0] = 0;
			controlModelInput->sensor.radVisionAngleError[1] = 0;
		}
	}
	else if (masterToTurretCommand->controlMode == 12) {//�]���ǔ�
		if (imgProcToTurretResponses[1]->matchValid == 2) {
			pxOffsetToRadAngleError(imgProcToTurretResponses[1]->pxMatchPos, jointOffset, ServoController::RESOLUTION, radPerPixel[1], radRotationCorrection, pxTeleCamCoordinateAimpointOffsets, controlModelInput->sensor.radVisionAngleError);
			controlModelInput->sensor.visionUpdateFlag = (prevMatchIds[1] != imgProcToTurretResponses[1]->matchId);
			controlModelInput->sensor.validVision = 1;
			trackingCamId = 1;

		}
		else  if (imgProcToTurretResponses[0]->matchValid == 2) {
			pxOffsetToRadAngleError(imgProcToTurretResponses[0]->pxMatchPos, wideJointOffset, WideCamLensUtils::RESOLUTION, radPerPixel[0], 0, pxWideCamCoordinateAimpointOffsets, controlModelInput->sensor.radVisionAngleError);
			controlModelInput->sensor.visionUpdateFlag = (prevMatchIds[0] != imgProcToTurretResponses[0]->matchId);
			controlModelInput->sensor.validVision = 1;
			trackingCamId = 0;
		}
		else {
			controlModelInput->sensor.radVisionAngleError[0] = 0;
			controlModelInput->sensor.radVisionAngleError[1] = 0;
		}
	}
	else if (masterToTurretCommand->controlMode == 20) {//�{���]�葕�u�Ǐ]
		//use default value. do nothing here.
	}
	else if (masterToTurretCommand->controlMode == 21) {//�L�p�ǔ�(���X�g���{���]�葕�u�Ǐ])
		if (imgProcToTurretResponses[0]->matchValid == 2) {
			pxOffsetToRadAngleError(imgProcToTurretResponses[0]->pxMatchPos, wideJointOffset, WideCamLensUtils::RESOLUTION, radPerPixel[0], 0, pxWideCamCoordinateAimpointOffsets, controlModelInput->sensor.radVisionAngleError);
			controlModelInput->sensor.visionUpdateFlag = (prevMatchIds[0] != imgProcToTurretResponses[0]->matchId);
			controlModelInput->sensor.validVision = 1;
			trackingCamId = 0;
		}
		else {//���X�g���{���]�葕�u�Ǐ]
			//use default value. do nothing here.
		}
	}
	else if (masterToTurretCommand->controlMode == 22) {//�L�p�ǔ�(���X�g���{���]�葕�u�Ǐ])
		if (imgProcToTurretResponses[1]->matchValid == 2) {
			pxOffsetToRadAngleError(imgProcToTurretResponses[1]->pxMatchPos, jointOffset, ServoController::RESOLUTION, radPerPixel[1], radRotationCorrection, pxTeleCamCoordinateAimpointOffsets, controlModelInput->sensor.radVisionAngleError);
			controlModelInput->sensor.visionUpdateFlag = (prevMatchIds[1] != imgProcToTurretResponses[1]->matchId);
			controlModelInput->sensor.validVision = 1;
			trackingCamId = 1;

		}
		else  if (imgProcToTurretResponses[0]->matchValid == 2) {
			pxOffsetToRadAngleError(imgProcToTurretResponses[0]->pxMatchPos, wideJointOffset, WideCamLensUtils::RESOLUTION, radPerPixel[0], 0, pxWideCamCoordinateAimpointOffsets, controlModelInput->sensor.radVisionAngleError);
			controlModelInput->sensor.visionUpdateFlag = (prevMatchIds[0] != imgProcToTurretResponses[0]->matchId);
			controlModelInput->sensor.validVision = 1;
			trackingCamId = 0;
		}
		else {//���X�g���{���]�葕�u�Ǐ]
			//use default value. do nothing here.
		}
	}
	else {
		//use default. do nothing.
	}
	controlModelInput->command.servoOnCommand = masterToTurretCommand->servoOn;

	if (masterToTurretCommand->fineMirrorMode == 1) {	//manual mode
		fineMirrorCommand->posX = masterToTurretCommand->fineMirrorCommand[0] / 1000000.0;  //-1000000 to 1000000 -> -1.0 to 1.0
		fineMirrorCommand->posY = masterToTurretCommand->fineMirrorCommand[1] / 1000000.0;  //-1000000 to 1000000 -> -1.0 to 1.0
	}
	else if (masterToTurretCommand->fineMirrorMode == 101 || masterToTurretCommand->fineMirrorMode == 102) {
		int32_t toggleCamSource;
		if (masterToTurretCommand->fineMirrorMode == 101) {
			toggleCamSource = 0;
		}
		else {
			toggleCamSource = 1;
		}

		if (imgProcToTurretResponses[toggleCamSource]->matchId % 2 == 0) {
			fineMirrorCommand->posX = 1.0;
			fineMirrorCommand->posY = 1.0;
		}
		else {
			fineMirrorCommand->posX = -1.0;
			fineMirrorCommand->posY = -1.0;
		}
	}
	else {
		if ((masterToTurretCommand->controlMode == 11 || masterToTurretCommand->controlMode == 21) && imgProcToTurretResponses[1]->matchValid == 2) {	//tele cam lock
			int pxPosX = imgProcToTurretResponses[1]->pxMatchPos[0] + jointOffset[0];
			int pxPosY = imgProcToTurretResponses[1]->pxMatchPos[1] + jointOffset[1];

			fineMirrorCommand->posX = fineMapper.mapX(pxPosX + pxTeleCamCoordinateAimpointOffsets[0], pxPosY + pxTeleCamCoordinateAimpointOffsets[1], xCurrentZoom[1]);
			fineMirrorCommand->posY = fineMapper.mapY(pxPosX + pxTeleCamCoordinateAimpointOffsets[0], pxPosY + pxTeleCamCoordinateAimpointOffsets[1], xCurrentZoom[1]);

		}
		else {
			fineMirrorCommand->posX = 0.0;
			fineMirrorCommand->posY = 0.0;
		}
	}

	int32_t inRestrictArea = isInRestrictArea(servoStatus, masterToTurretCommand, userParameters, errorLoggingQueue);
	laserEnableCommand->helEnable = inRestrictArea & 0x01 && !degradeRequest && (masterToTurretCommand->armStatus == 2);
	laserEnableCommand->tilEnable = ((inRestrictArea & 0x02) >> 1)  && !degradeRequest && (masterToTurretCommand->armStatus == 2);


	//////////////////////////////////////////////////////////
	//  setup turretToMasterResponse
	//////////////////////////////////////////////////////////
	turretToMasterResponse->packetSize = sizeof(TurretToMasterResponse);
	turretToMasterResponse->packetType = 0x01;
	turretToMasterResponse->nradx10CoarsePos[0] = radToNradx10(servoStatus->radCoarsePos[0]);
	turretToMasterResponse->nradx10CoarsePos[1] = radToNradx10(servoStatus->radCoarsePos[1]);
	turretToMasterResponse->nradx10CoarsePos[2] = radToNradx10(servoStatus->radCoarsePos[2]);
	turretToMasterResponse->nradx10ExternalSensorTargetPos[0] = radToNradx10(controlCommandAndStatus->servoCommand.control.radRadarReference[0]);
	turretToMasterResponse->nradx10ExternalSensorTargetPos[1] = radToNradx10(controlCommandAndStatus->servoCommand.control.radRadarReference[1]);
	turretToMasterResponse->finePos[0] = (int32_t)(fineMirrorCommand->posX * 1000000);
	turretToMasterResponse->finePos[1] = (int32_t)(fineMirrorCommand->posY * 1000000);
	turretToMasterResponse->nradx10psCoarseSpeed[0] = radToNradx10(servoStatus->rpsCoarseSpeed[0]);
	turretToMasterResponse->nradx10psCoarseSpeed[1] = radToNradx10(servoStatus->rpsCoarseSpeed[1]);
	turretToMasterResponse->nradx10psCoarseSpeed[2] = radToNradx10(servoStatus->rpsCoarseSpeed[2]);
	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->aiModes[i] = imgProcToTurretResponses[i]->aiMode;
	}


	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->trackedTargetIndex[i] = imgProcToTurretResponses[i]->trackingIndex;
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < MAX_TARGETS; j++) {
			turretToMasterResponse->targetIds[i][j] = imgProcToTurretResponses[i]->targetIds[j];
			turretToMasterResponse->aiClasses[i][j] = imgProcToTurretResponses[i]->aiClasses[j];
			turretToMasterResponse->pxAiPoses[i][j][0] = imgProcToTurretResponses[i]->pxAiPoses[j][0];
			turretToMasterResponse->pxAiPoses[i][j][1] = imgProcToTurretResponses[i]->pxAiPoses[j][1];
			turretToMasterResponse->pxAiSizes[i][j][0] = imgProcToTurretResponses[i]->pxAiSizes[j][0];
			turretToMasterResponse->pxAiSizes[i][j][1] = imgProcToTurretResponses[i]->pxAiSizes[j][1];
		}
	}

	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < NUM_JOINTS; j++) {
			turretToMasterResponse->pxJointPoses[i][j][0] = imgProcToTurretResponses[i]->pxJointPoses[j][0];
			turretToMasterResponse->pxJointPoses[i][j][1] = imgProcToTurretResponses[i]->pxJointPoses[j][1];
		}
	}
	turretToMasterResponse->selectedJoint = masterToTurretCommand->aimPointMode;


	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->matchValid[i] = imgProcToTurretResponses[i]->matchValid;
		turretToMasterResponse->pxMatchPoses[i][0] = imgProcToTurretResponses[i]->pxMatchPos[0];
		turretToMasterResponse->pxMatchPoses[i][1] = imgProcToTurretResponses[i]->pxMatchPos[1];
		turretToMasterResponse->pxMatchSizes[i][0] = imgProcToTurretResponses[i]->pxMatchSize[0];
		turretToMasterResponse->pxMatchSizes[i][1] = imgProcToTurretResponses[i]->pxMatchSize[1];
	}
	turretToMasterResponse->rangeFinderModeStatus = rangefinderStatus->status;
	turretToMasterResponse->mRangeFinderDistance = rangefinderStatus->mmX100Range;


	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->camGainModeStatus[i] = masterToTurretCommand->camGainModeCommand[i];
		turretToMasterResponse->dB1_10CamGainStatus[i] = masterToTurretCommand->dB1_10CamGainCommand[i];
		turretToMasterResponse->camZoomModeStatus[i] = masterToTurretCommand->camZoomModeCommand[i];
		turretToMasterResponse->expandModeStatus[i] = imgProcToTurretResponses[i]->expandModeStatus;
		turretToMasterResponse->camIrisModeStatus[i] = masterToTurretCommand->camIrisModeCommand[i];
	}

	turretToMasterResponse->x1_1000CamZoomStatus[0] = xCurrentZoom[0] * 1000;
	turretToMasterResponse->camIrisStatus[0] = wideCamLensStatus->iris;
	turretToMasterResponse->mmX100CamFocusStatus[0] = uint16_t(WideCamLensUtils::hexToMFocus(wideCamLensStatus->focus) * 10);
	turretToMasterResponse->uradX100CamFov[0] = radVFov[0] * 10000;

	turretToMasterResponse->x1_1000CamZoomStatus[1] = xCurrentZoom[1] * 1000;
	turretToMasterResponse->camIrisStatus[1] = int16_t(teleCamLensStatus->teleCamIris * 1000);
	turretToMasterResponse->mmX100CamFocusStatus[1] = int16_t(teleCamLensStatus->mTeleCamFocus * 10);
	turretToMasterResponse->uradX100CamFov[1] = radVFov[1] * 10000;


	turretToMasterResponse->uradTilDivergence = int16_t(tilServoStatus->radTilDivergence * 1000000);
	turretToMasterResponse->mmX100HelFocus = int16_t(teleCamLensStatus->mHelFocus * 10);
	if (*operationMode == OperationMode::TRAINING) {
		turretToMasterResponse->trainingModeStatus[0] = 1;
	}
	else {
		turretToMasterResponse->trainingModeStatus[0] = 0;
	}

	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->trainingModeStatus[i + 1] = imgProcToTurretResponses[i]->trainingModeStatus;
		turretToMasterResponse->recStatus[i] = imgProcToTurretResponses[i]->recStatus;
		turretToMasterResponse->recDecimationStatus[i] = imgProcToTurretResponses[i]->recDecimationStatus;
	}

	turretToMasterResponse->swingScanStatus = masterToTurretCommand->swingScanCommand;
	turretToMasterResponse->coarseLimitActive = 0;
	if (controlCommandAndStatus->servoCommand.alarm.bfWarningFlag & 0x001) {	//Pan -
		turretToMasterResponse->coarseLimitActive |= 0x02;
	}
	if (controlCommandAndStatus->servoCommand.alarm.bfWarningFlag & 0x002) {	//Pan +
		turretToMasterResponse->coarseLimitActive |= 0x01;
	}
	if (controlCommandAndStatus->servoCommand.alarm.bfWarningFlag & 0x010) {	//Tilt -
		turretToMasterResponse->coarseLimitActive |= 0x08;
	}
	if (controlCommandAndStatus->servoCommand.alarm.bfWarningFlag & 0x020) {	//Tilt +
		turretToMasterResponse->coarseLimitActive |= 0x04;
	}
	if (controlCommandAndStatus->servoCommand.alarm.bfWarningFlag & 0x100) {	//Cam -
		turretToMasterResponse->coarseLimitActive |= 0x20;
	}
	if (controlCommandAndStatus->servoCommand.alarm.bfWarningFlag & 0x200) {	//Cam +
		turretToMasterResponse->coarseLimitActive |= 0x10;
	}
	turretToMasterResponse->laserRestrictedAreaStatus = inRestrictArea;
	turretToMasterResponse->bfServoErrorStatus = bfServoErrorStatus;
	turretToMasterResponse->bfTilServoErrorStatus = bfTilServoErrorStatus;
	turretToMasterResponse->bfFineMirrorErrorStatus = bfFineMirrorErrorStatus;
	turretToMasterResponse->bfRs485ConverterErrorStatus = bfRs485ConverterErrorStatus;
	turretToMasterResponse->bfImageProcCommunicationStatus = isImgProcAlive[0] << 1 | isImgProcAlive[1];
	turretToMasterResponse->turretCpuTemp = 0;
	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->imageProcCpuTemp[i] = imgProcToTurretResponses[i]->cpuTemp;
		turretToMasterResponse->imageProcGpuTemp[i] = imgProcToTurretResponses[i]->gpuTemp;
	}
	turretToMasterResponse->MBx100DiskRemaining[0] = logStatus->MBx100DiskRemaining;
	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->MBx100DiskRemaining[1 + i] = imgProcToTurretResponses[i]->MBx100DiskRemaining;
	}
	turretToMasterResponse->camErrorStatus = (imgProcToTurretResponses[1]->camErrorStatus<<1)  | (imgProcToTurretResponses[0]->camErrorStatus);
	if (*operationMode == OperationMode::NORMAL) {
		turretToMasterResponse->parameterFileStatus[0] = 2;
	}
	else {
		turretToMasterResponse->parameterFileStatus[0] = 1;
	}

	turretToMasterResponse->parameterFileStatus[1] = imgProcToTurretResponses[0]->parameterFileStatus;
	turretToMasterResponse->parameterFileStatus[2] = imgProcToTurretResponses[1]->parameterFileStatus;;
	turretToMasterResponse->logFileIdStatus[0] = logStatus->logFileIdStatus;
	for (int i = 0; i < NUM_CAMS; i++) {
		turretToMasterResponse->logFileIdStatus[i + 1] = imgProcToTurretResponses[i]->logFileIdStatus;
	}
	turretToMasterResponse->mX10HelSafeDistance = userParameters->mHelSafeDistance/10;
	turretToMasterResponse->mX10TilSafeDistance = userParameters->mTilSafeDistance/10;
	turretToMasterResponse->servoOnStatus = servoStatus->servoOn;


	for (int i = 0; i < NUM_CAMS; i++) {
		turretToImgProcCommands[i]->packetLength = sizeof(TurretToImgProcCommand) - 4;
		turretToImgProcCommands[i]->packetType = 100 + i;
		turretToImgProcCommands[i]->aiMode = masterToTurretCommand->aiModes[i];
		turretToImgProcCommands[i]->targetLock = masterToTurretCommand->targetLock[i];
		turretToImgProcCommands[i]->pxTargetPos[0] = masterToTurretCommand->pxTargetPos[i][0];
		turretToImgProcCommands[i]->pxTargetPos[1] = masterToTurretCommand->pxTargetPos[i][1];
		turretToImgProcCommands[i]->pxTargetSize[0] = masterToTurretCommand->pxTargetSize[i][0];
		turretToImgProcCommands[i]->pxTargetSize[1] = masterToTurretCommand->pxTargetSize[i][1];
		turretToImgProcCommands[i]->nrad_x10CoarsePos[0] = radToNradx10(servoStatus->radCoarsePos[0]);
		turretToImgProcCommands[i]->nrad_x10CoarsePos[1] = radToNradx10(servoStatus->radCoarsePos[1]);
		turretToImgProcCommands[i]->aimPointMode = masterToTurretCommand->aimPointMode;
		turretToImgProcCommands[i]->pxAimPointOffset[0] = masterToTurretCommand->pxAimPointOffset[0];
		turretToImgProcCommands[i]->pxAimPointOffset[1] = masterToTurretCommand->pxAimPointOffset[1];
		turretToImgProcCommands[i]->nrad_x10RadarTargetPos[0] = radToNradx10(servoCommand->control.radRadarReference[0]);
		turretToImgProcCommands[i]->nrad_x10RadarTargetPos[1] = radToNradx10(servoCommand->control.radRadarReference[1]);
		double mRadarX = masterToTurretCommand->mmExternalSensorPos[0] / 1000.0;
		double mRadarY = masterToTurretCommand->mmExternalSensorPos[1] / 1000.0;
		double mRadarZ = masterToTurretCommand->mmExternalSensorPos[2] / 1000.0;
		double mRadarRange = sqrt(mRadarX * mRadarX + mRadarY * mRadarY + mRadarZ * mRadarZ);
		turretToImgProcCommands[i]->mm_x100RadarTargetDistance = mRadarRange*10;
		turretToImgProcCommands[i]->camGainModeCommand = masterToTurretCommand->camGainModeCommand[i];
		turretToImgProcCommands[i]->camGainCommand = masterToTurretCommand->dB1_10CamGainCommand[i];
		turretToImgProcCommands[i]->camZoomModeStatus = masterToTurretCommand->camZoomModeCommand[i];
		turretToImgProcCommands[i]->xCamZoomStatus = xCurrentZoom[i] * 1000;
		turretToImgProcCommands[i]->uradX100VFov = radVFov[i] * 10000;
		turretToImgProcCommands[i]->expandModeCommand = masterToTurretCommand->expandModeCommand[i];
		turretToImgProcCommands[i]->camIrisModeCommand = masterToTurretCommand->camIrisModeCommand[i];
		turretToImgProcCommands[i]->camIrisCommand = masterToTurretCommand->camIrisCommand[i];
		turretToImgProcCommands[i]->camFocusModeStatus = masterToTurretCommand->camFocusModeCommand[i];
		turretToImgProcCommands[0]->mmX100CamFocusStatus = turretToMasterResponse->mmX100CamFocusStatus[0];
		turretToImgProcCommands[1]->mmX100CamFocusStatus = turretToMasterResponse->mmX100CamFocusStatus[1];
		turretToImgProcCommands[i]->armStatus = masterToTurretCommand->armStatus;
		turretToImgProcCommands[i]->sHelTimeout = masterToTurretCommand->sHelTimeout;
		turretToImgProcCommands[i]->bfHelStatus = masterToTurretCommand->bfHelStatus;
		turretToImgProcCommands[i]->bfTilStatus = masterToTurretCommand->tilStatus;
		turretToImgProcCommands[i]->uradTilDivergence = uint16_t(tilServoStatus->radTilDivergence*1000000.0);
		turretToImgProcCommands[i]->mmX100HelFocus = int16_t(teleCamLensStatus->mHelFocus * 10);
		turretToImgProcCommands[i]->lrfStatus = rangefinderStatus->status;
		turretToImgProcCommands[i]->mm_x100LrfDistance = rangefinderStatus->mmX100Range;
		turretToImgProcCommands[i]->bfIsInLaserRestrictArea = inRestrictArea;
		turretToImgProcCommands[i]->swingScanMode = masterToTurretCommand->swingScanCommand;
		turretToImgProcCommands[i]->scanZoneDesignateCommand = masterToTurretCommand->scanZoneDesignateCommand[i];
		turretToImgProcCommands[i]->pxDesignatedScanZone[0] = masterToTurretCommand->pxDesignatedScanZone[i][0];
		turretToImgProcCommands[i]->pxDesignatedScanZone[1] = masterToTurretCommand->pxDesignatedScanZone[i][1];
		turretToImgProcCommands[i]->mpsNeutralizationCriteria[0] = userParameters->mpsFallSpeedCriteriaLow;
		turretToImgProcCommands[i]->mpsNeutralizationCriteria[1] = userParameters->mpsFallSpeedCriteriaHigh;
		turretToImgProcCommands[i]->recCommand = masterToTurretCommand->recCommand[i];
		turretToImgProcCommands[i]->recDecimationCommand = masterToTurretCommand->recDecimationCommand[i];
		turretToImgProcCommands[i]->shootDownOverrideStatus = masterToTurretCommand->shootDownOverrideCommand;
		turretToImgProcCommands[i]->shutdownRequest = masterToTurretCommand->shutdownRequest;
		turretToImgProcCommands[i]->bfAuxDisplayInfo = masterToTurretCommand->auxDisplayInfo;
		turretToImgProcCommands[i]->nrad_x10VehicleHeading = masterToTurretCommand->nrad_x10VehicleAttitude[2];
		turretToImgProcCommands[i]->soiCamId = masterToTurretCommand->soiCamId;
		turretToImgProcCommands[i]->trackingCamId = trackingCamId;
		turretToImgProcCommands[i]->externalSensorTargetSelectionModeStatus = masterToTurretCommand->externalSensorTargetSelectionModeStatus;
		turretToImgProcCommands[i]->logFileId = masterToTurretCommand->logFileId[i + 1];
	}


	for (int i = 0; i < NUM_CAMS; i++) {
		prevMatchIds[i] = imgProcToTurretResponses[i]->matchId;
	}

	////////////////////////////////////////
	// Rangefinder
	////////////////////////////////////////
	rangefinderCommand->on = masterToTurretCommand->rangeFinderCommand;

	////////////////////////////////////////
	// WideCamLens
	////////////////////////////////////////

	double mRadarX = masterToTurretCommand->mmExternalSensorPos[0] / 1000.0;
	double mRadarY = masterToTurretCommand->mmExternalSensorPos[1] / 1000.0;
	double mRadarZ = masterToTurretCommand->mmExternalSensorPos[2] / 1000.0;
	double mRadarRange;
	if (masterToTurretCommand->externalSensorType != 0) {
		mRadarRange = sqrt(mRadarX * mRadarX + mRadarY * mRadarY + mRadarZ * mRadarZ);
	}
	else {
		mRadarRange = 0.0;
	}


	if (masterToTurretCommand->camZoomModeCommand[0] == 0) {//Manual
		wideCamLensCommand->zoom = WideCamLensUtils::xMagnificationToHex(masterToTurretCommand->x1_1000CamZoomCommand[0] / 1000.0);
	}
	else {//Auto
		if (masterToTurretCommand->controlMode == 20 && masterToTurretCommand->externalSensorType != 0) {	//Slave to Radar
			wideCamLensCommand->zoom = WideCamLensUtils::radarRangeToZoomCommand(mRadarRange);
		}
		else if (imgProcToTurretResponses[0]->matchValid == 2) {//keep target size
			wideCamLensCommand->zoom = WideCamLensUtils::targetSizeToZoomCommand(imgProcToTurretResponses[0]->pxMatchSize[0], imgProcToTurretResponses[0]->pxMatchSize[1], xCurrentZoom[0]);
		}
		else {
			//keep current zoom level
		}
	}

	if (masterToTurretCommand->camFocusModeCommand[0] == 0) {//Manual
		wideCamLensCommand->focus = WideCamLensUtils::mFocusToHex(masterToTurretCommand->mmX100CamFocusCommand[0] / 10.0);
	}
	else {//Auto
		if (masterToTurretCommand->externalSensorType != 0) {//Slave to Radar
			wideCamLensCommand->focus = WideCamLensUtils::mFocusToHex(mRadarRange);
		}
		else {
			//keep current focus
		}
	}

	if (masterToTurretCommand->camIrisModeCommand[0] == 0) {//Manual
		wideCamLensCommand->iris = ((int32_t)masterToTurretCommand->camIrisCommand[0]) * 0xFFFF / 1000;
	}
	else {//Auto
		wideCamLensCommand->iris = 0xFFFF;
	}


	////////////////////////////////////////
	// TeleCamLens
	////////////////////////////////////////
	if (masterToTurretCommand->camZoomModeCommand[1] == 0) {//Manual
		teleCamLensCommand->xZoom = masterToTurretCommand->x1_1000CamZoomCommand[1] / 1000.0;
	}
	else {//Auto
		if (masterToTurretCommand->controlMode == 20 && masterToTurretCommand->externalSensorType != 0) {	//Slave to Radar
			teleCamLensCommand->xZoom = ServoController::radarRangeToZoomCommand(mRadarRange);
		}
		else if (imgProcToTurretResponses[1]->matchValid == 2) {	//keep target size
			teleCamLensCommand->xZoom = ServoController::targetSizeToZoomCommand(imgProcToTurretResponses[1]->pxMatchSize[0], imgProcToTurretResponses[1]->pxMatchSize[1], xCurrentZoom[1]);
		}
		else {
			//keep current zoom level
		}
	}

	if (masterToTurretCommand->camFocusModeCommand[1] == 0) {//Manual
		teleCamLensCommand->mFocus = masterToTurretCommand->mmX100CamFocusCommand[1] / 10.0;
	}
	else {//Auto
		if (masterToTurretCommand->externalSensorType != 0) {//Slave to Radar
			teleCamLensCommand->mFocus = mRadarRange;
		}
		else {
			//keep current focus
		}
	}

	if (masterToTurretCommand->camIrisModeCommand[1] == 0) {//Manual
		teleCamLensCommand->iris = masterToTurretCommand->camIrisCommand[1] / 1000.0;
	}
	else {//Auto
		teleCamLensCommand->iris = ServoController::xZoomCommandToIrisCommand(teleCamLensCommand->xZoom);
	}

	teleCamLensCommand->mHelFocus = masterToTurretCommand->mmX100HelFocus / 10.0;

	tilServoCommand->radTilDivergence = masterToTurretCommand->uradTilDivergence / 1000000.0;


	controlCommandAndStatus->logFileIdCommand = masterToTurretCommand->logFileId[0];


	return ret;
}