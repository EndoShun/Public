#pragma once

#include "stdint.h"

class WideCamLensUtils {
private:
	static constexpr double MM_WIDE_END_FLENGTH = 15.6;
	static constexpr double MM_TELE_END_FLENGTH = 500.0;
	static constexpr double MM_FLENGTH_AT_X1 = 30.625;
	static constexpr double RAD_ANGLE_RESOLUTION_AT_RAW_X1 = 247.248 / 1000000.0;
	static constexpr int32_t SENSOR_RESOLUTION_Y = 4600;

	static constexpr uint16_t PX_PREFFERED_TARGET_SIZE = 80;
	static constexpr double   PREFFERED_TARGET_SIZE_MARGIN = 1.2;

	static constexpr int32_t ZOMM_COMMAND_TO_RAW_MAGNIFICATION_TABLE_LENGTH = 17;
	static constexpr double ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[ZOMM_COMMAND_TO_RAW_MAGNIFICATION_TABLE_LENGTH] = {
		1.00,//0x0000
		1.12,//0x1000
		1.27,//0x2000
		1.44,//0x3000
		1.66,//0x4000
		1.93,//0x5000
		2.28,//0x6000
		2.72,//0x7000
		3.31,//0x8000
		4.14,//0x9000
		5.31,//0xA000
		7.05,//0xB000
		9.62,//0xC000
		13.01,//0xD000
		17.69,//0xE000
		23.97,//0xF000
		32.00,//0xFFFF
	};

	static constexpr uint16_t FOCUS_COMMAND_OFFSET = 0xC000;
	static constexpr int32_t FOCUS_COMMAND_TO_M_FOCUS_TABLE_LENGTH = 17;
	static constexpr double FOCUS_COMMAND_TO_M_FOCUS_TABLE[FOCUS_COMMAND_TO_M_FOCUS_TABLE_LENGTH] = {
		//��p�͈�75m�`1200m�ł̐��x�����߂邽�߁A0xC000�`0xFFFF�͈̔͂��e�[�u���Ƃ���
		11.3,//0xC000
		12.1,//0xC400
		13.0,//0xC800
		14.0,//0xCC00
		15.2,//0xD000
		16.6,//0xD400
		18.3,//0xD800
		20.4,//0xDC00
		23.1,//0xE000
		26.5,//0xE400
		31.2,//0xE800
		37.8,//0xEC00
		48.2,//0xF000
		66.2,//F400
		106.1,//F800
		267.7,//0xFC00
		2000.0,//(inf)0xFFFF
	};

	static constexpr uint16_t RADAR_TO_ZOOM_COMMAND_CEIL = 0xEC00;
	static constexpr double   RADAR_TO_ZOOM_CEIL_RANGE = 850;
	static constexpr uint16_t RADAR_TO_ZOOM_COMMAND_FLOOR = 0x5000;
	static constexpr double   RADAR_TO_ZOOM_FLOOR_RANGE = 75;

public:
	static constexpr int16_t RESOLUTION[2] = { 4320,4320 };

	static double xRawMagnificationToRadAngleResolution(double xRawMagnification);
	static uint16_t xRawMagnificationToHex(double rawMagnification);
	static double hexToXRawMagnification(uint16_t zoomCommand);

	static uint16_t xMagnificationToHex(double magnification);
	static double hexToXMagnification(uint16_t zoomCommand);

	static double xZoomToRadVFov(double zoom);
	static double xZoomToRadPerPixel(double zoom);

	static uint16_t radarRangeToZoomCommand(double mRange);
	static uint16_t targetSizeToZoomCommand(uint16_t width,uint16_t height,double xCurrentZoom);

	static uint16_t mFocusToHex(double mFocus);
	static double hexToMFocus(uint16_t focusCommand);
};