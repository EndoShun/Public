/*****************************************************************************
* Poll2.c - �|�[�����O�̂��߂̃��W���[�� Poll2
\*****************************************************************************/

#include <stdio.h>
#include <rt.h>
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "MotorCtrl.h"
#include "INtimeMotorCtrl.h"

/*****************************************************************************
* FUNCTION:		PollMotorMonitor
* DESCRIPTION:
*   �|�[�����O�X���b�h PollMotorMonitor
\*****************************************************************************/
void				PollMotorMonitor(
	void*				param)
{
	LONG pos[AXIS_NUM] = { 0,0 };
	LONG fspd[AXIS_NUM] = { 0,0 };
	LONG trq[AXIS_NUM] = { 0,0 };
	double da[AXIS_NUM] = { 0.0,0.0 };
	int send_flg = FALSE;
	ULONG seq = 0;
#ifdef _DEBUG
	fprintf(stderr, "PollMotorMonitor started\n");
#endif

	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollMotorMonitor = GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollMotorMonitor, "TPollMotorMonitor");

	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(100000));

#ifdef _DEBUG
//		fprintf(stderr, "PollMotorMonitor waking up\n");
#endif

		// TODO:  1000 �~���b���ƂɌJ��Ԃ�������z�u���܂�
		//if(pMonitorParam1!=NULL){
		//	memcpy(&pShm->axis1_param, pMonitorParam1, sizeof(MON_PARAM));
		//}
		//if(pMonitorParam2!=NULL){
		//	memcpy(&pShm->axis2_param, pMonitorParam2, sizeof(MON_PARAM));
		//}

		// TODO:  1000 �~���b���ƂɌJ��Ԃ�������z�u���܂�
		if(pMonitorParam1!=NULL){
			if (pos[0] != pMonitorParam1->SV.apos) {
				pos[0] = pMonitorParam1->SV.apos;
				fspd[0] = pMonitorParam1->SV.fspd;
				trq[0] = pMonitorParam1->SV.trq;
				if(pMonitorParam2!=NULL){
					pos[1] = pMonitorParam2->SV.apos;
					fspd[1] = pMonitorParam2->SV.fspd;
					trq[1] = pMonitorParam2->SV.trq;
				}
				da[0] = 0;
				da[1] = 0;
				send_flg = TRUE;
			}
		}
		if(pMonitorParam2!=NULL){
			if (pos[1] != pMonitorParam2->SV.apos) {
				if(pMonitorParam1!=NULL){
					pos[0] = pMonitorParam1->SV.apos;
					fspd[0] = pMonitorParam1->SV.fspd;
					trq[0] = pMonitorParam1->SV.trq;
				}
				pos[1] = pMonitorParam2->SV.apos;
				fspd[1] = pMonitorParam2->SV.fspd;
				trq[1] = pMonitorParam2->SV.trq;
				da[0] = 0;
				da[1] = 0;
				send_flg = TRUE;
			}
		}
		if (da[0] != 0) {
			if(pMonitorParam1!=NULL){
				pos[0] = pMonitorParam1->SV.apos;
				fspd[0] = pMonitorParam1->SV.fspd;
				trq[0] = pMonitorParam1->SV.trq;
			}
			if(pMonitorParam2!=NULL){
				pos[1] = pMonitorParam2->SV.apos;
				fspd[1] = pMonitorParam2->SV.fspd;
				trq[1] = pMonitorParam2->SV.trq;
			}
			da[0] = 0;
			da[1] = 0;
			send_flg = TRUE;
		}
		if (da[1] != 0) {
			if(pMonitorParam1!=NULL){
				pos[0] = pMonitorParam1->SV.apos;
				fspd[0] = pMonitorParam1->SV.fspd;
				trq[0] = pMonitorParam1->SV.trq;
			}
			if(pMonitorParam2!=NULL){
				pos[1] = pMonitorParam2->SV.apos;
				fspd[1] = pMonitorParam2->SV.fspd;
				trq[1] = pMonitorParam2->SV.trq;
			}
			da[0] = 0;
			da[1] = 0;
			send_flg = TRUE;
		}
		if (send_flg == TRUE) {
			//SendMonitorMsg(STAT_EVT_CODE, seq, pos[0], fspd[0], trq[0], pos[1], fspd[1], trq[1], da[0], da[1]);
			seq++;
		}
		else {
			if (pMonitorParam1 != NULL && pMonitorParam2 != NULL) {
				//SendMonitorMsg(MONI_EVT_CODE, seq,
				//	pMonitorParam1->SV.apos, pMonitorParam1->SV.fspd, pMonitorParam1->SV.trq,
				//	pMonitorParam2->SV.apos, pMonitorParam2->SV.fspd, pMonitorParam2->SV.trq,
				//	da[0], da[1]);
			}
			else if (pMonitorParam1 != NULL) {
				//SendMonitorMsg(MONI_EVT_CODE, seq,
				//	pMonitorParam1->SV.apos, pMonitorParam1->SV.fspd, pMonitorParam1->SV.trq,
				//	pos[1], fspd[1], trq[1],
				//	da[0], da[1]);
			}
			else if (pMonitorParam2 != NULL) {
				//SendMonitorMsg(MONI_EVT_CODE, seq,
				//	pos[0], fspd[0], trq[0],
				//	pMonitorParam2->SV.apos, pMonitorParam2->SV.fspd, pMonitorParam2->SV.trq,
				//	da[0], da[1]);
			}
			else {
				//SendMonitorMsg(MONI_EVT_CODE, seq,
				//	pos[0], fspd[0], trq[0],
				//	pos[1], fspd[1], trq[1],
				//	da[0], da[1]);
			}

			seq++;
		}
		send_flg = FALSE;
	}

	// �{�X���b�h�̏I����ʒm
	gInit.htPollMotorMonitor = NULL_RTHANDLE;
}
