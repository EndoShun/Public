
#include "MotorDriver.h"
#include "rt.h"
#include "../INtimeMotorCtrl.h"
#include "stdio.h"
#include "ServoController.h"
#include "../MyDebug.h"

DWORD MotorDriver::setupResisterAddress() {
	HREGISTERDATA hIRegister;
	HREGISTERDATA hORegister;
	HREGISTERDATA hMonitorParam;
	HREGISTERDATA hSettingParam;
	HREGISTERDATA hSystemRegister;

	DWORD ret;

	//////////////////////////////////////
	// ���W�X�^�n���h���擾
	//////////////////////////////////////
	ret = ymcGetRegisterDataHandle((LPBYTE)"IW0000", &hIRegister);
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"OW0000", &hORegister);
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"IW8000", &hMonitorParam);					// �`���l���P���j�^�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"OW8000", &hSettingParam);					// �`���l���P�ݒ�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"SW0000", &hSystemRegister);					// �V�X�e�����W�X�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}

	ret = ymcGetRegisterDataAddress(hIRegister, (LPDWORD)&pIRegister);
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	ret = ymcGetRegisterDataAddress(hORegister, (LPDWORD)&pORegister);
	if (ret != MP_SUCCESS)
	{
		return ret;
	}

	PMON_PARAM monitorParamBase;
	ret = ymcGetRegisterDataAddress(hMonitorParam, (LPDWORD)&monitorParamBase);	// �`���l���P���j�^�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	for (int i = 0; i < AXIS_NUM; i++) {
		pMonitorParams[i] = monitorParamBase + (STATION_NO_SERVOS[i]-1);
	}

	PSET_PARAM settingParamsBase;
	ret = ymcGetRegisterDataAddress(hSettingParam, (LPDWORD)&settingParamsBase);	// �`���l���P�ݒ�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	for (int i = 1; i < AXIS_NUM; i++) {
		pSettingParams[i] = settingParamsBase + (STATION_NO_SERVOS[i]-1);
	}
	ret = ymcGetRegisterDataAddress(hSystemRegister, (LPDWORD)&pSystemRegister);	// �V�X�e�����W�X�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}

	return MP_SUCCESS;
}



MotorDriver::MotorDriver() {
	initOk = 0;
	isControllerOpen = 0;

	pIRegister = nullptr;
	pORegister = nullptr;
	for (int i = 0; i < AXIS_NUM; i++) {
		pMonitorParams[i] = nullptr;
		pSettingParams[i] = nullptr;
	}
	pSystemRegister = nullptr;

	cyclesSearchZeroTimeout = 0;
}
MotorDriver::~MotorDriver() {
	ULONG ret;

	if (isControllerOpen) {
		servoEnable(0);
		servoStop();
		tilServo.tilTerminate();
		ret = ymcCloseController();
	}
}

DWORD MotorDriver::init(ServoErrors::MotorInitSequence& sequenceMarker) {
	if (DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}

	//////////////////////////////////////
	// MP3110 init
	//////////////////////////////////////
	sequenceMarker = ServoErrors::MotorInitSequence::OK;

	DWORD ret;
	ret = ymcOpenController(BUILD_TYPE);
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::OPEN_CONTROLLER;
		return ret;
	}
	isControllerOpen = 1;

	ret = ymcInitializeAPIThread();
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::INITIALIZE_THREAD;
		return ret;
	}

	ret = ymcSetAPITimeoutValue(MS_API_TIMEOUT);
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::SET_API_TIMEOUT;
		return ret;
	}

	//////////////////////////////////////
	// Servos init
	//////////////////////////////////////
	ret = setupResisterAddress();
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::SETUP_REGISTER_ADDRESS;
		return ret;
	}

	//AXIS_INFO axisInfo;
	//axisInfo.SlotNo = SLOT1;
	//axisInfo.ChannelNo = CHANNEL1;
	//axisInfo.STCount = AXIS_NUM;
	//axisInfo.MotionFunc = MODULE_SVC32;
	//for (int i = 0; i < AXIS_NUM; i++) {
	//	axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	//}
	//ret = ymcClearServoAlarm(&axisInfo);
	//if (ret != MP_SUCCESS) {
	//	sequenceMarker = 5;
	//	return ret;
	//}

	//////////////////////////////////////
	// DAC init
	//////////////////////////////////////
	//IO_DATA iodata;
	//USHORT ival[8];

	//axisInfo.SlotNo = SLOT1;
	//axisInfo.ChannelNo = CHANNEL1;
	//axisInfo.MotionFunc = MODULE_SVC32;
	//axisInfo.STCount = 1;
	//axisInfo.STNo[0] = STATION_NO_DAC;

	//ival[0] = 0x0004;	//�R�}���h = �p�����[�^��������
	//ival[1] = 0x0000;	//�R�}���h���� = N/A
	////ival[2] = 0x0300;	//DA2
	//ival[3] = 2;		//SIZE = 2byte
	//ival[4] = 2;		//�d�����[�h2(0-10V)
	//ival[5] = 0x0000;
	//ival[6] = 0x0000;
	//ival[7] = 0x0000;
	//iodata.Size = 8;
	//iodata.pIoBuffer = (void*)ival;

	//for (int i = 0; i < 4; i++) {
	//	ival[2] = (i + 1) << 16;	//�p�����[�^NO (CH[i] �o�̓��[�h�ݒ�)
	//	ret = ymcSetIoData(&axisInfo, &iodata);
	//	if (ret != MP_SUCCESS) {
	//		sequenceMarker = ServoController::MotorInitSequence::INIT_DAC;
	//		return ret;
	//	}
	//}

	initOk = 1;
	return MP_SUCCESS;
}

DWORD MotorDriver::tmpInit2(ServoErrors::MotorInitSequence& sequenceMarker) {
	//////////////////////////////////////
	// MP3110 init
	//////////////////////////////////////
	sequenceMarker = ServoErrors::MotorInitSequence::OK;

	DWORD ret;
	ret = ymcOpenController(BUILD_TYPE);
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::OPEN_CONTROLLER;
		return ret;
	}
	isControllerOpen = 1;

	ret = ymcInitializeAPIThread();
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::INITIALIZE_THREAD;
		return ret;
	}

	ret = ymcSetAPITimeoutValue(MS_API_TIMEOUT);
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::SET_API_TIMEOUT;
		return ret;
	}

	initOk = 1;
	return MP_SUCCESS;
}

DWORD MotorDriver::waitCycle() {
	if (!DEBUG_SERVO_DISABLE) {
		AXIS_INFO axisInfo;
		axisInfo.SlotNo = SLOT1;
		axisInfo.ChannelNo = CHANNEL1;

		DWORD ret = ymcWaitCycleTime(&axisInfo);

		return ret;
	}
	else {
		knRtSleep(UsecsToKticks(1000));

	}
}

DWORD MotorDriver::servoEnable(int32_t on[AXIS_NUM]) {
	if (!initOk || DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}

	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = AXIS_NUM;
	
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}

	SVCTRL_DATA svControlData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		if (on[i]) {
			svControlData->ControlType = SERVO_ON;
		}
		else {
			svControlData->ControlType = SERVO_OFF;
		}
	}
	
	return ymcServoControl(&axisInfo,svControlData);
}

DWORD MotorDriver::servoEnable(int32_t on) {
	int32_t axisOn[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		axisOn[i] = on;
	}

	return servoEnable(axisOn);
}

DWORD MotorDriver::servoStop() {
	if (DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}

	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.STCount = AXIS_NUM;
	axisInfo.MotionFunc = MODULE_SVC32;
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}
	
	STOP_DATA stopData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		stopData[i].StopMode = STOP_SLOW;
	}

	return ymcStopMotion(&axisInfo, stopData);
}

DWORD MotorDriver::servoPositionControl(const double radPositions[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM], const double nmTorqueLimits[AXIS_NUM]) {
	if (DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}
	
	AXIS_INFO axisInfo;

	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = AXIS_NUM;
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}
	
	MOTION_DATA motionData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		motionData[i].VelocityUnit = VELUNIT_SEC;
		motionData[i].AccUnit = ACCUNIT_SEC;
		motionData[i].FilterType = FILTER_DISABLE;
		motionData[i].FilterValue = 0;
		motionData[i].PsetWidth = SERVO_POSITION_CONTROL_PSET_WIDTH;
		motionData[i].Accel = SERVO_POSITION_CONTROL_ACCEL;
		motionData[i].Decel = SERVO_POSITION_CONTROL_DECEL;
		motionData[i].TrqUnit = TRQUNIT_SMALLPERCENT;
		double trqLimit = nmTorqueLimits[i] * 1000000.0 / NM_SERVO_RATED_TORQUES[i];
		if (trqLimit < 0) {
			trqLimit = 0.0;
		}
		else if (trqLimit >= 1000000.0) {
			trqLimit = 1000000.0;
		}
		motionData[i].TrqLimit = (ULONG)trqLimit;
	}
	
	MOVE_DATA moveData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		moveData[i].PosType = POSTYPE_ABS;
		double velocity = rpsVelocityLimits[i] / RAD_PER_STEP_SERVO_RESOLUTION[i];
		if (velocity < 0) {
			velocity = 0;
		}
		else if (velocity > INT32_MAX) {
			velocity = INT32_MAX;
		}
		moveData[i].Velocity = (LONG)velocity;

		double pos = radPositions[i] / RAD_PER_STEP_SERVO_RESOLUTION[i];
		if (pos < -STEPS_PER_REV_SERVO_RESOLUTION[i]) {
			pos = -STEPS_PER_REV_SERVO_RESOLUTION[i];
		}
		else if (pos > STEPS_PER_REV_SERVO_RESOLUTION[i]) {
			pos = STEPS_PER_REV_SERVO_RESOLUTION[i];
		}
		moveData[i].TargetPos = (long)pos;

	}

	return ymcMovePositioning(&axisInfo,motionData,moveData,COMMAND_STARTED);
}

DWORD MotorDriver::servoVelocityControl(const double rpsVelocities[AXIS_NUM], const double nmTorqueLimits[AXIS_NUM]) {
	if (DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}

	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = AXIS_NUM;
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}

	VELOCTRL_DATA veloCtrlData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		veloCtrlData[i].TrqUnit = TRQUNIT_SMALLPERCENT;
		double torque = 1000000.0 * nmTorqueLimits[i] / NM_SERVO_RATED_TORQUES[i];
		if (torque < 0) {
			torque = 0;
		}
		else if (torque > 1000000.0) {
			torque = 1000000.0;
		}

		veloCtrlData[i].TrqLimit = (ULONG) torque;
		veloCtrlData[i].TrqFF = 0;
		veloCtrlData[i].VelocityUnit = VELUNIT_SEC;
		double vel = rpsVelocities[i] / RAD_PER_STEP_SERVO_RESOLUTION[i];
		if (vel < INT32_MIN) {
			vel = INT32_MIN;
		}
		else if (vel > INT32_MAX) {
			vel = INT32_MAX;
		}
		veloCtrlData[i].Velocity = (LONG)vel;
	}

	return ymcVelocityModeControl(&axisInfo, veloCtrlData);
}

DWORD MotorDriver::servoTorqueControl(const double nmTorques[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM]) {
	if (DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}
	
	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = AXIS_NUM;
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}

	TRQCTRL_DATA torqueCtrlData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		torqueCtrlData[i].TrqUnit = TRQUNIT_SMALLPERCENT;
		double torque = nmTorques[i] * 1000000.0/NM_SERVO_RATED_TORQUES[i];
		if (torque < -1000000.0) {
			torque = -1000000.0;
		}
		else if (torque > 1000000.0) {
			torque = 1000000.0;
		}
		torqueCtrlData[i].ComTorque = (LONG)torque;


		double vel = rpsVelocityLimits[i] * 10000.0 * RPS_SERVO_RATED_VELOCITIES[i];
		if (vel < -10000.0) {
			vel = -10000.0;
		}
		else if (vel > 10000.0) {
			vel = 10000.0;
		}
		torqueCtrlData[i].VelocityLimit = (ULONG)vel;
	}

	return ymcTorqueModeControl(&axisInfo, torqueCtrlData);
}

DWORD MotorDriver::servoSearchZero(const double nmTorqueLimits[AXIS_NUM]) {
	if (DEBUG_SERVO_DISABLE) {
		return MP_SUCCESS;
	}

	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = AXIS_NUM;
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}

	MOTION_DATA motionData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		motionData[i].FilterType = FILTER_DISABLE;
		motionData[i].FilterValue = 0;
		motionData[i].PsetWidth = SERVO_POSITION_CONTROL_PSET_WIDTH;

		motionData[i].AccUnit = ACCUNIT_SEC;
		motionData[i].Accel = SERVO_POSITION_CONTROL_ACCEL;
		motionData[i].Decel = SERVO_POSITION_CONTROL_DECEL;

		motionData[i].VelocityUnit = VELUNIT_SEC;

		motionData[i].TrqUnit = TRQUNIT_SMALLPERCENT;
		double torque = nmTorqueLimits[i] * 1000000.0 / NM_SERVO_RATED_TORQUES[i];
		if (torque < 0) {
			torque = 0;
		}
		else if (torque > 1000000.0) {
			torque = 1000000.0;
		}
		motionData[i].TrqLimit = (ULONG)torque;
	}

	HOMEPOS_DATA homeposData[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		homeposData[i].ZretMode = 3;//TODO: set proper value
		homeposData[i].ZretDecDist = SERVO_SEARCH_ZERO_ZRET_DEC_DIST;
		homeposData[i].StartDirection = SERVO_SEARCH_ZERO_START_DIRECTIONS[i];
		homeposData[i].Velocity = SERVO_SEARCH_ZERO_VELOCITY;
		homeposData[i].ApproachSpeed = SERVO_SEARCH_ZERO_APPROACH_VELOCITY;
		homeposData[i].CreepSpeed = SERVO_SEARCH_ZERO_CREEP_VELOCITY;
	}

	return ymcMoveHomePosition(&axisInfo,motionData,homeposData);
}

DWORD MotorDriver::servoSearchZero() {
	return servoSearchZero(NM_SERVO_SEARCH_ZERO_DEFAULT_TORQUE);
}

int32_t MotorDriver::isServoSearchZeroComplete() {
	if (DEBUG_SERVO_DISABLE) {
		return 1;
	}

	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = AXIS_NUM;
	for (int i = 0; i < AXIS_NUM; i++) {
		axisInfo.STNo[i] = STATION_NO_SERVOS[i];
	}

	CHKCMP_DATA checkComp[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		checkComp[i].APINo = MOVEHOMEPOSITION;
	}

	ULONG ret = ymcCheckComplete(&axisInfo,checkComp);
	if (ret == MP_SUCCESS) {
		return 1;
	}
	else {
		return 0;
	}
}

int32_t MotorDriver::isRetracted(const ServoStatus& servoStatus) {
	if (DEBUG_SERVO_DISABLE) {
		return 1;
	}

	int32_t retracted = 1;

	for (int i = 0; i < AXIS_NUM; i++) {
		double radPosError = servoStatus.radCoarsePos[i] - ServoController::RAD_RETRACT_POS[i];
		if (radPosError < -ServoController::RAD_RETRACT_COMPLETE_MARGIN || radPosError > ServoController::RAD_RETRACT_COMPLETE_MARGIN) {
			retracted = 0;
			break;
		}

		double radSpeedError = servoStatus.rpsCoarseSpeed[i];
		if (radSpeedError < -ServoController::RPS_RETRACT_COMPLETE_MARGIN || radSpeedError > ServoController::RPS_RETRACT_COMPLETE_MARGIN) {
			retracted = 0;
			break;
		}
	}

	return retracted;
}

DWORD MotorDriver::setDACValue(double axis0, double axis1, double axis2, double axis3) {
	//axis0,axis1: input -1.0 �` 1.0, output: 0�`10V
	//axis2,axis3: input    0 �` 1,   output: 0�`5V
	// 
	//�p�����[�^�\���A�o�͒l�\���F�uSIJP C880781 04D ���o�̓��W���[�� ���[�U�[�Y�}�j���A���v�Q��
	//�R�}���h�t�H�[�}�b�g�F�uSIJP C880725 11Q ���[�V��������@�\�@���[�U�[�Y�}�j���A�� SVC/SVC32/SVC64, SVR/SVR32�v�Q��
	
	int32_t daVal[4];
	daVal[0] = (int32_t)(((axis0 / 2.0) * FINEX_GAIN + FINEX_OFFSET) * DA_FULLSCALE);
	daVal[1] = (int32_t)(((axis1 / 2.0) * FINEY_GAIN + FINXY_OFFSET) * DA_FULLSCALE);
	daVal[2] = (int32_t)(((axis2 / 2.0) * DA2_GAIN + DA2_OFFSET) * DA_FULLSCALE);
	daVal[3] = (int32_t)(((axis3 / 2.0) * DA3_GAIN + DA3_OFFSET) * DA_FULLSCALE);

	for (int i = 0; i < 4; i++) {
		if (daVal[i] < 0) {
			daVal[i] = 0;
		}
		else if (daVal[i] > DA_FULLSCALE) {
			daVal[i] = DA_FULLSCALE;
		}
	}
	
	AXIS_INFO axisInfo;

	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = 1;
	axisInfo.STNo[0] = STATION_NO_DAC;

	IO_DATA iodata;
	USHORT ival[8];
	iodata.Size = 8;
	iodata.pIoBuffer = (void*)ival;

	ival[0] = 0x0000;	//�f�[�^���o�̓R�}���h
	ival[1] = 0x0000;	//�R�}���h���� = N/A
	ival[2] = (USHORT)daVal[0];
	ival[3] = (USHORT)daVal[1];
	ival[4] = (USHORT)daVal[2];
	ival[5] = (USHORT)daVal[3];
	ival[6] = 0x0000;
	ival[7] = 0x0000;

	return ymcSetIoData(&axisInfo, &iodata);
}

int32_t MotorDriver::readServoStatus(ServoStatus& servoStatus, FineMirrorStatus& fineMirrorStatus, TeleCamLensStatus& lensStatus, TilServoStatus& tilServoStatus) {
	for (int i = 0; i < AXIS_NUM; i++) {
		if (pMonitorParams[i] != NULL) {
			servoStatus.radCoarsePos[i] = stepToRad(0, pMonitorParams[i]->SV.apos);            // ���񑕒u�̌��݂̈ʒu
			servoStatus.rpsCoarseSpeed[i] = stepToRad(0, pMonitorParams[i]->SV.fspd);
			servoStatus.coarseStatus[i] = (unsigned char)pMonitorParams[i]->SV.runsts;
			servoStatus.coarseParamErrorNo[i] = pMonitorParams[i]->SV.erno;
			servoStatus.coarseWarning[i] = (unsigned short)pMonitorParams[i]->SV.warning;
			servoStatus.coarseAlarm[i] = pMonitorParams[i]->SV.alarm;
			servoStatus.coarseDriverAlarmCode[i] = pMonitorParams[i]->SV.svalarm;
		}
	}

	//servoStatus.servoOn = 0; servoOn��ServoController�ɂĐݒ�
	//servoStatus.homingComplete = 0;//homingComplete��ServoController�ɂĐݒ�
	fineMirrorStatus.alarmCode = 0;	//TODO: �ڑ�
	fineMirrorStatus.warningCode = 0;	//TODO: �ڑ�

	lensStatus.xTeleCamZoom = teleCamLensControl.getXZoom();
	lensStatus.radTeleCamFov = ServoController::RAD_VFOV_AT_X1 / lensStatus.xTeleCamZoom;
	lensStatus.mTeleCamFocus = teleCamLensControl.getMFocus();
	lensStatus.teleCamIris = teleCamLensControl.getIris();
	lensStatus.mHelFocus = teleCamLensControl.getMHelFocus();
	tilServoStatus.radTilDivergence = tilServo.getRadTilDivergence();
	tilServoStatus.alarmCode = tilServo.getAlarmCode();

	teleCamLensControl.getAlarmInfo(lensStatus.alarmCode);
	teleCamLensControl.getWarningInfo(lensStatus.warningCode);
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		lensStatus.bfErrorStatus[i] = 0;
		if (lensStatus.alarmCode[i] != 0) {
			lensStatus.bfErrorStatus[i] |= 1;
		}
		if (lensStatus.warningCode[i] != 0) {
			lensStatus.bfErrorStatus[i] |= 2;
		}
	}
	lensStatus.rs485ConverterAlarmCode = teleCamLensControl.getRs485ConverterAlarmCode();

	return 0;
}

double MotorDriver::stepToRad(int32_t axis, int32_t step) {
	return step * RAD_PER_STEP_SERVO_RESOLUTION[axis];
}

int32_t MotorDriver::stepToNradX10(int32_t axis, int32_t step) {
	return radToNradx10(stepToRad(axis,step));
}

void MotorDriver::setXTeleCamZoom(double xZoom) {
	teleCamLensControl.setXZoom(xZoom);
}
void MotorDriver::setMTeleCamFocus(double mFocus) {
	teleCamLensControl.setMFocus(mFocus);
}
void MotorDriver::setMHelFocus(double mFocus) {
	teleCamLensControl.setMHelFocus(mFocus);
}
void MotorDriver::setTeleCamIris(double iris) {
	teleCamLensControl.setIris(iris);
}
double MotorDriver::getXTeleCamZoom() {
	return teleCamLensControl.getXZoom();
}
double MotorDriver::getMTeleCamFocus() {
	return teleCamLensControl.getMFocus();
}
double MotorDriver::getMHelFocus() {
	return teleCamLensControl.getMHelFocus();
}
double MotorDriver::getTeleCamIris() {
	return teleCamLensControl.getIris();
}

MotorDriver::TeleCamLensControl::TeleCamLensControl() {
	axis = 0;
	transactionState = TransactionState::SET_OPCODE;
	TransactionState nextTransactionState = TransactionState::SET_OPCODE;
	moveCommandState = MoveCommandState::SET_POSITION_COMMAND;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		stepsPosCommands[i] = 0;
		stepsPosStatus[i] = 0;
		alarmCode[i] = 0;
	}
	startSignalTimeout = 0;
	initializeLoopCount = 0;
	stepsPosCommandLatch = 0;
	alarm = 0;

	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		alarmCode[i] = 0;
		warningCode[i] = 0;
	}

	for (int i = 0; i < 16; i++) {
		readDataBuf[i] = 0;
		writeDataBuf[i] = 0;
	}
	sequenceError = ServoErrors::MotorInitSequence::OK;

	M3IOState m3State;
	iRegPtr = nullptr;
	oRegPtr = nullptr;
	rs485ConverterAlarmCode = 0;
}
MotorDriver::TeleCamLensControl::~TeleCamLensControl() {

}

DWORD MotorDriver::TeleCamLensControl::setIoData(const USHORT* writeData) {
	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = 1;
	axisInfo.STNo[0] = STATION_NO_TELELENS;

	IO_DATA ioData;
	ioData.Size = 16;
	ioData.pIoBuffer = (void*)writeData;

	return ymcSetIoData(&axisInfo, &ioData);
}

DWORD MotorDriver::TeleCamLensControl::getIoData(USHORT* readBuf) {
	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = 1;
	axisInfo.STNo[0] = STATION_NO_TELELENS;

	IO_DATA ioData;
	ioData.Size = 16;
	ioData.pIoBuffer = (void*)readBuf;

	return ymcGetIoData(&axisInfo, &ioData);
}

DWORD MotorDriver::TeleCamLensControl::setStart() {
	writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
	writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
	writeDataBuf[2] = 0x00;	//Reserved.
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		writeDataBuf[3 + i] = 0x2100;//C-ON=1, start=1, other=0
	}
	for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
		writeDataBuf[3 + i] = 0x0000;
	}
	writeDataBuf[11] = 0;
	writeDataBuf[12] = 0x003F;	//Pos63 + (trig = 0)
	writeDataBuf[13] = 0;
	writeDataBuf[14] = 0;

	return setIoData(writeDataBuf);
}

DWORD MotorDriver::TeleCamLensControl::setHome() {
	writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
	writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
	writeDataBuf[2] = 0x00;	//Reserved.
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		writeDataBuf[3 + i] = 0x2800;//C-ON=1, home=1, other=0
	}
	for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
		writeDataBuf[3 + i] = 0x0000;
	}
	writeDataBuf[11] = 0;
	writeDataBuf[12] = 0x003F;	//Pos63 + (trig = 0)
	writeDataBuf[13] = 0;
	writeDataBuf[14] = 0;

	return setIoData(writeDataBuf);
}

DWORD MotorDriver::TeleCamLensControl::setCOn() {
	writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
	writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
	writeDataBuf[2] = 0x00;	//Reserved.
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		writeDataBuf[3 + i] = 0x2000;//C-ON=1, other=0
	}
	for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
		writeDataBuf[3 + i] = 0x0000;
	}
	writeDataBuf[11] = 0;
	writeDataBuf[12] = 0x003F;	//Pos63 + (trig = 0)
	writeDataBuf[13] = 0;
	writeDataBuf[14] = 0;

	return setIoData(writeDataBuf);
}

DWORD MotorDriver::TeleCamLensControl::setStop() {
	writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
	writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
	writeDataBuf[2] = 0x00;	//Reserved.
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		writeDataBuf[3 + i] = 0x3000;//C-ON=1, stop=1, other=0
	}
	for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
		writeDataBuf[3 + i] = 0x0000;
	}
	writeDataBuf[11] = 0;
	writeDataBuf[12] = 0x003F;	//Pos63 + (trig = 0)
	writeDataBuf[13] = 0;
	writeDataBuf[14] = 0;

	return setIoData(writeDataBuf);
}

DWORD MotorDriver::TeleCamLensControl::readHomeP(int32_t* isHomeP) {
	//AND of each axis.
	DWORD ret = getIoData(readDataBuf);
	
	*isHomeP = 1;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		if ((readDataBuf[3 + i] & 0x0800) == 0) {//HomeP
			*isHomeP = 0;
		}
		if ((readDataBuf[3 + i] & 0x0400)) {//Move
			*isHomeP = 0;
		}
	}

	return ret;
}

DWORD MotorDriver::TeleCamLensControl::readReady(int32_t* isReady) {
	//AND of each axis.
	DWORD ret = getIoData(readDataBuf);

	*isReady = 1;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		if (readDataBuf[3 + i] & 0x2000) {//Ready
			*isReady = 0;
		}
	}

	return ret;
}

DWORD MotorDriver::TeleCamLensControl::readMove(int32_t* isMove) {
	//AND of each axis.
	DWORD ret = getIoData(readDataBuf);

	*isMove = 0;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		if (readDataBuf[3 + i] & 0x0400) {//Move
			*isMove = 1;
		}
	}

	return ret;
}

DWORD MotorDriver::TeleCamLensControl::readAlarm(int32_t* alarm) {
	//OR of each axis.
	DWORD ret = getIoData(readDataBuf);

	*alarm = 0;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		if (readDataBuf[3 + i] & 0x0080) {//alm
			*alarm = 1;
		}
	}

	return ret;
}

char* MotorDriver::TeleCamLensControl::transactionStateToStr(TransactionState transactionState) {
	if (transactionState == TransactionState::SET_OPCODE) {
		return "SET_OPCODE";
	}
	else if (transactionState == TransactionState::OPCODE_CHECK) {
		return "OPCODE_CHECK";
	}
	else if (transactionState == TransactionState::TRIG_ON) {
		return "TRIG_ON";
	}
	else if (transactionState == TransactionState::TRIG_ON_CHECK) {
		return "TRIG_ON_CHECK";
	}
	else if (transactionState == TransactionState::TRIG_OFF) {
		return "TRIG_OFF";
	}
	else if (transactionState == TransactionState::TRIG_OFF_CHECK) {
		return "TRIG_OFF_CHECK";
	}
	else if (transactionState == TransactionState::ERROR) {
		return "ERROR";
	}
	else {
		return "INVALID_STATE";
	}
}

DWORD MotorDriver::TeleCamLensControl::writeRemoteReg(TransactionState transactionState, uint16_t axis, uint16_t opcode, uint32_t data,uint32_t start, uint32_t* done, TransactionState* nextTransactionState) {
	DWORD ret;

	uint16_t remoteIOValue;
	if (start) {
		remoteIOValue = 0x2100;//C-ON=1, START=1, other=0
	}
	else {
		remoteIOValue = 0x2000;//C-ON=1, other=0
	}
	

	if (transactionState == TransactionState::SET_OPCODE) {
		writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
		writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
		writeDataBuf[2] = 0x00;	//Reserved.
		for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
			writeDataBuf[3 + i] = remoteIOValue;
		}
		for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
			writeDataBuf[3 + i] = 0x0000;
		}
		writeDataBuf[11] = axis;
		writeDataBuf[12] = opcode;	//opcode + (trig = 0)
		writeDataBuf[13] = data & 0xFFFF;
		writeDataBuf[14] = (data >> 16);

		ret = setIoData(writeDataBuf);

		*done = 0;
		*nextTransactionState = TransactionState::OPCODE_CHECK;

		return ret;
	}
	else if (transactionState == TransactionState::OPCODE_CHECK) {
		//printf("opcode check\n");
		ret = getIoData(readDataBuf);

		if (readDataBuf[11] == axis) {
			*nextTransactionState = TransactionState::TRIG_ON;
		}
		else {
			*nextTransactionState = TransactionState::OPCODE_CHECK;
		}
		*done = 0;

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_ON) {
		//printf("trig on\n");
		writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
		writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
		writeDataBuf[2] = 0x00;	//Reserved.
		for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
			writeDataBuf[3 + i] = remoteIOValue;
		}
		for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
			writeDataBuf[3 + i] = 0x0000;
		}
		writeDataBuf[11] = axis;
		writeDataBuf[12] = opcode | 0x4000;	//opcode + (trig = 1)
		writeDataBuf[13] = data & 0xFFFF;
		writeDataBuf[14] = (data >> 16);

		ret = setIoData(writeDataBuf);

		*done = 0;
		*nextTransactionState = TransactionState::TRIG_ON_CHECK;

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_ON_CHECK) {
		//printf("check trig on\n");
		ret = getIoData(readDataBuf);

		if (readDataBuf[12] & 0x4000) {	//TRIG_R = 1
			*nextTransactionState = TransactionState::TRIG_OFF;
			*done = 0;
		}
		else {
			*nextTransactionState = TransactionState::TRIG_ON_CHECK;
			*done = 0;
		}

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_OFF) {
		//printf("trig off\n");
		writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
		writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
		writeDataBuf[2] = 0x00;	//Reserved.
		for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
			writeDataBuf[3 + i] = remoteIOValue;
		}
		for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
			writeDataBuf[3 + i] = 0x0000;
		}
		writeDataBuf[11] = axis;
		writeDataBuf[12] = opcode;	//opcode + (trig = 0)
		writeDataBuf[13] = data & 0xFFFF;
		writeDataBuf[14] = (data >> 16);

		ret = setIoData(writeDataBuf);

		*done = 0;
		*nextTransactionState = TransactionState::TRIG_OFF_CHECK;

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_OFF_CHECK) {
		//printf("check trig off\n");
		ret = getIoData(readDataBuf);
		if (readDataBuf[12] & 0x8000) {	//STATUS = error
			*nextTransactionState = TransactionState::ERROR;
			*done = 1;
		}
		else if ((readDataBuf[12] & 0x4000) == 0) {	//TRIG_R = 0
			*nextTransactionState = TransactionState::SET_OPCODE;
			*done = 1;
		}
		else {
			*nextTransactionState = TransactionState::TRIG_OFF_CHECK;
			*done = 0;
		}

		return ret;
	}
	else {
		*done = 0;
		*nextTransactionState = TransactionState::ERROR;
		return 0;
	}
}

DWORD MotorDriver::TeleCamLensControl::readRemoteReg(TransactionState transactionState, uint16_t axis, uint16_t opcode, uint32_t* data,uint32_t start, uint32_t* done, TransactionState* nextTransactionState) {
	DWORD ret;
	uint16_t remoteIOValue;
	if (start) {
		remoteIOValue = 0x2100;//C-ON=1, START=1, other=0
	}
	else {
		remoteIOValue = 0x2000;//C-ON=1, other=0
	}
	


	if (transactionState == TransactionState::SET_OPCODE) {
		writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
		writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
		writeDataBuf[2] = 0x00;	//Reserved.
		for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
			writeDataBuf[3 + i] = remoteIOValue;
		}
		for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
			writeDataBuf[3 + i] = 0x0000;
		}
		writeDataBuf[11] = axis;
		writeDataBuf[12] = opcode;	//opcode + (trig = 0)
		writeDataBuf[13] = 0;
		writeDataBuf[14] = 0;

		ret = setIoData(writeDataBuf);

		*done = 0;
		*nextTransactionState = TransactionState::OPCODE_CHECK;
		*data = 0;

		return ret;
	}
	else if (transactionState == TransactionState::OPCODE_CHECK) {
		ret = getIoData(readDataBuf);

		if (readDataBuf[11] == axis) {
			*nextTransactionState = TransactionState::TRIG_ON;
		}
		else {
			*nextTransactionState = TransactionState::OPCODE_CHECK;
		}
		*done = 0;
		*data = 0;

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_ON) {
		writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
		writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
		writeDataBuf[2] = 0x00;	//Reserved.
		for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
			writeDataBuf[3 + i] = remoteIOValue;
		}
		for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
			writeDataBuf[3 + i] = 0x0000;
		}
		writeDataBuf[11] = axis;
		writeDataBuf[12] = opcode | 0x4000;	//opcode + (trig = 1)
		writeDataBuf[13] = 0;
		writeDataBuf[14] = 0;

		ret = setIoData(writeDataBuf);

		*done = 0;
		*nextTransactionState = TransactionState::TRIG_ON_CHECK;
		*data = 0;

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_ON_CHECK) {
		ret = getIoData(readDataBuf);

		if (readDataBuf[12] & 0x8000) {	//STATUS = error
			*nextTransactionState = TransactionState::ERROR;
			*done = 1;
			*data = 0;
		}
		else if (readDataBuf[12] & 0x4000) {	//TRIG_R = 1
			*nextTransactionState = TransactionState::TRIG_OFF;
			*done = 0;
			*data = readDataBuf[13] | ((uint32_t)readDataBuf[14] << 16);
		}
		else {
			*nextTransactionState = TransactionState::TRIG_ON_CHECK;
			*done = 0;
			*data = readDataBuf[13] | ((uint32_t)readDataBuf[14] << 16);
		}

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_OFF) {
		writeDataBuf[0] = 0x00;	//�f�[�^���o�̓R�}���h
		writeDataBuf[1] = 0x00;	//�R�}���h���� = N/A
		writeDataBuf[2] = 0x00;	//Reserved.
		for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
			writeDataBuf[3 + i] = remoteIOValue;
		}
		for (int i = NUM_TELE_LENS_AXIS; i < 8; i++) {
			writeDataBuf[3 + i] = 0x0000;
		}
		writeDataBuf[11] = axis;
		writeDataBuf[12] = opcode;	//opcode + (trig = 0)
		writeDataBuf[13] = 0;
		writeDataBuf[14] = 0;

		ret = setIoData(writeDataBuf);

		*done = 0;
		*nextTransactionState = TransactionState::TRIG_OFF_CHECK;
		*data = readDataBuf[13] | ((uint32_t)readDataBuf[14] << 16);

		return ret;
	}
	else if (transactionState == TransactionState::TRIG_OFF_CHECK) {
		ret = getIoData(readDataBuf);

		if (readDataBuf[12] & 0x8000) {	//STATUS = error
			*nextTransactionState = TransactionState::ERROR;
			*done = 1;
			*data = 0;
		}
		else if ((readDataBuf[12] & 0x4000) == 0) {	//TRIG_R = 0
			*nextTransactionState = TransactionState::SET_OPCODE;
			*done = 1;
			*data = readDataBuf[13] | ((uint32_t)readDataBuf[14] << 16);
		}
		else {
			*nextTransactionState = TransactionState::TRIG_OFF_CHECK;
			*done = 0;
			*data = readDataBuf[13] | ((uint32_t)readDataBuf[14] << 16);
		}

		return ret;
	}
	else {
		*done = 0;
		*nextTransactionState = TransactionState::ERROR;
		*data = 0;
		return 0;
	}
}

DWORD MotorDriver::TeleCamLensControl::readRs485ConverterAlarmWarning(M3IOState m3State, M3IOState* nextM3State, uint16_t& alarm, uint32_t& done) {
	if (m3State == M3IOState::SET_COMMAND) {
		if (iRegPtr[1] & 0x04) {	//CMDRDY
			oRegPtr[0] = 0x0001;
			oRegPtr[1] = 0x0000;
			oRegPtr[2] = 0x0000;
			oRegPtr[3] = 0x0000;
			alarm = 0;
			done = 0;
			*nextM3State = M3IOState::WAIT_FOR_RESPONSE;
		}
		else {
			alarm = 0;
			done = 0;
			*nextM3State = M3IOState::SET_COMMAND;
		}
	}
	else {
		if ((iRegPtr[0] & 0x0F) == 0x01) {
			alarm = iRegPtr[4];
			done = 1;
			*nextM3State = M3IOState::SET_COMMAND;
		}
		else {
			alarm = 0;
			done = 0;
			*nextM3State = M3IOState::WAIT_FOR_RESPONSE;
		}
	}
	return 0;
}

DWORD MotorDriver::TeleCamLensControl::initialize(ServoErrors::MotorInitSequence& sequenceMarker) {
	TransactionState nextTransactionState = TransactionState::SET_OPCODE;
	uint32_t done = 0;

	DWORD ret;

	HREGISTERDATA hIRegister, hORegister;
	ret = ymcGetRegisterDataHandle((LPBYTE)"IW1000", &hIRegister);
	if (ret != MP_SUCCESS) {
		eventLoggingQueue.log("ymcGetRegisterDataHandle fail. ret = 0x%08x\n", ret);
		//printf("ymcGetRegisterDataHandle fail. ret = 0x%08x\n", ret);
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"OW1010", &hORegister);
	if (ret != MP_SUCCESS) {
		eventLoggingQueue.log("ymcGetRegisterDataHandle fail. ret = 0x%08x\n", ret);
		//printf("ymcGetRegisterDataHandle fail. ret = 0x%08x\n", ret);
	}
	ret = ymcGetRegisterDataAddress(hIRegister, (LPDWORD)&iRegPtr);
	if (ret != MP_SUCCESS) {
		eventLoggingQueue.log("ymcGetRegisterDataHandle fail. ret = 0x%08x\n", ret);
		//printf("ymcGetRegisterDataHandle fail. ret = 0x%08x\n", ret);
	}
	ret = ymcGetRegisterDataAddress(hORegister, (LPDWORD)&oRegPtr);
	if (ret != MP_SUCCESS) {
		eventLoggingQueue.log("ymcGetRegisterDataHandle fail. ret = 0x%08x\n",ret);
		//printf("ymcGetRegisterDataHandle fail. ret = 0x%08x\n");
	}

	M3IOState m3State = M3IOState::SET_COMMAND;
	M3IOState nextM3State;
	uint16_t alarm;
	int32_t readWarningCount = 0;
	while (!done) {
		readRs485ConverterAlarmWarning(m3State, &nextM3State, alarm, done);
		m3State = nextM3State;
		readWarningCount++;
		if (readWarningCount > CYCLES_INITIALIZE_TIMEOUT) {
			sequenceMarker = ServoErrors::MotorInitSequence::TELE_LENS_READ_ALARM;
			return ServoErrors::TELE_LENS_READ_RS485CONVERTER_ALARM_TIMEOUT;
		}
	}
	rs485ConverterAlarmCode = alarm;
	done = 0;


	if (alarm) {
		sequenceMarker = ServoErrors::MotorInitSequence::TELE_LENS_ALARM_CHECK;
		return ServoErrors::TELE_LENS_ALARM_CHECK;
	}


	initializeLoopCount = 0;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		for (int j = 0; j < INIT_DATA_COUNT; j++) {
			done = 0;
			while (!gInit.bShutdown && !done) {
				ret = writeRemoteReg(transactionState, i, INIT_DATA[j].opCode, INIT_DATA[j].value,0, &done, &nextTransactionState);
				if (ret != MP_SUCCESS) {
					sequenceMarker = ServoErrors::MotorInitSequence::TELE_LENS_INITIALIZE;
					return ret;
				}
				

				transactionState = nextTransactionState;

				knRtSleep(UsecsToKticks(1000));
				initializeLoopCount++;
				if (initializeLoopCount > CYCLES_INITIALIZE_TIMEOUT) {
					sequenceMarker = ServoErrors::MotorInitSequence::TELE_LENS_INITIALIZE_TIMEOUT;
					sequenceError = ServoErrors::MotorInitSequence::TELE_LENS_INITIALIZE_TIMEOUT;
					return ServoErrors::TELE_LENS_REGWRITE_TIMEOUT;
				}
			}
		}
	}
	
	ret = setHome();
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::TELE_LENS_HOMING;
		return ret;
	}
	knRtSleep(UsecsToKticks(4000));
	int32_t homeP = 0;
	initializeLoopCount = 0;
	while (!gInit.bShutdown && !homeP) {
		knRtSleep(UsecsToKticks(1000));
		readHomeP(&homeP);

		initializeLoopCount++;
		if (initializeLoopCount > CYCLES_HOMING_TIMEOUT) {
			sequenceMarker = ServoErrors::MotorInitSequence::TELE_LENS_HOMING_TIMEOUT;
			sequenceError = ServoErrors::MotorInitSequence::TELE_LENS_HOMING_TIMEOUT;
			return ServoErrors::TELE_LENS_HOMING_TIMEOUT;
		}
	}

	return MP_SUCCESS;
}

int32_t MotorDriver::TeleCamLensControl::processCycle() {
	TransactionState nextTransactionState;
	M3IOState nextM3State;
	uint32_t done;

	if (moveCommandState == MoveCommandState::SET_POSITION_COMMAND) {
		//Pos1
		if (transactionState == TransactionState::SET_OPCODE) {
			stepsPosCommandLatch = stepsPosCommands[axis];
			if (stepsPosCommandLatch - stepsPosStatus[axis] > STEPS_MAX_MOVE_IN_CYCLE) {
				stepsPosCommandLatch = stepsPosStatus[axis] + STEPS_MAX_MOVE_IN_CYCLE;
			}
			if (stepsPosCommandLatch - stepsPosStatus[axis] < -STEPS_MAX_MOVE_IN_CYCLE) {
				stepsPosCommandLatch = stepsPosStatus[axis] - STEPS_MAX_MOVE_IN_CYCLE;
			}
		}
		//printf("SET POSITION COMMAND [%d]:[%d]\n", axis, stepsPosCommandLatch);


		writeRemoteReg(transactionState, axis, 0x1001, stepsPosCommandLatch,0, &done, &nextTransactionState);
		transactionState = nextTransactionState;
		if (done) {
			if (axis == NUM_TELE_LENS_AXIS - 1) {
				axis = 0;
				moveCommandState = MoveCommandState::START;
			}
			else {
				axis++;
			}
		}
	}
	else if (moveCommandState == MoveCommandState::START) {
		//printf("START\n");
		setStart();
		startSignalTimeout = CYCLES_START_SIGNAL_TIMEOUT_MAX;
		moveCommandState = MoveCommandState::READ_POSITION;
	}
	else if (moveCommandState == MoveCommandState::READ_POSITION) {
		//printf("READ POSITION [%d]\n",axis);

		uint32_t start;
		if (startSignalTimeout > 0) {
			startSignalTimeout--;
			start = 1;
		}
		else {
			start = 0;
		}

		uint32_t readData;
		readRemoteReg(transactionState, axis, 0x2E18, &readData, start, &done, &nextTransactionState);
		transactionState = nextTransactionState;
		if (done) {
			stepsPosStatus[axis] = readData;
			if (axis < NUM_TELE_LENS_AXIS-1) {
				axis++;
			}
			else {
				axis = 0;
				moveCommandState = MoveCommandState::CHECK_STOP;
			}
		}
	}
	else if (moveCommandState == MoveCommandState::CHECK_STOP) {
		//printf("CHECK STOP\n");
		int32_t isMove;
		readMove(&isMove);

		if (isMove) {
			moveCommandState = MoveCommandState::READ_POSITION;
		}
		else {
			moveCommandState = MoveCommandState::CHECK_ALARM;
		}
	}
	else if (moveCommandState == MoveCommandState::CHECK_ALARM) {
		//printf("CHECK ALARM\n");
		readAlarm(&alarm);

		if (alarm == 0) {
			moveCommandState = MoveCommandState::CHECK_RS485CONVERTER_ALARM;
		}
		else {
			moveCommandState = MoveCommandState::READ_ALARM_CODE;
		}
		
	}
	else if (moveCommandState == MoveCommandState::CHECK_RS485CONVERTER_ALARM) {
		uint16_t rs485Alarm;
		readRs485ConverterAlarmWarning(m3State,&nextM3State, rs485Alarm,done);
		m3State = nextM3State;
		rs485ConverterAlarmCode = rs485Alarm;
		if (done) {
			moveCommandState = MoveCommandState::SET_POSITION_COMMAND;
		}
	}
	else if (moveCommandState == MoveCommandState::READ_ALARM_CODE) {
		//printf("READ ALARAM\n");
		uint32_t readData;
		readRemoteReg(transactionState, axis, 0x2E00, &readData,0, &done, &nextTransactionState);
		transactionState = nextTransactionState;
		if (done) {
			alarmCode[axis] = readData;
			if (axis < NUM_TELE_LENS_AXIS - 1) {
				axis++;
			}
			else {
				axis = 0;
				moveCommandState = MoveCommandState::READ_WARNING_CODE;
			}
		}
	}
	else if (moveCommandState == MoveCommandState::READ_WARNING_CODE) {
		//printf("READ WARNING\n");
		uint32_t readData;
		readRemoteReg(transactionState, axis, 0x2E0B, &readData, 0, &done, &nextTransactionState);
		transactionState = nextTransactionState;
		if (done) {
			warningCode[axis] = readData;
			if (axis < NUM_TELE_LENS_AXIS - 1) {
				axis++;
			}
			else {
				axis = 0;
				moveCommandState = MoveCommandState::SET_POSITION_COMMAND;
			}
		}
	}
	else {
		//printf("INVALID STATE\n");
	}

	return 0;
}

double MotorDriver::TeleCamLensControl::lookupTable(double key, const double table[LOOKUP_TABLE_LENGTH]) {
	//key must be normalized to 0.0 �` 1.0
	if (key < 0) {
		key = 0;
	}
	if (key > 1.0) {
		key = 1.0;
	}

	int32_t index = key * (LOOKUP_TABLE_LENGTH-1);

	if (index == LOOKUP_TABLE_LENGTH-1) {
		return table[LOOKUP_TABLE_LENGTH - 1];
	}

	double remainder = key * (LOOKUP_TABLE_LENGTH - 1) - index;

	return table[index] + (table[index+1] - table[index])*remainder;
}

double MotorDriver::TeleCamLensControl::reverseLookupTable(double value, const double table[LOOKUP_TABLE_LENGTH]) {
	//return normalized key(0.0 �` 1.0)
	int32_t tableSearchStep = (LOOKUP_TABLE_LENGTH - 1) / 2;
	int32_t pivot = tableSearchStep;

	while (tableSearchStep > 1) {
		tableSearchStep /= 2;
		if (table[pivot] <= value) {
			pivot += tableSearchStep;
		}
		else {
			pivot -= tableSearchStep;
		}
	}

	if (table[pivot] > value) {
		pivot -= 1;
	}

	double tableFloor = table[pivot];
	double tableCeil = table[pivot + 1];
	double valueOffset = value - tableFloor;

	double key = (pivot + valueOffset / (tableCeil - tableFloor)) / (LOOKUP_TABLE_LENGTH - 1);

	if (key < 0) {
		key = 0;
	}
	if (key > 1.0) {
		key = 1.0;
	}

	return key;
}

double MotorDriver::TeleCamLensControl::getXZoom() {
	return reverseLookupTable(stepsPosStatus[AXIS_ZOOM], XZOOM_TO_STEP_TABLE) * 10.5 + 1;
}

double MotorDriver::TeleCamLensControl::getMFocus() {
	return STEPS_FOCUS_COEFF / (stepsPosStatus[AXIS_FOCUS] - STEPS_FOCUS_YOFFSET) - STEPS_FOCUS_XOFFSET;
}

double MotorDriver::TeleCamLensControl::getMHelFocus() {
	return STEPS_HEL_COEFF / (stepsPosStatus[AXIS_HEL] - STEPS_HEL_YOFFSET) - STEPS_HEL_XOFFSET;
}

double MotorDriver::TeleCamLensControl::getIris() {
	return 1 - stepsPosStatus[AXIS_IRIS]/STEPS_IRIS_COEFF;
}

void MotorDriver::TeleCamLensControl::setXZoom(double xZoom) {
	double zoom = (xZoom - 1) / 10.5;
	stepsPosCommands[AXIS_ZOOM] = lookupTable(zoom, XZOOM_TO_STEP_TABLE);
}

void MotorDriver::TeleCamLensControl::setMFocus(double mFocus) {
	if (mFocus < 10) {
		mFocus = 10;
	}
	if (mFocus > 1200) {
		mFocus = 1200;
	}

	stepsPosCommands[AXIS_FOCUS] = STEPS_FOCUS_COEFF / (mFocus + STEPS_FOCUS_XOFFSET) + STEPS_FOCUS_YOFFSET;
}

void MotorDriver::TeleCamLensControl::setMHelFocus(double mFocus) {
	if (mFocus < 10) {
		mFocus = 10;
	}
	if (mFocus > 1200) {
		mFocus = 1200;
	}

	stepsPosCommands[AXIS_HEL] = STEPS_HEL_COEFF / (mFocus + STEPS_HEL_XOFFSET) + STEPS_HEL_YOFFSET;
}

void MotorDriver::TeleCamLensControl::setIris(double iris) {
	if (iris < 0) {
		iris = 0;
	}
	if (iris > 1.0) {
		iris = 1.0;
	}

	stepsPosCommands[AXIS_IRIS] = (1.0 - iris) * STEPS_IRIS_COEFF;
}

void MotorDriver::TeleCamLensControl::getAlarmInfo(uint16_t(&alarmCode)[NUM_TELE_LENS_AXIS]) {
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		alarmCode[i] = this->alarmCode[i];
	}
}
void MotorDriver::TeleCamLensControl::getWarningInfo(uint16_t(&warningCode)[NUM_TELE_LENS_AXIS]) {
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		warningCode[i] = this->warningCode[i];
	}
}
uint16_t MotorDriver::TeleCamLensControl::getRs485ConverterAlarmCode() {
	return rs485ConverterAlarmCode;
}

MotorDriver::TilServo::TilServo() {
	pMonitorParams = nullptr;
	pSettingParams = nullptr;
	nextPos = 0;
}

MotorDriver::TilServo::~TilServo() {

}

DWORD MotorDriver::TilServo::setupResisterAddress() {
	HREGISTERDATA hMonitorParam;
	HREGISTERDATA hSettingParam;

	DWORD ret;

	//////////////////////////////////////
	// ���W�X�^�n���h���擾
	//////////////////////////////////////
	ret = ymcGetRegisterDataHandle((LPBYTE)"IW8000", &hMonitorParam);					// �`���l���P���j�^�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"OW8000", &hSettingParam);					// �`���l���P�ݒ�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}

	PMON_PARAM monitorParamBase;
	ret = ymcGetRegisterDataAddress(hMonitorParam, (LPDWORD)&monitorParamBase);	// �`���l���P���j�^�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	pMonitorParams = monitorParamBase + (STATION_NO_TIL - 1);
	

	PSET_PARAM settingParamsBase;
	ret = ymcGetRegisterDataAddress(hSettingParam, (LPDWORD)&settingParamsBase);	// �`���l���P�ݒ�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		return ret;
	}
	pSettingParams = settingParamsBase + (STATION_NO_TIL - 1);
	
	return MP_SUCCESS;
}

DWORD MotorDriver::TilServo::servoOnAndHome() {
	if (pMonitorParams->SV.M3_sviomon & 0x02000000) {//HEND��1�̏ꍇ�A

	}



	pSettingParams->SV.svruncmd = 0x0000;
	pSettingParams->SV.venderIO = 0x0000;

	knRtSleep(UsecsToKticks(2000));
	while (pMonitorParams->SV.runsts & RUNSTS_SVCRUN) {
		knRtSleep(UsecsToKticks(2000));
	}

	pSettingParams->SV.svruncmd = 0x0001;
	while (!(pMonitorParams->SV.runsts & RUNSTS_SVCRUN)) {
		knRtSleep(UsecsToKticks(2000));
	}

	pSettingParams->SV.venderIO = 0x0002;	

	return MP_SUCCESS;
}

DWORD MotorDriver::TilServo::initialize(ServoErrors::MotorInitSequence& sequenceMarker) {
	DWORD ret;

	ret = setupResisterAddress();
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::TIL_SERVO_SETUP_REGISTER;
		return ret;
	}
	
	AXIS_INFO axisInfo;
	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = 1;
	axisInfo.STNo[0] = STATION_NO_TIL;

	ret = ymcClearServoAlarm(&axisInfo);
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::TIL_CLEAR_ALARM;
		return ret;
	}


	ret = servoOnAndHome();
	if (ret != MP_SUCCESS) {
		sequenceMarker = ServoErrors::MotorInitSequence::TIL_SERVO_ON_AND_HOMING;
		return ret;
	}

	int32_t waitCount = 0;
	while (1) {
		if ((pMonitorParams->SV.runsts & RUNSTS_SVCRUN) && (pMonitorParams->SV.M3_sviomon & 0x02000000)) {//servo ON && hend(homing complete)
			pSettingParams->SV.venderIO = 0x0000;
			break;
		}

		if (waitCount > MS_TIL_SERVO_HOMING_TIMEOUT) {
			sequenceMarker = ServoErrors::MotorInitSequence::TIL_SERVO_WAIT_FOR_HOMING_COMPLETE;
			return API_TIMEOUT;
		}
		waitCount++;
		knRtSleep(UsecsToKticks(1000));
	}
	


	return MP_SUCCESS;
}

DWORD MotorDriver::TilServo::tilTerminate() {
	DWORD ret;
	AXIS_INFO axisInfo;
	SVCTRL_DATA svControlData;

	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = 1;
	axisInfo.STNo[0] = STATION_NO_TIL;
	svControlData.ControlType = SERVO_OFF;


	ret = ymcServoControl(&axisInfo, &svControlData);

	return ret;
}

int32_t MotorDriver::TilServo::processCycle() {
	AXIS_INFO axisInfo;
	//CHKCMP_DATA chkCmp;

	axisInfo.SlotNo = SLOT1;
	axisInfo.ChannelNo = CHANNEL1;
	axisInfo.MotionFunc = MODULE_SVC32;
	axisInfo.STCount = 1;
	axisInfo.STNo[0] = STATION_NO_TIL;
	//chkCmp.APINo = MOVEPOSITIONING;
	//chkCmp.CompCondition = POSITIONING_COMPLETED;

	//DWORD complete = ymcCheckComplete(&axisInfo, &chkCmp);
	//if (complete != MP_SUCCESS && complete != API_BUSY) {
	//	eventLoggingQueue.log("error complete: 0x%02x\n", complete);
	//}

	MOTION_DATA motionData;
	MOVE_DATA moveData;

	motionData.VelocityUnit = VELUNIT_SMALLPERCENT;
	motionData.AccUnit = ACCUNIT_MS;
	motionData.FilterType = FILTER_DISABLE;
	motionData.Accel = 1;
	motionData.Decel = 1;
	motionData.FilterValue = 0;
	motionData.PsetWidth = 500;
	motionData.TrqUnit = TUNIT_SMALLPERCENT;
	motionData.TrqLimit = 1000000;

	moveData.Velocity = 1000000;
	moveData.PosType = POSTYPE_ABS;
	moveData.TargetPos = nextPos;

	DWORD ret = ymcMovePositioning(&axisInfo, &motionData, &moveData, POSITIONING_COMPLETED);

	if (ret != MP_SUCCESS) {
		eventLoggingQueue.log("error move position: 0x%02x\n", ret);
		return -1;
	}
	return 0;
}

void MotorDriver::TilServo::setRadTilDivergence(double radTilDivergence) {
	nextPos = radDivergenceToStepsPos(radTilDivergence);
	if (nextPos < 0) {
		nextPos = 0;
	}
	else if (nextPos > STEPS_MAX_POS) {
		nextPos = STEPS_MAX_POS;
	}
}

double MotorDriver::TilServo::getRadTilDivergence() {
	return stepsPosToRadDivergence(pMonitorParams->SV.apos);
}

uint16_t MotorDriver::TilServo::getAlarmCode() {
	return pMonitorParams->SV.alarm;
}

uint16_t MotorDriver::TilServo::getWarningCode() {
	return pMonitorParams->SV.warning;
}

int32_t MotorDriver::TilServo::mmPosToStepsPos(double mmPos) {
	return mmPos / MM_PER_REV * STEPS_PER_REV;
}

double MotorDriver::TilServo::stepsPosToMmPos(int32_t stepsPos) {
	return stepsPos / STEPS_PER_REV * MM_PER_REV;
}

double MotorDriver::TilServo::radDivergenceToMmPos(double radTilDivergence) {
	return MM_MAX_POS * (radTilDivergence - RAD_TIL_DIVERGENCE_MIN) / (RAD_TIL_DIVERGENCE_MAX - RAD_TIL_DIVERGENCE_MIN);
}
double MotorDriver::TilServo::mmPosToRadDivergence(double mmPos) {
	return mmPos / MM_MAX_POS * (RAD_TIL_DIVERGENCE_MAX - RAD_TIL_DIVERGENCE_MIN) + RAD_TIL_DIVERGENCE_MIN;
}
int32_t MotorDriver::TilServo::radDivergenceToStepsPos(double radTilDivergence) {
	return mmPosToStepsPos(radDivergenceToMmPos(radTilDivergence));
}
double MotorDriver::TilServo::stepsPosToRadDivergence(int32_t stepsPos) {
	return mmPosToRadDivergence(stepsPosToMmPos(stepsPos));
}