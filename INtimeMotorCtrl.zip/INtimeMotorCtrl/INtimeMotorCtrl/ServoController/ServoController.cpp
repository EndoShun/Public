#include "ServoController.h"
#include "DummyMotorModel/DummyMotorDriver.h"
#include "MotorDriver.h"
#include "stdio.h"
#include "ServoErrors.h"
#include "../MyDebug.h"

ServoController::ServoController(OperationMode operationMode,const ServoParameters* servoParameters) {
	servoState = State::OFF_NO_ORIGIN;
	cyclesSearchZeroTimeout = 0;
	this->operationMode = operationMode;
	this->servoParameters = servoParameters;
	initOk = 0;
}
ServoController::~ServoController() {
}

DWORD ServoController::init(ServoErrors::MotorInitSequence& sequenceMarker) {
	//////////////////////////////////////////////////////////////////////////////
	// INTime�ł̓|�����[�t�B�Y�����g�p�ł��Ȃ�(__purecall���Q�Ƃ���Ȃ�)���߁A
	// ��ɒʏ�̃��[�^�[�A�_�~�[��2�̃C���X�^���X���쐬��if���ŌĂѕ�����
	//////////////////////////////////////////////////////////////////////////////
	controlModelWrapper.initControlModel(servoParameters);

	DWORD ret;
	if (operationMode == OperationMode::NORMAL) {
		ret = motorDriver.init(sequenceMarker);
		if (ret != MP_SUCCESS) {
			return ret;
		}

		//ret = motorDriver.teleCamLensControl.initialize(sequenceMarker);
		//if (ret != MP_SUCCESS) {
		//	return ret;
		//}

		ret = motorDriver.tilServo.initialize(sequenceMarker);
		if (ret != MP_SUCCESS) {
			return ret;
		}
	}
	else if (operationMode == OperationMode::TRAINING) {
		ret = dummyMotorDriver.init(sequenceMarker);
	}
	else {//ParameterError
		ret = dummyMotorDriver.init(sequenceMarker);
	}

	initOk = 1;

	return ret;
}

DWORD ServoController::waitCycle() {
	DWORD ret;
	if (operationMode == OperationMode::NORMAL) {
		ret = motorDriver.waitCycle();
	}
	else if (operationMode == OperationMode::TRAINING) {
		ret = dummyMotorDriver.waitCycle();
	}
	else {
		ret = dummyMotorDriver.waitCycle();
	}
	return ret;
}

DWORD ServoController::readServoStatus(ServoStatus& servoStatus, FineMirrorStatus& fineMirrorStatus, TeleCamLensStatus& lensStatus, TilServoStatus& tilStatus) {
	DWORD ret;
	if (operationMode == OperationMode::NORMAL) {
		ret = motorDriver.readServoStatus(servoStatus,fineMirrorStatus, lensStatus,tilStatus);
	}
	else if (operationMode == OperationMode::TRAINING) {
		ret = dummyMotorDriver.readServoStatus(servoStatus,fineMirrorStatus,lensStatus,tilStatus);
	}
	else {
		ret = dummyMotorDriver.readServoStatus(servoStatus, fineMirrorStatus,lensStatus,tilStatus);
	}

	if (servoState == State::ON || servoState == State::TURNING_OFF) {
		servoStatus.servoOn = 1;
		servoStatus.homingComplete = 1;
	}
	else {
		servoStatus.servoOn = 0;
		servoStatus.homingComplete = 0;
	}

	servoStatus.bfControlModelAlarmFlags = controlModelWrapper.getBfAlarmFlags();
	servoStatus.bfControlModelWarningFlags = controlModelWrapper.getBfWarningFlags();

	return ret;
}

#include "stdio.h"

DWORD ServoController::control(ControlCommandAndStatus* controlCommandAndStatus) {
	DWORD ret;
	double da0 = controlCommandAndStatus->fineMirrorCommand.posX;
	double da1 = controlCommandAndStatus->fineMirrorCommand.posY;
	double da2 = controlCommandAndStatus->laserEnableCommand.helEnable;
	double da3 = controlCommandAndStatus->laserEnableCommand.tilEnable;

	if (operationMode == OperationMode::NORMAL) {
		ret = motorDriver.setDACValue(da0, da1, da2, da3);
		//if (ret != MP_SUCCESS) {
		//  servoState = State::ERROR;
		//	return ret;
		//}
	}
	else if (operationMode == OperationMode::TRAINING) {
		dummyMotorDriver.setDACValue(da0, da1, da2, da3);
	}
	else {
	}

	if (servoState == State::TURNING_OFF) {
		//���[�ʒu�ֈʒu����
		controlCommandAndStatus->controlModelInput.command.mode = 1;
		for (int i = 0; i < AXIS_NUM; i++) {
			controlCommandAndStatus->controlModelInput.command.radAngle[i] = RAD_RETRACT_POS[i];
			controlCommandAndStatus->controlModelInput.command.rpsVelocity[i] = RPS_RETRACT_VEL;
			controlCommandAndStatus->controlModelInput.command.rpsVelocityLimit[i] = RPS_RETRACT_VEL;
		}
		controlCommandAndStatus->controlModelInput.command.radScanOffset[0] = 0.0;
		controlCommandAndStatus->controlModelInput.command.radScanOffset[1] = 0.0;
		
	}

	controlCommandAndStatus->controlModelInput.sensor.mPositionRadar[0] = 1;
	controlCommandAndStatus->controlModelInput.sensor.mPositionRadar[1] = 1;
	controlCommandAndStatus->controlModelInput.sensor.mPositionRadar[2] = 0;
	controlModelWrapper.calc(&controlCommandAndStatus->controlModelInput, &controlCommandAndStatus->servoCommand);
	eventLoggingQueue.log("%d,%d,%d\n", controlCommandAndStatus->servoCommand.control.radRadarReference[0] * 180 * 1000/3.14, controlCommandAndStatus->servoCommand.control.radRadarReference[1] * 180 * 1000 / 3.14, controlCommandAndStatus->servoCommand.control.radRadarReference[2] * 180 * 1000 / 3.14);


	if (servoState == State::OFF_NO_ORIGIN) {
		if (controlCommandAndStatus->servoCommand.control.servoOnCommand) {
			if (operationMode == OperationMode::NORMAL) {
				ret = motorDriver.servoEnable(1);
				if (ret != MP_SUCCESS) {
					servoState = State::ERROR;
					return ret;
				}
				ret = motorDriver.servoSearchZero();
				if (ret != MP_SUCCESS) {
					servoState = State::ERROR;
					return ret;
				}
			}
			else if (operationMode == OperationMode::TRAINING) {
				dummyMotorDriver.servoEnable(1);
				dummyMotorDriver.servoSearchZero();
			}
			else {
			}
			
			cyclesSearchZeroTimeout = CYCLES_SEARCH_ZERO_TIMEOUT_MAX;
			servoState = State::TURNING_ON;
		}
	}
	else if (servoState == State::OFF) {
		if (controlCommandAndStatus->servoCommand.control.servoOnCommand) {
			if (operationMode == OperationMode::NORMAL) {
				ret = motorDriver.servoEnable(1);
				if (ret != MP_SUCCESS) {
					servoState = State::ERROR;
					return ret;
				}
			}
			else if (operationMode == OperationMode::TRAINING) {
				dummyMotorDriver.servoEnable(1);
			}
			else {

			}

			servoState = State::ON;
		}
	}
	else if (servoState == State::TURNING_ON) {
		if (cyclesSearchZeroTimeout > 0) {
			cyclesSearchZeroTimeout--;

			int32_t searchZeroComplete;
			if (operationMode == OperationMode::NORMAL) {
				searchZeroComplete = motorDriver.isServoSearchZeroComplete();
			}
			else if (operationMode == OperationMode::TRAINING) {
				searchZeroComplete = dummyMotorDriver.isServoSearchZeroComplete();
			}
			else {
				searchZeroComplete = 0;
			}

			if (searchZeroComplete) {
				servoState = State::ON;
				if (operationMode == OperationMode::NORMAL) {
					ret = motorDriver.servoStop();
					if (ret != MP_SUCCESS) {
						servoState = State::ERROR;
						return ret;
					}
				}
				else if (operationMode == OperationMode::TRAINING) {
					dummyMotorDriver.servoStop();
				}
				else {

				}
			}
		}
	}
	else if (servoState == State::ON) {
		if (controlCommandAndStatus->servoCommand.control.servoOnCommand == 0) {
			servoState = State::TURNING_OFF;
		}
		else {
			if (operationMode == OperationMode::NORMAL) {
				ret = motorDriver.servoTorqueControl(controlCommandAndStatus->servoCommand.control.nmTorque, servoParameters->all.rpsVelocityLimit);
				if (ret != MP_SUCCESS) {
					servoState = State::ERROR;
					return ret;
				}
			}
			else if (operationMode == OperationMode::TRAINING) {
				dummyMotorDriver.servoTorqueControl(controlCommandAndStatus->servoCommand.control.nmTorque, servoParameters->all.rpsVelocityLimit);
			}
			else {
			}

		}
	}
	else if (servoState == State::TURNING_OFF) {
		int32_t retracted;
		if (operationMode == OperationMode::NORMAL) {
			retracted = motorDriver.isRetracted(controlCommandAndStatus->servoStatus);
		}
		else if (operationMode == OperationMode::TRAINING) {
			retracted = dummyMotorDriver.isRetracted(controlCommandAndStatus->servoStatus);
		}
		else {
			retracted = 0;
		}


		if (retracted) {
			if (operationMode == OperationMode::NORMAL) {
				ret = motorDriver.servoStop();
				if (ret != MP_SUCCESS) {
					servoState = State::ERROR;
					return ret;
				}
			}
			else if (operationMode == OperationMode::TRAINING) {
				dummyMotorDriver.servoStop();
			}
			else {
			}
			servoState = State::OFF;
		}
		else {
			if (operationMode == OperationMode::NORMAL) {
				ret = motorDriver.servoTorqueControl(controlCommandAndStatus->servoCommand.control.nmTorque, servoParameters->all.rpsVelocityLimit);
				if (ret != MP_SUCCESS) {
					servoState = State::ERROR;
					return ret;
				}
			}
			else if (operationMode == OperationMode::TRAINING) {
				dummyMotorDriver.servoTorqueControl(controlCommandAndStatus->servoCommand.control.nmTorque, servoParameters->all.rpsVelocityLimit);
			}
			else {
			}
		}
	}
	else if (servoState == State::ERROR) {
		if(operationMode == OperationMode::NORMAL){
			motorDriver.servoStop();
		}
		else if (operationMode == OperationMode::TRAINING) {
			dummyMotorDriver.servoStop();
		}
		else {
		}
	}

	if (operationMode == OperationMode::NORMAL) {
		//motorDriver.setXTeleCamZoom(controlCommandAndStatus->teleCamLensCommand.xZoom);
		//motorDriver.setMTeleCamFocus(controlCommandAndStatus->teleCamLensCommand.mFocus);
		//motorDriver.setTeleCamIris(controlCommandAndStatus->teleCamLensCommand.iris);
		motorDriver.setMHelFocus(controlCommandAndStatus->teleCamLensCommand.mHelFocus);
		//motorDriver.setRadTilDivergence(controlCommandAndStatus->teleCamLensCommand.radTilDivergence);
		int32_t error = motorDriver.teleCamLensControl.processCycle();
		//if (error < 0) {
		//  servoState = State::ERROR;
		//	return error;
		//}
	}
	else if (operationMode == OperationMode::TRAINING) {
		dummyMotorDriver.setXTeleCamZoom(controlCommandAndStatus->teleCamLensCommand.xZoom);
		dummyMotorDriver.setMTeleCamFocus(controlCommandAndStatus->teleCamLensCommand.mFocus);
		dummyMotorDriver.setTeleCamIris(controlCommandAndStatus->teleCamLensCommand.iris);
		dummyMotorDriver.setMHelFocus(controlCommandAndStatus->teleCamLensCommand.mHelFocus);
	}
	else {
	}
	
	if (operationMode == OperationMode::NORMAL) {
		motorDriver.tilServo.setRadTilDivergence(controlCommandAndStatus->tilServoCommand.radTilDivergence);
		int32_t error = motorDriver.tilServo.processCycle();
		if (error < 0) {
			servoState = State::ERROR;
			return error;
		}
	}
	else {
		dummyMotorDriver.setRadTilDivergence(controlCommandAndStatus->tilServoCommand.radTilDivergence);
	}

	return MP_SUCCESS;
	
}

double ServoController::xZoomToRadFov(double xZoom) {
	return RAD_VFOV_AT_X1 / xZoom;
}

double ServoController::xZoomToRadPerPixel(double xZoom) {
	return RAD_ANGLE_RESOLUTION_AT_X1 / xZoom;
}

double ServoController::radarRangeToZoomCommand(double mRange) {
	if (mRange < RADAR_TO_ZOOM_FLOOR_RANGE) {
		return RADAR_TO_ZOOM_COMMAND_FLOOR;
	}
	else if (RADAR_TO_ZOOM_CEIL_RANGE < mRange) {
		return RADAR_TO_ZOOM_COMMAND_CEIL;
	}
	else {
		return (RADAR_TO_ZOOM_COMMAND_CEIL - RADAR_TO_ZOOM_COMMAND_FLOOR) / (RADAR_TO_ZOOM_CEIL_RANGE - RADAR_TO_ZOOM_FLOOR_RANGE) * (mRange - RADAR_TO_ZOOM_FLOOR_RANGE);
	}
}

double ServoController::targetSizeToZoomCommand(uint16_t width, uint16_t height, double xCurrentZoom) {
	uint16_t size = width > height ? width : height;
	double ratio = PX_PREFFERED_TARGET_SIZE / size;
	if (1 / PREFFERED_TARGET_SIZE_MARGIN < ratio && ratio < PREFFERED_TARGET_SIZE_MARGIN) {
		return xCurrentZoom;
	}
	double xZoom = xCurrentZoom * ratio;
	return xZoom;
}

double ServoController::xZoomCommandToIrisCommand(double xZoom) {
	if (xZoom < XZOOM_TO_IRIS_FLOOR) {
		return XZOOM_TO_IRIS_FLOOR_IRIS;
	}
	if (xZoom > XZOOM_TO_IRIS_CEIL) {
		return XZOOM_TO_IRIS_CEIL_IRIS;
	}

	return (XZOOM_TO_IRIS_CEIL_IRIS - XZOOM_TO_IRIS_FLOOR_IRIS) / (XZOOM_TO_IRIS_CEIL - XZOOM_TO_IRIS_FLOOR) * (xZoom - XZOOM_TO_IRIS_FLOOR) + XZOOM_TO_IRIS_FLOOR_IRIS;
}

const char* ServoController::motorInitSequenceToStr(ServoErrors::MotorInitSequence motorInitSequence) {
	if (motorInitSequence == ServoErrors::MotorInitSequence::OK) {
		return "OK";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::OPEN_CONTROLLER) {
		return "OpenController";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::INITIALIZE_THREAD) {
		return "InitializeThread";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::SET_API_TIMEOUT) {
		return "SetApiTimeout";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::SETUP_REGISTER_ADDRESS) {
		return "SetupRegisterAddress";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::CLEAR_ALARM) {
		return "ClearAlarm";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::INIT_DAC) {
		return "InitDAC";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TELE_LENS_INITIALIZE) {
		return "TeleLensInitialize";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TELE_LENS_READ_ALARM) {
		return "TeleLensReadAlarm";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TELE_LENS_ALARM_CHECK) {
		return "TeleLensAlarmCheck";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TELE_LENS_INITIALIZE_TIMEOUT) {
		return "TeleLensInitializeTimeout";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TELE_LENS_HOMING) {
		return "TeleLensHoming";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TELE_LENS_HOMING_TIMEOUT) {
		return "TeleLensHomingTimeout";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TIL_SERVO_SETUP_REGISTER) {
		return "TilServoSetupRegister";
	}
	else if (motorInitSequence == ServoErrors::MotorInitSequence::TIL_SERVO_ON_AND_HOMING) {
		return "TilServoOnAndHoming";
	}
	else {
		return "Undefined sequence";
	}
}