#pragma once

#define __STDC_LIMIT_MACROS

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/
#include "ymcSMTAPI.h"
#ifdef __cplusplus
}
#endif /*__cplusplus*/

#include "IoStructs.h"
#include "math.h"
#include "stdint.h"
#include "MyUtils.h"
#include "MyRtQueue.h"
#include "ControlModel/ControlModelWrapper.h"
#include "DummyMotorModel/DummyMotorDriver.h"
#include "MotorDriver.h"
#include "ServoErrors.h"

class ServoController {
public:
	static constexpr int16_t RESOLUTION[2] = { 1920,1080 };

	enum class State {
		OFF_NO_ORIGIN,	//����������A���_���F��
		OFF,			//�R�}���h�ɂ��OFF�A���_�F����
		TURNING_OFF,
		ON,
		TURNING_ON,
		ERROR
	};

	static constexpr double RAD_VFOV_AT_X1 = 0.0284151;	//f=350mm, 2160px(x2Binning)
	static constexpr double X_TELECAM_ZOOM_MIN = 1.0;
	static constexpr double X_TELECAM_ZOOM_MAX = 11.428;

	static constexpr double RAD_SEARCH_ZERO_COMPLETE_MARGIN = 0.01 * M_PI / 180.0;
	static constexpr double RPS_SEARCH_ZERO_COMPLETE_MARGIN = 0.1 * M_PI / 180.0;
	static constexpr double RAD_RETRACT_POS[AXIS_NUM] = {
		-90 * M_PI / 180,
		-90 * M_PI / 180,
		-90 * M_PI / 180
	};
	static constexpr double RPS_RETRACT_VEL = 1 * M_PI/180.0;

	static constexpr double RAD_RETRACT_COMPLETE_MARGIN = 0.01 * M_PI / 180.0;
	static constexpr double RPS_RETRACT_COMPLETE_MARGIN = 0.1 * M_PI / 180.0;

public:
//private://TODO:�߂�
	static constexpr int32_t CYCLES_SEARCH_ZERO_TIMEOUT_MAX = 10000;

	static constexpr double RAD_ANGLE_RESOLUTION_AT_X1 = RAD_VFOV_AT_X1 / RESOLUTION[1];

	static constexpr double RADAR_TO_ZOOM_FLOOR_RANGE = 75.0;
	static constexpr double RADAR_TO_ZOOM_COMMAND_FLOOR = 1.0;
	static constexpr double RADAR_TO_ZOOM_CEIL_RANGE = 850;
	static constexpr double RADAR_TO_ZOOM_COMMAND_CEIL = 11.5;

	static constexpr uint16_t PX_PREFFERED_TARGET_SIZE = 250;
	static constexpr double PREFFERED_TARGET_SIZE_MARGIN = 1.2;

	static constexpr double XZOOM_TO_IRIS_FLOOR = 2.0;
	static constexpr double XZOOM_TO_IRIS_FLOOR_IRIS = 0.0;
	static constexpr double XZOOM_TO_IRIS_CEIL = 3.0;
	static constexpr double XZOOM_TO_IRIS_CEIL_IRIS = 1.0;

	State servoState;
	MotorDriver motorDriver;
	DummyMotorDriver dummyMotorDriver;
	OperationMode operationMode;
	ControlModelWrapper controlModelWrapper;

	int32_t cyclesSearchZeroTimeout;

	const ServoParameters* servoParameters;

	int32_t initOk;
public:

	ServoController(OperationMode operationMode, const ServoParameters* servoParameters);
	~ServoController();

	DWORD init(ServoErrors::MotorInitSequence& sequenceMarker);
	DWORD waitCycle();
	DWORD readServoStatus(ServoStatus& servoStatus, FineMirrorStatus& fineMirrorStatus, TeleCamLensStatus& lensStatus, TilServoStatus& tilStatus);
	DWORD control(ControlCommandAndStatus* controlCommandAndStatus);

	static double xZoomToRadFov(double xZoom);
	static double xZoomToRadPerPixel(double xZoom);
	static double radarRangeToZoomCommand(double mRange);
	static double targetSizeToZoomCommand(uint16_t width, uint16_t height, double xCurrentZoom);
	static double xZoomCommandToIrisCommand(double xZoom);
	static const char* motorInitSequenceToStr(ServoErrors::MotorInitSequence motorInitSequence);
};
