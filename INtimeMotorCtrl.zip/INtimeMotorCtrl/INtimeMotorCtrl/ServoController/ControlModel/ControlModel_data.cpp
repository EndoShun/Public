//
// File: ControlModel_data.cpp
//
// Code generated for Simulink model 'ControlModel'.
//
// Model version                  : 1.120
// Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
// C/C++ source code generated on : Tue Mar 14 21:46:48 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "ControlModel.h"
#include "ControlModel_private.h"

// Block parameters (default storage)
P_ControlModel_T ControlModelModelClass::ControlModel_P = {
  // Variable: FrictionFF
  //  Referenced by: '<S4>/Constant9'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0 }
  },

  // Variable: DecoupleFF
  //  Referenced by: '<S4>/Constant3'

  {
    { 0.0, 0.0, 0.0 },

    { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0,
      15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 24.0, 25.0, 26.0,
      27.0, 28.0, 29.0, 30.0, 31.0, 32.0, 33.0, 34.0, 35.0, 36.0, 37.0, 38.0,
      39.0, 40.0, 41.0, 42.0, 43.0, 44.0, 45.0, 46.0, 47.0, 48.0 }
  },

  // Variable: PhaseComp
  //  Referenced by: '<S4>/Constant13'

  {
    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }
  },

  // Variable: DOB
  //  Referenced by: '<S4>/Constant7'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: All
  //  Referenced by:
  //    '<S3>/Constant4'
  //    '<S4>/Constant4'
  //    '<S39>/Constant4'

  {
    { 100.0, 10.0, 5.0 },

    { 30.0, 15.0, 15.0 },

    { -6.2831853071795862, 6.2831853071795862, -3.1415926535897931,
      3.1415926535897931, -3.1415926535897931, 3.1415926535897931 }
  },

  // Variable: TrackControl
  //  Referenced by:
  //    '<S4>/Constant15'
  //    '<S33>/Constant4'

  {
    { 25.393191099279051, 25.393191099279051, 25.393191099279051 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: NotchFilter
  //  Referenced by: '<S4>/Constant12'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: Reference
  //  Referenced by: '<S4>/Constant1'

  {
    { 180.0, 90.0, 90.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 }
  },

  // Variable: InertialFF
  //  Referenced by: '<S4>/Constant11'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: AngleControl
  //  Referenced by:
  //    '<S4>/Constant6'
  //    '<S32>/Constant4'
  //    '<S34>/Constant4'

  {
    { 25.393191099279051, 25.393191099279051, 25.393191099279051 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: VelocityControl
  //  Referenced by:
  //    '<S4>/Constant16'
  //    '<S31>/Constant4'

  {
    { 76.179573297837138, 76.179573297837138, 76.179573297837138 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: GravityFF
  //  Referenced by: '<S4>/Constant10'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: SensorFilter
  //  Referenced by: '<S4>/Constant14'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  },

  // Variable: Estimate
  //  Referenced by: '<S4>/Constant8'

  {
    { 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0 }
  }
};

//
// File trailer for generated code.
//
// [EOF]
//
