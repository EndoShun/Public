//
// File: ControlModel_types.h
//
// Code generated for Simulink model 'ControlModel'.
//
// Model version                  : 1.120
// Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
// C/C++ source code generated on : Tue Mar 14 21:46:48 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_ControlModel_types_h_
#define RTW_HEADER_ControlModel_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_ioBusCommand_
#define DEFINED_TYPEDEF_FOR_ioBusCommand_

typedef struct {
  uint8_T mode;
  uint8_T homingComplete;
  real_T radAngle[3];
  real_T rpsVelocity[3];
  real_T rpsVelocityLimit[3];
  real_T radScanOffset[2];
} ioBusCommand;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ioBusSensor_
#define DEFINED_TYPEDEF_FOR_ioBusSensor_

typedef struct {
  real_T radAngle[3];
  real_T rpsVelocity[3];
  real_T radVisionAngleError[2];
  uint8_T updateVision;
  uint8_T validVision;
  real_T mPositionRadar[3];
  real_T mpsVelocityRadar[3];
} ioBusSensor;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ioBusControl_
#define DEFINED_TYPEDEF_FOR_ioBusControl_

typedef struct {
  int8_T mode;
  real_T nmTorque[3];
  real_T rpsVelocity[3];
  real_T radRadarReference[3];
} ioBusControl;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ioBusAlarm_
#define DEFINED_TYPEDEF_FOR_ioBusAlarm_

typedef struct {
  uint16_T warningFlag;
  uint16_T alarmFlag;
} ioBusAlarm;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ioBusDebugLog_
#define DEFINED_TYPEDEF_FOR_ioBusDebugLog_

typedef struct {
  ioBusCommand Command;
  ioBusSensor Sensor;
  ioBusControl Control;
  ioBusAlarm Alarm;
  real_T radAngleReference[3];
  real_T rpsVelocityReference[3];
  real_T rpsVelocityFeedback[3];
  real_T nmDisturbance[3];
  real_T estReference[3];
  real_T maintenance[32];
} ioBusDebugLog;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusAll_
#define DEFINED_TYPEDEF_FOR_paramBusAll_

typedef struct {
  real_T nmLimit[3];
  real_T radpsLimit[3];
  real_T radLimit[6];
} paramBusAll;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusReference_
#define DEFINED_TYPEDEF_FOR_paramBusReference_

typedef struct {
  real_T radpsRateLimit[3];
  real_T radps2RateLimit[6];
} paramBusReference;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusGravityFF_
#define DEFINED_TYPEDEF_FOR_paramBusGravityFF_

typedef struct {
  real_T nmTorqueMax[3];
  real_T radPhase[3];
} paramBusGravityFF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusInertialFF_
#define DEFINED_TYPEDEF_FOR_paramBusInertialFF_

typedef struct {
  real_T kgm2Inertia[3];
  real_T hzF[3];
  real_T zeta[3];
} paramBusInertialFF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusNotchFilter_
#define DEFINED_TYPEDEF_FOR_paramBusNotchFilter_

typedef struct {
  real_T hzF[3];
  real_T w[3];
  real_T d[3];
} paramBusNotchFilter;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusPhaseComp_
#define DEFINED_TYPEDEF_FOR_paramBusPhaseComp_

typedef struct {
  real_T hzFLag[6];
  real_T aLag[6];
  real_T hzFLead[6];
  real_T aLead[6];
} paramBusPhaseComp;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusSensorFilter_
#define DEFINED_TYPEDEF_FOR_paramBusSensorFilter_

typedef struct {
  real_T hzFVelocityFilter[3];
  real_T zetaVelocityFilter[3];
} paramBusSensorFilter;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusTrackControl_
#define DEFINED_TYPEDEF_FOR_paramBusTrackControl_

typedef struct {
  real_T pGain[3];
  real_T iGain[3];
  real_T dGain[3];
} paramBusTrackControl;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusVelocityControl_
#define DEFINED_TYPEDEF_FOR_paramBusVelocityControl_

typedef struct {
  real_T pGain[3];
  real_T iGain[3];
} paramBusVelocityControl;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusDecoupleFF_
#define DEFINED_TYPEDEF_FOR_paramBusDecoupleFF_

typedef struct {
  real_T gain[3];
  real_T pseudoInertiaMatrix[48];
} paramBusDecoupleFF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusAngleControl_
#define DEFINED_TYPEDEF_FOR_paramBusAngleControl_

typedef struct {
  real_T pGain[3];
  real_T iGain[3];
} paramBusAngleControl;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusDOB_
#define DEFINED_TYPEDEF_FOR_paramBusDOB_

typedef struct {
  real_T gain[3];
  real_T kgm2Inertia[3];
  real_T hzF[3];
  real_T zeta[3];
  real_T gainDCDOB[3];
} paramBusDOB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusEstimate_
#define DEFINED_TYPEDEF_FOR_paramBusEstimate_

typedef struct {
  real_T Gain[3];
  real_T sTimeSet[3];
} paramBusEstimate;

#endif

#ifndef DEFINED_TYPEDEF_FOR_paramBusFrictionFF_
#define DEFINED_TYPEDEF_FOR_paramBusFrictionFF_

typedef struct {
  real_T mode[3];
  real_T nmFc[18];
  real_T nmFs[18];
  real_T nmsprViscocity[3];
  real_T nmprStiffness[18];
  real_T attractionParameter[18];
  real_T radpsStribeckVelocity[18];
} paramBusFrictionFF;

#endif

// Custom Type definition for MATLAB Function: '<S4>/MATLAB Function9'
#ifndef struct_tag_skA4KFEZ4HPkJJBOYCrevdH
#define struct_tag_skA4KFEZ4HPkJJBOYCrevdH

struct tag_skA4KFEZ4HPkJJBOYCrevdH
{
  uint32_T SafeEq;
  uint32_T Absolute;
  uint32_T NaNBias;
  uint32_T NaNWithFinite;
  uint32_T FiniteWithNaN;
  uint32_T NaNWithNaN;
};

#endif                                 //struct_tag_skA4KFEZ4HPkJJBOYCrevdH

#ifndef typedef_skA4KFEZ4HPkJJBOYCrevdH_Contr_T
#define typedef_skA4KFEZ4HPkJJBOYCrevdH_Contr_T

typedef struct tag_skA4KFEZ4HPkJJBOYCrevdH skA4KFEZ4HPkJJBOYCrevdH_Contr_T;

#endif                                 //typedef_skA4KFEZ4HPkJJBOYCrevdH_Contr_T

#ifndef struct_tag_sJCxfmxS8gBOONUZjbjUd9E
#define struct_tag_sJCxfmxS8gBOONUZjbjUd9E

struct tag_sJCxfmxS8gBOONUZjbjUd9E
{
  boolean_T CaseSensitivity;
  boolean_T StructExpand;
  char_T PartialMatching[6];
  boolean_T IgnoreNulls;
};

#endif                                 //struct_tag_sJCxfmxS8gBOONUZjbjUd9E

#ifndef typedef_sJCxfmxS8gBOONUZjbjUd9E_Contr_T
#define typedef_sJCxfmxS8gBOONUZjbjUd9E_Contr_T

typedef struct tag_sJCxfmxS8gBOONUZjbjUd9E sJCxfmxS8gBOONUZjbjUd9E_Contr_T;

#endif                                 //typedef_sJCxfmxS8gBOONUZjbjUd9E_Contr_T

// Parameters (default storage)
typedef struct P_ControlModel_T_ P_ControlModel_T;

// Forward declaration for rtModel
typedef struct tag_RTM_ControlModel_T RT_MODEL_ControlModel_T;

#endif                                 // RTW_HEADER_ControlModel_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
