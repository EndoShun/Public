//
// File: ControlModel.cpp
//
// Code generated for Simulink model 'ControlModel'.
//
// Model version                  : 1.120
// Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
// C/C++ source code generated on : Tue Mar 14 21:46:48 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "ControlModel.h"
#include "ControlModel_private.h"

//
// Output and update for iterator system:
//    '<S8>/For Each Subsystem'
//    '<S10>/For Each Subsystem1'
//
void ControlModelModelClass::ControlModel_ForEachSubsystem(int32_T NumIters,
  const real_T rtu_Input[3], const real_T rtu_Input1[3], real_T rty_Out1[3],
  P_ControlModel_T *ControlModel_P)
{
  // local scratch DWork variables
  int32_T ForEach_itr;

  // Outputs for Iterator SubSystem: '<S8>/For Each Subsystem' incorporates:
  //   ForEach: '<S32>/For Each'

  for (ForEach_itr = 0; ForEach_itr < NumIters; ForEach_itr++) {
    // ForEachSliceAssignment generated from: '<S32>/Out1' incorporates:
    //   Constant: '<S32>/Constant4'
    //   ForEachSliceSelector generated from: '<S32>/Input1'
    //   ForEachSliceSelector generated from: '<S32>/Input'
    //   Product: '<S32>/Product'
    //   Selector: '<S32>/Selector'
    //   Sum: '<S32>/Sum'

    rty_Out1[ForEach_itr] = (rtu_Input[ForEach_itr] - rtu_Input1[ForEach_itr]) *
      ControlModel_P->AngleControl.pGain[ForEach_itr];
  }

  // End of Outputs for SubSystem: '<S8>/For Each Subsystem'
}

//
// Output and update for action system:
//    '<S10>/Switch Case Action Subsystem1'
//    '<S10>/Switch Case Action Subsystem4'
//
void ControlModelModelClass::Cont_SwitchCaseActionSubsystem1(const real_T
  rtu_In1[3], uint8_T rtu_In2, const real_T rtu_In3[3], real_T rty_Out1[3])
{
  // Switch: '<S35>/Switch'
  if (rtu_In2 != 0) {
    rty_Out1[0] = rtu_In1[0];
    rty_Out1[1] = rtu_In1[1];
    rty_Out1[2] = rtu_In1[2];
  } else {
    rty_Out1[0] = rtu_In3[0];
    rty_Out1[1] = rtu_In3[1];
    rty_Out1[2] = rtu_In3[2];
  }

  // End of Switch: '<S35>/Switch'
}

real_T rt_hypotd(real_T u0, real_T u1)
{
  real_T y;
  real_T a;
  real_T b;
  a = abs(u0);
  b = abs(u1);
  if (a < b) {
    a /= b;
    y = sqrt(a * a + 1.0) * b;
  } else if (a > b) {
    b /= a;
    y = sqrt(b * b + 1.0) * a;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

void ControlModelModelClass::C_reshapeRowMajorDataColumnWise(const real_T tmp[6],
  const int32_T *tmp_0, real_T tmp_1[6])
{
  int32_T tmp_2;
  int32_T tmp_3;
  int32_T tmp_4;
  int32_T i;

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  // MATLAB Function: '<S4>/MATLAB Function1'
  tmp_4 = 0;
  tmp_2 = 0;
  tmp_3 = 0;
  for (i = 0; i < *tmp_0; i++) {
    tmp_1[tmp_4] = tmp[(tmp_2 << 1) + tmp_3];
    tmp_4++;
    tmp_2++;
    if (tmp_2 > 2) {
      tmp_2 = 0;
      tmp_3++;
    }
  }

  // End of MATLAB Function: '<S4>/MATLAB Function1'
  // End of Outputs for SubSystem: '<Root>/ControlModel'
}

void ControlModelModelClass::reshapeRowMajorDataColumnWise_j(const real_T tmp[48],
  const int32_T *tmp_0, real_T tmp_1[48])
{
  int32_T tmp_2;
  int32_T tmp_3;
  int32_T tmp_4;
  int32_T tmp_5;
  int32_T i;

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  // MATLAB Function: '<S4>/MATLAB Function'
  tmp_5 = 0;
  tmp_2 = 0;
  tmp_3 = 0;
  tmp_4 = 0;
  for (i = 0; i < *tmp_0; i++) {
    tmp_1[tmp_5] = tmp[((tmp_3 << 2) + tmp_4) + (tmp_2 << 4)];
    tmp_5++;
    tmp_2++;
    if (tmp_2 > 2) {
      tmp_2 = 0;
      tmp_3++;
      if (tmp_3 > 3) {
        tmp_3 = 0;
        tmp_4++;
      }
    }
  }

  // End of MATLAB Function: '<S4>/MATLAB Function'
  // End of Outputs for SubSystem: '<Root>/ControlModel'
}

void ControlModelModelClass::reshapeRowMajorDataColumnWis_jp(const real_T tmp[18],
  const int32_T *tmp_0, real_T tmp_1[18])
{
  int32_T tmp_2;
  int32_T tmp_3;
  int32_T tmp_4;
  int32_T i;

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  // MATLAB Function: '<S4>/MATLAB Function5'
  tmp_4 = 0;
  tmp_2 = 0;
  tmp_3 = 0;
  for (i = 0; i < *tmp_0; i++) {
    tmp_1[tmp_4] = tmp[6 * tmp_2 + tmp_3];
    tmp_4++;
    tmp_2++;
    if (tmp_2 > 2) {
      tmp_2 = 0;
      tmp_3++;
    }
  }

  // End of MATLAB Function: '<S4>/MATLAB Function5'
  // End of Outputs for SubSystem: '<Root>/ControlModel'
}

// Model step function
void ControlModelModelClass::step()
{
  // local block i/o variables
  real_T rtb_ImpAsg_InsertedFor_Out1_a_k[3];
  real_T rtb_ImpAsg_InsertedFor_Out1_ke3[3];
  real_T varargin_1[6];
  real_T varargin_1_0[48];
  real_T b_y;
  real_T varargin_1_1[18];
  real_T b_y_0;
  real_T c_y;
  real_T e_y;
  real_T f_y;
  real_T g_y;
  real_T y;
  real_T b_y_1;
  real_T c_y_0;
  real_T d_y;
  real_T b_y_2;
  real_T tmp;
  int32_T i;
  real_T rtb_Atan1;
  int32_T rtb_Merge2;
  int32_T rtb_Gain;
  real_T rtb_Switch_k;
  real_T rtb_Switch2_n;
  real_T rtb_SigConversion_InsertedFor_S[3];
  uint16_T rtb_ImpAsg_InsertedFor_Out1_a_d[3];
  real_T rtb_ImpAsg_InsertedFor_Out1_a_f[3];
  real_T rtb_y_g_0[14];
  real_T rtb_ImpAsg_InsertedFor_Out1_a_p[3];
  static const int32_T tmp_0 = 6;
  static const int32_T tmp_1 = 48;
  static const int32_T tmp_2 = 18;

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  // Outputs for Iterator SubSystem: '<S1>/For Each Subsystem1' incorporates:
  //   ForEach: '<S3>/For Each'

  // ForEachSliceAssignment generated from: '<S3>/Out1' incorporates:
  //   ArithShift: '<S3>/Shift Arithmetic'
  //   ArithShift: '<S3>/Shift Arithmetic1'
  //   Constant: '<S3>/Constant1'
  //   Constant: '<S3>/Constant4'
  //   DataTypeConversion: '<S3>/Data Type Conversion'
  //   DataTypeConversion: '<S3>/Data Type Conversion1'
  //   ForEachSliceSelector generated from: '<S3>/Input'
  //   Inport: '<Root>/Sensor'
  //   RelationalOperator: '<S3>/Relational Operator'
  //   RelationalOperator: '<S3>/Relational Operator1'
  //   Selector: '<S3>/Selector'
  //   Sum: '<S3>/Sum'
  //   Sum: '<S3>/Sum1'
  //   Sum: '<S3>/Sum2'

  rtb_ImpAsg_InsertedFor_Out1_a_d[0] = static_cast<uint16_T>
    (static_cast<uint32_T>((ControlModel_P.All.radLimit[1] <=
       ControlModel_U.Sensor.radAngle[0]) << 1U) +
     ((ControlModel_U.Sensor.radAngle[0] <= ControlModel_P.All.radLimit[0]) <<
      0U));
  rtb_ImpAsg_InsertedFor_Out1_a_d[1] = static_cast<uint16_T>
    (static_cast<uint32_T>((ControlModel_P.All.radLimit[3] <=
       ControlModel_U.Sensor.radAngle[1]) << 5U) +
     ((ControlModel_U.Sensor.radAngle[1] <= ControlModel_P.All.radLimit[2]) <<
      4U));
  rtb_ImpAsg_InsertedFor_Out1_a_d[2] = static_cast<uint16_T>
    (static_cast<uint32_T>((ControlModel_P.All.radLimit[5] <=
       ControlModel_U.Sensor.radAngle[2]) << 9U) +
     ((ControlModel_U.Sensor.radAngle[2] <= ControlModel_P.All.radLimit[4]) <<
      8U));

  // End of Outputs for SubSystem: '<S1>/For Each Subsystem1'

  // SignalConversion generated from: '<S1>/Sensor_BusSelector' incorporates:
  //   Inport: '<Root>/Sensor'

  rtb_SigConversion_InsertedFor_S[0] = ControlModel_U.Sensor.radAngle[0];
  rtb_SigConversion_InsertedFor_S[1] = ControlModel_U.Sensor.radAngle[1];
  rtb_SigConversion_InsertedFor_S[2] = ControlModel_U.Sensor.radAngle[2];

  // SwitchCase: '<S1>/Switch Case1' incorporates:
  //   Inport: '<Root>/Command'
  //   Inport: '<Root>/Sensor'
  //   Inport: '<S9>/In1'
  //   SignalConversion generated from: '<S1>/Command_BusSelector'

  switch (ControlModel_U.Command.mode) {
   case 1:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem3' incorporates:
    //   ActionPort: '<S8>/Action Port'

    // Outputs for Iterator SubSystem: '<S8>/For Each Subsystem'
    ControlModel_ForEachSubsystem(3, ControlModel_U.Command.radAngle,
      rtb_SigConversion_InsertedFor_S, rtb_ImpAsg_InsertedFor_Out1_ke3,
      &ControlModel_P);

    // End of Outputs for SubSystem: '<S8>/For Each Subsystem'

    // Reshape: '<S8>/Reshape'
    rtb_SigConversion_InsertedFor_S[0] = rtb_ImpAsg_InsertedFor_Out1_ke3[0];
    rtb_SigConversion_InsertedFor_S[1] = rtb_ImpAsg_InsertedFor_Out1_ke3[1];
    rtb_SigConversion_InsertedFor_S[2] = rtb_ImpAsg_InsertedFor_Out1_ke3[2];

    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem3'
    break;

   case 10:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem4' incorporates:
    //   ActionPort: '<S9>/Action Port'

    rtb_SigConversion_InsertedFor_S[0] = ControlModel_U.Command.rpsVelocity[0];
    rtb_SigConversion_InsertedFor_S[1] = ControlModel_U.Command.rpsVelocity[1];
    rtb_SigConversion_InsertedFor_S[2] = ControlModel_U.Command.rpsVelocity[2];

    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem4'
    break;

   case 11:
   case 12:
   case 20:
   case 21:
   case 22:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem5' incorporates:
    //   ActionPort: '<S10>/Action Port'

    // SignalConversion generated from: '<S10>/For Each Subsystem' incorporates:
    //   Inport: '<Root>/Sensor'

    rtb_SigConversion_InsertedFor_S[0] =
      ControlModel_U.Sensor.radVisionAngleError[0];
    rtb_SigConversion_InsertedFor_S[1] =
      ControlModel_U.Sensor.radVisionAngleError[1];
    rtb_SigConversion_InsertedFor_S[2] =
      ControlModel_U.Sensor.radVisionAngleError[1];

    // Outputs for Iterator SubSystem: '<S10>/For Each Subsystem' incorporates:
    //   ForEach: '<S33>/For Each'

    // ForEachSliceAssignment generated from: '<S33>/Out1' incorporates:
    //   Constant: '<S33>/Constant4'
    //   ForEachSliceSelector generated from: '<S33>/Input'
    //   Product: '<S33>/Product'
    //   Selector: '<S33>/Selector'

    rtb_ImpAsg_InsertedFor_Out1_a_p[0] = rtb_SigConversion_InsertedFor_S[0] *
      ControlModel_P.TrackControl.pGain[0];
    rtb_ImpAsg_InsertedFor_Out1_a_p[1] = rtb_SigConversion_InsertedFor_S[1] *
      ControlModel_P.TrackControl.pGain[1];
    rtb_ImpAsg_InsertedFor_Out1_a_p[2] = rtb_SigConversion_InsertedFor_S[2] *
      ControlModel_P.TrackControl.pGain[2];

    // End of Outputs for SubSystem: '<S10>/For Each Subsystem'

    // Trigonometry: '<S10>/Atan1' incorporates:
    //   Inport: '<Root>/Sensor'
    //   Math: '<S10>/Hypot'
    //   UnaryMinus: '<S10>/Unary Minus'

    rtb_Atan1 = atan2(-ControlModel_U.Sensor.mPositionRadar[2], rt_hypotd
                      (ControlModel_U.Sensor.mPositionRadar[0],
                       ControlModel_U.Sensor.mPositionRadar[1]));

    // SignalConversion generated from: '<S10>/For Each Subsystem1' incorporates:
    //   Inport: '<Root>/Sensor'
    //   Trigonometry: '<S10>/Atan2'

    ControlModel_B.OutportBufferForOut2[0] = atan2
      (ControlModel_U.Sensor.mPositionRadar[1],
       ControlModel_U.Sensor.mPositionRadar[0]);
    ControlModel_B.OutportBufferForOut2[1] = rtb_Atan1;
    ControlModel_B.OutportBufferForOut2[2] = rtb_Atan1;

    // Outputs for Iterator SubSystem: '<S10>/For Each Subsystem1'
    ControlModel_ForEachSubsystem(3, ControlModel_B.OutportBufferForOut2,
      ControlModel_U.Sensor.radAngle, rtb_ImpAsg_InsertedFor_Out1_a_k,
      &ControlModel_P);

    // End of Outputs for SubSystem: '<S10>/For Each Subsystem1'
    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem5'
    switch (ControlModel_U.Command.mode) {
     case 11:
     case 12:
      // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem5' incorporates:
      //   ActionPort: '<S10>/Action Port'

      // Outputs for IfAction SubSystem: '<S10>/Switch Case Action Subsystem1' incorporates:
      //   ActionPort: '<S35>/Action Port'

      // SwitchCase: '<S10>/Switch Case1' incorporates:
      //   Inport: '<Root>/Sensor'

      Cont_SwitchCaseActionSubsystem1(rtb_ImpAsg_InsertedFor_Out1_a_p,
        ControlModel_U.Sensor.validVision, ControlModel_U.Command.rpsVelocity,
        rtb_SigConversion_InsertedFor_S);

      // End of Outputs for SubSystem: '<S10>/Switch Case Action Subsystem1'
      // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem5'
      break;

     case 20:
      // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem5' incorporates:
      //   ActionPort: '<S10>/Action Port'

      // Outputs for IfAction SubSystem: '<S10>/Switch Case Action Subsystem3' incorporates:
      //   ActionPort: '<S37>/Action Port'

      // SwitchCase: '<S10>/Switch Case1' incorporates:
      //   Inport: '<S37>/In1'
      //   Reshape: '<S10>/Reshape'

      rtb_SigConversion_InsertedFor_S[0] = rtb_ImpAsg_InsertedFor_Out1_a_k[0];
      rtb_SigConversion_InsertedFor_S[1] = rtb_ImpAsg_InsertedFor_Out1_a_k[1];
      rtb_SigConversion_InsertedFor_S[2] = rtb_ImpAsg_InsertedFor_Out1_a_k[2];

      // End of Outputs for SubSystem: '<S10>/Switch Case Action Subsystem3'
      // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem5'
      break;

     case 21:
     case 22:
      // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem5' incorporates:
      //   ActionPort: '<S10>/Action Port'

      // Outputs for IfAction SubSystem: '<S10>/Switch Case Action Subsystem4' incorporates:
      //   ActionPort: '<S38>/Action Port'

      // SwitchCase: '<S10>/Switch Case1' incorporates:
      //   Inport: '<Root>/Sensor'

      Cont_SwitchCaseActionSubsystem1(rtb_ImpAsg_InsertedFor_Out1_a_p,
        ControlModel_U.Sensor.validVision, rtb_ImpAsg_InsertedFor_Out1_a_k,
        rtb_SigConversion_InsertedFor_S);

      // End of Outputs for SubSystem: '<S10>/Switch Case Action Subsystem4'
      // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem5'
      break;

     default:
      // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem5' incorporates:
      //   ActionPort: '<S10>/Action Port'

      // Outputs for IfAction SubSystem: '<S10>/Switch Case Action Subsystem2' incorporates:
      //   ActionPort: '<S36>/Action Port'

      // SwitchCase: '<S10>/Switch Case1' incorporates:
      //   SignalConversion generated from: '<S36>/Out1'

      rtb_SigConversion_InsertedFor_S[0] = 0.0;
      rtb_SigConversion_InsertedFor_S[1] = 0.0;
      rtb_SigConversion_InsertedFor_S[2] = 0.0;

      // End of Outputs for SubSystem: '<S10>/Switch Case Action Subsystem2'
      // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem5'
      break;
    }
    break;

   default:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem2' incorporates:
    //   ActionPort: '<S7>/Action Port'

    // SignalConversion generated from: '<S7>/Out1'
    rtb_SigConversion_InsertedFor_S[0] = 0.0;
    rtb_SigConversion_InsertedFor_S[1] = 0.0;
    rtb_SigConversion_InsertedFor_S[2] = 0.0;

    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem2'
    break;
  }

  // End of SwitchCase: '<S1>/Switch Case1'

  // Sum: '<S1>/Sum12'
  rtb_Gain = static_cast<int32_T>((static_cast<uint32_T>
    (rtb_ImpAsg_InsertedFor_Out1_a_d[0]) + rtb_ImpAsg_InsertedFor_Out1_a_d[1]) +
    rtb_ImpAsg_InsertedFor_Out1_a_d[2]);

  // Outputs for Iterator SubSystem: '<S13>/For Each Subsystem' incorporates:
  //   ForEach: '<S39>/For Each'

  // Abs: '<S39>/Abs' incorporates:
  //   Constant: '<S39>/Constant4'
  //   Selector: '<S39>/Selector'

  rtb_Atan1 = abs(ControlModel_P.All.radpsLimit[0]);

  // Switch: '<S40>/Switch2' incorporates:
  //   ForEachSliceSelector generated from: '<S39>/Input'
  //   RelationalOperator: '<S40>/LowerRelop1'
  //   RelationalOperator: '<S40>/UpperRelop'
  //   Switch: '<S40>/Switch'
  //   UnaryMinus: '<S39>/Unary Minus'

  if (rtb_SigConversion_InsertedFor_S[0] > rtb_Atan1) {
    // ForEachSliceAssignment generated from: '<S39>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_p[0] = rtb_Atan1;
  } else if (rtb_SigConversion_InsertedFor_S[0] < -rtb_Atan1) {
    // Switch: '<S40>/Switch' incorporates:
    //   ForEachSliceAssignment generated from: '<S39>/Out1'
    //   UnaryMinus: '<S39>/Unary Minus'

    rtb_ImpAsg_InsertedFor_Out1_a_p[0] = -rtb_Atan1;
  } else {
    // ForEachSliceAssignment generated from: '<S39>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_p[0] = rtb_SigConversion_InsertedFor_S[0];
  }

  // Abs: '<S39>/Abs' incorporates:
  //   Constant: '<S39>/Constant4'
  //   Selector: '<S39>/Selector'

  rtb_Atan1 = abs(ControlModel_P.All.radpsLimit[1]);

  // Switch: '<S40>/Switch2' incorporates:
  //   ForEachSliceSelector generated from: '<S39>/Input'
  //   RelationalOperator: '<S40>/LowerRelop1'
  //   RelationalOperator: '<S40>/UpperRelop'
  //   Switch: '<S40>/Switch'
  //   UnaryMinus: '<S39>/Unary Minus'

  if (rtb_SigConversion_InsertedFor_S[1] > rtb_Atan1) {
    // ForEachSliceAssignment generated from: '<S39>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_p[1] = rtb_Atan1;
  } else if (rtb_SigConversion_InsertedFor_S[1] < -rtb_Atan1) {
    // Switch: '<S40>/Switch' incorporates:
    //   ForEachSliceAssignment generated from: '<S39>/Out1'
    //   UnaryMinus: '<S39>/Unary Minus'

    rtb_ImpAsg_InsertedFor_Out1_a_p[1] = -rtb_Atan1;
  } else {
    // ForEachSliceAssignment generated from: '<S39>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_p[1] = rtb_SigConversion_InsertedFor_S[1];
  }

  // Abs: '<S39>/Abs' incorporates:
  //   Constant: '<S39>/Constant4'
  //   Selector: '<S39>/Selector'

  rtb_Atan1 = abs(ControlModel_P.All.radpsLimit[2]);

  // Switch: '<S40>/Switch2' incorporates:
  //   ForEachSliceSelector generated from: '<S39>/Input'
  //   RelationalOperator: '<S40>/LowerRelop1'
  //   RelationalOperator: '<S40>/UpperRelop'
  //   Switch: '<S40>/Switch'
  //   UnaryMinus: '<S39>/Unary Minus'

  if (rtb_SigConversion_InsertedFor_S[2] > rtb_Atan1) {
    // ForEachSliceAssignment generated from: '<S39>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_p[2] = rtb_Atan1;
  } else if (rtb_SigConversion_InsertedFor_S[2] < -rtb_Atan1) {
    // Switch: '<S40>/Switch' incorporates:
    //   ForEachSliceAssignment generated from: '<S39>/Out1'
    //   UnaryMinus: '<S39>/Unary Minus'

    rtb_ImpAsg_InsertedFor_Out1_a_p[2] = -rtb_Atan1;
  } else {
    // ForEachSliceAssignment generated from: '<S39>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_p[2] = rtb_SigConversion_InsertedFor_S[2];
  }

  // End of Outputs for SubSystem: '<S13>/For Each Subsystem'

  // SwitchCase: '<S1>/Switch Case' incorporates:
  //   Inport: '<Root>/Command'

  switch (ControlModel_U.Command.mode) {
   case 1:
   case 10:
   case 11:
   case 12:
   case 20:
   case 21:
   case 22:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem' incorporates:
    //   ActionPort: '<S5>/Action Port'

    // Outputs for Iterator SubSystem: '<S5>/For Each Subsystem' incorporates:
    //   ForEach: '<S31>/For Each'

    // ForEachSliceAssignment generated from: '<S31>/Out1' incorporates:
    //   Constant: '<S31>/Constant4'
    //   ForEachSliceSelector generated from: '<S31>/Input1'
    //   ForEachSliceSelector generated from: '<S31>/Input'
    //   Inport: '<Root>/Sensor'
    //   Product: '<S31>/Product'
    //   Reshape: '<S13>/Reshape'
    //   Selector: '<S31>/Selector'
    //   Sum: '<S31>/Sum'

    rtb_ImpAsg_InsertedFor_Out1_a_f[0] = (rtb_ImpAsg_InsertedFor_Out1_a_p[0] -
      ControlModel_U.Sensor.rpsVelocity[0]) *
      ControlModel_P.VelocityControl.pGain[0];
    rtb_ImpAsg_InsertedFor_Out1_a_f[1] = (rtb_ImpAsg_InsertedFor_Out1_a_p[1] -
      ControlModel_U.Sensor.rpsVelocity[1]) *
      ControlModel_P.VelocityControl.pGain[1];
    rtb_ImpAsg_InsertedFor_Out1_a_f[2] = (rtb_ImpAsg_InsertedFor_Out1_a_p[2] -
      ControlModel_U.Sensor.rpsVelocity[2]) *
      ControlModel_P.VelocityControl.pGain[2];

    // End of Outputs for SubSystem: '<S5>/For Each Subsystem'
    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem'
    break;

   default:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem1' incorporates:
    //   ActionPort: '<S6>/Action Port'

    // SignalConversion generated from: '<S6>/Out1'
    rtb_ImpAsg_InsertedFor_Out1_a_f[0] = 0.0;
    rtb_ImpAsg_InsertedFor_Out1_a_f[1] = 0.0;
    rtb_ImpAsg_InsertedFor_Out1_a_f[2] = 0.0;

    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem1'
    break;
  }

  // End of SwitchCase: '<S1>/Switch Case'

  // Switch: '<S2>/Switch5' incorporates:
  //   Constant: '<S2>/Constant5'
  //   RelationalOperator: '<S2>/Relational Operator5'
  //   S-Function (sfix_bitop): '<S2>/Bitwise Operator6'
  //   Sum: '<S1>/Sum12'

  if ((static_cast<uint16_T>(rtb_Gain) & 512U) == 0U) {
    rtb_Atan1 = rtb_ImpAsg_InsertedFor_Out1_a_f[2];
  } else {
    rtb_Atan1 = 0.0;
  }

  // End of Switch: '<S2>/Switch5'

  // Switch: '<S16>/Switch2' incorporates:
  //   RelationalOperator: '<S16>/LowerRelop1'

  if (rtb_ImpAsg_InsertedFor_Out1_a_f[2] <= rtb_Atan1) {
    // Switch: '<S2>/Switch4' incorporates:
    //   Constant: '<S2>/Constant4'
    //   RelationalOperator: '<S2>/Relational Operator4'
    //   S-Function (sfix_bitop): '<S2>/Bitwise Operator5'
    //   Sum: '<S1>/Sum12'

    if ((static_cast<uint16_T>(rtb_Gain) & 256U) == 0U) {
      rtb_Atan1 = rtb_ImpAsg_InsertedFor_Out1_a_f[2];
    } else {
      rtb_Atan1 = 0.0;
    }

    // End of Switch: '<S2>/Switch4'

    // Switch: '<S16>/Switch' incorporates:
    //   RelationalOperator: '<S16>/UpperRelop'

    if (rtb_ImpAsg_InsertedFor_Out1_a_f[2] >= rtb_Atan1) {
      rtb_Atan1 = rtb_ImpAsg_InsertedFor_Out1_a_f[2];
    }

    // End of Switch: '<S16>/Switch'
  }

  // End of Switch: '<S16>/Switch2'

  // Switch: '<S2>/Switch1' incorporates:
  //   Constant: '<S2>/Constant1'
  //   RelationalOperator: '<S2>/Relational Operator1'
  //   S-Function (sfix_bitop): '<S2>/Bitwise Operator2'
  //   Sum: '<S1>/Sum12'

  if ((static_cast<uint16_T>(rtb_Gain) & 2U) == 0U) {
    rtb_Switch_k = rtb_ImpAsg_InsertedFor_Out1_a_f[0];
  } else {
    rtb_Switch_k = 0.0;
  }

  // End of Switch: '<S2>/Switch1'

  // Switch: '<S14>/Switch2' incorporates:
  //   RelationalOperator: '<S14>/LowerRelop1'

  if (rtb_ImpAsg_InsertedFor_Out1_a_f[0] <= rtb_Switch_k) {
    // Switch: '<S2>/Switch' incorporates:
    //   Constant: '<S2>/Constant'
    //   RelationalOperator: '<S2>/Relational Operator'
    //   S-Function (sfix_bitop): '<S2>/Bitwise Operator1'
    //   Sum: '<S1>/Sum12'

    if ((static_cast<uint16_T>(rtb_Gain) & 1U) == 0U) {
      rtb_Switch_k = rtb_ImpAsg_InsertedFor_Out1_a_f[0];
    } else {
      rtb_Switch_k = 0.0;
    }

    // End of Switch: '<S2>/Switch'

    // Switch: '<S14>/Switch' incorporates:
    //   RelationalOperator: '<S14>/UpperRelop'

    if (rtb_ImpAsg_InsertedFor_Out1_a_f[0] >= rtb_Switch_k) {
      rtb_Switch_k = rtb_ImpAsg_InsertedFor_Out1_a_f[0];
    }

    // End of Switch: '<S14>/Switch'
  }

  // End of Switch: '<S14>/Switch2'

  // Switch: '<S2>/Switch3' incorporates:
  //   Constant: '<S2>/Constant3'
  //   RelationalOperator: '<S2>/Relational Operator3'
  //   S-Function (sfix_bitop): '<S2>/Bitwise Operator4'
  //   Sum: '<S1>/Sum12'

  if ((static_cast<uint16_T>(rtb_Gain) & 32U) == 0U) {
    rtb_Switch2_n = rtb_ImpAsg_InsertedFor_Out1_a_f[1];
  } else {
    rtb_Switch2_n = 0.0;
  }

  // End of Switch: '<S2>/Switch3'

  // Switch: '<S15>/Switch2' incorporates:
  //   RelationalOperator: '<S15>/LowerRelop1'

  if (rtb_ImpAsg_InsertedFor_Out1_a_f[1] <= rtb_Switch2_n) {
    // Switch: '<S2>/Switch2' incorporates:
    //   Constant: '<S2>/Constant2'
    //   RelationalOperator: '<S2>/Relational Operator2'
    //   S-Function (sfix_bitop): '<S2>/Bitwise Operator3'
    //   Sum: '<S1>/Sum12'

    if ((static_cast<uint16_T>(rtb_Gain) & 16U) == 0U) {
      rtb_Switch2_n = rtb_ImpAsg_InsertedFor_Out1_a_f[1];
    } else {
      rtb_Switch2_n = 0.0;
    }

    // End of Switch: '<S2>/Switch2'

    // Switch: '<S15>/Switch' incorporates:
    //   RelationalOperator: '<S15>/UpperRelop'

    if (rtb_ImpAsg_InsertedFor_Out1_a_f[1] >= rtb_Switch2_n) {
      rtb_Switch2_n = rtb_ImpAsg_InsertedFor_Out1_a_f[1];
    }

    // End of Switch: '<S15>/Switch'
  }

  // End of Switch: '<S15>/Switch2'

  // SwitchCase: '<S1>/Switch Case2' incorporates:
  //   Inport: '<Root>/Command'

  switch (ControlModel_U.Command.mode) {
   case 1:
   case 10:
   case 11:
   case 12:
   case 20:
   case 21:
   case 22:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem6' incorporates:
    //   ActionPort: '<S11>/Action Port'

    // SignalConversion generated from: '<S11>/Out1' incorporates:
    //   Constant: '<S11>/Constant'

    rtb_Merge2 = 1;

    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem6'
    break;

   default:
    // Outputs for IfAction SubSystem: '<S1>/Switch Case Action Subsystem7' incorporates:
    //   ActionPort: '<S12>/Action Port'

    // SignalConversion generated from: '<S12>/Out1'
    rtb_Merge2 = 0;

    // End of Outputs for SubSystem: '<S1>/Switch Case Action Subsystem7'
    break;
  }

  // End of SwitchCase: '<S1>/Switch Case2'

  // BusAssignment: '<S1>/Bus Assignment'
  rtb_ImpAsg_InsertedFor_Out1_a_f[1] = rtb_Switch2_n;

  // MATLAB Function: '<S4>/MATLAB Function1' incorporates:
  //   Constant: '<S4>/Constant4'

  C_reshapeRowMajorDataColumnWise(ControlModel_P.All.radLimit, &tmp_0,
    varargin_1);
  rtb_Switch2_n = varargin_1[0];
  for (i = 0; i < 5; i++) {
    rtb_Switch2_n += varargin_1[i + 1];
  }

  // MATLAB Function: '<S4>/MATLAB Function' incorporates:
  //   Constant: '<S4>/Constant3'

  reshapeRowMajorDataColumnWise_j(ControlModel_P.DecoupleFF.pseudoInertiaMatrix,
    &tmp_1, varargin_1_0);
  b_y = varargin_1_0[0];
  for (i = 0; i < 47; i++) {
    b_y += varargin_1_0[i + 1];
  }

  // MATLAB Function: '<S4>/MATLAB Function5' incorporates:
  //   Constant: '<S4>/Constant9'

  reshapeRowMajorDataColumnWis_jp(ControlModel_P.FrictionFF.nmFc, &tmp_2,
    varargin_1_1);
  b_y_0 = varargin_1_1[0];
  for (i = 0; i < 17; i++) {
    b_y_0 += varargin_1_1[i + 1];
  }

  reshapeRowMajorDataColumnWis_jp(ControlModel_P.FrictionFF.nmFs, &tmp_2,
    varargin_1_1);
  c_y = varargin_1_1[0];
  for (i = 0; i < 17; i++) {
    c_y += varargin_1_1[i + 1];
  }

  reshapeRowMajorDataColumnWis_jp(ControlModel_P.FrictionFF.nmprStiffness,
    &tmp_2, varargin_1_1);
  e_y = varargin_1_1[0];
  for (i = 0; i < 17; i++) {
    e_y += varargin_1_1[i + 1];
  }

  reshapeRowMajorDataColumnWis_jp(ControlModel_P.FrictionFF.attractionParameter,
    &tmp_2, varargin_1_1);
  f_y = varargin_1_1[0];
  for (i = 0; i < 17; i++) {
    f_y += varargin_1_1[i + 1];
  }

  reshapeRowMajorDataColumnWis_jp
    (ControlModel_P.FrictionFF.radpsStribeckVelocity, &tmp_2, varargin_1_1);
  g_y = varargin_1_1[0];
  for (i = 0; i < 17; i++) {
    g_y += varargin_1_1[i + 1];
  }

  // MATLAB Function: '<S4>/MATLAB Function9' incorporates:
  //   Constant: '<S4>/Constant13'

  C_reshapeRowMajorDataColumnWise(ControlModel_P.PhaseComp.hzFLag, &tmp_0,
    varargin_1);
  y = varargin_1[0];
  for (i = 0; i < 5; i++) {
    y += varargin_1[i + 1];
  }

  C_reshapeRowMajorDataColumnWise(ControlModel_P.PhaseComp.aLag, &tmp_0,
    varargin_1);
  b_y_1 = varargin_1[0];
  for (i = 0; i < 5; i++) {
    b_y_1 += varargin_1[i + 1];
  }

  C_reshapeRowMajorDataColumnWise(ControlModel_P.PhaseComp.hzFLead, &tmp_0,
    varargin_1);
  c_y_0 = varargin_1[0];
  for (i = 0; i < 5; i++) {
    c_y_0 += varargin_1[i + 1];
  }

  C_reshapeRowMajorDataColumnWise(ControlModel_P.PhaseComp.aLead, &tmp_0,
    varargin_1);
  d_y = varargin_1[0];
  for (i = 0; i < 5; i++) {
    d_y += varargin_1[i + 1];
  }

  // MATLAB Function: '<S4>/MATLAB Function13' incorporates:
  //   Constant: '<S4>/Constant1'

  C_reshapeRowMajorDataColumnWise(ControlModel_P.Reference.radps2RateLimit,
    &tmp_0, varargin_1);
  b_y_2 = varargin_1[0];
  for (i = 0; i < 5; i++) {
    b_y_2 += varargin_1[i + 1];
  }

  // Sum: '<S4>/Sum' incorporates:
  //   Constant: '<S4>/Constant1'
  //   Constant: '<S4>/Constant10'
  //   Constant: '<S4>/Constant11'
  //   Constant: '<S4>/Constant12'
  //   Constant: '<S4>/Constant14'
  //   Constant: '<S4>/Constant15'
  //   Constant: '<S4>/Constant16'
  //   Constant: '<S4>/Constant3'
  //   Constant: '<S4>/Constant4'
  //   Constant: '<S4>/Constant6'
  //   Constant: '<S4>/Constant7'
  //   Constant: '<S4>/Constant8'
  //   Constant: '<S4>/Constant9'
  //   MATLAB Function: '<S4>/MATLAB Function'
  //   MATLAB Function: '<S4>/MATLAB Function1'
  //   MATLAB Function: '<S4>/MATLAB Function10'
  //   MATLAB Function: '<S4>/MATLAB Function11'
  //   MATLAB Function: '<S4>/MATLAB Function12'
  //   MATLAB Function: '<S4>/MATLAB Function13'
  //   MATLAB Function: '<S4>/MATLAB Function2'
  //   MATLAB Function: '<S4>/MATLAB Function3'
  //   MATLAB Function: '<S4>/MATLAB Function4'
  //   MATLAB Function: '<S4>/MATLAB Function5'
  //   MATLAB Function: '<S4>/MATLAB Function6'
  //   MATLAB Function: '<S4>/MATLAB Function7'
  //   MATLAB Function: '<S4>/MATLAB Function8'
  //   MATLAB Function: '<S4>/MATLAB Function9'

  tmp = -0.0;
  rtb_y_g_0[0] = (((ControlModel_P.All.nmLimit[0] + ControlModel_P.All.nmLimit[1])
                   + ControlModel_P.All.nmLimit[2]) +
                  ((ControlModel_P.All.radpsLimit[0] +
                    ControlModel_P.All.radpsLimit[1]) +
                   ControlModel_P.All.radpsLimit[2])) + rtb_Switch2_n;
  rtb_y_g_0[1] = ((ControlModel_P.AngleControl.pGain[0] +
                   ControlModel_P.AngleControl.pGain[1]) +
                  ControlModel_P.AngleControl.pGain[2]) +
    ((ControlModel_P.AngleControl.iGain[0] + ControlModel_P.AngleControl.iGain[1])
     + ControlModel_P.AngleControl.iGain[2]);
  rtb_y_g_0[2] = (((((ControlModel_P.DOB.gain[0] + ControlModel_P.DOB.gain[1]) +
                     ControlModel_P.DOB.gain[2]) +
                    ((ControlModel_P.DOB.kgm2Inertia[0] +
                      ControlModel_P.DOB.kgm2Inertia[1]) +
                     ControlModel_P.DOB.kgm2Inertia[2])) +
                   ((ControlModel_P.DOB.hzF[0] + ControlModel_P.DOB.hzF[1]) +
                    ControlModel_P.DOB.hzF[2])) + ((ControlModel_P.DOB.zeta[0] +
    ControlModel_P.DOB.zeta[1]) + ControlModel_P.DOB.zeta[2])) +
    ((ControlModel_P.DOB.gainDCDOB[0] + ControlModel_P.DOB.gainDCDOB[1]) +
     ControlModel_P.DOB.gainDCDOB[2]);
  rtb_y_g_0[3] = ((ControlModel_P.DecoupleFF.gain[0] +
                   ControlModel_P.DecoupleFF.gain[1]) +
                  ControlModel_P.DecoupleFF.gain[2]) + b_y;
  rtb_y_g_0[4] = ((ControlModel_P.Estimate.Gain[0] +
                   ControlModel_P.Estimate.Gain[1]) +
                  ControlModel_P.Estimate.Gain[2]) +
    ((ControlModel_P.Estimate.sTimeSet[0] + ControlModel_P.Estimate.sTimeSet[1])
     + ControlModel_P.Estimate.sTimeSet[2]);
  rtb_y_g_0[5] = (((((((ControlModel_P.FrictionFF.mode[0] +
                        ControlModel_P.FrictionFF.mode[1]) +
                       ControlModel_P.FrictionFF.mode[2]) + b_y_0) + c_y) +
                    ((ControlModel_P.FrictionFF.nmsprViscocity[0] +
                      ControlModel_P.FrictionFF.nmsprViscocity[1]) +
                     ControlModel_P.FrictionFF.nmsprViscocity[2])) + e_y) + f_y)
    + g_y;
  rtb_y_g_0[6] = ((ControlModel_P.GravityFF.nmTorqueMax[0] +
                   ControlModel_P.GravityFF.nmTorqueMax[1]) +
                  ControlModel_P.GravityFF.nmTorqueMax[2]) +
    ((ControlModel_P.GravityFF.radPhase[0] + ControlModel_P.GravityFF.radPhase[1])
     + ControlModel_P.GravityFF.radPhase[2]);
  rtb_y_g_0[7] = (((ControlModel_P.InertialFF.kgm2Inertia[0] +
                    ControlModel_P.InertialFF.kgm2Inertia[1]) +
                   ControlModel_P.InertialFF.kgm2Inertia[2]) +
                  ((ControlModel_P.InertialFF.hzF[0] +
                    ControlModel_P.InertialFF.hzF[1]) +
                   ControlModel_P.InertialFF.hzF[2])) +
    ((ControlModel_P.InertialFF.zeta[0] + ControlModel_P.InertialFF.zeta[1]) +
     ControlModel_P.InertialFF.zeta[2]);
  rtb_y_g_0[8] = (((ControlModel_P.NotchFilter.hzF[0] +
                    ControlModel_P.NotchFilter.hzF[1]) +
                   ControlModel_P.NotchFilter.hzF[2]) +
                  ((ControlModel_P.NotchFilter.w[0] +
                    ControlModel_P.NotchFilter.w[1]) +
                   ControlModel_P.NotchFilter.w[2])) +
    ((ControlModel_P.NotchFilter.d[0] + ControlModel_P.NotchFilter.d[1]) +
     ControlModel_P.NotchFilter.d[2]);
  rtb_y_g_0[9] = ((y + b_y_1) + c_y_0) + d_y;
  rtb_y_g_0[10] = ((ControlModel_P.SensorFilter.hzFVelocityFilter[0] +
                    ControlModel_P.SensorFilter.hzFVelocityFilter[1]) +
                   ControlModel_P.SensorFilter.hzFVelocityFilter[2]) +
    ((ControlModel_P.SensorFilter.zetaVelocityFilter[0] +
      ControlModel_P.SensorFilter.zetaVelocityFilter[1]) +
     ControlModel_P.SensorFilter.zetaVelocityFilter[2]);
  rtb_y_g_0[11] = (((ControlModel_P.TrackControl.pGain[0] +
                     ControlModel_P.TrackControl.pGain[1]) +
                    ControlModel_P.TrackControl.pGain[2]) +
                   ((ControlModel_P.TrackControl.iGain[0] +
                     ControlModel_P.TrackControl.iGain[1]) +
                    ControlModel_P.TrackControl.iGain[2])) +
    ((ControlModel_P.TrackControl.dGain[0] + ControlModel_P.TrackControl.dGain[1])
     + ControlModel_P.TrackControl.dGain[2]);
  rtb_y_g_0[12] = ((ControlModel_P.VelocityControl.pGain[0] +
                    ControlModel_P.VelocityControl.pGain[1]) +
                   ControlModel_P.VelocityControl.pGain[2]) +
    ((ControlModel_P.VelocityControl.iGain[0] +
      ControlModel_P.VelocityControl.iGain[1]) +
     ControlModel_P.VelocityControl.iGain[2]);
  rtb_y_g_0[13] = ((ControlModel_P.Reference.radpsRateLimit[0] +
                    ControlModel_P.Reference.radpsRateLimit[1]) +
                   ControlModel_P.Reference.radpsRateLimit[2]) + b_y_2;
  for (i = 0; i < 14; i++) {
    tmp += rtb_y_g_0[i];
  }

  // Sum: '<S1>/Sum2' incorporates:
  //   DataTypeConversion: '<S1>/Data Type Conversion3'
  //   Inport: '<Root>/Command'
  //   Sum: '<S1>/Sum7'
  //   Sum: '<S4>/Sum'

  rtb_Switch2_n = (tmp + static_cast<real_T>
                   (ControlModel_U.Command.homingComplete)) +
    (ControlModel_U.Command.radScanOffset[0] +
     ControlModel_U.Command.radScanOffset[1]);

  // Outport: '<Root>/Control' incorporates:
  //   DataTypeConversion: '<S1>/Data Type Conversion2'
  //   Switch: '<S1>/Switch'

  ControlModel_Y.Control.mode = static_cast<int8_T>(rtb_Merge2);

  // Outport: '<Root>/Alarm' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment1'
  //   Sum: '<S1>/Sum12'

  ControlModel_Y.Alarm.warningFlag = static_cast<uint16_T>(rtb_Gain);
  ControlModel_Y.Alarm.alarmFlag = 0U;

  // End of Outputs for SubSystem: '<Root>/ControlModel'

  // Outport: '<Root>/DebugLog' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment1'
  //   BusAssignment: '<S1>/Bus Assignment2'
  //   DataTypeConversion: '<S1>/Data Type Conversion2'
  //   Inport: '<Root>/Command'
  //   Inport: '<Root>/Sensor'
  //   Sum: '<S1>/Sum12'
  //   Switch: '<S1>/Switch'

  ControlModel_Y.DebugLog.Command = ControlModel_U.Command;
  ControlModel_Y.DebugLog.Sensor = ControlModel_U.Sensor;

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  ControlModel_Y.DebugLog.Control.mode = static_cast<int8_T>(rtb_Merge2);
  ControlModel_Y.DebugLog.Alarm.warningFlag = static_cast<uint16_T>(rtb_Gain);
  ControlModel_Y.DebugLog.Alarm.alarmFlag = 0U;
  ControlModel_Y.DebugLog.radAngleReference[0] = rtb_Switch2_n;
  ControlModel_Y.DebugLog.radAngleReference[1] = rtb_Switch2_n;
  ControlModel_Y.DebugLog.radAngleReference[2] = rtb_Switch2_n;

  // Outport: '<Root>/Control' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   Inport: '<Root>/Command'

  ControlModel_Y.Control.nmTorque[0] = rtb_Switch_k;
  ControlModel_Y.Control.rpsVelocity[0] =
    ControlModel_U.Command.rpsVelocityLimit[0];
  ControlModel_Y.Control.radRadarReference[0] =
    ControlModel_B.OutportBufferForOut2[0];

  // Outport: '<Root>/DebugLog' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   BusAssignment: '<S1>/Bus Assignment2'
  //   Inport: '<Root>/Command'

  ControlModel_Y.DebugLog.Control.nmTorque[0] = rtb_Switch_k;
  ControlModel_Y.DebugLog.Control.rpsVelocity[0] =
    ControlModel_U.Command.rpsVelocityLimit[0];
  ControlModel_Y.DebugLog.Control.radRadarReference[0] =
    ControlModel_B.OutportBufferForOut2[0];
  ControlModel_Y.DebugLog.rpsVelocityReference[0] = 0.0;
  ControlModel_Y.DebugLog.rpsVelocityFeedback[0] = 0.0;
  ControlModel_Y.DebugLog.nmDisturbance[0] = 0.0;
  ControlModel_Y.DebugLog.estReference[0] = 0.0;

  // End of Outputs for SubSystem: '<Root>/ControlModel'

  // Outport: '<Root>/Control' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   Inport: '<Root>/Command'

  ControlModel_Y.Control.nmTorque[1] = rtb_ImpAsg_InsertedFor_Out1_a_f[1];

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  ControlModel_Y.Control.rpsVelocity[1] =
    ControlModel_U.Command.rpsVelocityLimit[1];
  ControlModel_Y.Control.radRadarReference[1] =
    ControlModel_B.OutportBufferForOut2[1];

  // End of Outputs for SubSystem: '<Root>/ControlModel'

  // Outport: '<Root>/DebugLog' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   BusAssignment: '<S1>/Bus Assignment2'
  //   Inport: '<Root>/Command'
  //   Outport: '<Root>/Control'

  ControlModel_Y.DebugLog.Control.nmTorque[1] = rtb_ImpAsg_InsertedFor_Out1_a_f
    [1];

  // Outputs for Atomic SubSystem: '<Root>/ControlModel'
  ControlModel_Y.DebugLog.Control.rpsVelocity[1] =
    ControlModel_U.Command.rpsVelocityLimit[1];
  ControlModel_Y.DebugLog.Control.radRadarReference[1] =
    ControlModel_B.OutportBufferForOut2[1];
  ControlModel_Y.DebugLog.rpsVelocityReference[1] = 0.0;
  ControlModel_Y.DebugLog.rpsVelocityFeedback[1] = 0.0;
  ControlModel_Y.DebugLog.nmDisturbance[1] = 0.0;
  ControlModel_Y.DebugLog.estReference[1] = 0.0;

  // Outport: '<Root>/Control' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   Inport: '<Root>/Command'

  ControlModel_Y.Control.nmTorque[2] = rtb_Atan1;
  ControlModel_Y.Control.rpsVelocity[2] =
    ControlModel_U.Command.rpsVelocityLimit[2];
  ControlModel_Y.Control.radRadarReference[2] =
    ControlModel_B.OutportBufferForOut2[2];

  // Outport: '<Root>/DebugLog' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   BusAssignment: '<S1>/Bus Assignment2'
  //   Inport: '<Root>/Command'

  ControlModel_Y.DebugLog.Control.nmTorque[2] = rtb_Atan1;
  ControlModel_Y.DebugLog.Control.rpsVelocity[2] =
    ControlModel_U.Command.rpsVelocityLimit[2];
  ControlModel_Y.DebugLog.Control.radRadarReference[2] =
    ControlModel_B.OutportBufferForOut2[2];
  ControlModel_Y.DebugLog.rpsVelocityReference[2] = 0.0;
  ControlModel_Y.DebugLog.rpsVelocityFeedback[2] = 0.0;
  ControlModel_Y.DebugLog.nmDisturbance[2] = 0.0;
  ControlModel_Y.DebugLog.estReference[2] = 0.0;
  memset(&ControlModel_Y.DebugLog.maintenance[0], 0, sizeof(real_T) << 5U);

  // End of Outputs for SubSystem: '<Root>/ControlModel'
}

// Model initialize function
void ControlModelModelClass::initialize()
{
  // Registration code

  // block I/O
  (void) memset((static_cast<void *>(&ControlModel_B)), 0,
                     sizeof(B_ControlModel_T));

  // external inputs
  (void)memset(&ControlModel_U, 0, sizeof(ExtU_ControlModel_T));

  // external outputs
  (void) memset(static_cast<void *>(&ControlModel_Y), 0,
                     sizeof(ExtY_ControlModel_T));
}

// Model terminate function
void ControlModelModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
ControlModelModelClass::ControlModelModelClass() : ControlModel_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
ControlModelModelClass::~ControlModelModelClass()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_ControlModel_T * ControlModelModelClass::getRTM()
{
  return (&ControlModel_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
