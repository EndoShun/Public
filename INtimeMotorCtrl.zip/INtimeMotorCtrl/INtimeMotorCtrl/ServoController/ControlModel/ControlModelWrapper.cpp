#include <stddef.h>
#include <stdio.h>                     // This ert_main.c example uses printf/fflush 
#include <stdint.h>
#include "rtwtypes.h"
#include "IoStructs.h"
#include "ControlModelWrapper.h"
#include "../../MyDebug.h"

ControlModelWrapper::ControlModelWrapper() {
    bfAlarmFlags = 0;
    bfWarningFlags = 0;
}

ControlModelWrapper::~ControlModelWrapper() {

}

int32_t ControlModelWrapper::initControlModel(const ServoParameters* servoParameters) {
    ControlModel_Obj.initialize();

    for (int i = 0; i < AXIS_NUM; i++) {
        ControlModel_Obj.ControlModel_P.All.nmLimit[i] = servoParameters->all.nmToqrueLimit[i];
        ControlModel_Obj.ControlModel_P.All.radpsLimit[i] = servoParameters->all.rpsVelocityLimit[i];
        ControlModel_Obj.ControlModel_P.All.radLimit[i*2] = servoParameters->all.radAngleLimit[i][0];
        ControlModel_Obj.ControlModel_P.All.radLimit[i*2+1] = servoParameters->all.radAngleLimit[i][1];

        ControlModel_Obj.ControlModel_P.Reference.radpsRateLimit[i] = servoParameters->reference.rpsRateLimit[i];
        ControlModel_Obj.ControlModel_P.Reference.radps2RateLimit[i*2] = servoParameters->reference.rps2RateLimit[i][0];
        ControlModel_Obj.ControlModel_P.Reference.radps2RateLimit[i*2+1] = servoParameters->reference.rps2RateLimit[i][1];

        ControlModel_Obj.ControlModel_P.SensorFilter.hzFVelocityFilter[i] = servoParameters->sensor.hzFVelecityFilter[i];
        ControlModel_Obj.ControlModel_P.SensorFilter.zetaVelocityFilter[i] = servoParameters->sensor.zetaVelocityFilter[i];

        ControlModel_Obj.ControlModel_P.VelocityControl.pGain[i] = servoParameters->velocityControl.pGain[i];
        ControlModel_Obj.ControlModel_P.VelocityControl.iGain[i] = servoParameters->velocityControl.iGain[i];

        ControlModel_Obj.ControlModel_P.AngleControl.pGain[i] = servoParameters->angleControl.pGain[i];
        ControlModel_Obj.ControlModel_P.AngleControl.iGain[i] = servoParameters->angleControl.iGain[i];

        ControlModel_Obj.ControlModel_P.TrackControl.pGain[i] = servoParameters->trackControl.pGain[i];
        ControlModel_Obj.ControlModel_P.TrackControl.iGain[i] = servoParameters->trackControl.iGain[i];
        ControlModel_Obj.ControlModel_P.TrackControl.dGain[i] = servoParameters->trackControl.dGain[i];

        ControlModel_Obj.ControlModel_P.NotchFilter.hzF[i] = servoParameters->notch.hzF[i];
        ControlModel_Obj.ControlModel_P.NotchFilter.w[i] = servoParameters->notch.w[i];
        ControlModel_Obj.ControlModel_P.NotchFilter.d[i] = servoParameters->notch.d[i];

        ControlModel_Obj.ControlModel_P.PhaseComp.hzFLag[i*2  ] = servoParameters->phaseComp.hzFLag[i][0];
        ControlModel_Obj.ControlModel_P.PhaseComp.hzFLag[i*2+1] = servoParameters->phaseComp.hzFLag[i][1];
        ControlModel_Obj.ControlModel_P.PhaseComp.aLag[i*2  ] = servoParameters->phaseComp.aLag[i][0];
        ControlModel_Obj.ControlModel_P.PhaseComp.aLag[i*2+1] = servoParameters->phaseComp.aLag[i][1];
        ControlModel_Obj.ControlModel_P.PhaseComp.hzFLead[i*2  ] = servoParameters->phaseComp.hzFLead[i][0];
        ControlModel_Obj.ControlModel_P.PhaseComp.hzFLead[i*2+1] = servoParameters->phaseComp.hzFLead[i][1];
        ControlModel_Obj.ControlModel_P.PhaseComp.aLead[i*2  ] = servoParameters->phaseComp.aLead[i][0];
        ControlModel_Obj.ControlModel_P.PhaseComp.aLead[i*2+1] = servoParameters->phaseComp.aLead[i][1];

        ControlModel_Obj.ControlModel_P.DOB.gain[i] = servoParameters->dob.gain[i];
        ControlModel_Obj.ControlModel_P.DOB.kgm2Inertia[i] = servoParameters->dob.kgm2Inertia[i];
        ControlModel_Obj.ControlModel_P.DOB.hzF[i] = servoParameters->dob.hzF[i];
        ControlModel_Obj.ControlModel_P.DOB.zeta[i] = servoParameters->dob.zeta[i];
        ControlModel_Obj.ControlModel_P.DOB.gainDCDOB[i] = servoParameters->dob.gainDCDOB[i];

        ControlModel_Obj.ControlModel_P.InertialFF.kgm2Inertia[i] = servoParameters->inertialFF.kgm2Inertia[i];
        ControlModel_Obj.ControlModel_P.InertialFF.hzF[i] = servoParameters->inertialFF.hzF[i];
        ControlModel_Obj.ControlModel_P.InertialFF.zeta[i] = servoParameters->inertialFF.zeta[i];

        ControlModel_Obj.ControlModel_P.FrictionFF.mode[i] = servoParameters->frictionFF.mode[i];
        for (int j = 0; j < 6; j++) {
            ControlModel_Obj.ControlModel_P.FrictionFF.nmFc[i*6 + j] = servoParameters->frictionFF.nmFc[i][j];
            ControlModel_Obj.ControlModel_P.FrictionFF.nmFs[i*6 + j] = servoParameters->frictionFF.nmFs[i][j];
        }
        ControlModel_Obj.ControlModel_P.FrictionFF.nmsprViscocity[i] = servoParameters->frictionFF.nmsprViscocity[i];
        for (int j = 0; j < 6; j++) {
            ControlModel_Obj.ControlModel_P.FrictionFF.nmprStiffness[i*6 + j] = servoParameters->frictionFF.nmprStiffness[i][j];
            ControlModel_Obj.ControlModel_P.FrictionFF.attractionParameter[i*6 + j] = servoParameters->frictionFF.attractionParameter[i][j];
            ControlModel_Obj.ControlModel_P.FrictionFF.radpsStribeckVelocity[i*6 + j] = servoParameters->frictionFF.rpsStribeckVelocity[i][j];
        }

        ControlModel_Obj.ControlModel_P.DecoupleFF.gain[i] = servoParameters->decoupleFF.gain[i];
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                ControlModel_Obj.ControlModel_P.DecoupleFF.pseudoInertiaMatrix[i*16 + j*4 + k] = servoParameters->decoupleFF.pseudoInertiaMatrix[i][j][k];
            }
        }
        
        ControlModel_Obj.ControlModel_P.GravityFF.nmTorqueMax[i] = servoParameters->gravityFF.nmTorqueMax[i];
        ControlModel_Obj.ControlModel_P.GravityFF.radPhase[i] = servoParameters->gravityFF.radPhase[i];

        ControlModel_Obj.ControlModel_P.Estimate.Gain[i] = servoParameters->estimate.gain[i];
        ControlModel_Obj.ControlModel_P.Estimate.sTimeSet[i] = servoParameters->estimate.sTimeSet[i];
    }

    return 0;
}


int32_t ControlModelWrapper::calc(const ControlModelInput* controlModelInput, ServoCommand* servoCommand) {
    static boolean_T OverrunFlag = false; if (OverrunFlag) {
        rtmSetErrorStatus(ControlModel_Obj.getRTM(), "Overrun");
        return -1;
    }

    OverrunFlag = true;


    ControlModel_Obj.ControlModel_U.Command.mode = controlModelInput->command.mode;
    ControlModel_Obj.ControlModel_U.Command.homingComplete = controlModelInput->command.homingComplete;
    for (int i = 0; i < AXIS_NUM; i++) {
        ControlModel_Obj.ControlModel_U.Command.radAngle[i] = controlModelInput->command.radAngle[i];
        ControlModel_Obj.ControlModel_U.Command.rpsVelocity[i] = controlModelInput->command.rpsVelocity[i];
        ControlModel_Obj.ControlModel_U.Command.rpsVelocityLimit[i] = controlModelInput->command.rpsVelocityLimit[i];
    }
    for (int i = 0; i < 2; i++) {
        ControlModel_Obj.ControlModel_U.Command.radScanOffset[i] = controlModelInput->command.radScanOffset[i];
    }

    for (int i = 0; i < AXIS_NUM; i++) {
        ControlModel_Obj.ControlModel_U.Sensor.radAngle[i] = controlModelInput->sensor.radAngle[i];
        ControlModel_Obj.ControlModel_U.Sensor.rpsVelocity[i] = controlModelInput->sensor.rpsVelocity[i];
    }
    for (int i = 0; i < 2; i++) {
        ControlModel_Obj.ControlModel_U.Sensor.radVisionAngleError[i] = controlModelInput->sensor.radVisionAngleError[i];
    }
    ControlModel_Obj.ControlModel_U.Sensor.updateVision = controlModelInput->sensor.visionUpdateFlag;
    ControlModel_Obj.ControlModel_U.Sensor.validVision = controlModelInput->sensor.validVision;
    for (int i = 0; i < 3; i++) {
        ControlModel_Obj.ControlModel_U.Sensor.mPositionRadar[i] = controlModelInput->sensor.mPositionRadar[i];
        ControlModel_Obj.ControlModel_U.Sensor.mpsVelocityRadar[i] = controlModelInput->sensor.mpsVelocityRadar[i];
    }



    ControlModel_Obj.step();


    servoCommand->control.mode = ControlModel_Obj.ControlModel_Y.Control.mode;
    for (int i = 0; i < AXIS_NUM; i++) {
        servoCommand->control.nmTorque[i] = ControlModel_Obj.ControlModel_Y.Control.nmTorque[i];
        servoCommand->control.rpsVelocity[i] = ControlModel_Obj.ControlModel_Y.Control.rpsVelocity[i];
        servoCommand->control.radRadarReference[i] = ControlModel_Obj.ControlModel_Y.Control.radRadarReference[i];
    }
    servoCommand->alarm.bfWarningFlag = ControlModel_Obj.ControlModel_Y.Alarm.warningFlag;
    servoCommand->alarm.bfAlarmFlag = ControlModel_Obj.ControlModel_Y.Alarm.alarmFlag;

    servoCommand->control.servoOnCommand = controlModelInput->command.servoOnCommand;

    OverrunFlag = false;

    return 0;
}

uint16_t ControlModelWrapper::getBfAlarmFlags() {
    return bfAlarmFlags;
}

uint16_t ControlModelWrapper::getBfWarningFlags() {
    return bfWarningFlags;
}