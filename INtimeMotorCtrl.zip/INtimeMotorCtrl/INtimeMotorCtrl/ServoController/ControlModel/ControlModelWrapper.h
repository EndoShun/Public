#pragma once
#include "IoStructs.h"
#include "ControlModel.h"              // Model's header file

#ifdef __cplusplus
extern "C" {
#endif

	class ControlModelWrapper {
	private:
		ControlModelModelClass ControlModel_Obj;// Instance of model class
		uint16_t bfAlarmFlags;
		uint16_t bfWarningFlags;
	public:
		ControlModelWrapper();
		~ControlModelWrapper();
		int initControlModel(const ServoParameters* servoParameters);
		int calc(const ControlModelInput* controlModelInput, ServoCommand* servoCommand);
		uint16_t getBfWarningFlags();
		uint16_t getBfAlarmFlags();
		
	};

#ifdef __cplusplus
}
#endif
