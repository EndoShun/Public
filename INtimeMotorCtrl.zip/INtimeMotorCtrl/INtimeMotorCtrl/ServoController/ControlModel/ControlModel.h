//
// File: ControlModel.h
//
// Code generated for Simulink model 'ControlModel'.
//
// Model version                  : 1.120
// Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
// C/C++ source code generated on : Tue Mar 14 21:46:48 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_ControlModel_h_
#define RTW_HEADER_ControlModel_h_
#include <cmath>
#include <cstring>
#include <math.h>
#ifndef ControlModel_COMMON_INCLUDES_
# define ControlModel_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 // ControlModel_COMMON_INCLUDES_

#include "ControlModel_types.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

// Block signals (default storage)
typedef struct {
  real_T OutportBufferForOut2[3];
} B_ControlModel_T;

// External inputs (root inport signals with default storage)
typedef struct {
  ioBusCommand Command;                // '<Root>/Command'
  ioBusSensor Sensor;                  // '<Root>/Sensor'
} ExtU_ControlModel_T;

// External outputs (root outports fed by signals with default storage)
typedef struct {
  ioBusControl Control;                // '<Root>/Control'
  ioBusAlarm Alarm;                    // '<Root>/Alarm'
  ioBusDebugLog DebugLog;              // '<Root>/DebugLog'
} ExtY_ControlModel_T;

// Parameters (default storage)
struct P_ControlModel_T_ {
  paramBusFrictionFF FrictionFF;       // Variable: FrictionFF
                                          //  Referenced by: '<S4>/Constant9'

  paramBusDecoupleFF DecoupleFF;       // Variable: DecoupleFF
                                          //  Referenced by: '<S4>/Constant3'

  paramBusPhaseComp PhaseComp;         // Variable: PhaseComp
                                          //  Referenced by: '<S4>/Constant13'

  paramBusDOB DOB;                     // Variable: DOB
                                          //  Referenced by: '<S4>/Constant7'

  paramBusAll All;                     // Variable: All
                                          //  Referenced by:
                                          //    '<S3>/Constant4'
                                          //    '<S4>/Constant4'
                                          //    '<S39>/Constant4'

  paramBusTrackControl TrackControl;   // Variable: TrackControl
                                          //  Referenced by:
                                          //    '<S4>/Constant15'
                                          //    '<S33>/Constant4'

  paramBusNotchFilter NotchFilter;     // Variable: NotchFilter
                                          //  Referenced by: '<S4>/Constant12'

  paramBusReference Reference;         // Variable: Reference
                                          //  Referenced by: '<S4>/Constant1'

  paramBusInertialFF InertialFF;       // Variable: InertialFF
                                          //  Referenced by: '<S4>/Constant11'

  paramBusVelocityControl AngleControl;// Variable: AngleControl
                                          //  Referenced by:
                                          //    '<S4>/Constant6'
                                          //    '<S32>/Constant4'
                                          //    '<S34>/Constant4'

  paramBusVelocityControl VelocityControl;// Variable: VelocityControl
                                             //  Referenced by:
                                             //    '<S4>/Constant16'
                                             //    '<S31>/Constant4'

  paramBusGravityFF GravityFF;         // Variable: GravityFF
                                          //  Referenced by: '<S4>/Constant10'

  paramBusSensorFilter SensorFilter;   // Variable: SensorFilter
                                          //  Referenced by: '<S4>/Constant14'

  paramBusEstimate Estimate;           // Variable: Estimate
                                          //  Referenced by: '<S4>/Constant8'

};

// Real-time Model Data Structure
struct tag_RTM_ControlModel_T {
  const char_T * volatile errorStatus;
};

// Class declaration for model ControlModel
class ControlModelModelClass {
  // public data and function members
 public:
  // External inputs
  ExtU_ControlModel_T ControlModel_U;

  // External outputs
  ExtY_ControlModel_T ControlModel_Y;

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  ControlModelModelClass();

  // Destructor
  ~ControlModelModelClass();

  // Real-Time Model get method
  RT_MODEL_ControlModel_T * getRTM();

  // Tunable parameters
  static P_ControlModel_T ControlModel_P;

  // private data and function members
 private:

  // Block signals
  B_ControlModel_T ControlModel_B;

  // Real-Time Model
  RT_MODEL_ControlModel_T ControlModel_M;

  // private member function(s) for subsystem '<S8>/For Each Subsystem'
  void ControlModel_ForEachSubsystem(int32_T NumIters, const real_T rtu_Input[3],
    const real_T rtu_Input1[3], real_T rty_Out1[3], P_ControlModel_T
    *ControlModel_P);

  // private member function(s) for subsystem '<S10>/Switch Case Action Subsystem1'
  void Cont_SwitchCaseActionSubsystem1(const real_T rtu_In1[3], uint8_T rtu_In2,
    const real_T rtu_In3[3], real_T rty_Out1[3]);

  // private member function(s) for subsystem '<Root>'
  void C_reshapeRowMajorDataColumnWise(const real_T tmp[6], const int32_T *tmp_0,
    real_T tmp_1[6]);
  void reshapeRowMajorDataColumnWise_j(const real_T tmp[48], const int32_T
    *tmp_0, real_T tmp_1[48]);
  void reshapeRowMajorDataColumnWis_jp(const real_T tmp[18], const int32_T
    *tmp_0, real_T tmp_1[18]);
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S14>/Data Type Duplicate' : Unused code path elimination
//  Block '<S14>/Data Type Propagation' : Unused code path elimination
//  Block '<S15>/Data Type Duplicate' : Unused code path elimination
//  Block '<S15>/Data Type Propagation' : Unused code path elimination
//  Block '<S16>/Data Type Duplicate' : Unused code path elimination
//  Block '<S16>/Data Type Propagation' : Unused code path elimination
//  Block '<S1>/Bitwise Operator' : Unused code path elimination
//  Block '<S1>/Display' : Unused code path elimination
//  Block '<S1>/Display1' : Unused code path elimination
//  Block '<S1>/Display2' : Unused code path elimination
//  Block '<S1>/Display3' : Unused code path elimination
//  Block '<S1>/Relational Operator' : Unused code path elimination
//  Block '<S1>/Scope' : Unused code path elimination
//  Block '<S1>/Scope2' : Unused code path elimination
//  Block '<S40>/Data Type Duplicate' : Unused code path elimination
//  Block '<S40>/Data Type Propagation' : Unused code path elimination
//  Block '<S1>/Data Type Conversion7' : Eliminate redundant data type conversion
//  Block '<S1>/Data Type Conversion8' : Eliminate redundant data type conversion


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Note that this particular code originates from a subsystem build,
//  and has its own system numbers different from the parent model.
//  Refer to the system hierarchy for this subsystem below, and use the
//  MATLAB hilite_system command to trace the generated code back
//  to the parent model.  For example,
//
//  hilite_system('SampleModel/ControlModel')    - opens subsystem SampleModel/ControlModel
//  hilite_system('SampleModel/ControlModel/Kp') - opens and selects block Kp
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'SampleModel'
//  '<S1>'   : 'SampleModel/ControlModel'
//  '<S2>'   : 'SampleModel/ControlModel/AngleTorqueLimiter'
//  '<S3>'   : 'SampleModel/ControlModel/For Each Subsystem1'
//  '<S4>'   : 'SampleModel/ControlModel/Subsystem'
//  '<S5>'   : 'SampleModel/ControlModel/Switch Case Action Subsystem'
//  '<S6>'   : 'SampleModel/ControlModel/Switch Case Action Subsystem1'
//  '<S7>'   : 'SampleModel/ControlModel/Switch Case Action Subsystem2'
//  '<S8>'   : 'SampleModel/ControlModel/Switch Case Action Subsystem3'
//  '<S9>'   : 'SampleModel/ControlModel/Switch Case Action Subsystem4'
//  '<S10>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5'
//  '<S11>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem6'
//  '<S12>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem7'
//  '<S13>'  : 'SampleModel/ControlModel/VelLimiter'
//  '<S14>'  : 'SampleModel/ControlModel/AngleTorqueLimiter/Saturation Dynamic'
//  '<S15>'  : 'SampleModel/ControlModel/AngleTorqueLimiter/Saturation Dynamic1'
//  '<S16>'  : 'SampleModel/ControlModel/AngleTorqueLimiter/Saturation Dynamic2'
//  '<S17>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function'
//  '<S18>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function1'
//  '<S19>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function10'
//  '<S20>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function11'
//  '<S21>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function12'
//  '<S22>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function13'
//  '<S23>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function2'
//  '<S24>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function3'
//  '<S25>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function4'
//  '<S26>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function5'
//  '<S27>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function6'
//  '<S28>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function7'
//  '<S29>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function8'
//  '<S30>'  : 'SampleModel/ControlModel/Subsystem/MATLAB Function9'
//  '<S31>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem/For Each Subsystem'
//  '<S32>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem3/For Each Subsystem'
//  '<S33>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5/For Each Subsystem'
//  '<S34>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5/For Each Subsystem1'
//  '<S35>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5/Switch Case Action Subsystem1'
//  '<S36>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5/Switch Case Action Subsystem2'
//  '<S37>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5/Switch Case Action Subsystem3'
//  '<S38>'  : 'SampleModel/ControlModel/Switch Case Action Subsystem5/Switch Case Action Subsystem4'
//  '<S39>'  : 'SampleModel/ControlModel/VelLimiter/For Each Subsystem'
//  '<S40>'  : 'SampleModel/ControlModel/VelLimiter/For Each Subsystem/Saturation Dynamic'

#endif                                 // RTW_HEADER_ControlModel_h_

//
// File trailer for generated code.
//
// [EOF]
//
