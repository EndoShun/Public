//
// File: DummyModel_types.h
//
// Code generated for Simulink model 'DummyModel'.
//
// Model version                  : 1.88
// Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
// C/C++ source code generated on : Mon Jan 16 00:56:25 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_DummyModel_types_h_
#define RTW_HEADER_DummyModel_types_h_
#include "../ControlModel/rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_ioBusControl_
#define DEFINED_TYPEDEF_FOR_ioBusControl_

typedef struct {
  int8_T mode;
  real_T nmTorque[3];
  real_T rpsVelocity[3];
} ioBusControl;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ioBusSensor_
#define DEFINED_TYPEDEF_FOR_ioBusSensor_

typedef struct {
  real_T radAngle[3];
  real_T rpsVelocity[3];
  real_T radVisionAngleError[2];
  real_T updateVision;
  real_T mPositionRader[3];
  real_T mpsVelocityRader[3];
} ioBusSensor;

#endif

// Forward declaration for rtModel
typedef struct tag_RTM_DummyModel_T RT_MODEL_DummyModel_T;

#endif                                 // RTW_HEADER_DummyModel_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
