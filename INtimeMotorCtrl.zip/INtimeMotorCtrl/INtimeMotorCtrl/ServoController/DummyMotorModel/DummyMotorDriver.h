#pragma once

#define __STDC_LIMIT_MACROS

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/
#include "ymcSMTAPI.h"
#ifdef __cplusplus
}
#endif /*__cplusplus*/

#include "IoStructs.h"
#include "math.h"
#include "stdint.h"
#include "DummyModel.h"
#include "rt.h"
#include "../ServoErrors.h"

class DummyMotorDriver{
public:
	enum class State {
		OFF_NO_ORIGIN,	//����������A���_���F��
		OFF,			//�R�}���h�ɂ��OFF�A���_�F����
		TURNING_OFF,
		ON,
		TURNING_ON,
		ERROR
	};

private:
	DummyModelModelClass DummyModel_Obj;
	ServoStatus servoInternalStatus;
	TeleCamLensStatus lensInternalStatus;
	TilServoStatus tilServoInternalStatus;
	FineMirrorStatus fineMirrorInternalStatus;
public:
	State servoState;
	int32_t cyclesSearchZeroTimeout;

	DummyMotorDriver();
	~DummyMotorDriver();

	DWORD waitCycle();
	DWORD init(ServoErrors::MotorInitSequence& sequenceMarker);

	DWORD servoStop();
	DWORD servoSearchZero(const double nmTorqueLimits[AXIS_NUM]);
	DWORD servoSearchZero();
	int32_t isServoSearchZeroComplete();
	DWORD servoPositionControl(const double radPositions[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM], const double nmTorqueLimits[AXIS_NUM]);
	DWORD servoVelocityControl(const double rpsVelocities[AXIS_NUM], const double nmTorqueLimits[AXIS_NUM]);
	DWORD servoTorqueControl(const double nmTorques[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM]);

	DWORD servoEnable(int32_t on[AXIS_NUM]);
	DWORD servoEnable(int32_t on);

	//DWORD setTeleCamPos(double xZoomLevel, double mFocus);

	//DWORD setTilFocus(double mFocus);
	//DWORD setHelDivergence(double radDivergence);

	void setXTeleCamZoom(double xZoom);
	void setMTeleCamFocus(double mFocus);
	void setMHelFocus(double mFocus);
	void setTeleCamIris(double iris);
	void setRadTilDivergence(double radTilDivergence);
	double getXTeleCamZoom();
	double getMTeleCamFocus();
	double getMHelFocus();
	double getTeleCamIris();
	double getRadTilDivergence();

	int32_t readServoStatus(ServoStatus& servoStatus, FineMirrorStatus& fineMirrorStatus, TeleCamLensStatus& lensStatus, TilServoStatus& tilServoStatus);

	int32_t isRetracted(const ServoStatus& servoStatus);

	DWORD setDACValue(double axis0, double axis1, double axis2, double axis3);
};
