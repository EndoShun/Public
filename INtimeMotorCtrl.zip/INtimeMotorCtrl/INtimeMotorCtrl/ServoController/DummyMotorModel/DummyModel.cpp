//
// File: DummyModel.cpp
//
// Code generated for Simulink model 'DummyModel'.
//
// Model version                  : 1.88
// Simulink Coder version         : 9.2 (R2019b) 18-Jul-2019
// C/C++ source code generated on : Mon Jan 16 00:56:25 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "DummyModel.h"
#include "DummyModel_private.h"

const ioBusSensor DummyModel_rtZioBusSensor = {
  {
    0.0, 0.0, 0.0 }
  ,                                    // radAngle

  {
    0.0, 0.0, 0.0 }
  ,                                    // rpsVelocity

  {
    0.0, 0.0 }
  ,                                    // radVisionAngleError
  0.0,                                 // updateVision

  {
    0.0, 0.0, 0.0 }
  ,                                    // mPositionRader

  {
    0.0, 0.0, 0.0 }
  // mpsVelocityRader
} ;                                    // ioBusSensor ground

const ioBusControl DummyModel_rtZioBusControl = { 0,// mode
  { 0.0, 0.0, 0.0 },                   // nmTorque
  { 0.0, 0.0, 0.0 }                    // rpsVelocity
};

// Model step function
void DummyModelModelClass::step()
{
  boolean_T rtb_Compare;
  real_T DiscreteTimeIntegrator1;
  real_T DiscreteTimeIntegrator;
  real_T rtb_Switch;

  // Outputs for Atomic SubSystem: '<Root>/DummyModel'
  // RelationalOperator: '<S2>/Compare' incorporates:
  //   Constant: '<S2>/Constant'
  //   Inport: '<Root>/Control'

  rtb_Compare = (DummyModel_U.Control.mode == 1);

  // Switch: '<S1>/Switch' incorporates:
  //   Inport: '<Root>/Control'

  if (rtb_Compare) {
    rtb_Switch = DummyModel_U.Control.nmTorque[0];
  } else {
    rtb_Switch = 0.0;
  }

  // Outputs for Iterator SubSystem: '<S1>/For Each Subsystem' incorporates:
  //   ForEach: '<S3>/For Each'

  // DiscreteIntegrator: '<S3>/Discrete-Time Integrator' incorporates:
  //   Outport: '<Root>/Sensor'

  DiscreteTimeIntegrator = 0.0005 * rtb_Switch + DummyModel_DW.CoreSubsys[0].
    DiscreteTimeIntegrator_DSTATE;

  // DiscreteIntegrator: '<S3>/Discrete-Time Integrator1' incorporates:
  //   Outport: '<Root>/Sensor'

  DiscreteTimeIntegrator1 = 0.0005 * DiscreteTimeIntegrator +
    DummyModel_DW.CoreSubsys[0].DiscreteTimeIntegrator1_DSTATE;

  // Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator' incorporates:
  //   Outport: '<Root>/Sensor'

  DummyModel_DW.CoreSubsys[0].DiscreteTimeIntegrator_DSTATE = 0.0005 *
    rtb_Switch + DiscreteTimeIntegrator;

  // Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator1' incorporates:
  //   Outport: '<Root>/Sensor'

  DummyModel_DW.CoreSubsys[0].DiscreteTimeIntegrator1_DSTATE = 0.0005 *
    DiscreteTimeIntegrator + DiscreteTimeIntegrator1;

  // Outport: '<Root>/Sensor' incorporates:
  //   ForEachSliceAssignment generated from: '<S3>/Out1'
  //   ForEachSliceAssignment generated from: '<S3>/Out2'

  DummyModel_Y.Sensor.radAngle[0] = DiscreteTimeIntegrator1;
  DummyModel_Y.Sensor.rpsVelocity[0] = DiscreteTimeIntegrator;

  // End of Outputs for SubSystem: '<S1>/For Each Subsystem'

  // Switch: '<S1>/Switch' incorporates:
  //   Inport: '<Root>/Control'

  if (rtb_Compare) {
    rtb_Switch = DummyModel_U.Control.nmTorque[1];
  } else {
    rtb_Switch = 0.0;
  }

  // Outputs for Iterator SubSystem: '<S1>/For Each Subsystem' incorporates:
  //   ForEach: '<S3>/For Each'

  // DiscreteIntegrator: '<S3>/Discrete-Time Integrator' incorporates:
  //   Outport: '<Root>/Sensor'

  DiscreteTimeIntegrator = 0.0005 * rtb_Switch + DummyModel_DW.CoreSubsys[1].
    DiscreteTimeIntegrator_DSTATE;

  // DiscreteIntegrator: '<S3>/Discrete-Time Integrator1' incorporates:
  //   Outport: '<Root>/Sensor'

  DiscreteTimeIntegrator1 = 0.0005 * DiscreteTimeIntegrator +
    DummyModel_DW.CoreSubsys[1].DiscreteTimeIntegrator1_DSTATE;

  // Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator' incorporates:
  //   Outport: '<Root>/Sensor'

  DummyModel_DW.CoreSubsys[1].DiscreteTimeIntegrator_DSTATE = 0.0005 *
    rtb_Switch + DiscreteTimeIntegrator;

  // Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator1' incorporates:
  //   Outport: '<Root>/Sensor'

  DummyModel_DW.CoreSubsys[1].DiscreteTimeIntegrator1_DSTATE = 0.0005 *
    DiscreteTimeIntegrator + DiscreteTimeIntegrator1;

  // Outport: '<Root>/Sensor' incorporates:
  //   ForEachSliceAssignment generated from: '<S3>/Out1'
  //   ForEachSliceAssignment generated from: '<S3>/Out2'

  DummyModel_Y.Sensor.radAngle[1] = DiscreteTimeIntegrator1;
  DummyModel_Y.Sensor.rpsVelocity[1] = DiscreteTimeIntegrator;

  // End of Outputs for SubSystem: '<S1>/For Each Subsystem'

  // Switch: '<S1>/Switch' incorporates:
  //   Inport: '<Root>/Control'

  if (rtb_Compare) {
    rtb_Switch = DummyModel_U.Control.nmTorque[2];
  } else {
    rtb_Switch = 0.0;
  }

  // Outputs for Iterator SubSystem: '<S1>/For Each Subsystem' incorporates:
  //   ForEach: '<S3>/For Each'

  // DiscreteIntegrator: '<S3>/Discrete-Time Integrator' incorporates:
  //   Outport: '<Root>/Sensor'

  DiscreteTimeIntegrator = 0.0005 * rtb_Switch + DummyModel_DW.CoreSubsys[2].
    DiscreteTimeIntegrator_DSTATE;

  // DiscreteIntegrator: '<S3>/Discrete-Time Integrator1' incorporates:
  //   Outport: '<Root>/Sensor'

  DiscreteTimeIntegrator1 = 0.0005 * DiscreteTimeIntegrator +
    DummyModel_DW.CoreSubsys[2].DiscreteTimeIntegrator1_DSTATE;

  // Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator' incorporates:
  //   Outport: '<Root>/Sensor'

  DummyModel_DW.CoreSubsys[2].DiscreteTimeIntegrator_DSTATE = 0.0005 *
    rtb_Switch + DiscreteTimeIntegrator;

  // Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator1' incorporates:
  //   Outport: '<Root>/Sensor'

  DummyModel_DW.CoreSubsys[2].DiscreteTimeIntegrator1_DSTATE = 0.0005 *
    DiscreteTimeIntegrator + DiscreteTimeIntegrator1;

  // Outport: '<Root>/Sensor' incorporates:
  //   BusAssignment: '<S1>/Bus Assignment'
  //   ForEachSliceAssignment generated from: '<S3>/Out1'
  //   ForEachSliceAssignment generated from: '<S3>/Out2'

  DummyModel_Y.Sensor.radAngle[2] = DiscreteTimeIntegrator1;
  DummyModel_Y.Sensor.rpsVelocity[2] = DiscreteTimeIntegrator;

  // End of Outputs for SubSystem: '<S1>/For Each Subsystem'
  DummyModel_Y.Sensor.radVisionAngleError[0] = 0.0;
  DummyModel_Y.Sensor.radVisionAngleError[1] = 0.0;
  DummyModel_Y.Sensor.updateVision = 0.0;
  DummyModel_Y.Sensor.mPositionRader[0] = 0.0;
  DummyModel_Y.Sensor.mpsVelocityRader[0] = 0.0;
  DummyModel_Y.Sensor.mPositionRader[1] = 0.0;
  DummyModel_Y.Sensor.mpsVelocityRader[1] = 0.0;
  DummyModel_Y.Sensor.mPositionRader[2] = 0.0;
  DummyModel_Y.Sensor.mpsVelocityRader[2] = 0.0;

  // End of Outputs for SubSystem: '<Root>/DummyModel'
}

// Model initialize function
void DummyModelModelClass::initialize()
{
  // Registration code

  // states (dwork)
  (void) memset(static_cast<void *>(&DummyModel_DW), 0,
                     sizeof(DW_DummyModel_T));

  // external inputs
  DummyModel_U.Control = DummyModel_rtZioBusControl;

  // external outputs
  DummyModel_Y.Sensor = DummyModel_rtZioBusSensor;

  // Start for Atomic SubSystem: '<Root>/DummyModel'
  // Start for Iterator SubSystem: '<S1>/For Each Subsystem'
  DummyModel_DW.CoreSubsys[0].DiscreteTimeIntegrator_DSTATE = 0.0;
  DummyModel_DW.CoreSubsys[0].DiscreteTimeIntegrator1_DSTATE = 0.0;
  DummyModel_DW.CoreSubsys[1].DiscreteTimeIntegrator_DSTATE = 0.0;
  DummyModel_DW.CoreSubsys[1].DiscreteTimeIntegrator1_DSTATE = 0.0;
  DummyModel_DW.CoreSubsys[2].DiscreteTimeIntegrator_DSTATE = 0.0;
  DummyModel_DW.CoreSubsys[2].DiscreteTimeIntegrator1_DSTATE = 0.0;

  // End of Start for SubSystem: '<S1>/For Each Subsystem'
  // End of Start for SubSystem: '<Root>/DummyModel'
}

// Model terminate function
void DummyModelModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
DummyModelModelClass::DummyModelModelClass() : DummyModel_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
DummyModelModelClass::~DummyModelModelClass()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_DummyModel_T * DummyModelModelClass::getRTM()
{
  return (&DummyModel_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
