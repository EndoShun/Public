
#include "DummyMotorDriver.h"
#include "../../INtimeMotorCtrl.h"
#include "../ServoController.h"
#include "stdio.h"

DummyMotorDriver::DummyMotorDriver() {
	servoState = State::OFF_NO_ORIGIN;
	cyclesSearchZeroTimeout = 0;
	DummyModel_Obj.initialize();

	for (int i = 0; i < AXIS_NUM; i++) {
		servoInternalStatus.radCoarsePos[i] = DummyModel_Obj.DummyModel_Y.Sensor.radAngle[i];
		servoInternalStatus.rpsCoarseSpeed[i] = DummyModel_Obj.DummyModel_Y.Sensor.rpsVelocity[i];
		servoInternalStatus.coarseStatus[i] = 0;
		servoInternalStatus.coarseParamErrorNo[i] = 0;
		servoInternalStatus.coarseWarning[i] = 0;
		servoInternalStatus.coarseAlarm[i] = 0;
		servoInternalStatus.coarseDriverAlarmCode[i] = 0;
		servoInternalStatus.homingComplete = 0;
	}
	
	lensInternalStatus.xTeleCamZoom = 1.0;
	lensInternalStatus.mTeleCamFocus = 1200.0;
	lensInternalStatus.teleCamIris = 1.0;
	lensInternalStatus.mHelFocus = 1200.0;
	for (int i = 0; i < NUM_TELE_LENS_AXIS; i++) {
		lensInternalStatus.bfErrorStatus[i] = 0;
		lensInternalStatus.alarmCode[i] = 0;
		lensInternalStatus.warningCode[i] = 0;
	}
	lensInternalStatus.rs485ConverterAlarmCode = 0;
	lensInternalStatus.rs485ConverterWarningCode = 0;
	tilServoInternalStatus.radTilDivergence = 1200.0;
	tilServoInternalStatus.alarmCode = 0;
	fineMirrorInternalStatus.alarmCode = 0;
	fineMirrorInternalStatus.warningCode = 0;
}
DummyMotorDriver::~DummyMotorDriver() {
	DummyModel_Obj.terminate();
}

DWORD DummyMotorDriver::waitCycle() {
	knRtSleep(UsecsToKticks(1000));
	return MP_SUCCESS;
}

DWORD DummyMotorDriver::init(ServoErrors::MotorInitSequence& sequenceMarker) {
	sequenceMarker = ServoErrors::MotorInitSequence::OK;
	DummyModel_Obj.initialize();
	return 0;
}

DWORD DummyMotorDriver::servoStop() {
	DummyModel_Obj.DummyModel_U.Control.mode = 0;
	for (int i = 0; i < AXIS_NUM; i++) {
		DummyModel_Obj.DummyModel_U.Control.nmTorque[i] = 0;
		DummyModel_Obj.DummyModel_U.Control.rpsVelocity[i] = 0;
	}

	DummyModel_Obj.step();

	for (int i = 0; i < AXIS_NUM; i++) {
		servoInternalStatus.radCoarsePos[i] = DummyModel_Obj.DummyModel_Y.Sensor.radAngle[i];
		servoInternalStatus.rpsCoarseSpeed[i] = DummyModel_Obj.DummyModel_Y.Sensor.rpsVelocity[i];
	}
	
	return 0;
}

DWORD DummyMotorDriver::servoSearchZero(const double nmTorqueLimits[AXIS_NUM]) {
	DummyModel_Obj.DummyModel_U.Control.mode = 30;
	for (int i = 0; i < AXIS_NUM; i++) {
		DummyModel_Obj.DummyModel_U.Control.nmTorque[i] = 0;
		DummyModel_Obj.DummyModel_U.Control.rpsVelocity[i] = 0;
	}

	DummyModel_Obj.step();

	for (int i = 0; i < AXIS_NUM; i++) {
		servoInternalStatus.radCoarsePos[i] = DummyModel_Obj.DummyModel_Y.Sensor.radAngle[i];
		servoInternalStatus.rpsCoarseSpeed[i] = DummyModel_Obj.DummyModel_Y.Sensor.rpsVelocity[i];
	}

	return 0;
}

DWORD DummyMotorDriver::servoSearchZero() {
	double nmTorqueLimits[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		nmTorqueLimits[i] = 0.0;
	}

	return servoSearchZero(nmTorqueLimits);
}

int32_t DummyMotorDriver::isServoSearchZeroComplete() {
	DummyModel_Obj.DummyModel_U.Control.mode = 0;
	for (int i = 0; i < AXIS_NUM; i++) {
		DummyModel_Obj.DummyModel_U.Control.nmTorque[i] = 0;
		DummyModel_Obj.DummyModel_U.Control.rpsVelocity[i] = 0;
	}

	DummyModel_Obj.step();


	bool complete = true;
	for (int i = 0; i < AXIS_NUM; i++) {
		servoInternalStatus.radCoarsePos[i] = DummyModel_Obj.DummyModel_Y.Sensor.radAngle[i];
		servoInternalStatus.rpsCoarseSpeed[i] = DummyModel_Obj.DummyModel_Y.Sensor.rpsVelocity[i];

		if (servoInternalStatus.radCoarsePos[i] < -ServoController::RAD_SEARCH_ZERO_COMPLETE_MARGIN || ServoController::RAD_SEARCH_ZERO_COMPLETE_MARGIN < servoInternalStatus.radCoarsePos[i]) {
			complete = false;
		}
		if (servoInternalStatus.rpsCoarseSpeed[i] < -ServoController::RPS_SEARCH_ZERO_COMPLETE_MARGIN || ServoController::RPS_SEARCH_ZERO_COMPLETE_MARGIN < servoInternalStatus.rpsCoarseSpeed[i]) {
			complete = false;
		}
	}
	servoInternalStatus.homingComplete = 1;

	return complete;
}

DWORD DummyMotorDriver::servoTorqueControl(const double nmTorques[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM]) {
	DummyModel_Obj.DummyModel_U.Control.mode = 1;
	for (int i = 0; i < AXIS_NUM; i++) {
		DummyModel_Obj.DummyModel_U.Control.nmTorque[i] = nmTorques[i];
		DummyModel_Obj.DummyModel_U.Control.rpsVelocity[i] = 10000;
	}

	DummyModel_Obj.step();

	for (int i = 0; i < AXIS_NUM; i++) {
		servoInternalStatus.radCoarsePos[i] = DummyModel_Obj.DummyModel_Y.Sensor.radAngle[i];
		servoInternalStatus.rpsCoarseSpeed[i] = DummyModel_Obj.DummyModel_Y.Sensor.rpsVelocity[i];
	}

	return 0;
}

int32_t DummyMotorDriver::readServoStatus(ServoStatus& servoStatus, FineMirrorStatus& fineMirrorStatus, TeleCamLensStatus& lensStatus, TilServoStatus& tilServoStatus) {
	servoStatus = servoInternalStatus;
	lensStatus = lensInternalStatus;
	fineMirrorStatus = fineMirrorInternalStatus;
	tilServoStatus = tilServoInternalStatus;
	return 0;
}

DWORD DummyMotorDriver::servoEnable(int32_t on[AXIS_NUM]) {
	//No function
	return 0;
}
DWORD DummyMotorDriver::servoEnable(int32_t on) {
	//No function
	return 0;
}

int32_t DummyMotorDriver::isRetracted(const ServoStatus& servoStatus) {
	double radPosError[AXIS_NUM];
	for (int i = 0; i < AXIS_NUM; i++) {
		radPosError[i] = ServoController::RAD_RETRACT_POS[i] - servoStatus.radCoarsePos[i];
	}

	bool complete = true;
	for (int i = 0; i < AXIS_NUM; i++) {
		if (radPosError[i] < -ServoController::RAD_RETRACT_COMPLETE_MARGIN || ServoController::RAD_RETRACT_COMPLETE_MARGIN < radPosError[i]) {
			complete = false;
		}

		if (servoStatus.rpsCoarseSpeed[i] < -ServoController::RPS_RETRACT_COMPLETE_MARGIN || ServoController::RPS_RETRACT_COMPLETE_MARGIN < servoStatus.rpsCoarseSpeed[i]) {
			complete = false;
		}
	}

	return complete;
}

DWORD DummyMotorDriver::servoPositionControl(const double radPositions[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM], const double nmTorqueLimits[AXIS_NUM]) {
	//not supported.
	return MP_SUCCESS;
}
DWORD DummyMotorDriver::servoVelocityControl(const double rpsVelocities[AXIS_NUM], const double nmTorqueLimits[AXIS_NUM]) {
	//not supported.
	return MP_SUCCESS;
}

DWORD DummyMotorDriver::setDACValue(double axis0, double axis1, double axis2, double axis3) {
	//not supported.
	return MP_SUCCESS;
}

void DummyMotorDriver::setXTeleCamZoom(double xZoom) {
	if (xZoom < ServoController::X_TELECAM_ZOOM_MIN) {
		xZoom = ServoController::X_TELECAM_ZOOM_MIN;
	}
	else if (xZoom > ServoController::X_TELECAM_ZOOM_MAX) {
		xZoom = ServoController::X_TELECAM_ZOOM_MAX;
	}

	lensInternalStatus.xTeleCamZoom = xZoom;
	lensInternalStatus.radTeleCamFov = ServoController::RAD_VFOV_AT_X1/xZoom;
}
void DummyMotorDriver::setMTeleCamFocus(double mFocus) {
	lensInternalStatus.mTeleCamFocus = mFocus;
}
void DummyMotorDriver::setMHelFocus(double mFocus) {
	lensInternalStatus.mHelFocus = mFocus;
}
void DummyMotorDriver::setTeleCamIris(double iris) {
	lensInternalStatus.teleCamIris = iris;
}
void DummyMotorDriver::setRadTilDivergence(double radTilDivergence) {
	tilServoInternalStatus.radTilDivergence = radTilDivergence;
}
double DummyMotorDriver::getXTeleCamZoom() {
	return lensInternalStatus.xTeleCamZoom;
}
double DummyMotorDriver::getMTeleCamFocus() {
	return lensInternalStatus.mTeleCamFocus;
}
double DummyMotorDriver::getMHelFocus() {
	return lensInternalStatus.mHelFocus;
}
double DummyMotorDriver::getTeleCamIris() {
	return lensInternalStatus.teleCamIris;
}
double DummyMotorDriver::getRadTilDivergence() {
	return tilServoInternalStatus.radTilDivergence;
}