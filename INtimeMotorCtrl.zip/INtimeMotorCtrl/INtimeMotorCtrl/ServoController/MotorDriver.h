#pragma once

#define __STDC_LIMIT_MACROS

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/
#include "ymcSMTAPI.h"
#ifdef __cplusplus
}
#endif /*__cplusplus*/

#include "IoStructs.h"
#include "math.h"
#include "stdint.h"
#include "MyUtils.h"
#include "MyRtQueue.h"
#include "ServoErrors.h"

class MotorDriver {
public:
	static constexpr int32_t CYCLES_SEARCH_ZERO_TIMEOUT_MAX = 1000;
	int32_t cyclesSearchZeroTimeout;

private:
	static const int DEBUG_SERVO_DISABLE = 0;

	static constexpr double NM_SERVO_RATED_TORQUES[AXIS_NUM] = {
		10000.0,	//TODO: set correct value
		10000.0,	//TODO: set correct value
		10000.0,	//TODO: set correct value
	};

	static constexpr int32_t STEPS_PER_REV_SERVO_RESOLUTION[AXIS_NUM] = {
		65536,		//TODO: set correct value
		65536,		//TODO: set correct value
		65536,		//TODO: set correct value
	};

	static constexpr double RAD_PER_STEP_SERVO_RESOLUTION[AXIS_NUM] = {
		2*M_PI/ STEPS_PER_REV_SERVO_RESOLUTION[0],
		2*M_PI/ STEPS_PER_REV_SERVO_RESOLUTION[1],
		2*M_PI/ STEPS_PER_REV_SERVO_RESOLUTION[2],
	};

	static constexpr double RPS_SERVO_RATED_VELOCITIES[AXIS_NUM] = {
		10.0, //TODO: set correct value.
		10.0, //TODO: set correct value.
		10.0, //TODO: set correct value.
	};

	static constexpr int32_t SERVO_SEARCH_ZERO_START_DIRECTIONS[AXIS_NUM] = {
		0,	//TODO: set proper value.
		0,	//TODO: set proper value.
		1,	//TODO: set proper value.
	};

	static constexpr double NM_SERVO_SEARCH_ZERO_DEFAULT_TORQUE[AXIS_NUM] = {
		1.0,	//TODO: set proper value.
		1.0,	//TODO: set proper value.
		1.0,	//TODO: set proper value.
	};

	static const ULONG SERVO_POSITION_CONTROL_FILTER = 0;
	static const ULONG SERVO_POSITION_CONTROL_PSET_WIDTH = 100;
	static const ULONG SERVO_POSITION_CONTROL_ACCEL = 10000000;
	static const ULONG SERVO_POSITION_CONTROL_DECEL = 10000000;

	static const ULONG SERVO_SEARCH_ZERO_ZRET_DEC_DIST = 0;
	static const ULONG SERVO_SEARCH_ZERO_VELOCITY = 1000;	//TODO: set to proper value
	static const ULONG SERVO_SEARCH_ZERO_APPROACH_VELOCITY = 500;	//TODO: set to proper value
	static const ULONG SERVO_SEARCH_ZERO_CREEP_VELOCITY = 250;	//TODO: set to proper value

	static const ULONG MS_API_TIMEOUT = 10000;

	static constexpr ULONG STATION_NO_SERVOS[AXIS_NUM] = { //�X�e�[�V����No.�B�X�e�[�V�����A�h���X�ł͂Ȃ��̂Œ��ӁB
		3,
		4,
		5
	};
	static constexpr ULONG STATION_NO_TIL = 1;
	static constexpr ULONG STATION_NO_DAC = 7;
	static constexpr ULONG STATION_NO_TELELENS = 8;//TODO �ڑ��ɂ��킹�ďC��
	
	

	static constexpr int32_t DA_FULLSCALE = 31276;
	static constexpr double FINEX_OFFSET = 0.5;
	static constexpr double FINEX_GAIN = 0.8;
	static constexpr double FINXY_OFFSET = 0.5;
	static constexpr double FINEY_GAIN = 0.8;
	static constexpr double DA2_OFFSET = 0.0;
	static constexpr double DA2_GAIN = 1.0;
	static constexpr double DA3_OFFSET = 0.0;
	static constexpr double DA3_GAIN = 1.0;


	int32_t initOk;
	int32_t isControllerOpen;

	USHORT* pIRegister;
	USHORT* pORegister;
	PMON_PARAM pMonitorParams[AXIS_NUM];	//Pan,tilt,camera
	PSET_PARAM pSettingParams[AXIS_NUM];	//Pan,tilt,camera
	PSYSTEM_REG pSystemRegister;

	DWORD setupResisterAddress();
public:
	MotorDriver();
	~MotorDriver();

	DWORD init(ServoErrors::MotorInitSequence& sequenceMarker);
	DWORD tmpInit2(ServoErrors::MotorInitSequence& sequenceMarker);
	
	DWORD waitCycle();
	
	DWORD servoStop();
	DWORD servoEnable(int32_t on);
	DWORD servoEnable(int32_t on[AXIS_NUM]);
	DWORD servoSearchZero(const double nmTorqueLimits[AXIS_NUM]);
	DWORD servoSearchZero();
	DWORD servoPositionControl(const double radPositions[AXIS_NUM],const double rpsVelocityLimits[AXIS_NUM],const double nmTorqueLimits[AXIS_NUM]);
	DWORD servoVelocityControl(const double rpsVelocities[AXIS_NUM],const double nmTorqueLimits[AXIS_NUM]);
	DWORD servoTorqueControl(const double nmTorques[AXIS_NUM], const double rpsVelocityLimits[AXIS_NUM]);
	
	DWORD setDACValue(double axis0,double axis1, double axis2,double axis3);

	double mapRadTilDivergenceToMmPos(double radTilDivergence);
	double mapMmPosToRadTilDivergence(double mmPos);


	int32_t readServoStatus(ServoStatus& servoStatus, FineMirrorStatus& fineMirrorStatus, TeleCamLensStatus& lensStatus, TilServoStatus& tilServoStatus);

	int32_t isServoSearchZeroComplete();
	int32_t isRetracted(const ServoStatus& servoStatus);

	double stepToRad(int32_t axis,int32_t step);
	int32_t stepToNradX10(int32_t axis, int32_t step);

	void setXTeleCamZoom(double xZoom);
	void setMTeleCamFocus(double mFocus);
	void setMHelFocus(double mFocus);
	void setTeleCamIris(double iris);

	double getXTeleCamZoom();
	double getMTeleCamFocus();
	double getMHelFocus();
	double getTeleCamIris();

	class TeleCamLensControl {
	private:
		typedef struct {
			uint16_t opCode;
			int32_t value;
		}RegWriteData;

		static constexpr int32_t INIT_DATA_COUNT = 17;
		static constexpr RegWriteData INIT_DATA[INIT_DATA_COUNT] = {
			{0x3E80,1 },//�A���[���̃��Z�b�g
			{0x3E8B,1 },//�J�E���^�N���A
			{0x1C00,0 },//START���͕��@ = RS-485
			{0x1C01,0 },//I/O STOP���� = ����
			{0x1C02,1 },//STOP��~���@ = ������~
			{0x1C0B,0 },//���[�^�[�㎥���@ = RS-485
			{0x1C0C,0 },//HOME/FWD/RVS���͕��@ = RS-485
			{0x1C0D,0 },//�f�[�^No���͕��@ = RS-485
			{0x1C40,5000},//���ʉ������[�g = [ms/kHz] //TODO: �K���l�ɐݒ�
			{0x1C41,5000},//���ʌ������[�g = [ms/kHz] //TODO: �K���l�ɐݒ�
			{0x1CC1, 1000000},//+�\�t�g�E�F�A���~�b�g = [step] //TODO: �K���l�ɐݒ�
			{0x1CC2,-1000000},//-�\�t�g�E�F�A���~�b�g = [step] //TODO: �K���l�ɐݒ�
			{0x1CCA,2},//�E�����o���� = �A���[��
			{0x1101,10000},//�^�]���xNo.1 //TODO:�K���l�ɐݒ�
			{0x1C66,0},	//���_�o������ 0:�t�����A1:������ //TODO:�K���l�ɐݒ�
			{0x1201,1},	//�^�]����No.1 0:�C���N�������^�� 1:�A�u�\�����[�g
			{0x1401,1},	//������ʒu����No.1 0:���� 1:�L��
		};

		enum class TransactionState {
			SET_OPCODE,
			OPCODE_CHECK,
			TRIG_ON,
			TRIG_ON_CHECK,
			TRIG_OFF,
			TRIG_OFF_CHECK,
			ERROR,
		};

		enum class M3IOState {
			SET_COMMAND,
			WAIT_FOR_RESPONSE
		};

		enum class MoveCommandState {
			SET_POSITION_COMMAND,
			START,
			READ_POSITION,
			CHECK_STOP,
			CHECK_ALARM,
			CHECK_RS485CONVERTER_ALARM,
			READ_ALARM_CODE,
			READ_WARNING_CODE,
			DEBUG
		};

		static constexpr int32_t LOOKUP_TABLE_LENGTH = 17;
		static constexpr double XZOOM_TO_STEP_TABLE[LOOKUP_TABLE_LENGTH] = {
			0,		//0: x1.00
			1217,	//1: x1.66
			1897,	//2: x2.31
			2328,	//3: x2.97
			2626,	//4: x3.63
			2877,	//5: x4.28
			3120,	//6: x4.94
			3354,	//7: x5.59
			3577,	//8: x6.25
			3789,	//9: x6.91
			3991,	//10: x7.56
			4183,	//11: x8.22
			4367,	//12: x8.88
			4543,	//13: x9.53
			4712,	//14: x10.19
			4875,	//15: x10.84
			5015,	//16: x11.50
		};

		static constexpr double STEPS_FOCUS_XOFFSET =  0.8;
		static constexpr double STEPS_FOCUS_YOFFSET = -5.5556;
		static constexpr double STEPS_FOCUS_COEFF = 328780.3;

		static constexpr double STEPS_HEL_XOFFSET = 1.1;
		static constexpr double STEPS_HEL_YOFFSET = -81.94;
		static constexpr double STEPS_HEL_COEFF = 100000.0;

		static constexpr double STEPS_IRIS_COEFF = 74.8;

		static constexpr int32_t AXIS_HEL = 0;
		static constexpr int32_t AXIS_FOCUS = 1;
		static constexpr int32_t AXIS_ZOOM = 2;
		static constexpr int32_t AXIS_IRIS = 3;

		static constexpr uint32_t CYCLES_START_SIGNAL_TIMEOUT_MAX = 4;
		static constexpr int32_t STEPS_MAX_MOVE_IN_CYCLE = 2000;

		static constexpr int32_t CYCLES_INITIALIZE_TIMEOUT = 10000;
		static constexpr int32_t CYCLES_HOMING_TIMEOUT = 20000;
		int32_t initializeLoopCount;

		MoveCommandState moveCommandState;

	public://TODO: �߂�
		int32_t stepsPosCommands[NUM_TELE_LENS_AXIS];
		int32_t stepsPosStatus[NUM_TELE_LENS_AXIS];
		int32_t stepsPosCommandLatch;
	private://TODO: �߂�
		TransactionState transactionState;
		M3IOState m3State;
		int32_t axis;
		ServoErrors::MotorInitSequence sequenceError;
		int32_t alarm;
		uint16_t alarmCode[NUM_TELE_LENS_AXIS];
		uint16_t warningCode[NUM_TELE_LENS_AXIS];
		int32_t startSignalTimeout;
		uint16_t* oRegPtr;
		uint16_t* iRegPtr;
		uint16_t rs485ConverterAlarmCode;

		USHORT writeDataBuf[16];
		USHORT readDataBuf[16];
		DWORD setIoData(const USHORT* writeData);
		DWORD getIoData(USHORT* readBuf);

		DWORD writeRemoteReg(TransactionState transactionState, uint16_t axis, uint16_t opcode, uint32_t data, uint32_t start, uint32_t* done, TransactionState* nextTransactionState);
		DWORD readRemoteReg(TransactionState transactionState, uint16_t axis, uint16_t opcode, uint32_t* data, uint32_t start, uint32_t* done, TransactionState* nextTransactionState);
		DWORD readRs485ConverterAlarmWarning(M3IOState m3State, M3IOState* nextM3State, uint16_t& alarm, uint32_t& done);
		DWORD setStart();
		DWORD setHome();
		DWORD setCOn();
		DWORD setStop();
		DWORD readHomeP(int32_t* isHomeP);
		DWORD readReady(int32_t* isReady);
		DWORD readMove(int32_t* isMove);
		DWORD readAlarm(int32_t* alarm);

		static double lookupTable(double key, const double table[LOOKUP_TABLE_LENGTH]);
		static double reverseLookupTable(double value, const double table[LOOKUP_TABLE_LENGTH]);

	public:
		TeleCamLensControl();
		~TeleCamLensControl();

		DWORD initialize(ServoErrors::MotorInitSequence& sequenceMarker);
		int32_t processCycle();
		double getXZoom();
		double getMFocus();
		double getMHelFocus();
		double getIris();
		void setXZoom(double xZoom);
		void setMFocus(double mFocus);
		void setMHelFocus(double mFocus);
		void setIris(double iris);
		void getAlarmInfo(uint16_t (&alarmCode)[NUM_TELE_LENS_AXIS]);
		void getWarningInfo(uint16_t (&warningCode)[NUM_TELE_LENS_AXIS]);
		uint16_t getRs485ConverterAlarmCode();

		char* transactionStateToStr(TransactionState transactionState);
	};

	TeleCamLensControl teleCamLensControl;

	class TilServo {
	private:
		static constexpr double MM_PER_REV = 1.0;
		static constexpr int32_t STEPS_PER_REV = 1048;
		static constexpr double RAD_TIL_DIVERGENCE_MIN = 0.25 * M_PI / 180;
		static constexpr double RAD_TIL_DIVERGENCE_MAX = 0.75 * M_PI / 180;
		static constexpr double MM_MAX_POS = 35.0;		//�����I���񂩂�35mm�ɐ���
		static constexpr int32_t STEPS_MAX_POS = MM_MAX_POS /MM_PER_REV * STEPS_PER_REV;

		static constexpr int32_t MS_TIL_SERVO_HOMING_TIMEOUT = 5000;

		PMON_PARAM pMonitorParams;
		PSET_PARAM pSettingParams;
		int32_t nextPos;

	public:
		TilServo();
		~TilServo();

		DWORD setupResisterAddress();
		DWORD servoOnAndHome();
		DWORD initialize(ServoErrors::MotorInitSequence& sequenceMarker);
		DWORD tilTerminate();
		int32_t processCycle();
		void setRadTilDivergence(double radTilDivergence);
		double getRadTilDivergence();
		uint16_t getAlarmCode();
		uint16_t getWarningCode();
		static int32_t mmPosToStepsPos(double mmPos);
		static double stepsPosToMmPos(int32_t stepsPos);
		static double radDivergenceToMmPos(double radTilDivergence);
		static double mmPosToRadDivergence(double mmPos);
		static int32_t radDivergenceToStepsPos(double radTilDivergence);
		static double stepsPosToRadDivergence(int32_t stepsPos);
	};

	TilServo tilServo;
};
