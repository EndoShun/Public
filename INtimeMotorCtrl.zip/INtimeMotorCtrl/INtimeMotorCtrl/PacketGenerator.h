#pragma once

#include "stdint.h"
#include "IoStructs.h"
#include "FineMapper.h"
#include "MyRtQueue.h"

class PacketGenerator {
private:
	int16_t WideCameraResolution[2] = { 5320,4600 };
	int16_t TeleCameraResolution[2] = { 1920,1080 };//With Binning


	static constexpr int32_t NRADX10_RESTRICTAREA_MIN = -314159265;
	static constexpr int32_t NRADX10_RESTRICTAREA_MAX = 314159265;

	static constexpr uint16_t SERVO_ERROR_DEGRADE_MASK			  = 0x0FFF;
	static constexpr uint8_t TIL_SERVO_ERROR_DEGRADE_MASK		  = 0x0F;
	static constexpr uint8_t FINE_MIRROR_ERROR_DEGRADE_MASK       = 0x0F;
	static constexpr uint8_t RS485_CONVERTER_ERROR_DEGRADE_MASK   = 0x0F;
	static constexpr uint8_t TELE_LENS_ERROR_DEGRADE_MASK         = 0x0F;


	uint32_t prevMatchIds[NUM_CAMS];
	FineMapper fineMapper;

	void pxOffsetToRadAngleError(const uint16_t pxPos[2], const int16_t jointOffset[2], const int16_t cameraResolution[2], double radPerPixel, double radRotationCorrection, const double pxCamCoordinateAimPointOffset[2], double outRadAngleError[2]);

	static constexpr double OVERRAP_RATE = 1.8;
	static constexpr int32_t CYCLES_PER_SHOT = 33;
	int scanCount;
	void generateScanPattern(int32_t swingScanCommand, double radRadialStep, double outRadScanOffset[2]);

	int debugCount;
public:
	PacketGenerator();
	PacketGenerator(FineMapperParam fineMapperParam);
	int32_t generatePackets(int32_t isMasterAlive, const int32_t isImgProcAlive[2], const OperationMode* operationMode, const UserParameters* userParameters,
		const MasterToTurretCommand* masterToTurretCommand, TurretToMasterResponse* turretToMasterResponse, TurretToImgProcCommand* turretToImgProcCommands[NUM_CAMS], ImgProcToTurretResponse* imgProcToTurretResponses[NUM_CAMS], 
		ControlCommandAndStatus* controlCommandAndStatus,
		RangefinderCommand* rangefinderCommand, const RangefinderStatus* rangefinderStatus,
		WideCamLensCommand* wideCamLensCommand, const WideCamLensStatus* wideCamLensStatus,
		const LogStatus* logStatus, MyRtQueue<MessageLog>* errorLoggingQueue);

	int32_t isInArea(int32_t nradx10Pos, int32_t nradx10Limit0, int32_t nradx10Limit1, int32_t nradx10Margin, MyRtQueue<MessageLog>* errorLoggingQueue);
	uint8_t isInRestrictArea(const ServoStatus* servoStatus, const MasterToTurretCommand* masterToTurretCommand, const UserParameters* userParameters, MyRtQueue<MessageLog>* errorLoggingQueue);

};

