#pragma once

#include <stdio.h>
#include <rt.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

#include "ymcSMTAPI.h"


#define AXIS_NUM 2
constexpr int32_t DA_INITIA_LVALUE = 0;
constexpr int32_t DA_FULLSCALE = 31276;


enum {
	CTRL_WAIT_STAT = 0,
	CTRL_MOVE_SETTING_STAT,
	CTRL_MOVE_START_STAT,
	CTRL_MOVE_STAT,
	CTRL_TRQ_START_STAT,
	CTRL_TRQ_STAT,
	CTRL_VELO_START_STAT,
	CTRL_VELO_STAT,
	CTRL_STOP_START_STAT,
	CTRL_STOP_STAT,
	CTRL_EXIT_STAT
};

enum {
	CTRL_STOP_MODE=0,
	CTRL_TRQ_MODE,
	CTRL_VELO_MODE,
	CTRL_POS_MODE
};

extern USHORT* pIRegister;
extern USHORT* pORegister;
extern PMON_PARAM			pMonitorParam1;
extern PMON_PARAM			pMonitorParam2;
extern PSET_PARAM			pSettingParam;
extern PSYSTEM_REG			pSystemRegister;




extern int CtrlStop(AXIS_INFO* AxisInfo, ULONG stop_mode);
extern int CtrlStopCompCheck(AXIS_INFO* AxisInfo);
extern int CtrlVelocityCompCheck(AXIS_INFO* AxisInfo, int tg_axis);
extern int CtrlTrqCompCheck(AXIS_INFO* AxisInfo, int tg_axis);
extern int CtrlPositionCompCheck(AXIS_INFO* AxisInfo, int tg_axis);
extern int CtrlExit(void);
extern ULONG	GetRegAddress(void);		/* ���W�X�^�̐擪�A�h���X���擾 */
extern int CtrlInit(int timeout);
extern int CtrlReset(AXIS_INFO* AxisInfo);
extern int CtrlServoAlarmClear(AXIS_INFO* AxisInfo);
extern int CtrlServo(AXIS_INFO* AxisInfo, int onoff);
extern int CtrlDaInit(AXIS_INFO* AxisInfo);
extern int CtrlDA(AXIS_INFO* AxisInfo, double axis1, double axis2);

extern int SendMonitorMsg(int code,ULONG seq, LONG pos1, LONG fspd1, LONG trq1, LONG pos2, LONG fspd2, LONG trq2,double da1,double da2);

int setupHomePosition();
int ServoSetVelocityUnit();

extern int CtrlPositionSetting(
	AXIS_INFO* AxisInfo,
	MOTION_DATA	MotionData[AXIS_NUM],
	MOVE_DATA	MoveData[AXIS_NUM],
	ULONG       axis_no,
	ULONG       velocityunit,
	ULONG       accunit,
	ULONG       filtertype,
	ULONG       accel,
	ULONG       decel,
	ULONG       filtervalue,
	ULONG       psetwidth,
	ULONG       trqunit,
	ULONG       trqlimit,
	LONG        velocity,
	ULONG       postype,
	LONG        targetpos);
extern int CtrlPosition(
	AXIS_INFO* AxisInfo,
	int         tg_axis,
	MOTION_DATA	MotionData[AXIS_NUM],
	MOVE_DATA	MoveData[AXIS_NUM]);

extern int CtrlTorque(AXIS_INFO* AxisInfo,
	int   tg_axis,
	LONG comtorque1,
	ULONG velocityLimit1,
	LONG comtorque2,
	ULONG velocityLimit2);


extern int CtrlVelocity(AXIS_INFO* AxisInfo,
	int         tg_axis,
	ULONG velocityunit1,
	LONG velocity1,
	ULONG trqunit1,
	LONG trqff1,
	ULONG trqLimit1,
	ULONG velocityunit2,
	LONG velocity2,
	ULONG trqunit2,
	LONG trqff2,
	ULONG trqLimit2);

extern void ServoEnable(int onoff);

#ifdef __cplusplus
}
#endif /*__cplusplus*/