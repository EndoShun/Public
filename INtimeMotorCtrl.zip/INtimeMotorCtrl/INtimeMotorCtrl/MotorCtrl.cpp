


#include "MotorCtrl.h"

USHORT* pIRegister;
USHORT* pORegister;
PMON_PARAM			pMonitorParam1;
PMON_PARAM			pMonitorParam2;
PSET_PARAM			pSettingParam1;
PSET_PARAM			pSettingParam2;
PSYSTEM_REG			pSystemRegister;

#define FINEX_OFFSET 0.5
#define FINEX_GAIN (-0.8)
#define FINEY_OFFSET 0.5
#define FINEY_GAIN (0.8)

//void	KeyWait(void);				// �L�[���͑҂��^�X�N 

static int servo1_enable = 0;
static int servo2_enable = 0;
//***************************************************************************
//int SendPosSettingMsg(ULONG       axis_no,
//	ULONG       velocityunit,
//	ULONG       accunit,
//	ULONG       filtertype,
//	ULONG       accel,
//	ULONG       decel,
//	ULONG       filtervalue,
//	ULONG       psetwidth,
//	ULONG       trqunit,
//	ULONG       trqlimit)
//{
//	GetRtSystemTimeAsTimeValue(&evt_msg.tv);
//	evt_msg.evtcode = SET_EVT_CODE;
//	snprintf(evt_msg.msg, MSG_STR_SZ, "axis%d possetting,%d,%d,%d,%d,%d,%d,%d,%d,%d",
//		axis_no,
//		velocityunit,
//		accunit,
//		filtertype,
//		accel,
//		decel,
//		filtervalue,
//		psetwidth,
//		trqunit,
//		trqlimit
//	);
//	if (!SendRtData(hEvtDmbx, (void*)&evt_msg, sizeof(EVT_LOG_MSG))) {
//		return -1;
//	}
//
//	return 0;
//}

//***************************************************************************
//int SendPositionMsg(ULONG ret, int  StationNo, LONG Velocity, ULONG PosType, LONG pos)
//{
//	GetRtSystemTimeAsTimeValue(&evt_msg.tv);
//	evt_msg.evtcode = SET_EVT_CODE;
//	snprintf(evt_msg.msg, MSG_STR_SZ, "axis%d targetpos,velocity,%d,postype,%d,pos,%d",
//		StationNo, Velocity, PosType, pos
//	);
//	if (!SendRtData(hEvtDmbx, (void*)&evt_msg, sizeof(EVT_LOG_MSG))) {
//		return -1;
//	}
//
//	return 0;
//}

//***************************************************************************
//int SendTrqMsg(ULONG ret, int  StationNo, ULONG trqunit, LONG comtorque, ULONG velocityLimit)
//{
//	GetRtSystemTimeAsTimeValue(&evt_msg.tv);
//	evt_msg.evtcode = SET_EVT_CODE;
//	snprintf(evt_msg.msg, MSG_STR_SZ, "axis%d trq,trqunit,%d,comtorque,%d,velocitylimit,%d",
//	StationNo,
//	trqunit, comtorque, velocityLimit
//	);
//	if (!SendRtData(hEvtDmbx, (void*)&evt_msg, sizeof(EVT_LOG_MSG))) {
//		return -1;
//	}
//
//	return 0;
//}

//***************************************************************************
//int SendVelocityMsg(ULONG ret, int  StationNo, ULONG velocityunit, LONG velocity, LONG trqunit, LONG trqff, ULONG trqLimit)
//{
//	GetRtSystemTimeAsTimeValue(&evt_msg.tv);
//	evt_msg.evtcode = SET_EVT_CODE;
//	snprintf(evt_msg.msg, MSG_STR_SZ, "axis%d velo,velocityunit,%d,velocity,%d,trqunit,%d,trqff,%d,trqlimit,%d",
//		StationNo,
//		velocityunit, velocity, trqunit, trqff, trqLimit
//	);
//	if (!SendRtData(hEvtDmbx, (void*)&evt_msg, sizeof(EVT_LOG_MSG))) {
//		return -1;
//	}
//
//	return 0;
//}

//***************************************************************************
//int SendMonitorMsg(int code,ULONG seq, LONG pos1, LONG fspd1, LONG trq1, LONG pos2, LONG fspd2, LONG trq2,double da1,double da2)
//{
//	GetRtSystemTimeAsTimeValue(&evt_msg.tv);
//	evt_msg.evtcode = code;
//	snprintf(evt_msg.msg, MSG_STR_SZ, "find seq,%u,pos,%d,%d,spd,%d,%d,trq,%d,%d,da,%.4lf,%.4lf",
//		seq,
//		pos1, pos2, fspd1, fspd2, trq1, trq2,da1,da2);
//	if (!SendRtData(hEvtDmbx, (void*)&evt_msg, sizeof(EVT_LOG_MSG))) {
//		return -1;
//	}
//
//	return 0;
//}
//***************************************************************************
//���[�^�[�h���C�o������
int CtrlInit(int timeout)
{
	ULONG	ret;		// �߂�l 

	// �R���g���[���ڑ� 
	ret = ymcOpenController(BUILD_TYPE);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcOpenController fail");
		return -1;
	}

	// API���\�[�X�̏����� 
	ret = ymcInitializeAPIThread();
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcInitializeAPIThread fail");
		return -2;
	}

	if (timeout > 0) {
		// API�^�C���A�E�g�ݒ� 
		ret = ymcSetAPITimeoutValue(timeout);			// �^�C���A�E�g���ԁF�P�O�b 
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "ymcSetAPITimeoutValue fail");
			return -4;
		}
	}
	// ���W�X�^�̐擪�A�h���X���擾 
	ret = GetRegAddress();
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "GetRegAddress fail");
		return -5;
	}

	return 0;
}
//***************************************************************************
int CtrlExit(void)
{
	ULONG	ret;		// �߂�l 
	// �R���g���[���ؒf 
	ret = ymcCloseController();
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcCloseController fail");

		return -1;
	}
	return 0;
}
//***************************************************************************
//�G���R�[�_���Z�b�g
int CtrlReset(AXIS_INFO* AxisInfo)
{
	//��Βl�G���R�[�_���Z�b�g�i20200609�g�c�L�q�j
	ULONG	ret;		// �߂�l 

	//    �����\���̂̐ݒ�    
	AxisInfo->SlotNo = SLOT1;                              //  �X���b�g�ԍ�          
	AxisInfo->ChannelNo = CHANNEL1;                        //  �`���l���ԍ�          
	AxisInfo->MotionFunc = MODULE_SVC32;                   //  ���[�V��������@�\    
	AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
#if 0
	SETUP_TYPE    SetupType[AXIS_NUM];
	for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
	{
		AxisInfo->STNo[StationNo] = StationNo + 1;         //  �X�e�[�V�����ԍ�  

		//    �Z�b�g�A�b�v��ʍ\���̂̐ݒ�    
		SetupType[StationNo].SetupType = SETUP_ABSINIT;   //  �Z�b�g�A�b�v���  
	}

	ret = ymcSetUpEncoder(AxisInfo, SetupType);
	if (ret != MP_SUCCESS)
	{
		printf(" ymcSetUpEncoder fail. ret = 0x%.8x\n ", ret);
		return -1;
	}
#endif
	// �A���[���N���A 
	//AxisInfo.SlotNo = SLOT1; //�G���R�[�_���Z�b�g���ɒ�`���Ă��邽�߂����̓R�����g�A�E�g
	//AxisInfo.ChannelNo = CHANNEL1;
	//AxisInfo.STCount = AXIS_NUM;
	//AxisInfo.MotionFunc = MODULE_SVC32;
#if 1
	AxisInfo->SlotNo = SLOT1; //�G���R�[�_���Z�b�g���ɒ�`���Ă��邽�߂����̓R�����g�A�E�g
	AxisInfo->ChannelNo = CHANNEL1;
	AxisInfo->STCount = 1;
	AxisInfo->MotionFunc = MODULE_SVC32;
	AxisInfo->STNo[0] = 1;
	ret = ymcClearServoAlarm(AxisInfo);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "axis0 ymcClearServoAlarm fail");
		servo1_enable = FALSE;
		pMonitorParam1 = NULL;
		//return -1;
	}else{
		servo1_enable = TRUE;
	}

	AxisInfo->STNo[0] = 2;
	ret = ymcClearServoAlarm(AxisInfo);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "axis1 ymcClearServoAlarm fail");
		servo2_enable = FALSE;
		pMonitorParam2 = NULL;
		//return -1;
	}else{
		servo2_enable = TRUE;
	}
	
#else
	for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
	{
		AxisInfo->STNo[StationNo] = StationNo + 1;
	}
	ret = ymcClearServoAlarm(AxisInfo);
	if (ret != MP_SUCCESS)
	{
		printf("ymcClearServoAlarm fail. ret = 0x%.8x\n", ret);
		SendErrMsg(ret, "ymcClearServoAlarm fail");
		return -1;
	}
#endif
	return 0;
}

//***************************************************************************
//�T�[�{����ON/OFF
int CtrlServoAlarmClear(AXIS_INFO* AxisInfo)
{
	ULONG   ret;
	
#if 1
	// �A���[���N���A 
	AxisInfo->SlotNo = SLOT1; //�G���R�[�_���Z�b�g���ɒ�`���Ă��邽�߂����̓R�����g�A�E�g
	AxisInfo->ChannelNo = CHANNEL1;
	AxisInfo->STCount = 1;
	AxisInfo->MotionFunc = MODULE_SVC32;

	if(servo1_enable==TRUE){
		AxisInfo->STNo[0] = 1;
		ret = ymcClearServoAlarm(AxisInfo);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis0 ymcClearServoAlarm fail");
			return ret;
		}
		
	}
	if(servo2_enable==TRUE){
		AxisInfo->STNo[0] = 2;
		ret = ymcClearServoAlarm(AxisInfo);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis1 ymcClearServoAlarm fail");
			return ret;
		}
	}
	
#else
	AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
	for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)return ret;
	{
		AxisInfo->STNo[StationNo] = StationNo + 1;
	}
	ret = ymcClearServoAlarm(AxisInfo);
	if (ret != MP_SUCCESS)
	{
		printf("ymcClearServoAlarm fail. ret = 0x%.8x\n", ret);
		SendErrMsg(ret, "ymcClearServoAlarm fail");
		return -1;
	}
#endif
	return 0;
}

//***************************************************************************
//�T�[�{����ON/OFF
int CtrlServo(AXIS_INFO* AxisInfo, int onoff)
{
	ULONG   ret;
	SVCTRL_DATA		SVControlData[AXIS_NUM];
	// �T�[�{�I�� 
	
	if(servo1_enable==TRUE){
		AxisInfo->STCount = 1;//AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 1;
		SVControlData[0].ControlType = onoff;
		ret = ymcServoControl(AxisInfo, SVControlData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis0 ymcServoControl fail");
			servo1_enable = FALSE;
			pMonitorParam1 = NULL;
		}
	}
	if(servo2_enable==TRUE){
		AxisInfo->STCount = 1;//AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 2;
		SVControlData[0].ControlType = onoff;
		ret = ymcServoControl(AxisInfo, SVControlData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis1 ymcServoControl fail");
			servo2_enable = FALSE;
			pMonitorParam2 = NULL;
		}
	}
	
	return 0;
}


//***************************************************************************
int CtrlPositionSetting(
	AXIS_INFO* AxisInfo,
	MOTION_DATA	MotionData[AXIS_NUM],
	MOVE_DATA	MoveData[AXIS_NUM],
	ULONG       axis_no,
	ULONG       velocityunit,
	ULONG       accunit,
	ULONG       filtertype,
	ULONG       accel,
	ULONG       decel,
	ULONG       filtervalue,
	ULONG       psetwidth,
	ULONG       trqunit,
	ULONG       trqlimit,
	LONG        velocity,
	ULONG       postype,
	LONG        targetpos)
{
	ULONG	StationNo = axis_no;
	// �ʒu���߃p�����[�^�̐ݒ� 
	MotionData[StationNo].VelocityUnit = velocityunit;
	MotionData[StationNo].AccUnit = accunit;
	MotionData[StationNo].FilterType = filtertype;
	MotionData[StationNo].Accel = accel;
	MotionData[StationNo].Decel = decel;
	MotionData[StationNo].FilterValue = filtervalue;
	MotionData[StationNo].PsetWidth = psetwidth;
	MotionData[StationNo].TrqUnit = trqunit;
	MotionData[StationNo].TrqLimit = trqlimit;
	MoveData[StationNo].Velocity = velocity;
	MoveData[StationNo].PosType = postype;
	MoveData[StationNo].TargetPos = targetpos;
	//SendPosSettingMsg(axis_no, velocityunit, accunit, filtertype, accel, decel, filtervalue, psetwidth,
	//	trqunit, trqlimit);

	return 0;
}

//***************************************************************************
int CtrlPosition(
	AXIS_INFO* AxisInfo,
	int tg_axis,
	MOTION_DATA	MotionData[AXIS_NUM],
	MOVE_DATA	MoveData[AXIS_NUM])
{
	ULONG   ret;
	ULONG StationNo = 0;

	if(tg_axis == 2){
		if(servo1_enable==FALSE){
			tg_axis = 1;
		}else if(servo2_enable==FALSE){
			tg_axis = 0;
		}
	}
	
	if (tg_axis == 0 && servo1_enable==TRUE) {
		AxisInfo->STCount = 1;// XIS_NUM;                          //  �w�߃X�e�[�V������    
		StationNo = 0;
		AxisInfo->STNo[StationNo] = 1;                  //  Station No.              
		ret = ymcMovePositioning(AxisInfo, &MotionData[0], &MoveData[0], COMMAND_STARTED);		// ���������F�ʒu���ߊ��� 

		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis0 ymcMovePositioning fail");
			return -1;
		}
		else {
			//SendPositionMsg(ret, 0, MoveData[0].Velocity, MoveData[0].PosType, MoveData[0].TargetPos);
		}
	}
	else if (tg_axis == 1 && servo2_enable==TRUE) {
		AxisInfo->STCount = 1;// XIS_NUM;                          //  �w�߃X�e�[�V������    
		StationNo = 0;
		AxisInfo->STNo[StationNo] = 2;                  //  Station No.              
		ret = ymcMovePositioning(AxisInfo, &MotionData[1], &MoveData[1], COMMAND_STARTED);		// ���������F�ʒu���ߊ��� 

		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis1 ymcMovePositioning fail");
			return -1;
		}
		else {
			//SendPositionMsg(ret, 1, MoveData[1].Velocity, MoveData[1].PosType, MoveData[1].TargetPos);
		}
	}
	else if(servo1_enable==TRUE && servo2_enable==TRUE){
		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    

		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			AxisInfo->STNo[StationNo] = StationNo + 1;                  //  Station No.              
		}

		ret = ymcMovePositioning(AxisInfo, MotionData, MoveData, COMMAND_STARTED);		// ���������F�ʒu���ߊ��� 
		//ret = ymcMovePositioning(AxisInfo, MotionData, MoveData, POSITIONING_COMPLETED);		// ���������F�ʒu���ߊ��� 

		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "ymcMovePositioning fail");
			return -1;
		}
		else {
			//SendPositionMsg(ret, 0, MoveData[0].Velocity, MoveData[0].PosType, MoveData[0].TargetPos);
			//SendPositionMsg(ret, 1, MoveData[1].Velocity, MoveData[1].PosType, MoveData[1].TargetPos);
		}
	}

	return 0;
}

//***************************************************************************
int CtrlTorque(AXIS_INFO* AxisInfo,
	int  tg_axis,
	LONG comtorque1,
	ULONG velocityLimit1,
	LONG comtorque2,
	ULONG velocityLimit2)
{
	ULONG            ret = 0;
	ULONG            StationNo;
	TRQCTRL_DATA     TorqueCtrlData[AXIS_NUM];

	
	if(tg_axis == 2){
		if(servo1_enable==FALSE){
			tg_axis = 1;
		}else if(servo2_enable==FALSE){
			tg_axis = 0;
		}
	}
	//Setting of axis information structure 
	if (tg_axis == 0 && servo1_enable==TRUE) {
		AxisInfo->STCount = 1;// XIS_NUM;                         //�w�߃X�e�[�V������
		StationNo = 0;
		AxisInfo->STNo[StationNo] = 1;                  //  Station No.
		TorqueCtrlData[StationNo].TrqUnit = 1;         //  Torque unit selection        
		TorqueCtrlData[StationNo].ComTorque = comtorque1;               //  Torque/force reference
		TorqueCtrlData[StationNo].VelocityLimit = velocityLimit1;             //  Speed limit for torque/force reference
		ret = ymcTorqueModeControl(AxisInfo, TorqueCtrlData);
		if (ret != MP_SUCCESS)
		{
			//printf("axis0 ymcTorqueModeControl fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis0 ymcTorqueModeControl fail");
			return -1;
		}		
	}
	else if (tg_axis == 1 && servo2_enable==TRUE) {
		StationNo = 0;
		AxisInfo->STCount = 1;// XIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[StationNo] = 2;                  //  Station No.              
		TorqueCtrlData[StationNo].TrqUnit = 1;         //  Torque unit selection                   
		TorqueCtrlData[StationNo].ComTorque = comtorque2;               //  Torque/force reference                  
		TorqueCtrlData[StationNo].VelocityLimit = velocityLimit2;             //  Speed limit for torque/force reference  
		ret = ymcTorqueModeControl(AxisInfo, TorqueCtrlData);
		if (ret != MP_SUCCESS)
		{
			//printf("axis1 ymcTorqueModeControl fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis1 ymcTorqueModeControl fail");
			return -1;
		}

	}
	else if(servo1_enable==TRUE && servo2_enable==TRUE){
		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    

		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			AxisInfo->STNo[StationNo] = StationNo + 1;                  //  Station No.              
		}

		//    Setting of torque control data structure    
		StationNo = 0;
		TorqueCtrlData[StationNo].TrqUnit = 1;         //  Torque unit selection                   
		TorqueCtrlData[StationNo].ComTorque = comtorque1;               //  Torque/force reference                  
		TorqueCtrlData[StationNo].VelocityLimit = velocityLimit1;             //  Speed limit for torque/force reference
		StationNo = 1;
		TorqueCtrlData[StationNo].TrqUnit = 1;         //  Torque unit selection
		TorqueCtrlData[StationNo].ComTorque = comtorque2;               //  Torque/force reference
		TorqueCtrlData[StationNo].VelocityLimit = velocityLimit2;             //  Speed limit for torque/force reference 
		ret = ymcTorqueModeControl(AxisInfo, TorqueCtrlData);
		if (ret != MP_SUCCESS)
		{
			//printf("ymcTorqueModeControl fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "ymcTorqueModeControl fail");
			return ret;
		}
	}else {
		return -1;
	}
	
	{
		if (tg_axis == 0) {
		//	SendTrqMsg(ret, 0, trqunit1, comtorque1, velocityLimit1);
		}
		else if (tg_axis == 1) {
		//	SendTrqMsg(ret, 1, trqunit2, comtorque2, velocityLimit2);
		}
		else {
		//	SendTrqMsg(ret, 0, trqunit1, comtorque1, velocityLimit1);
		//	SendTrqMsg(ret, 1, trqunit2, comtorque2, velocityLimit2);
		}
	}
	return 0;
}


//***************************************************************************
int CtrlVelocity(AXIS_INFO* AxisInfo,
	int tg_axis,
	ULONG velocityunit1,
	LONG velocity1,
	ULONG trqunit1,
	LONG trqff1,
	ULONG trqLimit1,
	ULONG velocityunit2,
	LONG velocity2,
	ULONG trqunit2,
	LONG trqff2,
	ULONG trqLimit2)
{
	ULONG            ret = 0;
	ULONG            StationNo;
	VELOCTRL_DATA    VeloCtrlData[AXIS_NUM];

	if(tg_axis == 2){
		if(servo1_enable==FALSE){
			tg_axis = 1;
		}else if(servo2_enable==FALSE){
			tg_axis = 0;
		}
	}
	if (tg_axis == 0 && servo1_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 1;           //  Station No.               
		StationNo = 0;
		VeloCtrlData[StationNo].VelocityUnit = velocityunit1;     //  Speed unit selection      
		VeloCtrlData[StationNo].Velocity = velocity1;              //  Speed reference setting   
		VeloCtrlData[StationNo].TrqUnit = trqunit1;        //  Torque unit selection     
		VeloCtrlData[StationNo].TrqFF = trqff1;                      //  Torque feedforward        
		VeloCtrlData[StationNo].TrqLimit = trqLimit1;              //  Torque/force limit        
		ret = ymcVelocityModeControl(AxisInfo, VeloCtrlData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis0 ymcVelocityModeControl fail");
			return -1;
		}
	}
	else if (tg_axis == 1 && servo2_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 2;           //  Station No.               
		StationNo = 0;
		VeloCtrlData[StationNo].VelocityUnit = velocityunit2;     //  Speed unit selection      
		VeloCtrlData[StationNo].Velocity = velocity2;              //  Speed reference setting   
		VeloCtrlData[StationNo].TrqUnit = trqunit2;        //  Torque unit selection     
		VeloCtrlData[StationNo].TrqFF = trqff2;                      //  Torque feedforward        
		VeloCtrlData[StationNo].TrqLimit = trqLimit2;              //  Torque/force limit        
		ret = ymcVelocityModeControl(AxisInfo, VeloCtrlData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis1 ymcVelocityModeControl fail");
			return -1;
		}
	}
	else if(servo1_enable==TRUE && servo2_enable==TRUE){

		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			AxisInfo->STNo[StationNo] = StationNo + 1;               //  Station No.              
		}

		//    Setting of speed control data structure    
		StationNo = 0;
		VeloCtrlData[StationNo].VelocityUnit = velocityunit1;     //  Speed unit selection      
		VeloCtrlData[StationNo].Velocity = velocity1;              //  Speed reference setting   
		VeloCtrlData[StationNo].TrqUnit = trqunit1;        //  Torque unit selection     
		VeloCtrlData[StationNo].TrqFF = trqff1;                      //  Torque feedforward        
		VeloCtrlData[StationNo].TrqLimit = trqLimit1;              //  Torque/force limit        
		StationNo = 1;
		VeloCtrlData[StationNo].VelocityUnit = velocityunit2;     //  Speed unit selection      
		VeloCtrlData[StationNo].Velocity = velocity2;              //  Speed reference setting   
		VeloCtrlData[StationNo].TrqUnit = trqunit2;        //  Torque unit selection     
		VeloCtrlData[StationNo].TrqFF = trqff2;                      //  Torque feedforward        
		VeloCtrlData[StationNo].TrqLimit = trqLimit2;              //  Torque/force limit        
		ret = ymcVelocityModeControl(AxisInfo, VeloCtrlData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "ymcVelocityModeControl fail");
			return -1;
		}
	}

	{
		if (tg_axis == 0) {
			//SendVelocityMsg(ret, 0, velocityunit1, velocity1, trqunit1, trqff1, trqLimit1);
		}
		else if (tg_axis == 1) {
			//SendVelocityMsg(ret, 1, velocityunit2, velocity2, trqunit2, trqff2, trqLimit2);
		}
		else {
			//SendVelocityMsg(ret, 0, velocityunit1, velocity1, trqunit1, trqff1, trqLimit1);
			//SendVelocityMsg(ret, 1, velocityunit2, velocity2, trqunit2, trqff1, trqLimit2);
		}
	}
	return 0;
}
//***************************************************************************
int CtrlStop(AXIS_INFO* AxisInfo, ULONG stop_mode)
{
	ULONG            ret;
	ULONG            StationNo;
	STOP_DATA        StopData[AXIS_NUM];

	if(servo1_enable==TRUE && servo2_enable==TRUE){
		//    Setting of axis information structure    
		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    

		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			AxisInfo->STNo[StationNo] = StationNo + 1;           //  Station No.               

			//   Setting of stop data structure     
			StopData[StationNo].StopMode = stop_mode;           //  Stop mode selection       
		}

		ret = ymcStopMotion(AxisInfo, StopData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "ymcStopMotion fail");
			return -1;
		}
	}else if(servo1_enable==TRUE){
		AxisInfo->STCount = 1;//AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 1;           //  Station No.               
			//   Setting of stop data structure     
		StopData[0].StopMode = stop_mode;           //  Stop mode selection       
		ret = ymcStopMotion(AxisInfo, StopData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis0 ymcStopMotion fail");
			return -1;
		}
	}else if(servo2_enable==TRUE){
		AxisInfo->STCount = 1;//AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 2;           //  Station No.               
			//   Setting of stop data structure     
		StopData[0].StopMode = stop_mode;           //  Stop mode selection       
		ret = ymcStopMotion(AxisInfo, StopData);
		if (ret != MP_SUCCESS)
		{
			//SendErrMsg(ret, "axis1 ymcStopMotion fail");
			return -1;
		}
	}
	return 0;
}


//***************************************************************************
int CtrlPositionCompCheck(AXIS_INFO* AxisInfo, int tg_axis)
{
	ULONG   ret;
	ULONG	StationNo;
	CHKCMP_DATA      ChkCmp[AXIS_NUM];

	if(tg_axis == 2){
		if(servo1_enable==FALSE){
			tg_axis = 1;
		}else if(servo2_enable==FALSE){
			tg_axis = 0;
		}
	}
	if (tg_axis == 0 && servo1_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 1;           //  Station No.               
		ChkCmp[0].APINo = MOVEPOSITIONING;               //  API No.               
		ChkCmp[0].CompCondition = POSITIONING_COMPLETED;   //  Completion condition  
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "axis0 ymcCheckComplete position");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//SendErrMsg(ret, "axis0 ymcCheckComplete fail");
			return -1;
		}

	}
	else if (tg_axis == 1 && servo2_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 2;           //  Station No.               
		ChkCmp[0].APINo = MOVEPOSITIONING;                 //  API No.               
		ChkCmp[0].CompCondition = POSITIONING_COMPLETED;   //  Completion condition  
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "axis1 ymcCheckComplete position");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf("axis1 ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis1 ymcCheckComplete fail");
			return -1;
		}
	}
	else if(servo1_enable==TRUE && servo2_enable==TRUE){
		//   Setting of completion confirmation data structure    
		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			ChkCmp[StationNo].APINo = MOVEPOSITIONING;                //  API No.               
			ChkCmp[StationNo].CompCondition = POSITIONING_COMPLETED;  //  Completion condition  
			AxisInfo->STNo[StationNo] = StationNo + 1;           //  Station No.               
		}
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "ymcCheckComplete position");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf(" ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "ymcCheckComplete fail");
			return -1;
		}
	
	}else{
		return 1;
	}


	return 0;
}

//***************************************************************************
int CtrlVelocityCompCheck(AXIS_INFO* AxisInfo, int tg_axis)
{
	ULONG   ret;
	ULONG	StationNo;
	CHKCMP_DATA      ChkCmp[AXIS_NUM];
	if(tg_axis == 2){
		if(servo1_enable==FALSE){
			tg_axis = 1;
		}else if(servo2_enable==FALSE){
			tg_axis = 0;
		}
	}
	if (tg_axis == 0 && servo1_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 1;           //  Station No.               
		ChkCmp[0].APINo = VELOCITYMODECONTROL;                //  API No.               
		ChkCmp[0].CompCondition = 0;  //  Completion condition  
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "axis0 ymcCheckComplete velocity");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf("axis0 ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis0 ymcCheckComplete fail");
			return -1;
		}			
	}
	else if (tg_axis == 1 && servo2_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 2;           //  Station No.               
		ChkCmp[0].APINo = VELOCITYMODECONTROL;                //  API No.               
		ChkCmp[0].CompCondition = 0;  //  Completion condition  
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "axis1 ymcCheckComplete velocity");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf("axis1 ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis1 ymcCheckComplete fail");
			return -1;
		}	
	}
	else if(servo1_enable==TRUE && servo2_enable==TRUE){

		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
	//   Setting of completion confirmation data structure    
		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			ChkCmp[StationNo].APINo = VELOCITYMODECONTROL;                //  API No.               
			ChkCmp[StationNo].CompCondition = 0;  //  Completion condition  
			AxisInfo->STNo[StationNo] = StationNo + 1;           //  Station No.               
		}
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "ymcCheckComplete velocity");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//SendErrMsg(ret, "ymcCheckComplete fail");
			return -1;
		}		
	}else{
		return 1;
	}


	return 0;
}

//***************************************************************************
int CtrlStopCompCheck(AXIS_INFO* AxisInfo)
{
	ULONG   ret;
	ULONG	StationNo;
	CHKCMP_DATA      ChkCmp[AXIS_NUM];
	if (servo1_enable == TRUE && servo2_enable == TRUE) {
		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
		//   Setting of completion confirmation data structure    
		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			ChkCmp[StationNo].APINo = STOPMOTION;                //  API No.               
			ChkCmp[StationNo].CompCondition = 0;  //  Completion condition  
			AxisInfo->STNo[StationNo] = StationNo + 1;           //  Station No.               
		}

		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "ymcCheckComplete Stop");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf(" ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "ymcCheckComplete fail");
			return -1;
		}
	}
	else if(servo1_enable==TRUE){
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		ChkCmp[0].APINo = STOPMOTION;                //  API No.               
		ChkCmp[0].CompCondition = 0;  //  Completion condition  
		AxisInfo->STNo[0] = 1;           //  Station No.               

		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "axis0 ymcCheckComplete Stop");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf("axis0  ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis0  ymcCheckComplete fail");
			return -1;
		}

	}else if(servo2_enable==TRUE){
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		ChkCmp[0].APINo = STOPMOTION;                //  API No.               
		ChkCmp[0].CompCondition = 0;  //  Completion condition  
		AxisInfo->STNo[0] = 2;           //  Station No.               

		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "axis1 ymcCheckComplete Stop");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//printf("axis1  ymcCheckComplete fail. ret = 0x%.8x\n ", ret);
			//SendErrMsg(ret, "axis1  ymcCheckComplete fail");
			return -1;
		}

	}else{
		return 1;
	}
	return 0;
}


//***************************************************************************
int CtrlTrqCompCheck(AXIS_INFO* AxisInfo, int tg_axis)
{
	ULONG   ret;
	ULONG	StationNo;
	CHKCMP_DATA      ChkCmp[AXIS_NUM];
	if(tg_axis == 2){
		if(servo1_enable==FALSE){
			tg_axis = 1;
		}else if(servo2_enable==FALSE){
			tg_axis = 0;
		}
	}
	if (tg_axis == 0 && servo1_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 1;           //  Station No.               
		ChkCmp[0].APINo = TORQUEMODECONTROL;                //  API No.               
		ChkCmp[0].CompCondition = 0;  //  Completion condition  
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
//			SendEvtMsg(COMP_EVT_CODE, "axis0 ymcCheckComplete trq");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete. 
			return 0;
		}
		else
		{
			//SendErrMsg(ret, "axis0 ymcCheckComplete fail");
			return -1;
		}		
	}
	else if (tg_axis == 1 && servo2_enable==TRUE) {
		AxisInfo->STCount = 1;// AXIS_NUM;                          //  �w�߃X�e�[�V������    
		AxisInfo->STNo[0] = 2;           //  Station No.               
		ChkCmp[0].APINo = TORQUEMODECONTROL;                //  API No.               
		ChkCmp[0].CompCondition = 0;  //  Completion condition  
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
//			SendEvtMsg(COMP_EVT_CODE, "axis1 ymcCheckComplete trq");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//SendErrMsg(ret, "axis1 ymcCheckComplete fail");
			return -1;
		}		
	}
	else if(servo1_enable==TRUE && servo2_enable==TRUE){
		AxisInfo->STCount = AXIS_NUM;                          //  �w�߃X�e�[�V������    
		//   Setting of completion confirmation data structure    
		for (StationNo = 0; StationNo < AXIS_NUM; StationNo++)
		{
			AxisInfo->STNo[StationNo] = StationNo + 1;           //  Station No.               
			ChkCmp[StationNo].APINo = TORQUEMODECONTROL;                //  API No.               
			ChkCmp[StationNo].CompCondition = 0;  //  Completion condition  
		}
		ret = ymcCheckComplete(AxisInfo, ChkCmp);
		if (ret == MP_SUCCESS)
		{
			//    Positioning completion processing.    
			//SendEvtMsg(COMP_EVT_CODE, "ymcCheckComplete trq");
			return 1;
		}
		else if (ret == API_BUSY)
		{
			//    Positioning process incomplete.    
			return 0;
		}
		else
		{
			//SendErrMsg(ret, "ymcCheckComplete fail");
			return -1;
		}		
	}


	return 0;
}

//***************************************************************************
// ���W�X�^�̐擪�A�h���X���擾 
ULONG	GetRegAddress(void)
{
	ULONG	ret;		// �߂�l 
	HREGISTERDATA	hIRegister, hORegister, hMonitorParam, hSettingParam, hSystemRegister;

	//**********************************************************
	// IW0000,OW0000,IW8000,OW8000,SW0000�̃��W�X�^�n���h���擾 
	//**********************************************************
	ret = ymcGetRegisterDataHandle((LPBYTE)"IW0000", &hIRegister);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataHandle fail");

		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"OW0000", &hORegister);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataHandle fail");
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"IW8000", &hMonitorParam);					// �`���l���P���j�^�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataHandle fail");
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"OW8000", &hSettingParam);					// �`���l���P�ݒ�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataHandle fail");
		return ret;
	}
	ret = ymcGetRegisterDataHandle((LPBYTE)"SW0000", &hSystemRegister);					// �V�X�e�����W�X�^ 
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataHandle fail");
		return ret;
	}

	//******************************************************
	// IW0000,OW0000,IW8000,OW8000,SW0000�̐擪�A�h���X�擾 
	//******************************************************
	ret = ymcGetRegisterDataAddress(hIRegister, (LPDWORD)&pIRegister);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataAddress fail");
		return ret;
	}
	ret = ymcGetRegisterDataAddress(hORegister, (LPDWORD)&pORegister);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataAddress fail");
		return ret;
	}
	ret = ymcGetRegisterDataAddress(hMonitorParam, (LPDWORD)&pMonitorParam1);	// �`���l���P���j�^�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataAddress fail");
		return ret;
	}
	pMonitorParam2 = pMonitorParam1 + 1;

	ret = ymcGetRegisterDataAddress(hSettingParam, (LPDWORD)&pSettingParam1);	// �`���l���P�ݒ�p�����[�^ 
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataAddress fail");
		return ret;
	}
	pSettingParam2 = pSettingParam1 + 1;
	ret = ymcGetRegisterDataAddress(hSystemRegister, (LPDWORD)&pSystemRegister);	// �V�X�e�����W�X�^ 
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcGetRegisterDataAddress fail");
		return ret;
	}

	return MP_SUCCESS;
}

//***************************************************************************
int CtrlDaInit(AXIS_INFO* AxisInfo)
{
	ULONG ret;
	IO_DATA idata[1];
	USHORT ival[8];
	double v;
	AxisInfo->STCount = 1;                          //  �w�߃X�e�[�V������    
	AxisInfo->STNo[0] = 3; //  Station No.               

	ival[0] = 0x0004;
	ival[1] = 0x0000;
	//ival[2] = 0x100;
	ival[2] = 0x300;	//DA1�̃R�l�N�^�j���̂��߁ADA2�ɕύX
	ival[3] = 2;
	ival[4] = 2;
	ival[5] = 0x0000;
	ival[6] = 0x0000;
	ival[7] = 0x0000;
	idata[0].Size = 8;
	idata[0].pIoBuffer = (void*)ival;

	ret = ymcSetIoData(AxisInfo, idata);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcSetIoData fail");
		return -1;
	}

	ival[0] = 0x0004;//DA�@�o�͐ݒ�
	ival[1] = 0x0000;
	//ival[2] = 0x200;
	ival[2] = 0x400;	//DA1�̃R�l�N�^�j���̂��߁ADA3�ɕύX
	ival[3] = 2;
	ival[4] = 2;     //DA�@�o�͐ݒ� 0�`10V
	ival[5] = 0x0000;
	ival[6] = 0x0000;
	ival[7] = 0x0000;
	idata[0].Size = 8;
	idata[0].pIoBuffer = (void*)ival;

	ret = ymcSetIoData(AxisInfo, idata);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcSetIoData fail");
		return -1;
	}

	double v0 = (double)DA_INITIA_LVALUE / 10000.0;
	double v1 = (double)DA_INITIA_LVALUE / 10000.0;

	return CtrlDA(AxisInfo, v0, v1);
}

//***************************************************************************
int CtrlDA(AXIS_INFO* AxisInfo, double axis1, double axis2)
{
	ULONG ret;
	IO_DATA idata[1];
	USHORT ival[8];
	LONG v;

	if (axis1 < -1.0) {
		axis1 = -1.0;
	}
	if (axis1 > 1.0) {
		axis1 = 1.0;
	}
	if (axis2 < -1.0) {
		axis2 = -1.0;
	}
	if (axis2 > 1.0) {
		axis2 = 1.0;
	}

	ival[0] = 0x2000;//DA�o�̓R�}���h
	ival[1] = 0x0000;
	//ival[2] = 0x0000;
	//ival[3] = 0x0000;
	v = (LONG)(((axis1 / 2.0) * FINEX_GAIN + FINEX_OFFSET) * (double)DA_FULLSCALE);
	if (v < 0)v = 0;
	else if (v > 0x7fff)v = 0x7fff;
	ival[4] = (USHORT)v;	//DA1�̃R�l�N�^�j���̂��߁ADA2��ch0���o�́B
	v = (LONG)(((axis2 / 2.0) * FINEY_GAIN + FINEY_OFFSET) * (double)DA_FULLSCALE);
	if (v < 0)v = 0;
	else if (v > 0x7fff)v = 0x7fff;
	ival[5] = (USHORT)v;	//DA1�̃R�l�N�^�j���̂��߁ADA3��ch1���o�́B
	ival[2] = ival[4];
	ival[3] = ival[5];
	ival[6] = 0x0000;
	ival[7] = 0x0000;
	idata[0].Size = 8;
	idata[0].pIoBuffer = (void*)ival;
	AxisInfo->STCount = 1;                          //  �w�߃X�e�[�V������    
	AxisInfo->STNo[0] = 3; //  Station No.               


	ret = ymcSetIoData(AxisInfo, idata);
	if (ret != MP_SUCCESS)
	{
		//SendErrMsg(ret, "ymcSetIoData fail");
		return -1;
	}
	return 0;
}

int ServoSetVelocityUnit() {

	pSettingParam1->SV.func_1 = (pSettingParam1->SV.func_1 & FUNC1_VELUNIT_MASK) | FUNC1_VELUNIT_SEC;
	pSettingParam2->SV.func_1 = (pSettingParam2->SV.func_1 & FUNC1_VELUNIT_MASK) | FUNC1_VELUNIT_SEC;

	return 0;
}

int setupHomePosition() {
	ULONG ret;
	AXIS_INFO AxisInfo;
	MOTION_DATA MotionData[AXIS_NUM];
	HOMEPOS_DATA HomePosData[AXIS_NUM];

	AxisInfo.SlotNo = SLOT1;
	AxisInfo.ChannelNo = CHANNEL1;
	AxisInfo.MotionFunc = MODULE_SVC32;
	AxisInfo.STCount = AXIS_NUM;

	for (int StationNo = 0; StationNo < AXIS_NUM; StationNo++) {
		AxisInfo.STNo[StationNo] = StationNo + 1;
		MotionData[StationNo].VelocityUnit = 0;
		MotionData[StationNo].AccUnit = 0;
		MotionData[StationNo].FilterType = 0;
		MotionData[StationNo].Accel = 10000;
		MotionData[StationNo].Decel = 10000;
		MotionData[StationNo].FilterValue = 0;
		MotionData[StationNo].PsetWidth = 10;
		MotionData[StationNo].TrqUnit = 0;
		MotionData[StationNo].TrqLimit = 6000;

		HomePosData[StationNo].ZretMode = 3;
		HomePosData[StationNo].StartDirection = 1;
		HomePosData[StationNo].Velocity = 10;
		HomePosData[StationNo].ApproachSpeed = 10;
		HomePosData[StationNo].CreepSpeed = 10;
		HomePosData[StationNo].ZretDecDist = 10;
	}

	ret = ymcMoveHomePosition(&AxisInfo, MotionData, HomePosData);
	if (ret != MP_SUCCESS) {
		//SendErrMsg(ret, "ymcSetIoData fail");
		return -1;
	}
	return 0;
}

void ServoEnable(int onoff)
{
	if (onoff == SERVO_ON)
	{
		servo1_enable = TRUE;
		servo2_enable = TRUE;
	}
	else
	{
		servo1_enable = FALSE;
		servo2_enable = FALSE;

	}
}