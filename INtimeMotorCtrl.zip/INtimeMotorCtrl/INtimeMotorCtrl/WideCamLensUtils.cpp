#include "WideCamLensUtils.h"
#include "stdio.h"


double WideCamLensUtils::xRawMagnificationToRadAngleResolution(double xRawMagnification) {
	return RAD_ANGLE_RESOLUTION_AT_RAW_X1 / xRawMagnification;
}

uint16_t WideCamLensUtils::xRawMagnificationToHex(double rawMagnification) {
	int32_t tableSearchStep = (ZOMM_COMMAND_TO_RAW_MAGNIFICATION_TABLE_LENGTH - 1) / 2;
	int32_t pivot = tableSearchStep;

	while (tableSearchStep > 1) {
		tableSearchStep /= 2;

		if (ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[pivot] <= rawMagnification) {
			pivot += tableSearchStep;
		}
		else {
			pivot -= tableSearchStep;
		}
	}

	if (ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[pivot] > rawMagnification) {
		pivot -= 1;
	}

	double tableFloor = ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[pivot];
	double tableCeil = ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[pivot+1];
	double magOffset = rawMagnification - tableFloor;
	
	int32_t command = (int32_t)(0x1000 * (pivot + magOffset / (tableCeil - tableFloor)));

	if (command < 0) {
		command = 0;
	}
	if (command > 0xFFFF) {
		command = 0xFFFF;
	}

	return (uint16_t)command;

}

double WideCamLensUtils::hexToXRawMagnification(uint16_t zoomCommand) {
	int32_t index = zoomCommand >> 12;
	int32_t offset = zoomCommand & 0x0FFF;

	double tableFloor = ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[index];
	double tableCeil = ZOOM_COMMAND_TO_RAW_MAGNIFICATION_TABLE[index + 1];

	return (tableCeil - tableFloor)* offset / 0x1000 + tableFloor;
}

uint16_t WideCamLensUtils::xMagnificationToHex(double magnification) {
	return xRawMagnificationToHex(magnification * (MM_FLENGTH_AT_X1 / MM_WIDE_END_FLENGTH));
}

double WideCamLensUtils::hexToXMagnification(uint16_t zoomCommand) {
	return hexToXRawMagnification(zoomCommand) / (MM_FLENGTH_AT_X1 / MM_WIDE_END_FLENGTH);
}

uint16_t WideCamLensUtils::radarRangeToZoomCommand(double mRange) {
	if (mRange < RADAR_TO_ZOOM_FLOOR_RANGE) {
		return RADAR_TO_ZOOM_COMMAND_FLOOR;
	}
	else if (RADAR_TO_ZOOM_CEIL_RANGE < mRange) {
		return RADAR_TO_ZOOM_COMMAND_CEIL;
	}
	else {
		return (RADAR_TO_ZOOM_COMMAND_CEIL - RADAR_TO_ZOOM_COMMAND_FLOOR) / (RADAR_TO_ZOOM_CEIL_RANGE - RADAR_TO_ZOOM_FLOOR_RANGE) * (mRange-RADAR_TO_ZOOM_FLOOR_RANGE);
	}
}


double WideCamLensUtils::xZoomToRadVFov(double zoom) {
	return xZoomToRadPerPixel(zoom) * SENSOR_RESOLUTION_Y;
}

double WideCamLensUtils::xZoomToRadPerPixel(double zoom) {
	double xRawZoom = (zoom * (MM_FLENGTH_AT_X1 / MM_WIDE_END_FLENGTH));
	return RAD_ANGLE_RESOLUTION_AT_RAW_X1/xRawZoom;
}

uint16_t WideCamLensUtils::targetSizeToZoomCommand(uint16_t width, uint16_t height, double xCurrentZoom) {
	uint16_t size = width > height ? width : height;
	double ratio = PX_PREFFERED_TARGET_SIZE / size;
	if (1/PREFFERED_TARGET_SIZE_MARGIN < ratio && ratio < PREFFERED_TARGET_SIZE_MARGIN) {
		return xCurrentZoom;
	}
	double xZoom = xCurrentZoom * ratio;
	return xMagnificationToHex(xZoom);
}

uint16_t WideCamLensUtils::mFocusToHex(double mFocus) {
	if (mFocus < FOCUS_COMMAND_TO_M_FOCUS_TABLE[0]) { //0x0000 - 0xC000
		if (mFocus < 0) {
			return 0;
		}
		else {
			return (uint16_t)(FOCUS_COMMAND_OFFSET * mFocus / FOCUS_COMMAND_TO_M_FOCUS_TABLE[0]);
		}
	}
	else if(mFocus > FOCUS_COMMAND_TO_M_FOCUS_TABLE[FOCUS_COMMAND_TO_M_FOCUS_TABLE_LENGTH-1]){	//0xFFFF
		return 0xFFFF;
	}else{	//0xC000 - 0xFFFF
		int32_t tableSearchStep = (FOCUS_COMMAND_TO_M_FOCUS_TABLE_LENGTH - 1) / 2;
		int32_t pivot = tableSearchStep;

		while (tableSearchStep > 1) {
			tableSearchStep /= 2;

			if (FOCUS_COMMAND_TO_M_FOCUS_TABLE[pivot] <= mFocus) {
				pivot += tableSearchStep;
			}
			else {
				pivot -= tableSearchStep;
			}
		}

		if (FOCUS_COMMAND_TO_M_FOCUS_TABLE[pivot] > mFocus) {
			pivot -= 1;
		}

		double tableFloor = FOCUS_COMMAND_TO_M_FOCUS_TABLE[pivot];
		double tableCeil = FOCUS_COMMAND_TO_M_FOCUS_TABLE[pivot + 1];
		double focusOffset = mFocus - tableFloor;

		int32_t command = (int32_t)(0x400 * (pivot + focusOffset / (tableCeil - tableFloor)) + FOCUS_COMMAND_OFFSET);

		if (command < 0) {
			command = 0;
		}
		if (command > 0xFFFF) {
			command = 0xFFFF;
		}

		return (uint16_t)command;
	}
}

double WideCamLensUtils::hexToMFocus(uint16_t focusCommand) {
	if (focusCommand >= FOCUS_COMMAND_OFFSET) {	//0xC000 - 0xFFFF
		int32_t index = (focusCommand - FOCUS_COMMAND_OFFSET) >> 10;
		int32_t offset = focusCommand & 0x03FF;

		double tableFloor = FOCUS_COMMAND_TO_M_FOCUS_TABLE[index];
		double tableCeil = FOCUS_COMMAND_TO_M_FOCUS_TABLE[index + 1];
		return (tableCeil - tableFloor) * offset / 0x400 + tableFloor;
	}
	else {	//0x0000 - 0xC000
		return (1.0 * FOCUS_COMMAND_TO_M_FOCUS_TABLE[0]) / FOCUS_COMMAND_OFFSET * focusCommand;
	}
	
}

