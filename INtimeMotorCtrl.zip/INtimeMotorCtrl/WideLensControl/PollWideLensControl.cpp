/*****************************************************************************
* Poll1.c - �|�[�����O�̂��߂̃��W���[�� Poll1
\*****************************************************************************/

extern "C" {
#include <rt.h>
#include <comm.h>
}

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "WideLensControl.h"
#include "RtSharedMemory.h"


/*****************************************************************************
* FUNCTION:		Poll1
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll1
\*****************************************************************************/

static const char* COMM_NAME = "COM1";
static constexpr int32_t BUFFER_SIZE = 32;

uint8_t readBuffer[BUFFER_SIZE];
uint8_t writeBuffer[BUFFER_SIZE];

enum class CommandError {
	OK,
	Timeout,
	ChecksumError,
	UnexpectedResponse,
	CommError,
};

const char* CommandErrorToStr(CommandError commandError) {
	if (commandError == CommandError::OK) {
		return "OK";
	}
	else if (commandError == CommandError::Timeout) {
		return "Timeout";
	}
	else if (commandError == CommandError::ChecksumError) {
		return "Checksum Error";
	}
	else if (commandError == CommandError::UnexpectedResponse) {
		return "Unexpected Response";
	}
	else if (commandError == CommandError::CommError) {
		return "Comm Error";
	}
	else {
		return "Undefined Error";
	}
}

int32_t checkChecksum(uint8_t* buffer, int32_t dataLength) {//dataLength includes checksum
	int8_t checksum = 0;
	for (int i = 0; i < dataLength; i++) {
		checksum += buffer[i];
	}
	return checksum == 0;
}

uint8_t calcChecksum(uint8_t* buffer, int32_t dataLength) {//dataLength includes checksum
	int8_t checksum = 0;
	for (int i = 0; i < dataLength - 1; i++) {
		checksum += buffer[i];
	}
	return -checksum;
}

CommandError readWrite(COMMHANDLE comm, uint8_t* writeData, int32_t writeDataLength,uint8_t* readBuffer, int32_t readDataLength) {
	DWORD bytesWritten;

	if (WriteComm(comm, (LPVOID)writeData, writeDataLength, &bytesWritten, 0) == 0) {
		fprintf(stderr, "Comm write fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}
	if (bytesWritten != writeDataLength) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}

	DWORD bytesRead;
	if (ReadComm(comm, readBuffer, readDataLength, &bytesRead, 0) == 0) {
		fprintf(stderr, "Comm raed fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::CommError;
	}

	if (bytesRead != readDataLength) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::Timeout;
	}

	return CommandError::OK;
}

CommandError setZoom(COMMHANDLE comm,uint16_t zoomPos) {
	writeBuffer[0] = 0x02;
	writeBuffer[1] = 0x21;
	writeBuffer[2] = zoomPos >> 8;
	writeBuffer[3] = zoomPos & 0xFF;
	writeBuffer[4] = calcChecksum(writeBuffer, 5);
	writeBuffer[5] = 0x0A;
	writeBuffer[6] = 0x0B;
	writeBuffer[7] = 0x0C;
	writeBuffer[8] = 0x0D;

	CommandError rwRet = readWrite(comm, writeBuffer, 5, readBuffer, 3);
	if (rwRet != CommandError::OK) {
		return rwRet;
	}

	if (readBuffer[0] != 0x00 ||
		readBuffer[1] != 0x21 ||
		readBuffer[2] != 0xDF) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}

	return CommandError::OK;
}

CommandError setFocus(COMMHANDLE comm, uint16_t focusPos) {
	writeBuffer[0] = 0x02;
	writeBuffer[1] = 0x22;
	writeBuffer[2] = focusPos >> 8;
	writeBuffer[3] = focusPos & 0xFF;
	writeBuffer[4] = calcChecksum(writeBuffer, 5);

	CommandError rwRet = readWrite(comm, writeBuffer, 5, readBuffer, 3);
	if (rwRet != CommandError::OK) {
		return rwRet;
	}

	if (readBuffer[0] != 0x00 ||
		readBuffer[1] != 0x22 ||
		readBuffer[2] != 0xDE) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}

	return CommandError::OK;
}

CommandError setIris(COMMHANDLE comm, uint16_t irisPos) {
	writeBuffer[0] = 0x02;
	writeBuffer[1] = 0x20;
	writeBuffer[2] = irisPos >> 8;
	writeBuffer[3] = irisPos & 0xFF;
	writeBuffer[4] = calcChecksum(writeBuffer, 5);

	CommandError rwRet = readWrite(comm, writeBuffer, 5, readBuffer, 3);
	if (rwRet != CommandError::OK) {
		return rwRet;
	}

	if (readBuffer[0] != 0x00 ||
		readBuffer[1] != 0x20 ||
		readBuffer[2] != 0xE0) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}
	return CommandError::OK;
}

CommandError setSwitch2Control(COMMHANDLE comm, uint8_t irisRemote,uint8_t videoLevelSerial) {
	writeBuffer[0] = 0x01;
	writeBuffer[1] = 0x42;
	if (irisRemote) {
		writeBuffer[2] = 0x10;
	}
	if (videoLevelSerial) {
		writeBuffer[2] |= 0x01;
	}
	
	writeBuffer[3] = calcChecksum(writeBuffer, 4);

	CommandError rwRet = readWrite(comm, writeBuffer, 4, readBuffer, 3);
	if (rwRet != CommandError::OK) {
		return rwRet;
	}

	if (readBuffer[0] != 0x00 ||
		readBuffer[1] != 0x42 ||
		readBuffer[2] != 0xBE) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}

	return CommandError::OK;
}

CommandError setSwitch0Control(COMMHANDLE comm, uint8_t visibleCutFilterOn) {
	writeBuffer[0] = 0x01;
	writeBuffer[1] = 0x40;
	if (visibleCutFilterOn) {
		writeBuffer[2] = 0xF0;
	}
	else {
		writeBuffer[2] = 0xE0;
	}
	writeBuffer[3] = calcChecksum(writeBuffer, 4);

	CommandError rwRet = readWrite(comm, writeBuffer, 4, readBuffer, 3);
	if (rwRet != CommandError::OK) {
		return rwRet;
	}

	if (readBuffer[0] != 0x00 ||
		readBuffer[1] != 0x40 ||
		readBuffer[2] != 0xC0) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}

	return CommandError::OK;
}

CommandError readZoom(COMMHANDLE comm, uint16_t* zoom) {
	writeBuffer[0] = 0x00;
	writeBuffer[1] = 0x31;
	writeBuffer[2] = calcChecksum(writeBuffer, 3);

	CommandError rwRet = readWrite(comm, writeBuffer, 3, readBuffer, 5);

	if (readBuffer[0] != 0x02 ||
		readBuffer[1] != 0x31) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}

	*zoom = readBuffer[2] << 8 | readBuffer[3];

	return CommandError::OK;
}

CommandError readFocus(COMMHANDLE comm, uint16_t* focus) {
	writeBuffer[0] = 0x00;
	writeBuffer[1] = 0x32;
	writeBuffer[2] = calcChecksum(writeBuffer, 3);

	CommandError rwRet = readWrite(comm,writeBuffer, 3,readBuffer,5);

	if (readBuffer[0] != 0x02 ||
		readBuffer[1] != 0x32) {
		PurgeComm(comm, PURGE_RXCLEAR | PURGE_TXCLEAR);
		return CommandError::UnexpectedResponse;
	}

	*focus = readBuffer[2] << 8 | readBuffer[3];

	return CommandError::OK;
}

void				PollWideLensControl(
	void* param)
{
	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPoll1 = GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPoll1, (LPSTR)"WideLens");

	LPCSTR tmp = COMM_NAME;
	COMMHANDLE comm = OpenComm(COMM_NAME, 0);
	if (comm == INVALID_COMM_HANDLE) {
		printf("WideCamLens comm port open fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<WideCamLensCommand> wideCamLensCommand;
	RtSharedMemory<WideCamLensStatus> wideCamLensStatus;

	knRtSleep(UsecsToKticks(100000));

	while (!gInit.bShutdown && bootParameters.setup(BOOT_PARAMETER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	while (!gInit.bShutdown && wideCamLensCommand.setup(WIDE_LENS_COMMAND_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	while (!gInit.bShutdown && wideCamLensStatus.setup(WIDE_LENS_STATUS_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);
		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}

	OperationMode operationMode = bootParameters.getBuf()->operationMode;


	COMMCONFIG config;
	config.dwSize = sizeof(config);
	config.wVersion = 1;
	config.wReserved = 0;
	config.dwProviderSubType = PST_RS232;
	config.dwProviderOffset = 0;
	config.dwProviderSize = 0;
	config.wcProviderData[0] = 0;
	config.dcb.DCBlength = sizeof(config.dcb);
	config.dcb.BaudRate = CBR_38400;
	config.dcb.fBinary = TRUE;
	config.dcb.fParity = FALSE;
	config.dcb.fOutxCtsFlow = FALSE;
	config.dcb.fOutxDsrFlow = FALSE;
	config.dcb.fDtrControl = DTR_CONTROL_DISABLE;
	config.dcb.fDsrSensitivity = FALSE;
	config.dcb.fTXContinueOnXoff = TRUE;
	config.dcb.fOutX = FALSE;
	config.dcb.fInX = FALSE;
	config.dcb.fErrorChar = FALSE;
	config.dcb.fNull = FALSE;
	config.dcb.fRtsControl = RTS_CONTROL_DISABLE;
	config.dcb.fAbortOnError = FALSE;
	config.dcb.wReserved = 0;
	config.dcb.XonLim = 255;
	config.dcb.ByteSize = 8;
	config.dcb.Parity = NOPARITY;
	config.dcb.StopBits = ONESTOPBIT;
	config.dcb.XonChar = FALSE;
	config.dcb.XoffChar = FALSE;
	config.dcb.ErrorChar = 0;
	config.dcb.EofChar = 0;
	config.dcb.EvtChar = 0;
	config.dcb.wReserved1 = 0;

	if (SetCommConfig(comm, &config, sizeof(config)) == 0) {
		printf("WideCamLens config fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	if (SetupComm(comm, BUFFER_SIZE, BUFFER_SIZE) == 0) {
		printf("WideCamLens setup comm port fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	COMMTIMEOUTS timeouts;
	timeouts.ReadIntervalTimeout = 200;//[ms]
	timeouts.ReadTotalTimeoutMultiplier = 200;//[ms] x bytes to receive
	timeouts.ReadTotalTimeoutConstant = 500;//[ms]
	timeouts.WriteTotalTimeoutMultiplier = 200;//[ms]
	timeouts.WriteTotalTimeoutConstant = 200;//[ms]

	if (SetCommTimeouts(comm, &timeouts) == 0) {
		printf("WideCamLens set timeout fail: %s(0x%04x)\n", GetRtErrorText(GetLastRtError()), GetLastRtError());
	}

	int32_t wideCamLensError = 0;

	if (operationMode == OperationMode::NORMAL) {
	//if(true){//DEBUG force Widecam Active
		CommandError ret = CommandError::Timeout;
		while ((!gInit.bShutdown) && (ret != CommandError::OK)) {
			ret = setSwitch2Control(comm, 1, 0);
		}

		ret = setSwitch0Control(comm, 0);
		if (ret != CommandError::OK) {
			wideCamLensError = 1;
		}
	}

	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(100000));

		wideCamLensCommand.copySharedToLocal(10);

		if (operationMode == OperationMode::NORMAL) {

			if (wideCamLensError) {
				wideCamLensStatus.getBuf()->focus = 0;
				wideCamLensStatus.getBuf()->zoom = 0;
				wideCamLensStatus.getBuf()->iris = 0;
			}
			else {
				CommandError ret;
				ret = setZoom(comm, wideCamLensCommand.getBuf()->zoom);
				ret = setFocus(comm, wideCamLensCommand.getBuf()->focus);
				ret = setIris(comm, wideCamLensCommand.getBuf()->iris);
				ret = readZoom(comm, &wideCamLensStatus.getBuf()->zoom);
				ret = readFocus(comm, &wideCamLensStatus.getBuf()->focus);
				wideCamLensStatus.getBuf()->iris = wideCamLensCommand.getBuf()->iris;
			}
		}
		else {
			//DEBUG force Widecam Active
			//CommandError ret;
			//ret = setZoom(comm, wideCamLensCommand.getBuf()->zoom);
			//ret = setFocus(comm, wideCamLensCommand.getBuf()->focus);
			//ret = setIris(comm, wideCamLensCommand.getBuf()->iris);
			//ret = readZoom(comm, &wideCamLensStatus.getBuf()->zoom);
			//ret = readFocus(comm, &wideCamLensStatus.getBuf()->focus);
			//wideCamLensStatus.getBuf()->iris = wideCamLensCommand.getBuf()->iris;

			wideCamLensStatus.getBuf()->zoom = wideCamLensCommand.getBuf()->zoom;
			wideCamLensStatus.getBuf()->focus = wideCamLensCommand.getBuf()->focus;
			wideCamLensStatus.getBuf()->iris = wideCamLensCommand.getBuf()->iris;
		}

		wideCamLensStatus.copyLocalToShared(10);

	}

	if (comm != INVALID_COMM_HANDLE) {
		CloseComm(comm);
	}

	// �{�X���b�h�̏I����ʒm
	gInit.htPoll1 = NULL_RTHANDLE;
}
