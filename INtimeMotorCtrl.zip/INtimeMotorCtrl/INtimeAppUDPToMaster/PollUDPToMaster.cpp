/*****************************************************************************
* Poll1.c - �|�[�����O�̂��߂̃��W���[�� Poll1
\*****************************************************************************/
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <rt.h>

#include "INtimeAppUDPToMaster.h"
#include "PollUDPToMaster.h"
#include "UdpApi.h"
#include "RtSharedMemory.h"
#include "MyRtQueue.h"

void printTurretToMasterResponse(TurretToMasterResponse* turretToMasterResponse) {
	printf("checksum: %d\n", turretToMasterResponse->checksum);
	printf("packetSize: %d\n", turretToMasterResponse->packetSize);
	printf("packetType: %d\n", turretToMasterResponse->packetType);
	printf("nradx10CoarsePos: (%d,%d,%d)\n", turretToMasterResponse->nradx10CoarsePos[0], turretToMasterResponse->nradx10CoarsePos[1], turretToMasterResponse->nradx10CoarsePos[2]);
	printf("finePos: (%d,%d)\n", turretToMasterResponse->finePos[0], turretToMasterResponse->finePos[1]);
	printf("nradx10psCoarseSpeed: (%d,%d,%d)\n", turretToMasterResponse->nradx10psCoarseSpeed[0], turretToMasterResponse->nradx10psCoarseSpeed[1], turretToMasterResponse->nradx10psCoarseSpeed[2]);
	printf("aiModes: (%d,%d)\n", turretToMasterResponse->aiModes[0], turretToMasterResponse->aiModes[1]);
	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < MAX_TARGETS; j++) {
			printf("targetIds[%d][%d]: %d\n", i, j, turretToMasterResponse->targetIds[i][j]);
		}
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("trackedTargetIndex[%d]: %d\n", i, turretToMasterResponse->trackedTargetIndex[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < MAX_TARGETS; j++) {
			printf("aiClasses[%d][%d]: %d\n", i, j, turretToMasterResponse->aiClasses[i][j]);
		}
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < MAX_TARGETS; j++) {
			printf("pxAiPoses[%d][%d]: (%d,%d)\n", i, j, turretToMasterResponse->pxAiPoses[i][j][0], turretToMasterResponse->pxAiPoses[i][j][1]);
		}
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < MAX_TARGETS; j++) {
			printf("pxAiSizes[%d][%d]: (%d,%d)\n", i, j, turretToMasterResponse->pxAiSizes[i][j][0], turretToMasterResponse->pxAiSizes[i][j][1]);
		}
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		for (int j = 0; j < NUM_JOINTS; j++) {
			printf("pxJointPoses[%d][%d]: (%d,%d)\n", i, j, turretToMasterResponse->pxJointPoses[i][j][0], turretToMasterResponse->pxJointPoses[i][j][1]);
		}
	}
	printf("selectedJoint: %d\n", turretToMasterResponse->selectedJoint);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("matchValid[%d]: %d\n", i, turretToMasterResponse->matchValid[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("pxMatchPoses[%d]: (%d,%d)\n", i, turretToMasterResponse->pxMatchPoses[i][0], turretToMasterResponse->pxMatchPoses[i][1]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("pxMatchSizes[%d]: (%d,%d)\n", i, turretToMasterResponse->pxMatchSizes[i][0], turretToMasterResponse->pxMatchSizes[i][1]);
	}
	printf("rangeFinderModeStatus: %d\n", turretToMasterResponse->rangeFinderModeStatus);
	printf("mRangeFinderDistance: %d\n", turretToMasterResponse->mRangeFinderDistance);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camGainModeStatus[%d]: %d\n", i, turretToMasterResponse->camGainModeStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camGainStatus[%d]: %d\n", i, turretToMasterResponse->dB1_10CamGainStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camZoomModeStatus[%d]: %d\n", i, turretToMasterResponse->camZoomModeStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("xCamZoomStatus[%d]: %d\n", i, turretToMasterResponse->x1_1000CamZoomStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camFov[%d]: %d\n", i, turretToMasterResponse->uradX100CamFov[i]);
	}
	printf("expandModeStatus: %d\n", turretToMasterResponse->expandModeStatus);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camIrisModeStatus[%d]: %d\n", i, turretToMasterResponse->camIrisModeStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camIrisStatus[%d]: %d\n", i, turretToMasterResponse->camIrisStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camFocusModeStatus[%d]: %d\n", i, turretToMasterResponse->camFocusModeStatus[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("mCamFocusStatus[%d]: %d\n", i, turretToMasterResponse->mmX100CamFocusStatus[i]);
	}
	printf("tilFocus: %d\n", turretToMasterResponse->uradTilDivergence);
	printf("mHelFocus: %d\n", turretToMasterResponse->mHelFocus);
	for (int i = 0; i < 1 + NUM_CAMS; i++) {
		printf("trainingModeStatus[%d]: %d\n", i, turretToMasterResponse->trainingModeStatus[i]);
	}
	printf("swingScanStatus: %d\n", turretToMasterResponse->swingScanStatus);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("recStatus[%d]: %d\n", i, turretToMasterResponse->recStatus[i]);
	}
	printf("recDecimationStatus: %d\n", turretToMasterResponse->recDecimationStatus);
	printf("coarseLimitActive: %d\n", turretToMasterResponse->coarseLimitActive);
	printf("laserRestrictedAreaStatus: %d\n", turretToMasterResponse->laserRestrictedAreaStatus);
	
	printf("coarseErrorStatus: 0x%04x\n",turretToMasterResponse->bfServoErrorStatus);
	printf("tilErrorStatus: 0x%02x\n",turretToMasterResponse->bfTilServoErrorStatus);
	printf("fineMirrorErrorStatus: 0x%02x\n",turretToMasterResponse->bfFineMirrorErrorStatus);
	printf("fineConverterErrorStatus: 0x%02x\n",turretToMasterResponse->bfRs485ConverterErrorStatus);
	printf("fineSystemErrorStatus: 0x%02x\n",turretToMasterResponse->bfTeleLensErrorStatus);
	
	printf("imageProcCommunicationStatus: %d\n", turretToMasterResponse->bfImageProcCommunicationStatus);
	printf("turretCpuTemp: %d\n", turretToMasterResponse->turretCpuTemp);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("imageProcCpuTemp[%d]: %d\n", i, turretToMasterResponse->imageProcCpuTemp[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("imageProcGpuTemp[%d]: %d\n", i, turretToMasterResponse->imageProcGpuTemp[i]);
	}
	printf("mBx100DiskRemaining: %d\n", turretToMasterResponse->MBx100DiskRemaining);
	printf("camStatus: 0x%02x\n", turretToMasterResponse->camErrorStatus);
}

void printMasterToTurretCommand(MasterToTurretCommand* masterToTurretCommand) {
	printf("\n");
	printf("-------------MasterToTurretCommand--------------\n");
	printf("checksum: %d\n", masterToTurretCommand->checksum);
	printf("packetLength: %d\n", masterToTurretCommand->packetLength);
	printf("packetType: %d\n", masterToTurretCommand->packetType);
	printf("controlMode: %d\n", masterToTurretCommand->controlMode);
	printf("manualCommand: (%d,%d)\n", masterToTurretCommand->manualCommand[0], masterToTurretCommand->manualCommand[1]);
	printf("externalSensorType: %d\n", masterToTurretCommand->externalSensorType);
	printf("unixTimeExternalSensorTimestamp: %d\n", masterToTurretCommand->unixTimeExternalSensorTimestamp);
	printf("mmExternalSensorPos: (%d,%d,%d)\n", masterToTurretCommand->mmExternalSensorPos[0], masterToTurretCommand->mmExternalSensorPos[1], masterToTurretCommand->mmExternalSensorPos[2]);
	printf("mmpsExternalSensorSpeed: (%d,%d,%d)\n", masterToTurretCommand->mmpsExternalSensorSpeed[0], masterToTurretCommand->mmpsExternalSensorSpeed[1], masterToTurretCommand->mmpsExternalSensorSpeed[2]);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("targetLock[%d]: %d\n", i, masterToTurretCommand->targetLock[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("pxTargetPos[%d]: (%d,%d)\n", i, masterToTurretCommand->pxTargetPos[i][0], masterToTurretCommand->pxTargetPos[i][1]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("pxTargetSize[%d]: (%d,%d)\n", i, masterToTurretCommand->pxTargetSize[i][0], masterToTurretCommand->pxTargetSize[i][1]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("aiModes[%d]: %d\n", i, masterToTurretCommand->aiModes[i]);
	}
	printf("aimPointMode: %d\n", masterToTurretCommand->aimPointMode);
	printf("aimPointOffset: (%d,%d)\n", masterToTurretCommand->pxAimPointOffset[0], masterToTurretCommand->pxAimPointOffset[1]);
	printf("fineMirrorMode: %d\n", masterToTurretCommand->fineMirrorMode);
	printf("fineMirrorCommand: (%d,%d)\n", masterToTurretCommand->fineMirrorCommand[0], masterToTurretCommand->fineMirrorCommand[1]);
	printf("rangeFinderCommand: %d\n", masterToTurretCommand->rangeFinderCommand);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camGainModeCommand[%d]: %d\n", i, masterToTurretCommand->camGainModeCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camGainCommand[%d]: %d\n", i, masterToTurretCommand->dB1_10CamGainCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camZoomModeCommand[%d]: %d\n", i, masterToTurretCommand->camZoomModeCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("xCamZoomCommand[%d]: %d\n", i, masterToTurretCommand->x1_1000CamZoomCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("expandModeCommand[%d]: %d\n", i, masterToTurretCommand->expandModeCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camIrisModeCommand[%d]: %d\n", i, masterToTurretCommand->camIrisModeCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camIrisCommand[%d]: %d\n", i, masterToTurretCommand->camIrisCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("camFocusModeCommand[%d]: %d\n", i, masterToTurretCommand->camFocusModeCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("mCamFocusCommand[%d]: %d\n", i, masterToTurretCommand->mmX100CamFocusCommand[i]);
	}
	printf("tilStatus: %d\n", masterToTurretCommand->tilStatus);
	printf("tilFocus: %d\n", masterToTurretCommand->uradTilDivergence);
	printf("swingScanCommand: %d\n", masterToTurretCommand->swingScanCommand);
	printf("scanZoneDesignateCommand: (%d,%d)\n", masterToTurretCommand->scanZoneDesignateCommand[0], masterToTurretCommand->scanZoneDesignateCommand[1]);
	printf("pxDesignatedScanZone: ((%d,%d),(%d,%d))\n", masterToTurretCommand->pxDesignatedScanZone[0][0], masterToTurretCommand->pxDesignatedScanZone[0][1], masterToTurretCommand->pxDesignatedScanZone[1][0], masterToTurretCommand->pxDesignatedScanZone[1][1]);
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("recCommand[%d]: %d\n", i, masterToTurretCommand->recCommand[i]);
	}
	for (int i = 0; i < NUM_CAMS; i++) {
		printf("recDecimationCommand[%d]: %d\n", i, masterToTurretCommand->recDecimationCommand[i]);
	}
	printf("shootDownOverrideCommand: %d\n", masterToTurretCommand->shootDownOverrideCommand);
	printf("shutdownRequest: %d\n", masterToTurretCommand->shutdownRequest);
	printf("auxDisplayInfo: %d\n", masterToTurretCommand->auxDisplayInfo);
	for (int i = 0; i < NUM_FRIENDLIES; i++) {
		printf("nradx10FriendlyPos[%d]: (%d,%d)\n", i, masterToTurretCommand->nradx10FriendlyPos[i][0], masterToTurretCommand->nradx10FriendlyPos[i][1]);
	}
	for (int i = 0; i < NUM_FRIENDLIES; i++) {
		printf("mFriendlyDistance[%d]: %d\n", i, masterToTurretCommand->mFriendlyDistance[i]);
	}
	printf("bfLaserRestrictedAreaValid: %d\n", masterToTurretCommand->bfLaserRestrictedAreaValid);
	for (int i = 0; i < NUM_RESTRICT_AREA; i++) {
		printf("nradx10LaserRestrictedAreaHeading[%d]: (%d,%d)\n", i, masterToTurretCommand->nradx10LaserRestrictedAreaPan[i][0], masterToTurretCommand->nradx10LaserRestrictedAreaPan[i][1]);
	}
	for (int i = 0; i < NUM_RESTRICT_AREA; i++) {
		printf("nradx10LaserRestrictedAreaPitch[%d]: (%d,%d)\n", i, masterToTurretCommand->nradx10LaserRestrictedAreaTilt[i][0], masterToTurretCommand->nradx10LaserRestrictedAreaTilt[i][1]);
	}
	for (int i = 0; i < NUM_RESTRICT_AREA; i++) {
		printf("mLaserRestrictedAreaDistance[%d]: %d\n", i, masterToTurretCommand->mLaserRestrictedAreaDistance[i]);
	}
	printf("nradx10VehicleAttitude: (%d,%d,%d)\n", masterToTurretCommand->nrad_x10VehicleAttitude[0], masterToTurretCommand->nrad_x10VehicleAttitude[1], masterToTurretCommand->nrad_x10VehicleAttitude[2]);
	printf("armStatus: %d\n", masterToTurretCommand->armStatus);
	printf("bfHelStatus: %d\n", masterToTurretCommand->bfHelStatus);
	printf("mmX100HelFocus: %d\n", masterToTurretCommand->mmX100HelFocus);
	printf("soiCamId: %d\n", masterToTurretCommand->soiCamId);
	printf("externalSensorTargetSelectionModeStatus: %d\n", masterToTurretCommand->externalSensorTargetSelectionModeStatus);
	printf("sHelTimeout: %d\n", masterToTurretCommand->sHelTimeout);
}

uint8_t calcChecksum(TurretToMasterResponse* packet) {
	uint8_t checksum = 0xFF;
	uint8_t* packetInUint8 = (uint8_t*)packet;

	for (int i = 1; i < sizeof(TurretToMasterResponse); i++) {
		checksum ^= packetInUint8[i];
	}
	return checksum;
}

int32_t checkChecksum(MasterToTurretCommand* res) {
	uint8_t checksum = 0x00;
	uint8_t* packetInUint8 = (uint8_t*)res;
	for (unsigned int i = 0; i < sizeof(MasterToTurretCommand); i++) {
		checksum ^= packetInUint8[i];
	}
	if (checksum == 0xFF) {
		return 0;
	}
	else {
		return -1;
	}
}

/*****************************************************************************
* FUNCTION:		Poll1
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll1
\*****************************************************************************/
void				PollUDPRecvFromMaster(
	void* param)
{
	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollUDPRecvFromMaster = GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollUDPRecvFromMaster, "RecvMaster");


	/////////////////////////////////////////
	// Setup shared resources.
	/////////////////////////////////////////
	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<MasterToTurretCommand> masterToTurretCommand;
	MyRtQueue<MasterToTurretCommand> m2tLoggingQueue;
	MyRtQueue<MessageLog> errorLoggingQueue;

	while (!gInit.bShutdown && bootParameters.setup(BOOT_PARAMETER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && masterToTurretCommand.setup(MASTER_TO_TURRET_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && m2tLoggingQueue.setup(MASTER_TO_TURRET_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && errorLoggingQueue.setup(ERROR_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}

	/////////////////////////////////////////////////
	// Wait for boot parameter
	/////////////////////////////////////////////////

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);

		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}


	/////////////////////////////////////////////////
	// Early exit if shutdown signal arrives.
	/////////////////////////////////////////////////
	if (gInit.bShutdown) {
		gInit.htPollUDPRecvFromMaster = NULL_RTHANDLE;
		return;
	}

	/////////////////////////////////////////////////
	// Init UDP
	/////////////////////////////////////////////////
	TY_UDP_SOCK s;
	UdpParam* udpParam = &bootParameters.getBuf()->systemParameters.masterUdpParam;
	udpapi_recv_init(&s, udpParam->recvPort);

	printf("From Master Recv Port: %s\n", udpParam->recvPort);


	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(1000));

		// TODO:  1 �~���b���ƂɌJ��Ԃ�������z�u���܂�
		int ret = udpapi_recv(&s, (unsigned char*)masterToTurretCommand.getBuf(), sizeof(MasterToTurretCommand));


		if ((ret == sizeof(MasterToTurretCommand)) && (checkChecksum(masterToTurretCommand.getBuf()) == 0)) {
			//if ((ret == sizeof(MasterToTurretCommand))) {	//�e�X�g�p�Bchecksum�𖳎�
			//printMasterToTurretCommand(masterToTurretCommand.getBuf());

			MySharedMemoryStatus shmStatus;
			shmStatus = masterToTurretCommand.copyLocalToShared(1);
			if (shmStatus == MySharedMemoryStatus::SEM_ERROR) {
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR,"Shared memory error at PollUDPRecvFromMaster\n");
			}

			MyQueueStatus queueStatus;
			queueStatus = m2tLoggingQueue.send(masterToTurretCommand.getBuf());
			if (queueStatus == MyQueueStatus::QUEUE_ERROR) {
				errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "Logging queue error at PollUDPRecvFromMaster\n");
			}
		}
		else {
			if (ret == sizeof(MasterToTurretCommand) && checkChecksum(masterToTurretCommand.getBuf()) != 0) {
				printf("checksum error at ReciveFromMaster. ReceivedChecksum: 0x%02x\n", masterToTurretCommand.getBuf()->checksum);
				printMasterToTurretCommand(masterToTurretCommand.getBuf());
			}
			else if (ret != 0) {
				printf("data length error. Expected: %d, Received: %d\n", sizeof(MasterToTurretCommand), ret);
			}
		}

	}

	printf("UdpRecvFromMaster exit\n");

	// �{�X���b�h�̏I����ʒm
	gInit.htPollUDPRecvFromMaster = NULL_RTHANDLE;
}


/*****************************************************************************
* FUNCTION:		Poll2
* DESCRIPTION:
*   �|�[�����O�X���b�h Poll2
\*****************************************************************************/
void				PollUDPSendToMaster(
	void* param)
{
	TY_UDP_SOCK s;
	TIMEVALUE    tv;

	// �{�X���b�h���������Ă��邱�Ƃ�o�^
	gInit.htPollUDPSendToMaster = GetRtThreadHandles(THIS_THREAD);

	// �X���b�h�J�^���O�A���������s�͖���
	Catalog(NULL_RTHANDLE, gInit.htPollUDPSendToMaster, "SendMaster");

	/////////////////////////////////////////
	// Setup shared resources.
	/////////////////////////////////////////
	RtSharedMemory<BootParameters> bootParameters;
	RtSharedMemory<TurretToMasterResponse> turretToMasterResponse;
	MyRtQueue<TurretToMasterResponse> t2mLoggingQueue;
	MyRtQueue<MessageLog> errorLoggingQueue;

	while (!gInit.bShutdown && bootParameters.setup(BOOT_PARAMETER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && turretToMasterResponse.setup(TURRET_TO_MASTER_SHM_NAMES) != MySharedMemoryStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && t2mLoggingQueue.setup(TURRET_TO_MASTER_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK) {
		knRtSleep(UsecsToKticks(100000));
	}
	while (!gInit.bShutdown && errorLoggingQueue.setup(ERROR_LOG_QUEUE_NAME, NO_WAIT) != MyQueueStatus::OK){
		knRtSleep(UsecsToKticks(100000));
	}


	/////////////////////////////////////////////////
	// Wait for boot parameter
	/////////////////////////////////////////////////

	while (!gInit.bShutdown) {
		bootParameters.copySharedToLocal(NO_WAIT);

		if (bootParameters.getBuf()->loadDone) {
			break;
		}
		else {
			knRtSleep(UsecsToKticks(100000));
		}
	}

	/////////////////////////////////////////////////
	// Early exit if shutdown signal arrives.
	/////////////////////////////////////////////////
	if (gInit.bShutdown) {
		gInit.htPollUDPSendToMaster = NULL_RTHANDLE;
		return;
	}

	/////////////////////////////////////////////////
	// Init UDP
	/////////////////////////////////////////////////
	UdpParam* udpParam = &bootParameters.getBuf()->systemParameters.masterUdpParam;
	udpapi_send_init(&s, udpParam->ipaddr_str, udpParam->sendPort);

	printf("To Master Send Address: %s, Port: %s\n", udpParam->ipaddr_str, udpParam->sendPort);
	

	
	while (!gInit.bShutdown)
	{
		knRtSleep(UsecsToKticks(20000));

		MySharedMemoryStatus shmStatus;
		shmStatus = turretToMasterResponse.copySharedToLocal(1);
		if (shmStatus == MySharedMemoryStatus::SEM_ERROR) {
			errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR,"Shared memory error at PollUDPSendToMaster\n");
		}
		turretToMasterResponse.getBuf()->checksum = calcChecksum(turretToMasterResponse.getBuf());

		if (udpapi_send(&s, (unsigned char*)turretToMasterResponse.getBuf(), sizeof(TurretToMasterResponse)) != 1) {
			printf("udp send error at UdpSendToMaster addr: %s, port: %s\n", udpParam->ipaddr_str, udpParam->sendPort);
		}
		
		MyQueueStatus queueStatus;
		queueStatus = t2mLoggingQueue.send(turretToMasterResponse.getBuf());
		if (queueStatus == MyQueueStatus::QUEUE_ERROR) {
			errorLoggingQueue.shutdownRequest(DEFAULT_ACTION_ON_ERROR, "Logging queue error at PollUDPSendToMaster\n");
		}

	}

	printf("UdpSendToMaster exit\n");

	// �{�X���b�h�̏I����ʒm
	gInit.htPollUDPSendToMaster = NULL_RTHANDLE;
}