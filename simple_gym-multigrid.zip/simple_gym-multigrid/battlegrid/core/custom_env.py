from __future__ import annotations

import math
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from battlegrid.multigrid.multigrid import TILE_PIXELS, Actions, Agent, Grid, Wall, World, WorldObj
from battlegrid.multigrid.rendering import (
    downsample,
    fill_coords,
    highlight_img,
    point_in_rect,
    point_in_triangle,
    rotate_fn,
)
from battlegrid.multigrid.window import Window


class CustomWorld(World):
    encode_dim = 4  # : OBJECT_TO_IDX, COLOR_TO_IDX(=team), OBJECT_TO_IDX(carry)/STATE_TO_IDX, COLOR_TO_IDX(carry), DIR_TO_VEC, current_agent?

    if encode_dim == 6:
        ENC_OBJ = 0
        ENC_COL = 1
        ENC_CAROBJ = 2
        ENC_CARCOL = 3
        ENC_DIR = 4
        ENC_SELF = 5
    elif encode_dim == 4:
        ENC_OBJ = 0
        ENC_COL = 1
        ENC_CAROBJ = 2  # not use
        ENC_CARCOL = 3  # not use
        ENC_DIR = 2
        ENC_SELF = 3

    normalize_obs = 1

    # Map of color names to RGB values
    COLORS = {
        "black": np.array([0, 0, 0]),
        "blue": np.array([0, 0, 255]),
        "red": np.array([255, 0, 0]),
        "lime": np.array([0, 255, 0]),
        "aqua": np.array([0, 255, 255]),
        # "fuchsia": np.array([255, 0, 255]),
        # "yellow": np.array([255, 255, 0]),
        # "navy": np.array([0, 0, 128]),
        # "maroon": np.array([128, 0, 0]),
        # "green": np.array([0, 128, 0]),
        # "teal": np.array([0, 128, 128]),
        # "purple": np.array([128, 0, 128]),
        # "olive": np.array([128, 128, 0]),
        # "dark_gray": np.array([64, 64, 64]),
        "grey": np.array([128, 128, 128]),
    }

    COLOR_NAMES = sorted(list(COLORS.keys()))

    COLOR_TO_IDX = {
        "black": 0,
        "blue": 1,
        "red": 2,
        "lime": 3,
        "aqua": 4,
        # "fuchsia": 5,
        # "yellow": 6,
        # "navy": 7,
        # "maroon": 8,
        # "green": 9,
        # "teal": 10,
        # "purple": 11,
        # "olive": 12,
        # "dark_gray": 13,
        "grey": 14,
    }

    IDX_TO_COLOR = dict(zip(COLOR_TO_IDX.values(), COLOR_TO_IDX.keys()))

    OBJECT_TO_IDX = {
        # 'null': 0,
        "unseen": 1,
        "empty": 2,
        "wall": 3,
        # 'floor': 4,
        # 'door': 5,
        # 'key': 6,
        # 'ball': 7,
        # 'box': 8,
        # 'goal': 9,
        # 'lava': 10,
        "agent": 11,
        # 'objgoal': 12,
        # 'switch': 13,
        # 'wrecked': 14 #大破
    }

    IDX_TO_OBJECT = dict(zip(OBJECT_TO_IDX.values(), OBJECT_TO_IDX.keys()))

    STATE_TO_IDX = {
        # "null": 0,
        "open": 1,
        "closed": 2,
        "locked": 3,
    }

    DIR_TO_VEC = [
        np.array((+0, +0)),  # NULL ※これは消してはいけない!（配列としてのindexで管理しているため、right=1とするには0が必要！）
        np.array((+0, +1)),  # Pointing right (positive X)
        np.array((+1, +1)),  # right down
        np.array((+1, +0)),  # Down (positive Y)
        np.array((+1, -1)),  # left down
        np.array((+0, -1)),  # Pointing left (negative X)
        np.array((-1, -1)),  # left up
        np.array((-1, +0)),  # Up (negative Y)
        np.array((-1, +1)),  # right up
    ]

    DIR_TO_IDX = {
        # "null": 0,
        "right": 1,
        "rightdown": 2,
        "down": 3,
        "leftdown": 4,
        "left": 5,
        "leftup": 6,
        "up": 7,
        "rightup": 8,
    }

    MYSELF_TO_IDX = {
        # 'nothing':0,
        "myself": 1,
        "other": 2,
    }

    IDX_TO_MYSELF = dict(zip(MYSELF_TO_IDX.values(), MYSELF_TO_IDX.keys()))

    if encode_dim == 6:
        total_encode_dim = (
            len(OBJECT_TO_IDX)
            + len(COLOR_TO_IDX)
            + len(OBJECT_TO_IDX)
            + len(COLOR_TO_IDX)
            + len(DIR_TO_IDX)
            + len(MYSELF_TO_IDX)
        )
    elif encode_dim == 4:
        total_encode_dim = len(OBJECT_TO_IDX) + len(COLOR_TO_IDX) + len(DIR_TO_IDX) + len(MYSELF_TO_IDX)


class CustomWorldObj(WorldObj):
    def __init__(self, world, type: str, color: str):
        assert type in world.OBJECT_TO_IDX, type
        assert color in world.COLOR_TO_IDX, color
        self.type = type
        self.color = color
        self.contains = None

        # Initial position of the object
        self.init_pos = None

        # Current position of the object
        self.cur_pos = None

    def encode(self, world, current_agent=False):
        """Encode the a description of this object as a 3-tuple of integers"""
        if world.encode_dim == 6:
            return (world.OBJECT_TO_IDX[self.type], world.COLOR_TO_IDX[self.color], 0, 0, 0, 0)
        elif world.encode_dim == 4:
            return (world.OBJECT_TO_IDX[self.type], world.COLOR_TO_IDX[self.color], 0, 0)


class CustomAgent(Agent):
    def __init__(self, world, index=0, view_size=None):
        super().__init__(world=world, index=index + 1, view_size=view_size)
        # index=0 -> blue, index=1 -> red とするための+1
        self.pos = None
        self.dir = None
        self.index = index
        self.view_size = view_size
        self.carrying = None
        self.terminated = False
        self.started = True
        self.paused = False

        self.headdir = None
        self.view_cood = []
        self.viewable = []
        self.world = world

    def render(self, img):
        c = self.world.COLORS[self.color]

        if self.terminated:  # dead
            fill_coords(img, point_in_rect(0.20, 0.80, 0.20, 0.80), c)
            fill_coords(img, point_in_rect(0.00, 0.45, 0.00, 0.40), (0, 0, 0))
            fill_coords(img, point_in_rect(0.55, 1.00, 0.00, 0.40), (0, 0, 0))
            fill_coords(img, point_in_rect(0.00, 0.45, 0.50, 1.00), (0, 0, 0))
            fill_coords(img, point_in_rect(0.55, 1.00, 0.50, 1.00), (0, 0, 0))
            return
        else:
            tri_fn = point_in_triangle(
                (0.12, 0.19),
                (0.87, 0.50),
                (0.12, 0.81),
            )  # 右向き

            # Rotate the agent based on its direction
            tri_fn = rotate_fn(tri_fn, cy=0.5, cx=0.5, theta=0.25 * math.pi * (self.dir - 1))
            fill_coords(img, tri_fn, c)

    def encode(self, world, current_agent=False):
        """Encode the a description of this object as a 3-tuple of integers"""
        a = 1 if current_agent else 0

        if world.encode_dim == 6:
            if self.carrying:
                return (
                    world.OBJECT_TO_IDX[self.type],
                    world.COLOR_TO_IDX[self.color],
                    world.OBJECT_TO_IDX[self.carrying.type],
                    world.COLOR_TO_IDX[self.carrying.color],
                    self.dir,
                    a,
                )
            else:
                return (
                    world.OBJECT_TO_IDX[self.type],
                    world.COLOR_TO_IDX[self.color],
                    0,
                    0,
                    self.dir,
                    a,
                )
        elif world.encode_dim == 4:
            return (world.OBJECT_TO_IDX[self.type], world.COLOR_TO_IDX[self.color], self.dir, a)

    def can_overlap(self):
        return True

    @property
    def dir_vec(self):
        """
        Get the direction vector for the agent, pointing in the direction
        of forward movement.
        """

        assert self.dir >= 1 and self.dir < 9
        return self.world.DIR_TO_VEC[self.dir]

    @property
    def right_vec(self):
        """
        Get the vector pointing to the right of the agent.
        """

        dy, dx = self.dir_vec
        return np.array((dx, -dy))

    @property
    def front_pos(self):
        return self.pos + self.world.DIR_TO_VEC[(self.dir + 7) % 8 + 1]

    @property
    def right_front_pos(self):
        return self.pos + self.world.DIR_TO_VEC[(self.dir + 0) % 8 + 1]

    @property
    def left_front_pos(self):
        return self.pos + self.world.DIR_TO_VEC[(self.dir + 6) % 8 + 1]

    @property
    def back_pos(self):
        return self.pos + self.world.DIR_TO_VEC[(self.dir + 3) % 8 + 1]

    @property
    def right_back_pos(self):
        return self.pos + self.world.DIR_TO_VEC[(self.dir + 2) % 8 + 1]

    @property
    def left_back_pos(self):
        return self.pos + self.world.DIR_TO_VEC[(self.dir + 4) % 8 + 1]

    def get_view_coords(self, h, w):
        """
        Translate and rotate absolute grid coordinates (i, j) into the
        agent's partially observable view (sub-grid). Note that the resulting
        coordinates may be negative or outside of the agent's view size.
        """

        ay, ax = self.pos
        dy, dx = self.dir_vec
        ry, rx = self.right_vec

        # Compute the absolute coordinates of the top-left view corner
        sz = self.view_size
        hs = self.view_size // 2
        ty = ay + (dy * (sz - 1)) - (ry * hs)
        tx = ax + (dx * (sz - 1)) - (rx * hs)

        ly = h - ty
        lx = w - tx

        # Project the coordinates of the object relative to the top-left
        # corner onto the agent's own coordinate system
        vy = dx * lx + dy * ly
        vx = -(rx * lx + ry * ly)

        return vy, vx

    def get_view_exts(self):
        """
        Get the extents of the square set of tiles visible to the agent
        Note: the bottom extent indices are not included in the set
        """
        # Facing right
        if self.dir == 1:
            topY = self.pos[0] - self.view_size // 2
            topX = self.pos[1]
        # Facing down
        elif self.dir == 3:
            topY = self.pos[0]
            topX = self.pos[1] - self.view_size // 2
        # Facing left
        elif self.dir == 5:
            topY = self.pos[0] - self.view_size // 2
            topX = self.pos[1] - self.view_size + 1
        # Facing up
        elif self.dir == 7:
            topY = self.pos[0] - self.view_size + 1
            topX = self.pos[1] - self.view_size // 2
        else:
            assert False, "invalid agent direction"

        botY = topY + self.view_size - 1
        botX = topX + self.view_size - 1

        return (topY, topX, botY, botX)

    def relative_coords(self, x, y):
        """
        Check if a grid position belongs to the agent's field of view, and returns the corresponding coordinates
        """

        vy, vx = self.get_view_coords(y, x)

        if vy < 0 or vx < 0 or vy >= self.view_size or vx >= self.view_size:
            return None

        return vy, vx

    def in_view(self, y, x):
        """
        check if a grid position is visible to the agent
        """

        return self.relative_coords(x, y) is not None


class CustomWall(Wall):
    def __init__(self, world, color="grey"):
        super().__init__(world, color)
        self.world = world

    def render(self, img):
        fill_coords(img, point_in_rect(0, 1, 0, 1), self.world.COLORS[self.color])

    def encode(self, world, current_agent=False):
        """Encode the a description of this object as a 3-tuple of integers"""
        if self.world.encode_dim == 6:
            return (self.world.OBJECT_TO_IDX[self.type], self.world.COLOR_TO_IDX[self.color], 0, 0, 0, 0)
        elif self.world.encode_dim == 4:
            return (self.world.OBJECT_TO_IDX[self.type], self.world.COLOR_TO_IDX[self.color], 0, 0)


class CustomSimpleActions(Actions):
    available = ["still", "left", "right", "forward", "fire"]  # 5

    still = 0
    left = 1
    right = 2
    forward = 3
    fire = 4


class CustomActions(Actions):
    available = [
        "still",
        "left",
        "right",
        "forward",
        "fire",
        "back",
        "forwardleft",
        "forwardright",
        "backleft",
        "backright",
    ]  # 10

    still = 0
    left = 1
    right = 2
    forward = 3
    fire = 4
    back = 5
    forwardleft = 6
    forwardright = 7
    backleft = 8
    backright = 9


class CustomGrid(Grid):
    # Static cache of pre-renderer tiles
    tile_cache: dict[tuple[Any, ...], Any] = {}

    def __init__(self, height, width):
        assert height >= 1
        assert width >= 1

        self.height = height
        self.width = width

        self.grid = [None] * width * height

    def set(self, v, h, w):
        assert h >= 0 and h < self.height
        assert w >= 0 and w < self.width
        self.grid[h * self.width + w] = v

    def get(self, h, w):
        assert w >= 0 and w < self.width
        assert h >= 0 and h < self.height
        return self.grid[h * self.width + w]
        # return self.grid[h + self.width * w] #もしかしてこう?

    def horz_wall(self, world, y, x, length=None, obj_type=CustomWall):
        if length is None:
            length = self.height - y
        for i in range(0, length):
            self.set(obj_type(world), y + i, x)

    def vert_wall(self, world, y, x, length=None, obj_type=CustomWall):
        if length is None:
            length = self.height - x
        for j in range(0, length):
            self.set(obj_type(world), y, x + j)

    def wall_rect(self, y, x, h, w):
        self.horz_wall(y, x, w)
        self.horz_wall(y, x + w - 1, h)
        self.vert_wall(y, x, h)
        self.vert_wall(y + h - 1, x, w)

    def rotate_left(self):
        """
        Rotate the grid to the left (counter-clockwise)
        """

        grid = CustomGrid(self.height, self.width)

        for h in range(self.height):
            for w in range(self.width):
                v = self.get(h, w)
                grid.set(v, h, grid.width - 1 - w)

        return grid

    def slice(self, world, topY, topX, height, width):
        """
        Get a subset of the grid
        """
        grid = CustomGrid(height, width)
        # i,jはローカル座標
        for h in range(0, height):
            for w in range(0, width):
                x = topX + w  # x,yは絶対座標
                y = topY + h

                if x >= 0 and x < self.width and y >= 0 and y < self.height:
                    v = self.get(y, x)
                else:
                    v = Wall(world)

                grid.set(v, h, w)

        return grid

    @classmethod
    def render_tile(cls, world, obj, highlights=[], tile_size=TILE_PIXELS, subdivs=3):
        """
        Render a tile and cache the result
        """

        key = (*highlights, tile_size)
        key = obj.encode(world) + key if obj else key

        if key in cls.tile_cache:
            return cls.tile_cache[key]

        img = np.zeros(shape=(tile_size * subdivs, tile_size * subdivs, 3), dtype=np.uint8)

        # Draw the grid lines (top and left edges)
        fill_coords(img, point_in_rect(0, 0.031, 0, 1), (0, 100, 100))
        fill_coords(img, point_in_rect(0, 1, 0, 0.031), (0, 100, 100))

        if obj != None:
            obj.render(img)

        # Highlight the cell  if needed
        if len(highlights) > 0:
            for h in highlights:
                if h != None:
                    highlight_img(
                        img, color=world.COLORS[world.IDX_TO_COLOR[h % len(world.IDX_TO_COLOR) + 1]]
                    )  # highlightカラーも+1しておく。

        # Downsample the image to perform supersampling/anti-aliasing
        img = downsample(img, subdivs)

        # Cache the rendered tile
        cls.tile_cache[key] = img

        return img

    def render(self, world, tile_size, highlight_masks=None):
        """
        Render this grid at a given scale
        :param r: target renderer object
        :param tile_size: tile size in pixels
        """

        # Compute the total grid size
        width_px = self.width * tile_size
        height_px = self.height * tile_size

        img = np.zeros(shape=(height_px, width_px, 3), dtype=np.uint8)

        # Render the grid
        for h in range(0, self.height):
            for w in range(0, self.width):
                cell = self.get(h, w)

                # agent_here = np.array_equal(agent_pos, (i, j))
                tile_img = CustomGrid.render_tile(
                    world,
                    cell,
                    highlights=[] if highlight_masks is None else highlight_masks[h, w],
                    tile_size=tile_size,
                )

                ymin = h * tile_size
                ymax = (h + 1) * tile_size
                xmin = w * tile_size
                xmax = (w + 1) * tile_size
                img[ymin:ymax, xmin:xmax, :] = tile_img
        return img

    def encode(self, world, vis_mask=None):
        """
        Produce a compact numpy encoding of the grid
        """

        if vis_mask is None:
            vis_mask = np.ones((self.height, self.width), dtype=bool)

        array = np.zeros((world.encode_dim, self.height, self.width), dtype="uint8")

        for h in range(self.height):
            for w in range(self.width):
                if vis_mask[h, w]:
                    v = self.get(h, w)

                    if v is None:
                        array[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["empty"]
                    else:
                        array[:, h, w] = v.encode(world)

        return array

    def encode_for_agents(self, world, agent, agents, vis_mask=None):
        """Custom encode_for_agents
        changed pont
        - not sharing view area. (sharing ver is "encode_for_team")
        -
        """
        agent_obs = np.zeros((world.encode_dim, self.height, self.width), dtype="uint8")
        viewable = False

        for h in range(self.height):
            for w in range(self.width):
                if np.array_equal(agent.pos, (h, w)):  # self pos
                    if agent.terminated:  # dead
                        agent_obs[world.ENC_DIR, h, w] = agent.dir
                        agent_obs[world.ENC_SELF, h, w] = world.MYSELF_TO_IDX["myself"]
                        return agent_obs  # can't observe
                    else:  # alive -> observe myself
                        agent_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["agent"]
                        agent_obs[world.ENC_COL, h, w] = agent.index + 1
                        agent_obs[world.ENC_DIR, h, w] = agent.dir
                        agent_obs[world.ENC_SELF, h, w] = world.MYSELF_TO_IDX["myself"]
                else:  # other pos
                    viewable = False
                    if not not agent.viewable[
                        h, w
                    ]:  # not notは、None、空の文字列、空のリスト、空の辞書、またはFalseでない場合にTrueを返すため、変数が存在する場合にTrueを返すようにします。
                        viewable = True

                    v = self.get(h, w)
                    if v is None:
                        if viewable:
                            agent_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["empty"]
                        else:
                            agent_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["unseen"]
                    else:
                        if viewable:
                            if v.type == "agent":
                                for idx, a in enumerate(agents):
                                    if np.array_equal(a.pos, (h, w)):
                                        break  # (h,w)にいるagentの番号をキープ
                                if agents[idx].terminated:  # dead
                                    agent_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["empty"]  # 何もない
                                else:
                                    agent_obs[:, h, w] = v.encode(
                                        world, current_agent=np.array_equal(agent.pos, (h, w))
                                    )  # agentを記録
                                    agent_obs[world.ENC_SELF, h, w] = world.MYSELF_TO_IDX["other"]  # 「自分以外」という意味の「2」
                            else:
                                agent_obs[:, h, w] = v.encode(
                                    world, current_agent=np.array_equal(agent.pos, (h, w))
                                )  # 絶対Falseになっているはず
                        else:  # 見えない
                            if v.type == "wall":  # 見えなくても壁の位置はわかる
                                agent_obs[:, h, w] = v.encode(world, current_agent=np.array_equal(agent.pos, (h, w)))
                            else:
                                agent_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["unseen"]
        return agent_obs

    def encode_for_team(self, world, agent, agents, vis_mask=None):

        team_obs = np.zeros((world.encode_dim, self.height, self.width), dtype="uint8")
        viewable = False

        for h in range(self.height):
            for w in range(self.width):
                if np.array_equal(agent.pos, (h, w)):  # self pos
                    if agent.terminated:  # dead
                        team_obs[world.ENC_DIR, h, w] = agent.dir
                        team_obs[world.ENC_SELF, h, w] = world.MYSELF_TO_IDX["myself"]
                        return team_obs  # can't observe
                    else:  # alive -> observe myself
                        team_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["agent"]
                        team_obs[world.ENC_COL, h, w] = agent.index + 1
                        team_obs[world.ENC_DIR, h, w] = agent.dir
                        team_obs[world.ENC_SELF, h, w] = world.MYSELF_TO_IDX["myself"]
                else:  # other pos
                    viewable = False
                    for k in range(len(agents)):
                        if not not agents[k].viewable[h, w] and (
                            agent.index == agents[k].index  # team mate
                        ):  # not notは、None、空の文字列、空のリスト、空の辞書、またはFalseでない場合にTrueを返すため、変数が存在する場合にTrueを返すようにします。
                            viewable = True

                    v = self.get(h, w)
                    if v is None:
                        if viewable:
                            team_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["empty"]
                        else:
                            team_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["unseen"]
                    else:
                        if viewable:

                            if v.type == "agent":
                                for idx, a in enumerate(agents):
                                    if np.array_equal(a.pos, (h, w)):
                                        break  # (h,w)にいるagentの番号をキープ
                                if agents[idx].terminated:  # dead
                                    team_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["empty"]  # 何もない
                                else:
                                    team_obs[:, h, w] = v.encode(
                                        world, current_agent=np.array_equal(agent.pos, (h, w))
                                    )  # agentを記録
                                    team_obs[world.ENC_SELF, h, w] = world.MYSELF_TO_IDX["other"]  # 「自分以外」という意味の「2」
                            else:
                                team_obs[:, h, w] = v.encode(
                                    world, current_agent=np.array_equal(agent.pos, (h, w))
                                )  # 絶対Falseになっているはず
                        else:  # 見えない
                            if v.type == "wall":  # 見えなくても壁の位置はわかる
                                team_obs[:, h, w] = v.encode(world, current_agent=np.array_equal(agent.pos, (h, w)))
                            else:
                                team_obs[world.ENC_OBJ, h, w] = world.OBJECT_TO_IDX["unseen"]
        return team_obs

    def process_vis(grid, agent_pos):
        mask = np.zeros(shape=(grid.height, grid.width), dtype=bool)

        mask[agent_pos[0], agent_pos[1]] = True

        for h in reversed(range(0, grid.height)):
            for w in range(0, grid.width - 1):
                if not mask[h, w]:
                    continue

                cell = grid.get(h, w)
                if cell and not cell.see_behind():
                    continue

                mask[h, w + 1] = True
                if h > 0:
                    mask[h - 1, w + 1] = True
                    mask[h - 1, w] = True

            for w in reversed(range(1, grid.width)):
                if not mask[h, w]:
                    continue

                cell = grid.get(h, w)
                if cell and not cell.see_behind():
                    continue

                mask[h, w - 1] = True
                if h > 0:
                    mask[h - 1, w - 1] = True
                    mask[h - 1, w] = True

        for h in range(0, grid.height):
            for w in range(0, grid.width):
                if not mask[h, w]:
                    grid.set(None, h, w)

        return mask


class CustomWindow(Window):
    def __init__(self, title):
        self.fig = None

        self.imshow_obj = None

        # Create the figure and axes
        self.fig, self.ax = plt.subplots()

        # Show the env name in the window title
        self.ax.set_title(title)

        # Turn off x/y axis numbering/ticks
        self.ax.set_xticks([])
        self.ax.set_yticks([])

        # Flag indicating the window was closed
        self.closed = False

        def close_handler(evt):
            self.closed = True

        self.fig.canvas.mpl_connect("close_event", close_handler)
