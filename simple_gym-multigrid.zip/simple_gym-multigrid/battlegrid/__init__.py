from gym import make
from gym.envs.registration import register

register(
    id="battlegame-v0",
    entry_point="battlegrid.envs:BattleGame_debug",
)

register(
    id="battlegame-v1",
    entry_point="battlegrid.envs:BattleGame_1vs1_5x5_wall20",
)

register(
    id="battlegame-v2",
    entry_point="battlegrid.envs:BattleGame_1vs1_7x7_wall20",
)

register(
    id="battlegame-v3",
    entry_point="battlegrid.envs:BattleGame_2vs2_9x9_wall20",
)

register(
    id="battlegame-v4",
    entry_point="battlegrid.envs:BattleGame_2vs2_11x11_wall20",
)

register(
    id="battlegame-v5",
    entry_point="battlegrid.envs:BattleGame_3vs3_13x13_wall20",
)

register(
    id="battlegame-v6",
    entry_point="battlegrid.envs:BattleGame_3vs3_15x15_wall20",
)

register(
    id="mazegame-v1",
    entry_point="battlegrid.envs:MazeGame_1vs1_5x5",
)

register(
    id="mazegame-v2",
    entry_point="battlegrid.envs:MazeGame_1vs1_7x7",
)

register(
    id="mazegame-v3",
    entry_point="battlegrid.envs:MazeGame_1vs1_9x9",
)

register(
    id="mazegame-v4",
    entry_point="battlegrid.envs:MazeGame_1vs1_11x11",
)

register(
    id="mazegame-v5",
    entry_point="battlegrid.envs:MazeGame_1vs1_13x13",
)
