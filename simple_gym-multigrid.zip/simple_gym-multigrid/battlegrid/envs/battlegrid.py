import math
import random
from enum import IntEnum

import matplotlib.pyplot as plt
import numpy as np
from battlegrid.core.custom_env import (
    TILE_PIXELS,
    CustomActions,
    CustomAgent,
    CustomGrid,
    CustomSimpleActions,
    CustomWall,
    CustomWindow,
    CustomWorld,
    CustomWorldObj,
)
from battlegrid.multigrid.multigrid import MultiGridEnv
from gym import spaces
from gym.utils import seeding


class GenerateMaze:

    # Width and Height are both odd and 5 or more integers
    def __init__(self, height, width):
        self.height = height
        self.width = width
        self.maze = [list("1" * width) for _ in range(height)]

    def search_directions(self, y, x):
        directions = []
        if x - 2 > 0 and self.maze[y][x - 2] == "1":
            directions.append("L")
        if x + 2 < self.width and self.maze[y][x + 2] == "1":
            directions.append("R")
        if y - 2 > 0 and self.maze[y - 2][x] == "1":
            directions.append("U")
        if y + 2 < self.height and self.maze[y + 2][x] == "1":
            directions.append("D")
        return directions

    def dig_walls(self):
        start_y = random.choice([i for i in range(1, self.height, 2)])
        start_x = random.choice([i for i in range(1, self.width, 2)])

        self.maze[start_y][start_x] = "0"
        stack = [(start_y, start_x)]

        while stack:
            y, x = stack[-1]
            directions = self.search_directions(y, x)
            if directions == []:
                stack.pop()
                continue

            choiced = random.choice(directions)
            if choiced == "L":
                for i in range(1, 3):
                    self.maze[y][x - i] = "0"
                x -= i
            elif choiced == "R":
                for i in range(1, 3):
                    self.maze[y][x + i] = "0"
                x += i
            elif choiced == "U":
                for i in range(1, 3):
                    self.maze[y - i][x] = "0"
                y -= i
            elif choiced == "D":
                for i in range(1, 3):
                    self.maze[y + i][x] = "0"
                y += i
            stack.append((y, x))

        return self.maze


class BattleGridEnv(MultiGridEnv):
    """MultiAgentBattleSimulator
    2D grid world battle game environment
    """

    metadata = {"render.modes": ["human", "rgb_array"], "video.frames_per_second": 5}

    def __init__(
        self,
        grid_size=None,
        width=None,
        height=None,
        max_steps=100,
        see_through_walls=True,  # Falseにすると全然見えなくなる。
        seed=0,
        agents=None,
        partial_obs=False,  # 情報共有するかしないか(Trueだとしない)
        agent_view_size=None,
        objects_set=CustomWorld,
        team_num=None,
        agent_num=None,
        obstacle_rate=100,
        target_goal=False,
        init_pos_set_besides=False,
        simple_fov=True,
        simple_act=True,
        agent_view_angle=90,
        attack_range=3,
        attack_angle=60,
        r_still=0,
        r_win=1,
        r_lose=0,
        r_shot=0,
        r_got_shot=0,
        r_time=0,
        r_timeout=0.5,
        r_special1=0,
        r_special2=0,
    ):
        if agents == None:
            self.agents = []
            for t in range(team_num):
                for _ in range(agent_num):
                    self.agents.append(CustomAgent(CustomWorld, index=t, view_size=agent_view_size))
        else:
            self.agents = agents

        # Does the agents have partial or full observation?
        self.partial_obs = partial_obs

        # Can't set both grid_size and width/height
        if grid_size:
            assert width == None and height == None
            width = grid_size
            height = grid_size

        # Action enumeration for this environment
        self.simple_fov = simple_fov
        self.simple_act = simple_act
        if self.simple_act:
            self.actions = CustomSimpleActions
        else:
            self.actions = CustomActions

        # Actions are discrete integer values
        self.action_space = spaces.Discrete(len(self.actions.available))

        self.objects = objects_set

        if partial_obs:
            self.observation_space = spaces.Box(
                low=0,
                high=255,
                shape=(self.objects.total_encode_dim, agent_view_size, agent_view_size),
                dtype="uint8",
            )
        else:
            self.observation_space = spaces.Box(
                low=0, high=255, shape=(self.objects.total_encode_dim, height, width), dtype="uint8"
            )

        self.obs_dim = np.prod(self.observation_space.shape)
        self.act_dim = self.action_space.n

        # Range of possible rewards
        self.reward_range = (-1, 1)

        # Window to use for human rendering mode
        self.window = None

        # Environment configuration
        self.width = width
        self.height = height
        self.max_steps = max_steps
        self.see_through_walls = see_through_walls

        # Additional configuration
        self.team_num = team_num
        self.agent_num = agent_num
        self.obstacle_rate = obstacle_rate
        self.target_goal = target_goal
        self.init_pos_set_besides = init_pos_set_besides
        self.agent_view_angle = agent_view_angle

        # rewards
        self.r_still = r_still
        self.r_win = r_win
        self.r_lose = r_lose
        self.r_shot = r_shot
        self.r_got_shot = r_got_shot
        self.r_time = r_time
        self.r_timeout = r_timeout
        self.r_special1 = r_special1
        self.r_special2 = r_special2

        # Initialize the RNG
        self.seed(seed=seed)

        # Initialize the state
        self.reset()

    def reset(self):
        # Generate a new random grid at the start of each episode
        # To keep the same grid for each episode, call env.seed() with
        # the same seed before calling env.reset()

        self._gen_grid(self.height, self.width)

        # Item picked up, being carried, initially nothing
        for a in self.agents:
            a.carrying = None

        # Step count since episode start
        self.step_count = 0

        # Return first observation
        if self.partial_obs:
            obs = self.gen_obs()
        else:
            obs = [0 for _ in range(len(self.agents))]
            for i, agent in enumerate(self.agents):
                self._field_of_view(i)
                obs[i] = self.grid.encode_for_agents(self.objects, agent, self.agents)

        obs = [CustomWorld.normalize_obs * ob for ob in obs]
        rewards = np.zeros(self.team_num * self.agent_num)
        done = False
        info = None

        return obs, rewards, done, info

    def __str__(self):
        """
        Produce a pretty string of the environment's grid along with the agent.
        A grid cell is represented by 2-character string, the first one for
        the object and the second one for the color.
        """
        # Map of object types to short string
        OBJECT_TO_STR = {
            "wall": "W",
            "floor": "F",
            "door": "D",
            "key": "K",
            "ball": "A",
            "box": "B",
            "goal": "G",
            "lava": "V",
        }

        # Short string for opened door
        OPENDED_DOOR_IDS = "_"

        # Map agent's direction to short string
        AGENT_DIR_TO_STR = {1: ">", 2: "V", 3: "<", 4: "^"}

        str = ""

        for h in range(self.grid.height):
            for w in range(self.grid.width):
                if h == self.agent_pos[0] and w == self.agent_pos[1]:
                    str += 2 * AGENT_DIR_TO_STR[self.agent_dir]
                    continue

                c = self.grid.get(h, w)

                if c == None:
                    str += "  "
                    continue

                if c.type == "door":
                    if c.is_open:
                        str += "__"
                    elif c.is_locked:
                        str += "L" + c.color[0].upper()
                    else:
                        str += "D" + c.color[0].upper()
                    continue

                str += OBJECT_TO_STR[c.type] + c.color[0].upper()

            if h < self.grid.height - 1:
                str += "\n"
        return str

    def _gen_grid(self, height, width):
        """
        GenerateMazeクラスによってまずは迷路を作成する。
        その後obstacle_rate以下になるまで、ランダムに壁を削除していく。
        はじめに迷路を作成する理由は、agentが初期配置から動けなくなることを防ぐため。
        """
        self.grid = CustomGrid(height, width)

        maze = GenerateMaze(height, width)
        map = maze.dig_walls()  #'0'が道、'1'が壁
        while True:
            inner_area = [map[h][w] for w in range(1, width - 1) for h in range(1, height - 1)]
            if inner_area.count("1") > int(self.obstacle_rate / 100 * (width - 2) * (height - 2)):
                del_x = random.randint(1, width - 2)
                del_y = random.randint(1, height - 2)
                if (
                    map[del_y - 1][del_x] == "0"
                    or map[del_y][del_x - 1] == "0"
                    or map[del_y + 1][del_x] == "0"
                    or map[del_y][del_x + 1] == "0"
                ):
                    map[del_y][del_x] = "0"
            else:
                break

        for h in range(height):
            for w in range(width):
                if map[h][w] == "1":
                    self.place_obj(obj=CustomWall(self.objects), top=[h, w], size=[1, 1])

        # Randomize the player start position and orientation
        if self.init_pos_set_besides:
            for i, a in enumerate(self.agents):
                if i < len(self.agents) / 2:
                    self.place_agent(a, top=(1, 1), size=(self.height - 2, int((self.width - 1) / 2) - 1))
                else:
                    self.place_agent(
                        a, top=(1, int((self.width + 1) / 2)), size=(self.height - 2, int((self.width - 1) / 2) - 1)
                    )
        else:
            for a in self.agents:
                self.place_agent(a, top=(1, 1), size=(self.height, self.width))

    def _rand_int(self, low, high):
        """
        Generate random integer in [low,high]
        """

        return np.random.randint(low, high)

    def _rand_pos(self, yLow, yHigh, xLow, xHigh):
        """
        Generate a random (x,y) position tuple
        """

        return (
            self.np_random.randint(yLow, yHigh),
            self.np_random.randint(xLow, xHigh),
        )

    def place_obj(
        self,
        obj,
        top=None,
        size=None,
        reject_fn=None,
        max_tries=100,  # 壁とかがあって、設置できなかった場合のリトライ回数
    ):
        """
        Place an object at an empty position in the grid

        :param top: top-left position of the rectangle where to place
        :param size: size of the rectangle where to place
        :param reject_fn: function to filter out potential positions
        """

        if top is None:
            top = (0, 0)
        else:
            top = (max(top[0], 0), max(top[1], 0))

        if size is None:
            size = (self.grid.height - 1, self.grid.width - 1)

        else:
            num_tries = 0
            while True:
                # This is to handle with rare cases where rejection sampling
                # gets stuck in an infinite loop
                if num_tries > max_tries:
                    raise RecursionError("rejection sampling failed in place_obj")

                num_tries += 1

                pos = np.array(
                    (
                        self._rand_int(top[0], min(top[0] + size[0], self.grid.height)),
                        self._rand_int(top[1], min(top[1] + size[1], self.grid.width)),
                    )
                )

                # Don't place the object on top of another object
                if self.grid.get(*pos) != None:
                    continue

                # # Check if there is a filtering criterion
                # if reject_fn and reject_fn(self, pos):
                #     continue

                break
            self.grid.set(obj, *pos)

        if obj is not None:
            obj.init_pos = pos
            obj.cur_pos = pos

        return pos

    def put_obj(self, obj, h, w):
        """
        Put an object at a specific position in the grid
        """

        self.grid.set(obj, h, w)
        obj.init_pos = (h, w)
        obj.cur_pos = (h, w)

    def place_agent(self, agent, top=None, size=None, rand_dir=True, max_tries=math.inf):
        """
        エージェントを配置する。
        初期配置及び初期方向はランダム。
        """
        agent.pos = None
        agent.dir = None
        agent.carrying = None
        agent.terminated = False  # dead or alive
        agent.started = True
        agent.paused = False
        agent.headdir = None
        agent.view_cood = []
        agent.viewable = []

        pos = self.place_obj(agent, top, size, max_tries=max_tries)  # size=0は長さ0を意味する。
        agent.pos = pos
        agent.init_pos = pos

        if rand_dir:
            if self.simple_act:
                agent.dir = random.randrange(1, 9, 2)
            else:
                agent.dir = self._rand_int(1, 9)

        agent.init_dir = agent.dir

        return pos

    def agent_sees(self, a, y, x):
        """
        Check if a non-empty grid position is visible to the agent
        """

        coordinates = a.relative_coords(y, x)
        if coordinates is None:
            return False
        vy, vx = coordinates

        obs = self.gen_obs()
        obs_grid, _ = CustomGrid.decode(obs["image"])
        obs_cell = obs_grid.get(vy, vx)
        world_cell = self.grid.get(y, x)

    def step(self, actions):
        """
        全エージェントのaction及びobservationを返す。

        例 : team_num:2, agent_num2の場合, action, observation, rewardsは、
            [teamA_agent0, teamA_agent1, team_B_agent0, teamB_agent1]
        となる。

        各エージェントのactionの順番はランダムで実行される。
        各エージェントのactionによりobservationが変化するため、
        「撃ったと思ったら逃げられた」「撃ったらたまたま当たった」
        が起こりうる。

        infoには主要なイベント及び勝利チームidを格納している。
        例）info['win_team_id'] = 1
        例）info['reward'][2] = ['shot', 'win'] ※[2]はagentのidx番号（agent.indexではない。agent.indexはteam番号）
        例）print(info) >>> {'reward': [['lose'], ['got_shot', 'lose'], ['shot', 'win'], ['win']], 'win_team_id': 1}
        infoに格納されるのは以下の5種類
        - shot
        - got_shot
        - win
        - lose
        - timeout

        """
        assert all(action >= 0 and action < len(self.actions.available) for action in actions), actions

        info = {"reward": [], "win_team_id": None}
        for _ in range(self.team_num * self.agent_num):
            info["reward"].append([])

        self.step_count += 1

        order = np.random.permutation(self.team_num * self.agent_num)  # 行動の順番をランダム化

        obs = [
            np.zeros((CustomWorld.encode_dim, self.height, self.width)) for _ in range(self.team_num * self.agent_num)
        ]

        rewards = [0 for _ in range(self.team_num * self.agent_num)]

        done = False

        dead_agent_num = [0] * self.team_num  # チーム数で初期化

        for od in order:
            self._reward(od, rewards, self.r_time)

            if not self.agents[od].terminated and self.step_count > 0:
                # Get the position in front of the agent
                fwd_pos = self.agents[od].front_pos
                rfwd_pos = self.agents[od].right_front_pos
                lfwd_pos = self.agents[od].left_front_pos
                bwd_pos = self.agents[od].back_pos
                rbwd_pos = self.agents[od].right_back_pos
                lbwd_pos = self.agents[od].left_back_pos
                # Get the contents of the cell in front of the agent
                fwd_cell = self.grid.get(*fwd_pos)
                rfwd_cell = self.grid.get(*rfwd_pos)
                lfwd_cell = self.grid.get(*lfwd_pos)
                bwd_cell = self.grid.get(*bwd_pos)
                rbwd_cell = self.grid.get(*rbwd_pos)
                lbwd_cell = self.grid.get(*lbwd_pos)

                if actions[od] == self.actions.still:
                    self.grid.set(self.agents[od], *self.agents[od].pos)
                    self._reward(od, rewards, self.r_still, info, "still")
                elif actions[od] == self.actions.left:
                    if self.simple_act:
                        self.grid.set(self.agents[od], *self.agents[od].pos)
                        self.agents[od].dir = (self.agents[od].dir + 5) % 8 + 1
                    else:
                        self.grid.set(self.agents[od], *self.agents[od].pos)
                        self.agents[od].dir = (self.agents[od].dir + 6) % 8 + 1
                    # self._reward(od, rewards, self.r_special1, info, "left")
                elif actions[od] == self.actions.right:
                    if self.simple_act:
                        self.grid.set(self.agents[od], *self.agents[od].pos)
                        self.agents[od].dir = (self.agents[od].dir + 1) % 8 + 1
                    else:
                        self.grid.set(self.agents[od], *self.agents[od].pos)
                        self.agents[od].dir = (self.agents[od].dir + 0) % 8 + 1
                    # self._reward(od, rewards, self.r_special2, info, "right")
                elif actions[od] == self.actions.forward:
                    if fwd_cell is None or fwd_cell.can_overlap():
                        self.grid.set(self.agents[od], *fwd_pos)
                        self.grid.set(None, *self.agents[od].pos)
                        self.agents[od].pos = fwd_pos
                    self._handle_special_moves(od, rewards, fwd_pos, fwd_cell)

                # # old
                # elif actions[od] == self.actions.fire:
                #     self.grid.set(self.agents[od], *self.agents[od].pos)
                #     min_range = self.agents[od].view_size + 1
                #     target = None
                #     for j in range(len(self.agents[od].view_cood)):
                #         temp = self.grid.get(
                #             self.agents[od].view_cood[j][0],
                #             self.agents[od].view_cood[j][1],
                #         )
                #         if temp is None:
                #             None  # This code is necessary.
                #         elif temp.type == "agent" and temp.index != self.agents[od].index and not temp.terminated:
                #             # 最短距離の敵を探索する
                #             if (
                #                 min_range
                #                 > (
                #                     (self.agents[od].pos[0] - temp.pos[0]) ** 2
                #                     + (self.agents[od].pos[1] - temp.pos[1]) ** 2
                #                 )
                #                 ** 0.5
                #             ):
                #                 target = temp
                #                 min_range = (
                #                     (self.agents[od].pos[0] - temp.pos[0]) ** 2
                #                     + (self.agents[od].pos[1] - temp.pos[1]) ** 2
                #                 ) ** 0.5
                #     if target == None:
                #         None
                #     elif not target.terminated and np.random.rand() <= 1:  # とりあえず百発百中
                #         self.agents[self.agents.index(target)].terminated = True  # die
                #         self._reward(od, rewards, self.r_shot, info, "shot")
                #         self._reward(self.agents.index(target), rewards, self.r_got_shot, info, "got_shot")

                # CHANGED: 火器管制の仕様を変更した。（観測範囲内ならどこでも射撃可能だったが、観測の意味があまりないので、攻撃範囲を極小化した。）
                elif actions[od] == self.actions.fire:
                    """
                    Note:
                        攻撃可能範囲は、前方1マスのみ
                        前方1マスに敵がいなくても攻撃アクションのみはできる。
                    """
                    self.grid.set(self.agents[od], *self.agents[od].pos)
                    if fwd_cell is None:
                        None  # This code is necessary.
                    elif (
                        fwd_cell.type == "agent" and fwd_cell.index != self.agents[od].index and not fwd_cell.terminated
                    ):
                        if not fwd_cell.terminated and np.random.rand() <= 1:  # とりあえず百発百中
                            self.agents[self.agents.index(fwd_cell)].terminated = True  # kill
                            self._reward(od, rewards, self.r_shot, info, "shot")
                            self._reward(self.agents.index(fwd_cell), rewards, self.r_got_shot, info, "got_shot")

                elif actions[od] == self.actions.back:
                    if bwd_cell is None or bwd_cell.can_overlap():
                        self.grid.set(self.agents[od], *bwd_pos)
                        self.grid.set(None, *self.agents[od].pos)
                        self.agents[od].pos = bwd_pos
                    self._handle_special_moves(od, rewards, bwd_pos, bwd_cell)
                elif actions[od] == self.actions.forwardleft:
                    if lfwd_cell is None or lfwd_cell.can_overlap():
                        self.grid.set(self.agents[od], *lfwd_pos)
                        self.grid.set(None, *self.agents[od].pos)
                        self.agents[od].pos = lfwd_pos
                        self.agents[od].dir = (self.agents[od].dir + 6) % 8 + 1
                    self._handle_special_moves(od, rewards, lfwd_pos, lfwd_cell)
                elif actions[od] == self.actions.forwardright:
                    if rfwd_cell is None or rfwd_cell.can_overlap():
                        self.grid.set(self.agents[od], *rfwd_pos)
                        self.grid.set(None, *self.agents[od].pos)
                        self.agents[od].pos = rfwd_pos
                        self.agents[od].dir = (self.agents[od].dir + 0) % 8 + 1
                    self._handle_special_moves(od, rewards, rfwd_pos, rfwd_cell)
                elif actions[od] == self.actions.backleft:
                    if lbwd_cell is None or lbwd_cell.can_overlap():
                        self.grid.set(self.agents[od], *lbwd_pos)
                        self.grid.set(None, *self.agents[od].pos)
                        self.agents[od].pos = lbwd_pos
                        self.agents[od].dir = (self.agents[od].dir + 0) % 8 + 1
                    self._handle_special_moves(od, rewards, lbwd_pos, lbwd_cell)
                elif actions[od] == self.actions.backright:
                    if rbwd_cell is None or rbwd_cell.can_overlap():
                        self.grid.set(self.agents[od], *rbwd_pos)
                        self.grid.set(None, *self.agents[od].pos)
                        self.agents[od].pos = rbwd_pos
                        self.agents[od].dir = (self.agents[od].dir + 6) % 8 + 1
                    self._handle_special_moves(od, rewards, rbwd_pos, rbwd_cell)

            self._field_of_view(od)

            # obsの更新
            if not self.partial_obs:
                obs[od] = self.grid.encode_for_agents(self.objects, self.agents[od], self.agents)

            dead_agent_num[self.agents[od].index] += self.agents[od].terminated
            if dead_agent_num[self.agents[od].index] == self.agent_num:
                for od2 in order:
                    if self.agents[od].index == self.agents[od2].index:
                        self._reward(od2, rewards, self.r_lose, info, "lose")
                    else:
                        self._reward(od2, rewards, self.r_win, info, "win")
                        info["win_team_id"] = self.agents[od2].index
                done = True

        if self.step_count >= self.max_steps:
            done = True
            for a in range(self.team_num * self.agent_num):
                self._reward(a, rewards, self.r_timeout, info, "timeout")

        # obsの更新
        if self.partial_obs:
            obs = self.gen_obs()

        obs = [CustomWorld.normalize_obs * ob for ob in obs]

        return obs, rewards, done, info

    def _reward(self, agent_id, rewards, reward=0, info=None, event=None):
        """
        rewardへの加算及びinfoへの情報付与を行う。
        """
        rewards[agent_id] += reward
        if info:
            info["reward"][agent_id].append(event)

    def gen_obs_grid(self):
        """
        Generate the sub-grid observed by the agents.
        This method also outputs a visibility mask telling us which grid
        cells the agents can actually see.
        """
        grids = []
        vis_masks = []

        for a in self.agents:
            topY, topX, botY, botX = a.get_view_exts()

            grid = self.grid.slice(self.objects, topY, topX, a.view_size, a.view_size)

            for _ in range(a.dir + 1):
                grid = grid.rotate_left()

            # Process occluders and visibility
            # Note that this incurs some performance cost
            if not self.see_through_walls:
                vis_mask = grid.process_vis(agent_pos=(a.view_size // 2, a.view_size - 1))
            else:
                # vis_mask = np.ones(shape=(grid.height, grid.width), dtype=np.bool)
                vis_mask = np.ones(shape=(grid.height, grid.width), dtype=np.bool_)

            grids.append(grid)
            vis_masks.append(vis_mask)

        return grids, vis_masks

    def get_obs_render(self, obs, tile_size=TILE_PIXELS // 2):
        """
        Render an agent observation for visualization
        """
        grid, vis_mask = CustomGrid.decode(obs)

        # Render the whole grid
        img = grid.render(self.objects, tile_size, highlight_mask=vis_mask)

        return img

    def _field_of_view(self, agent_idx):
        """
        calc agent's FOV with LOS
        """
        viewable_map = {(h, w): [] for h in range(self.height) for w in range(self.width)}
        view_cood = []

        if self.agents[agent_idx].terminated:
            return

        # Compute the world coordinates of the bottom-left corner
        # of the agent's view area
        f_vec = self.agents[agent_idx].dir_vec
        r_vec = self.agents[agent_idx].right_vec

        if self.simple_fov:

            # Compute which cells are visible to the agent
            _, vis_masks = self.gen_obs_grid()

            # pos of FOV-top_left
            top_left = (
                self.agents[agent_idx].pos
                + f_vec * (self.agents[agent_idx].view_size - 1)
                - r_vec * (self.agents[agent_idx].view_size // 2)
            )

            # Mask of which cells to highlight
            # For each cell in the visibility mask
            for vis_h in range(0, self.agents[agent_idx].view_size):
                for vis_w in range(0, self.agents[agent_idx].view_size):
                    # If this cell is not visible, don't highlight it
                    if not vis_masks[agent_idx][vis_h, vis_w]:
                        continue

                    # Compute the world coordinates of this cell
                    abs_h, abs_w = top_left - (f_vec * vis_h) + (r_vec * vis_w)

                    if abs_w < 1 or abs_w >= self.width - 1:
                        continue
                    if abs_h < 1 or abs_h >= self.height - 1:
                        continue

                    # Mark this cell to be highlighted
                    viewable_map[abs_h, abs_w].append(agent_idx)
                    view_cood.append([abs_h, abs_w])

            distances = np.sqrt(
                ((np.arange(self.height) - self.agents[agent_idx].pos[0]) ** 2)[:, np.newaxis]
                + (np.arange(self.width) - self.agents[agent_idx].pos[1]) ** 2
            )

            az_center = math.atan2(f_vec[0], f_vec[1])  # -180 ~ +180
            x, y = np.meshgrid(np.arange(self.width), np.arange(self.height))
            angles = np.arctan2(y - self.agents[agent_idx].pos[0], x - self.agents[agent_idx].pos[1]) - az_center
            angles = np.remainder(angles, 2 * np.pi)
            angles[angles > np.pi] -= 2 * np.pi

        else:
            visible_area = np.zeros((self.height, self.width), dtype=bool)

            # 相対距離grid map
            distances = np.sqrt(
                ((np.arange(self.height) - self.agents[agent_idx].pos[0]) ** 2)[:, np.newaxis]
                + (np.arange(self.width) - self.agents[agent_idx].pos[1]) ** 2
            )

            # 指向角度により相対角度grid mapを作る。180度の境界処理も行う。
            az_center = math.atan2(f_vec[0], f_vec[1])  # -180 ~ +180
            x, y = np.meshgrid(np.arange(self.width), np.arange(self.height))
            angles = np.arctan2(y - self.agents[agent_idx].pos[0], x - self.agents[agent_idx].pos[1]) - az_center
            angles = np.remainder(angles, 2 * np.pi)
            angles[angles > np.pi] -= 2 * np.pi

            # 相対距離と相対角度からFOVを絞り込む。
            visible_area[
                (distances <= self.agents[agent_idx].view_size)
                & (angles <= math.radians(self.agent_view_angle / 2))
                & (angles >= -math.radians(self.agent_view_angle / 2))
            ] = True

            # 自機位置追加
            visible_area[(self.agents[agent_idx].pos[0], self.agents[agent_idx].pos[1])] = True  # self pos

            # viewable_map, view_cood, highlight_masksに追加
            h_indices, w_indices = np.where(visible_area)
            viewable_map.update(zip(zip(h_indices, w_indices), [[agent_idx]] * len(h_indices)))
            view_cood = np.transpose(np.array([h_indices, w_indices])).tolist()
            unique_indices = np.unique(list(zip(h_indices, w_indices)), axis=0)

            ### wallに対するLOS計算を行う

            # 視野全体に対する相対角度と距離
            az_center = math.atan2(f_vec[0], f_vec[1])
            view_vecs = np.array(view_cood) - np.array(self.agents[agent_idx].pos)
            view_angles = np.arctan2(view_vecs[:, 0], view_vecs[:, 1]) - az_center
            view_angles = np.remainder(view_angles, 2 * np.pi)
            view_angles[view_angles > np.pi] -= 2 * np.pi
            view_distances = np.linalg.norm(view_vecs, axis=1)

            del_idcs = np.array([])

            for cood_num, cood in enumerate(view_cood):  # coodはwallの座標

                grid_temp = self.grid.get(cood[0], cood[1])

                if grid_temp == None:
                    continue
                elif grid_temp.type == "wall":

                    # wallを除外
                    row, col = cood
                    viewable_map[(row, col)] = []
                    del_idcs = np.append(del_idcs, cood_num)

                    # wall中心へのベクトル、角度、距離
                    vec2wall = np.array(cood) - np.array(self.agents[agent_idx].pos)
                    angle2wall = np.arctan2(vec2wall[0], vec2wall[1]) - az_center
                    angle2wall = np.remainder(angle2wall, 2 * np.pi)
                    if angle2wall > np.pi:
                        angle2wall -= 2 * np.pi
                    distance2wall = np.sqrt(
                        (cood[0] - self.agents[agent_idx].pos[0]) ** 2 + (cood[1] - self.agents[agent_idx].pos[1]) ** 2
                    )

                    # gridに対する接点の場合分け
                    rd = (0.5, 0.5)  # right down vec
                    ru = (-0.5, 0.5)  # right up vec
                    ld = (0.5, -0.5)  # left down vec
                    lu = (-0.5, -0.5)  # left up vec
                    if self.agents[agent_idx].pos[0] == cood[0]:
                        if self.agents[agent_idx].pos[1] > cood[1]:  # 相対位置 : wallの右
                            vec_r = vec2wall + ru
                            vec_l = vec2wall + rd
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左
                            vec_r = vec2wall + ld
                            vec_l = vec2wall + lu
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                    elif self.agents[agent_idx].pos[0] > cood[0]:
                        if self.agents[agent_idx].pos[1] == cood[1]:  # 相対位置 : wallの下
                            vec_r = vec2wall + rd
                            vec_l = vec2wall + ld
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        elif self.agents[agent_idx].pos[1] > cood[1]:  # 相対位置 : wallの右下
                            vec_r = vec2wall + ru
                            vec_l = vec2wall + ld
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左下
                            vec_r = vec2wall + rd
                            vec_l = vec2wall + lu
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                    else:
                        if self.agents[agent_idx].pos[1] == cood[1]:  # 相対位置 : wallの上
                            vec_r = vec2wall + lu
                            vec_l = vec2wall + ru
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        elif self.agents[agent_idx].pos[1] > cood[1]:  # 相対位置 : wallの右上
                            vec_r = vec2wall + lu
                            vec_l = vec2wall + rd
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左上
                            vec_r = vec2wall + ld
                            vec_l = vec2wall + ru
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )

                    # 見えない位置を探索
                    for cood_num2, cood2 in enumerate(view_cood):  # cood_num2はwallの背後に位置し、見えなくなる座標の順番
                        if (
                            view_distances[cood_num2] >= distance2wall
                            and view_angles[cood_num2] <= angle2wall + theta_r
                            and view_angles[cood_num2] >= angle2wall - theta_l
                        ):
                            # 見えない部分を除外
                            del_idcs = np.append(del_idcs, cood_num2)
                            row, col = cood2
                            viewable_map[(row, col)] = []

            if not del_idcs.all():
                view_cood = np.array(view_cood)
                view_cood = np.delete(view_cood, del_idcs.astype(int), axis=0)

        self.agents[agent_idx].viewable = viewable_map
        self.agents[agent_idx].view_cood = view_cood

    def _field_of_views(self):
        """
        calc agent's FOV with LOS
        """

        highlight_masks = {(h, w): [] for h in range(self.height) for w in range(self.width)}

        for i, a in enumerate(self.agents):
            viewable_map = {(h, w): [] for h in range(self.height) for w in range(self.width)}
            view_cood = []

            if a.terminated:
                continue

            # Compute the world coordinates of the bottom-left corner
            # of the agent's view area
            f_vec = a.dir_vec

            r_vec = a.right_vec

            if self.simple_fov:

                # Compute which cells are visible to the agent
                _, vis_masks = self.gen_obs_grid()

                # pos of FOV-top_left
                top_left = a.pos + f_vec * (a.view_size - 1) - r_vec * (a.view_size // 2)

                # Mask of which cells to highlight
                # For each cell in the visibility mask
                for vis_h in range(0, a.view_size):
                    for vis_w in range(0, a.view_size):
                        # If this cell is not visible, don't highlight it
                        if not vis_masks[i][vis_h, vis_w]:
                            continue

                        # Compute the world coordinates of this cell
                        abs_h, abs_w = top_left - (f_vec * vis_h) + (r_vec * vis_w)

                        if abs_w < 1 or abs_w >= self.width - 1:
                            continue
                        if abs_h < 1 or abs_h >= self.height - 1:
                            continue

                        # Mark this cell to be highlighted
                        highlight_masks[abs_h, abs_w].append(i)
                        viewable_map[abs_h, abs_w].append(i)
                        view_cood.append([abs_h, abs_w])

                distances = np.sqrt(
                    ((np.arange(self.height) - a.pos[0]) ** 2)[:, np.newaxis] + (np.arange(self.width) - a.pos[1]) ** 2
                )

                az_center = math.atan2(f_vec[0], f_vec[1])  # -180 ~ +180
                x, y = np.meshgrid(np.arange(self.width), np.arange(self.height))
                angles = np.arctan2(y - a.pos[0], x - a.pos[1]) - az_center
                angles = np.remainder(angles, 2 * np.pi)
                angles[angles > np.pi] -= 2 * np.pi
            else:
                visible_area = np.zeros((self.height, self.width), dtype=bool)

                # 相対距離grid map
                distances = np.sqrt(
                    ((np.arange(self.height) - a.pos[0]) ** 2)[:, np.newaxis] + (np.arange(self.width) - a.pos[1]) ** 2
                )

                # 指向角度により相対角度grid mapを作る。180度の境界処理も行う。
                az_center = math.atan2(f_vec[0], f_vec[1])  # -180 ~ +180
                x, y = np.meshgrid(np.arange(self.width), np.arange(self.height))
                angles = np.arctan2(y - a.pos[0], x - a.pos[1]) - az_center
                angles = np.remainder(angles, 2 * np.pi)
                angles[angles > np.pi] -= 2 * np.pi

                # 相対距離と相対角度からFOVを絞り込む。
                visible_area[
                    (distances <= a.view_size)
                    & (angles <= math.radians(self.agent_view_angle / 2))
                    & (angles >= -math.radians(self.agent_view_angle / 2))
                ] = True

                # 自機位置追加
                visible_area[(a.pos[0], a.pos[1])] = True  # self pos

                # viewable_map, view_cood, highlight_masksに追加
                h_indices, w_indices = np.where(visible_area)
                viewable_map.update(zip(zip(h_indices, w_indices), [[i]] * len(h_indices)))
                view_cood = np.transpose(np.array([h_indices, w_indices])).tolist()
                unique_indices = np.unique(list(zip(h_indices, w_indices)), axis=0)
                for h, w in unique_indices:
                    if (h, w) in highlight_masks:
                        highlight_masks[(h, w)].append(i)

            # wallに対するLOS計算を行う

            # 視野全体に対する相対角度と距離
            az_center = math.atan2(f_vec[0], f_vec[1])
            view_vecs = np.array(view_cood) - np.array(a.pos)
            view_angles = np.arctan2(view_vecs[:, 0], view_vecs[:, 1]) - az_center
            view_angles = np.remainder(view_angles, 2 * np.pi)
            view_angles[view_angles > np.pi] -= 2 * np.pi
            view_distances = np.linalg.norm(view_vecs, axis=1)

            del_idcs = np.array([])

            for cood_num, cood in enumerate(view_cood):  # coodはwallの座標

                grid_temp = self.grid.get(cood[0], cood[1])

                if grid_temp == None:
                    continue
                elif grid_temp.type == "wall":

                    # wallを除外
                    row, col = cood
                    highlight_masks[(row, col)] = [val for val in highlight_masks[(row, col)] if val != i]
                    viewable_map[(row, col)] = []
                    del_idcs = np.append(del_idcs, cood_num)

                    # wall中心へのベクトル、角度、距離
                    vec2wall = np.array(cood) - np.array(a.pos)
                    angle2wall = np.arctan2(vec2wall[0], vec2wall[1]) - az_center
                    angle2wall = np.remainder(angle2wall, 2 * np.pi)
                    if angle2wall > np.pi:
                        angle2wall -= 2 * np.pi
                    distance2wall = np.sqrt((cood[0] - a.pos[0]) ** 2 + (cood[1] - a.pos[1]) ** 2)

                    # gridに対する接点の場合分け
                    rd = (0.5, 0.5)  # right down vec
                    ru = (-0.5, 0.5)  # right up vec
                    ld = (0.5, -0.5)  # left down vec
                    lu = (-0.5, -0.5)  # left up vec
                    if a.pos[0] == cood[0]:
                        if a.pos[1] > cood[1]:  # 相対位置 : wallの右
                            vec_r = vec2wall + ru
                            vec_l = vec2wall + rd
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左
                            vec_r = vec2wall + ld
                            vec_l = vec2wall + lu
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                    elif a.pos[0] > cood[0]:
                        if a.pos[1] == cood[1]:  # 相対位置 : wallの下
                            vec_r = vec2wall + rd
                            vec_l = vec2wall + ld
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        elif a.pos[1] > cood[1]:  # 相対位置 : wallの右下
                            vec_r = vec2wall + ru
                            vec_l = vec2wall + ld
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左下
                            vec_r = vec2wall + rd
                            vec_l = vec2wall + lu
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                    else:
                        if a.pos[1] == cood[1]:  # 相対位置 : wallの上
                            vec_r = vec2wall + lu
                            vec_l = vec2wall + ru
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        elif a.pos[1] > cood[1]:  # 相対位置 : wallの右上
                            vec_r = vec2wall + lu
                            vec_l = vec2wall + rd
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左上
                            vec_r = vec2wall + ld
                            vec_l = vec2wall + ru
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )

                    # 見えない位置を探索
                    for cood_num2, cood2 in enumerate(view_cood):  # cood_num2はwallの背後に位置し、見えなくなる座標の順番
                        if (
                            view_distances[cood_num2] >= distance2wall
                            and view_angles[cood_num2] <= angle2wall + theta_r
                            and view_angles[cood_num2] >= angle2wall - theta_l
                        ):
                            # 見えない部分を除外
                            del_idcs = np.append(del_idcs, cood_num2)
                            row, col = cood2
                            highlight_masks[(row, col)] = [val for val in highlight_masks[(row, col)] if val != i]
                            viewable_map[(row, col)] = []

            if not del_idcs.all():
                view_cood = np.array(view_cood)
                view_cood = np.delete(view_cood, del_idcs.astype(int), axis=0)

            a.viewable = viewable_map
            a.view_cood = view_cood

        return highlight_masks

    def _field_of_attack(self):
        """
        now editing
        """
        # TODO: 視界と攻撃範囲の分離

        highlight_masks = {(h, w): [] for h in range(self.height) for w in range(self.width)}

        for i, a in enumerate(self.agents):
            attack_map = {(h, w): [] for h in range(self.height) for w in range(self.width)}
            attack_cood = []

            if a.terminated:
                continue

            # Compute the world coordinates of the bottom-left corner
            # of the agent's attack area
            f_vec = a.dir_vec
            r_vec = a.right_vec

            if self.simple_fov:

                # Compute which cells are visible to the agent
                _, vis_masks = self.gen_obs_grid()

                # pos of FOV-top_left
                top_left = a.pos + f_vec * (self.attack_range - 1) - r_vec * (self.attack_range // 2)

                # Mask of which cells to highlight
                # For each cell in the visibility mask
                for vis_h in range(0, self.attack_range):
                    for vis_w in range(0, self.attack_range):
                        # If this cell is not visible, don't highlight it
                        if not vis_masks[i][vis_h, vis_w]:
                            continue

                        # Compute the world coordinates of this cell
                        abs_h, abs_w = top_left - (f_vec * vis_h) + (r_vec * vis_w)

                        if abs_w < 1 or abs_w >= self.width - 1:
                            continue
                        if abs_h < 1 or abs_h >= self.height - 1:
                            continue

                        # Mark this cell to be highlighted
                        highlight_masks[abs_h, abs_w].append(i)
                        attack_map[abs_h, abs_w].append(i)
                        attack_cood.append([abs_h, abs_w])

                distances = np.sqrt(
                    ((np.arange(self.height) - a.pos[0]) ** 2)[:, np.newaxis] + (np.arange(self.width) - a.pos[1]) ** 2
                )

                az_center = math.atan2(f_vec[0], f_vec[1])  # -180 ~ +180
                x, y = np.meshgrid(np.arange(self.width), np.arange(self.height))
                angles = np.arctan2(y - a.pos[0], x - a.pos[1]) - az_center
                angles = np.remainder(angles, 2 * np.pi)
                angles[angles > np.pi] -= 2 * np.pi
            else:
                attack_area = np.zeros((self.height, self.width), dtype=bool)

                # 相対距離grid map
                distances = np.sqrt(
                    ((np.arange(self.height) - a.pos[0]) ** 2)[:, np.newaxis] + (np.arange(self.width) - a.pos[1]) ** 2
                )

                # 指向角度により相対角度grid mapを作る。180度の境界処理も行う。
                az_center = math.atan2(f_vec[0], f_vec[1])  # -180 ~ +180
                x, y = np.meshgrid(np.arange(self.width), np.arange(self.height))
                angles = np.arctan2(y - a.pos[0], x - a.pos[1]) - az_center
                angles = np.remainder(angles, 2 * np.pi)
                angles[angles > np.pi] -= 2 * np.pi

                # 相対距離と相対角度からFOVを絞り込む。
                attack_area[
                    (distances <= self.attack_range)
                    & (angles <= math.radians(self.agent_attack_angle / 2))
                    & (angles >= -math.radians(self.agent_attack_angle / 2))
                ] = True

                # 自機位置追加
                attack_area[(a.pos[0], a.pos[1])] = True  # self pos

                # attack_map, attack_cood, highlight_masksに追加
                h_indices, w_indices = np.where(attack_area)
                attack_map.update(zip(zip(h_indices, w_indices), [[i]] * len(h_indices)))
                attack_cood = np.transpose(np.array([h_indices, w_indices])).tolist()
                unique_indices = np.unique(list(zip(h_indices, w_indices)), axis=0)
                for h, w in unique_indices:
                    if (h, w) in highlight_masks:
                        highlight_masks[(h, w)].append(i)

            # wallに対するLOS計算を行う

            # 視野全体に対する相対角度と距離
            az_center = math.atan2(f_vec[0], f_vec[1])
            attack_vecs = np.array(attack_cood) - np.array(a.pos)
            attack_angles = np.arctan2(attack_vecs[:, 0], attack_vecs[:, 1]) - az_center
            attack_angles = np.remainder(attack_angles, 2 * np.pi)
            attack_angles[attack_angles > np.pi] -= 2 * np.pi
            attack_distances = np.linalg.norm(attack_vecs, axis=1)

            del_idcs = np.array([])

            for cood_num, cood in enumerate(attack_cood):  # coodはwallの座標

                grid_temp = self.grid.get(cood[0], cood[1])

                if grid_temp == None:
                    continue
                elif grid_temp.type == "wall":

                    # wallを除外
                    row, col = cood
                    highlight_masks[(row, col)] = [val for val in highlight_masks[(row, col)] if val != i]
                    attack_map[(row, col)] = []
                    del_idcs = np.append(del_idcs, cood_num)

                    # wall中心へのベクトル、角度、距離
                    vec2wall = np.array(cood) - np.array(a.pos)
                    angle2wall = np.arctan2(vec2wall[0], vec2wall[1]) - az_center
                    angle2wall = np.remainder(angle2wall, 2 * np.pi)
                    if angle2wall > np.pi:
                        angle2wall -= 2 * np.pi
                    distance2wall = np.sqrt((cood[0] - a.pos[0]) ** 2 + (cood[1] - a.pos[1]) ** 2)

                    # gridに対する接点の場合分け
                    rd = (0.5, 0.5)  # right down vec
                    ru = (-0.5, 0.5)  # right up vec
                    ld = (0.5, -0.5)  # left down vec
                    lu = (-0.5, -0.5)  # left up vec
                    if a.pos[0] == cood[0]:
                        if a.pos[1] > cood[1]:  # 相対位置 : wallの右
                            vec_r = vec2wall + ru
                            vec_l = vec2wall + rd
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左
                            vec_r = vec2wall + ld
                            vec_l = vec2wall + lu
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                    elif a.pos[0] > cood[0]:
                        if a.pos[1] == cood[1]:  # 相対位置 : wallの下
                            vec_r = vec2wall + rd
                            vec_l = vec2wall + ld
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        elif a.pos[1] > cood[1]:  # 相対位置 : wallの右下
                            vec_r = vec2wall + ru
                            vec_l = vec2wall + ld
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左下
                            vec_r = vec2wall + rd
                            vec_l = vec2wall + lu
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                    else:
                        if a.pos[1] == cood[1]:  # 相対位置 : wallの上
                            vec_r = vec2wall + lu
                            vec_l = vec2wall + ru
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        elif a.pos[1] > cood[1]:  # 相対位置 : wallの右上
                            vec_r = vec2wall + lu
                            vec_l = vec2wall + rd
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )
                        else:  # 相対位置 : wallの左上
                            vec_r = vec2wall + ld
                            vec_l = vec2wall + ru
                            theta_r = np.arccos(
                                np.inner(vec2wall, vec_r) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_r)
                            )
                            theta_l = np.arccos(
                                np.inner(vec2wall, vec_l) / np.linalg.norm(vec2wall) / np.linalg.norm(vec_l)
                            )

                    # 見えない位置を探索
                    for cood_num2, cood2 in enumerate(attack_cood):  # cood_num2はwallの背後に位置し、見えなくなる座標の順番
                        if (
                            attack_distances[cood_num2] >= distance2wall
                            and attack_angles[cood_num2] <= angle2wall + theta_r
                            and attack_angles[cood_num2] >= angle2wall - theta_l
                        ):
                            # 見えない部分を除外
                            del_idcs = np.append(del_idcs, cood_num2)
                            row, col = cood2
                            highlight_masks[(row, col)] = [val for val in highlight_masks[(row, col)] if val != i]
                            attack_map[(row, col)] = []

            if not del_idcs.all():
                attack_cood = np.array(attack_cood)
                attack_cood = np.delete(attack_cood, del_idcs.astype(int), axis=0)

            a.attack_map = attack_map
            a.attack_cood = attack_cood

        return highlight_masks

    def render(self, mode="human", close=False, highlight=True, tile_size=TILE_PIXELS):
        """
        Render the whole-grid human view
        """
        if close:
            if self.window:
                self.window.close()
            return

        if mode == "human" and not self.window:
            self.window = CustomWindow("battlegrid")
            self.window.show(block=False)

        # Render the whole grid
        img = self.grid.render(self.objects, tile_size, highlight_masks=self._field_of_views() if highlight else None)

        if mode == "human":
            self.window.show_img(img)

        return img
