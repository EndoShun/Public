from .battlegrid import BattleGridEnv


class BattleGame_debug(BattleGridEnv):
    """
    custom battle game for debug.
    """

    def __init__(self):
        super().__init__(
            width=3 + 2,  # odd number
            height=3 + 2,  # odd number
            max_steps=30,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=0,
            target_goal=True,
            init_pos_set_besides=False,
            simple_fov=True,
            simple_act=True,
            agent_view_angle=90,  # deg
            attack_range=3,  # odd
            attack_angle=3,  # odd
        )


class BattleGame_1vs1_5x5_wall20(BattleGridEnv):
    """
    1vs1 battle game in 5x5 area with 20% walls.
    """

    def __init__(self):
        super().__init__(
            width=5 + 2,  # odd number
            height=5 + 2,  # odd number
            max_steps=50,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=20,
            target_goal=False,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class BattleGame_1vs1_7x7_wall20(BattleGridEnv):
    """
    1vs1 battle game in 7x7 area with 20% walls.
    """

    def __init__(self):
        super().__init__(
            width=7 + 2,  # odd number
            height=7 + 2,  # odd number
            max_steps=50,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=20,
            target_goal=False,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class BattleGame_2vs2_9x9_wall20(BattleGridEnv):
    """
    2vs2 battle game in 9x9 area with 20% walls.
    """

    def __init__(self):
        super().__init__(
            width=9 + 2,  # odd number
            height=9 + 2,  # odd number
            max_steps=100,
            agent_view_size=5,  # odd number
            team_num=2,
            agent_num=2,
            obstacle_rate=20,
            target_goal=False,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class BattleGame_2vs2_11x11_wall20(BattleGridEnv):
    """
    2vs2 battle game in 11x11 area with 20% walls.
    """

    def __init__(self):
        super().__init__(
            width=11 + 2,  # odd number
            height=11 + 2,  # odd number
            max_steps=150,
            agent_view_size=5,  # odd number
            team_num=2,
            agent_num=2,
            obstacle_rate=20,
            target_goal=False,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class BattleGame_3vs3_13x13_wall20(BattleGridEnv):
    """
    3vs3 battle game in 13x13 area with 20% walls.
    """

    def __init__(self):
        super().__init__(
            width=13 + 2,  # odd number
            height=13 + 2,  # odd number
            max_steps=200,
            agent_view_size=7,  # odd number
            team_num=2,
            agent_num=3,
            obstacle_rate=20,
            target_goal=False,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class BattleGame_3vs3_15x15_wall20(BattleGridEnv):
    """
    3vs3 battle game in 15x15 area with 20% walls.
    """

    def __init__(self):
        super().__init__(
            width=15 + 2,  # odd number
            height=15 + 2,  # odd number
            max_steps=250,
            agent_view_size=7,  # odd number
            team_num=2,
            agent_num=3,
            obstacle_rate=20,
            target_goal=False,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class MazeGame_1vs1_5x5(BattleGridEnv):
    """
    1vs1 maze game in 5x5 area.
    """

    def __init__(self):
        super().__init__(
            width=5 + 2,  # odd number
            height=5 + 2,  # odd number
            max_steps=50,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=100,
            target_goal=True,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class MazeGame_1vs1_7x7(BattleGridEnv):
    """
    1vs1 maze game in 7x7 area.
    """

    def __init__(self):
        super().__init__(
            width=7 + 2,  # odd number
            height=7 + 2,  # odd number
            max_steps=100,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=100,
            target_goal=True,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class MazeGame_1vs1_9x9(BattleGridEnv):
    """
    1vs1 maze game in 9x9 area.
    """

    def __init__(self):
        super().__init__(
            width=9 + 2,  # odd number
            height=9 + 2,  # odd number
            max_steps=150,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=100,
            target_goal=True,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class MazeGame_1vs1_11x11(BattleGridEnv):
    """
    1vs1 maze game in 11x11 area.
    """

    def __init__(self):
        super().__init__(
            width=11 + 2,  # odd number
            height=11 + 2,  # odd number
            max_steps=200,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=100,
            target_goal=True,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )


class MazeGame_1vs1_13x13(BattleGridEnv):
    """
    1vs1 maze game in 13x13 area.
    """

    def __init__(self):
        super().__init__(
            width=13 + 2,  # odd number
            height=13 + 2,  # odd number
            max_steps=250,
            agent_view_size=3,  # odd number
            team_num=2,
            agent_num=1,
            obstacle_rate=100,
            target_goal=True,
            init_pos_set_besides=True,
            simple_fov=False,
            simple_act=True,
            agent_view_angle=90,
        )
