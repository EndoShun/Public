from .custom_battlegrid import (
    BattleGame_1vs1_5x5_wall20,
    BattleGame_1vs1_7x7_wall20,
    BattleGame_2vs2_9x9_wall20,
    BattleGame_2vs2_11x11_wall20,
    BattleGame_3vs3_13x13_wall20,
    BattleGame_3vs3_15x15_wall20,
    BattleGame_debug,
    MazeGame_1vs1_5x5,
    MazeGame_1vs1_7x7,
    MazeGame_1vs1_9x9,
    MazeGame_1vs1_11x11,
    MazeGame_1vs1_13x13,
)
