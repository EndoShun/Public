eval "$(conda shell.bash hook)"
conda activate formatter

pysen run lint
pysen run format