# original : https://github.com/seungeunrho/minimalRL

import argparse
import collections
import csv
import datetime
import importlib
import logging
import pickle
import random
import shutil
import sys
import termios
import time
import tty
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.transforms as T
from battlegrid import make
from battlegrid.core.custom_env import CustomSimpleActions, CustomWorld
from battlegrid.envs.custom_battlegrid import (
    BattleGame_1vs1_5x5_wall20,
    BattleGame_1vs1_7x7_wall20,
    BattleGame_2vs2_9x9_wall20,
    BattleGame_2vs2_11x11_wall20,
    BattleGame_3vs3_13x13_wall20,
    BattleGame_3vs3_15x15_wall20,
    BattleGame_debug,
    MazeGame_1vs1_5x5,
    MazeGame_1vs1_7x7,
    MazeGame_1vs1_9x9,
    MazeGame_1vs1_11x11,
    MazeGame_1vs1_13x13,
)
from learn_setting import LOAD, LOAD_DIR, LOAD_FILE, SLEEP_TIME

if LOAD:
    module = importlib.import_module(f"{LOAD_DIR}.learn_setting")

    ACTIVATION_FUNC = module.ACTIVATION_FUNC
    BATCH_SIZE = module.BATCH_SIZE
    BUFFER_LIMIT_DT = module.BUFFER_LIMIT_DT
    BUFFER_LIMIT_DQN = module.BUFFER_LIMIT_DQN
    DATASET_LOAD = module.DATASET_LOAD
    DATASET_SAVE = module.DATASET_SAVE
    DEVICE = module.DEVICE
    DISPOSE_RATE = module.DISPOSE_RATE
    DROPOUT = module.DROPOUT
    EMBED_DIM = module.EMBED_DIM
    ENV_TARGETS = module.ENV_TARGETS
    EPISODES = module.EPISODES
    EVAL_INTERVAL = module.EVAL_INTERVAL
    EVAL_ITERATION_NUM = module.EVAL_ITERATION_NUM
    EVAL_VIEW = True
    GAMMA = module.GAMMA
    ITERATION_NUM = module.ITERATION_NUM
    DEFAULT_LEARNING_RATE = module.DEFAULT_LEARNING_RATE
    LOG_TO_WANDB = module.LOG_TO_WANDB
    MANUAL_MODE = module.MANUAL_MODE
    MAX_LEN = module.MAX_LEN
    N_HEAD = module.N_HEAD
    N_LAYER = module.N_LAYER
    N_POSITIONS = module.N_POSITIONS
    EMBED_DIM = module.EMBED_DIM
    PCT_TRAJECTORY = module.PCT_TRAJECTORY
    PRINT_INTERVAL = module.PRINT_INTERVAL
    RULE_BASE = module.RULE_BASE
    SAVE_INTERVAL = module.SAVE_INTERVAL
    SCALE = module.SCALE
    TARGET_UPDATE_INTERVAL = module.TARGET_UPDATE_INTERVAL
    TEMP_BOT = module.TEMP_BOT
    TEMP_TOP = module.TEMP_TOP
    TRAIN_INTERVAL = module.TRAIN_INTERVAL
    TRAIN_ITERATION_NUM = module.TRAIN_ITERATION_NUM
    TRAIN_START_SIZE = module.TRAIN_START_SIZE
    TRAIN_VIEW = True
    UNIT_ID = module.UNIT_ID
    WARMUP_STEP = module.WARMUP_STEP
    WEIGHT_DECAY = module.WEIGHT_DECAY
else:
    from learn_setting import (
        BATCH_SIZE,
        BUFFER_LIMIT_DQN,
        DATASET_SAVE,
        DEVICE,
        DISPOSE_RATE,
        EPISODES,
        EVAL_INTERVAL,
        EVAL_ITERATION_NUM,
        EVAL_VIEW,
        GAMMA,
        DEFAULT_LEARNING_RATE,
        LOAD,
        LOAD_DIR,
        LOAD_FILE,
        MANUAL_MODE,
        MAX_LEN,
        EMBED_DIM,
        PRINT_INTERVAL,
        RULE_BASE,
        SAVE_INTERVAL,
        SLEEP_TIME,
        TARGET_UPDATE_INTERVAL,
        TEMP_BOT,
        TEMP_TOP,
        TRAIN_INTERVAL,
        TRAIN_ITERATION_NUM,
        TRAIN_START_SIZE,
        TRAIN_VIEW,
        UNIT_ID,
        WEIGHT_DECAY,
    )

from tqdm import tqdm, trange

# with open("data/mem.pickle", "rb") as f:
#     traj = pickle.load(f)

warnings.filterwarnings("ignore", category=DeprecationWarning)

sys.path.append("../")

result_dir_path = Path(f'./data/result/{datetime.datetime.now().strftime("%H%M%S")}')
if not result_dir_path.exists():
    result_dir_path.mkdir(parents=True)
    shutil.copy("./learn_setting.py", result_dir_path)
    shutil.copy("./endo_dqn.py", result_dir_path)
    dataset_path = Path(f"{result_dir_path}/memory")
    if not dataset_path.exists():
        dataset_path.mkdir(parents=True)
    print(result_dir_path)

logging.basicConfig(filename=f"{result_dir_path}/dqn_log.txt", level=logging.INFO)


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        char = sys.stdin.read(1)
        if char == "\x1b":  # エスケープシーケンスの場合、矢印キーとして処理
            char += sys.stdin.read(2)  # 残りの2文字を読み込む
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return char


class ReplayBuffer:  # Bufferはnumpy形式、batchのreturnはtensor形式(GPU)。
    def __init__(self):
        self.buffer = collections.deque(maxlen=BUFFER_LIMIT_DQN)  # deque型（ところてん型）のオブジェクト。最大長がBUFFER_LIMIT
        self.num_trajectories = len(self.buffer)

    def put(self, transition):
        self.buffer.append(transition)  # bufferにはtransitionが格納されていく。

    def delete_from_new(self, num):
        for _ in range(num):
            self.buffer.pop()

    def delete_from_old(self, num):
        for _ in range(num):
            self.buffer.popleft()

    def size(self):
        return len(self.buffer)

    def get_batch(self, index, batch_size):

        mini_batch = random.sample(self.buffer, min(batch_size, self.size()))
        mini_batch = [[mini_batch[b][sarsd][index] for sarsd in range(5)] for b in range(min(batch_size, self.size()))]

        s_lst, a_lst, r_lst, s_prime_lst, done_mask_lst = [], [], [], [], []  # s a r s d !?

        for transition in mini_batch:
            s, a, r, s_prime, done_mask = transition
            s_lst.append(s)
            a_lst.append([a])
            r_lst.append([r])
            s_prime_lst.append(s_prime)
            done_mask_lst.append([done_mask])

        s_lst = np.array(s_lst).astype(np.float32)
        s_lst = torch.from_numpy(s_lst).clone().to(device=DEVICE)

        a_lst = np.array(a_lst).astype(np.float32)
        a_lst = torch.from_numpy(a_lst).clone().to(device=DEVICE)

        r_lst = np.array(r_lst).astype(np.float32)
        r_lst = torch.from_numpy(r_lst).clone().to(device=DEVICE)

        s_prime_lst = np.array(s_prime_lst).astype(np.float32)
        s_prime_lst = torch.from_numpy(s_prime_lst).clone().to(device=DEVICE)

        done_mask_lst = np.array(done_mask_lst).astype(np.float32)
        done_mask_lst = torch.from_numpy(done_mask_lst).clone().to(device=DEVICE)

        return s_lst, a_lst, r_lst, s_prime_lst, done_mask_lst


class DQN(nn.Module):
    def __init__(self, observation_dim, action_dim):
        super(DQN, self).__init__()
        self.layer0 = nn.Linear(observation_dim, EMBED_DIM)
        self.layer1 = nn.Linear(EMBED_DIM, EMBED_DIM)
        self.layer2 = nn.Linear(EMBED_DIM, EMBED_DIM)
        self.layer3 = nn.Linear(EMBED_DIM, EMBED_DIM)
        # self.layer4 = nn.Linear(EMBED_DIM, EMBED_DIM)
        # self.layer5 = nn.Linear(EMBED_DIM, EMBED_DIM)
        # self.layer6 = nn.Linear(EMBED_DIM, EMBED_DIM)
        self.layer99 = nn.Linear(EMBED_DIM, action_dim)

    def forward(self, x):
        x = F.relu(self.layer0(x))
        x = F.relu(self.layer1(x))
        x = F.relu(self.layer2(x))
        x = F.relu(self.layer3(x))
        # x = F.relu(self.layer4(x))
        # x = F.relu(self.layer5(x))
        # x = F.relu(self.layer6(x))
        x = self.layer99(x)
        return x

    def sample_action(self, observation):
        out = self.forward(observation)
        return out


def temperature_softmax(logits, temperature=1.0):

    """Softmax with Temperature function
    Args:
        logits(Tensor array) : array of action
        temperature(float) : temperature

    Returns:
        softmax_probs

    Note:
        温度Tが1より大きいとき: 低い確率を強調
        温度Tが1より小さいとき: 高い確率を強調
        y=e(x)はxが大きくなると飛躍的にyが大きくなるのでTが小さい→xが大きくなる→高い確率が強調される

        https://qiita.com/nkriskeeic/items/db3b4b5e835e63a7f243
    """
    scaled_logits = logits / temperature

    softmax_probs = torch.softmax(scaled_logits, dim=-1)
    return softmax_probs


def main(variant):

    env_name = variant["env"]
    env = make(env_name)
    print(env_name)

    if env_name == "battlegame-v0":
        game = BattleGame_debug()
    elif env_name == "battlegame-v1":
        game = BattleGame_1vs1_5x5_wall20()
    elif env_name == "battlegame-v2":
        game = BattleGame_1vs1_7x7_wall20()
    elif env_name == "battlegame-v3":
        game = BattleGame_2vs2_9x9_wall20()
    elif env_name == "battlegame-v4":
        game = BattleGame_2vs2_11x11_wall20()
    elif env_name == "battlegame-v5":
        game = BattleGame_3vs3_13x13_wall20()
    elif env_name == "battlegame-v6":
        game = BattleGame_3vs3_15x15_wall20()
    elif env_name == "mazegame-v1":
        game = MazeGame_1vs1_5x5()
    elif env_name == "mazegame-v2":
        game = MazeGame_1vs1_7x7()
    elif env_name == "mazegame-v3":
        game = MazeGame_1vs1_9x9()
    elif env_name == "mazegame-v4":
        game = MazeGame_1vs1_11x11()
    elif env_name == "mazegame-v5":
        game = MazeGame_1vs1_13x13()

    logging.info(vars(env))
    logging.info(vars(game))

    height = game.height
    width = game.width

    # np.set_printoptions(threshold=10000000, linewidth=(max(height, width) * 2 - 1) * 3 + 1)
    # torch.set_printoptions(threshold=10000000, linewidth=(max(height, width) * 2 - 1) * 3 + 1)
    np.set_printoptions(threshold=10000000, linewidth=250)
    torch.set_printoptions(threshold=10000000, linewidth=250)

    team_num = game.team_num
    agent_num = game.agent_num
    all_agent_num = team_num * agent_num

    target_goal = game.target_goal

    encode_dim = CustomWorld.encode_dim
    enc_obj = CustomWorld.ENC_OBJ
    enc_col = CustomWorld.ENC_COL
    enc_carobj = CustomWorld.ENC_CAROBJ
    enc_carcol = CustomWorld.ENC_CARCOL
    enc_dir = CustomWorld.ENC_DIR
    enc_self = CustomWorld.ENC_SELF
    total_encode_dim = CustomWorld.total_encode_dim

    COLOR_TO_IDX = CustomWorld.COLOR_TO_IDX
    OBJECT_TO_IDX = CustomWorld.OBJECT_TO_IDX
    DIR_TO_IDX = CustomWorld.DIR_TO_IDX
    MYSELF_TO_IDX = CustomWorld.MYSELF_TO_IDX

    encode_dim = CustomWorld.encode_dim
    total_encode_dim = CustomWorld.total_encode_dim

    area = (max(env.height, env.width) * 2 - 1) ** 2  # observation正規化後の面積
    memory = ReplayBuffer()

    obs_dim = np.prod(env.observation_space.shape)
    obs_dim_ext = area * total_encode_dim  # 拡張後の観測範囲 #total_encode_dim×正規化辺長**2

    act_dim = env.action_space.n

    q = DQN(observation_dim=obs_dim_ext * agent_num, action_dim=act_dim).to(DEVICE)
    q_target = DQN(observation_dim=obs_dim_ext * agent_num, action_dim=act_dim).to(DEVICE)
    q_target.load_state_dict(q.state_dict())

    logging.info(q)

    if LOAD:
        path_dir = Path(LOAD_DIR.replace(".", "/"))
        q.load_state_dict(torch.load(path_dir / LOAD_FILE))

    # CHANGED: もともとweight_decayは入力なしだったが、DTと同条件にするために追加
    # CHANGED: MAX_LENはDQNに使用しないパラメータだが、DTと同条件にするために追加
    optimizer = optim.AdamW(q.parameters(), lr=DEFAULT_LEARNING_RATE * BATCH_SIZE * MAX_LEN, weight_decay=WEIGHT_DECAY)
    # optimizer = optim.Adam(q.parameters(), lr=DEFAULT_LEARNING_RATE * BATCH_SIZE * MAX_LEN, weight_decay=WEIGHT_DECAY)
    # optimizer = optim.SGD(q.parameters(), lr=DEFAULT_LEARNING_RATE * BATCH_SIZE * MAX_LEN, weight_decay=WEIGHT_DECAY)
    print(f"lr = {DEFAULT_LEARNING_RATE * BATCH_SIZE * MAX_LEN}")

    logs = {
        "elapsed time": [],
        "SAMPLE epi": [],
        "SAMPLE score ave": [],
        "SAMPLE win": [],
        "SAMPLE lose": [],
        "SAMPLE timeout": [],
        "SAMPLE unknown": [],
        "SAMPLE win rate": [],
        "SAMPLE buf size": [],
        "SAMPLE temp": [],
        "train time": [],
        "train loss": [],
        "layer in max": [],
        "layer out max": [],
        "eval time": [],
        "eval score ave": [],
        "eval win": [],
        "eval lose": [],
        "eval timeout": [],
        "eval unknown": [],
        "eval win rate": [],
        "eval timeout rate": [],
    }

    csvlog = logs.copy()

    # csvファイル生成
    header = list(logs.keys())
    filename = f"{result_dir_path}/output.csv"
    try:
        with open(filename, mode="x", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(header)
    except FileExistsError:
        pass

    score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0
    act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")
    onehot_obs = np.zeros(shape=(all_agent_num, total_encode_dim, height, width))
    rotate_obs = np.zeros(shape=(all_agent_num, total_encode_dim, int(area**0.5), int(area**0.5)))
    flat_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))
    pre_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))
    post_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))

    def obs_onehot_encode(obs):
        onehot_obs = np.zeros((total_encode_dim, height, width), dtype=np.float32)  # "+2はcurrent_agentの0と1。"
        if encode_dim == 6:
            channel_nums = [
                list(OBJECT_TO_IDX.values()),
                list(COLOR_TO_IDX.values()),
                list(OBJECT_TO_IDX.values()),
                list(COLOR_TO_IDX.values()),
                list(DIR_TO_IDX.values()),
                list(MYSELF_TO_IDX.values()),
            ]
        elif encode_dim == 4:
            channel_nums = [
                list(OBJECT_TO_IDX.values()),
                list(COLOR_TO_IDX.values()),
                list(DIR_TO_IDX.values()),
                list(MYSELF_TO_IDX.values()),
            ]

        count_num = 0
        for ch_idx, channel_num in enumerate(channel_nums):
            for obj_idx in channel_num:
                onehot_obs[count_num, :, :][np.where(obs[ch_idx, :, :] == obj_idx)] = 1
                count_num += 1
        return onehot_obs

    def obs_rotate_encode(onehot_obs, pos, dir):
        side = max(height, width) * 2 - 1
        norm_obs = np.zeros((total_encode_dim, side, side), dtype=np.float32)  # "+2はcurrent_agentの0と1。"
        norm_obs[
            :,
            int((side + 1) / 2 - pos[0][0] - 1) : int((side + 1) / 2 - pos[0][0] + height - 1),
            int((side + 1) / 2 - pos[1][0] - 1) : int((side + 1) / 2 - pos[1][0] + width - 1),
        ] = onehot_obs

        if dir == 1:
            rotate_obs = np.rot90(norm_obs, 1, axes=(1, 2))
        elif dir == 3:
            rotate_obs = np.rot90(norm_obs, 2, axes=(1, 2))
        elif dir == 5:
            rotate_obs = np.rot90(norm_obs, 3, axes=(1, 2))
        elif dir == 7:
            rotate_obs = np.rot90(norm_obs, 4, axes=(1, 2))
        else:
            assert dir % 2 == 1, "dir = {dir} : simple_fov = False is not still supported"

        return rotate_obs

    def act_onehot_encode(act):
        onehot_act = np.identity(act_dim, dtype=np.uint8)
        onehot_act = np.array(onehot_act[act])
        return onehot_act

    def prohibit_action(obs):

        ###禁則行為を除外(細かいルールは別資料を参照)
        # ただし以下のルールは180度視野を持つ場合を想定している
        # 禁則1.観測範囲を狭めるような回転をしない（効率の悪い回転をしない）
        # 禁則2.壁に向かって進まない

        act_mask = np.ones(shape=(act_dim), dtype="int8")

        self_pos = np.where(obs[enc_self, :, :] == 1)  # 自分の位置(np,array(y), np.array(x))を取得
        self_dir = obs[enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

        if self_dir == 1:  # 右
            front_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
            left_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] - 0]
            right_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
            back_obj = obs[enc_obj, self_pos[0][0] - 0, self_pos[1][0] - 1]
        elif self_dir == 3:  # 下
            front_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
            left_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
            right_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] - 1]
            back_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] + 0]
        elif self_dir == 5:  # 左
            front_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] - 1]
            left_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
            right_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] + 0]
            back_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
        elif self_dir == 7:  # 上
            front_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] + 0]
            left_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] - 1]
            right_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
            back_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
        else:
            assert self_dir % 2 == 0, f"dir = {self_dir} : [simple_fov = False] is not still supported"

        if front_obj == OBJECT_TO_IDX["wall"]:  # 前が壁の場合
            if left_obj == OBJECT_TO_IDX["wall"] and right_obj == OBJECT_TO_IDX["wall"]:  # 前と左と右だけが壁の場合
                act_mask[CustomSimpleActions.forward] = 0
                act_mask[CustomSimpleActions.still] = 0
            elif left_obj == OBJECT_TO_IDX["wall"]:  # 前と左だけが壁の場合
                act_mask[CustomSimpleActions.forward] = 0
                act_mask[CustomSimpleActions.still] = 0
                act_mask[CustomSimpleActions.left] = 0
            elif right_obj == OBJECT_TO_IDX["wall"]:  # 前と右だけが壁の場合
                act_mask[CustomSimpleActions.forward] = 0
                act_mask[CustomSimpleActions.still] = 0
                act_mask[CustomSimpleActions.right] = 0
            else:  # 前だけが壁の場合
                act_mask[CustomSimpleActions.forward] = 0
        elif left_obj == OBJECT_TO_IDX["wall"] and right_obj == OBJECT_TO_IDX["wall"]:
            if back_obj == OBJECT_TO_IDX["wall"]:  # 左と右と後だけが壁の場合
                act_mask[CustomSimpleActions.left] = 0
                act_mask[CustomSimpleActions.right] = 0
            else:  # 左と右だけが壁の場合
                pass
        elif left_obj == OBJECT_TO_IDX["wall"] and right_obj != OBJECT_TO_IDX["wall"]:  # 左が壁の場合
            act_mask[CustomSimpleActions.left] = 0
        elif left_obj != OBJECT_TO_IDX["wall"] and right_obj == OBJECT_TO_IDX["wall"]:  # 右が壁の場合
            act_mask[CustomSimpleActions.right] = 0

        return act_mask

    def train(q, q_target, memory, optimizer):

        logs = dict()

        q.train()
        q.to(device=DEVICE)

        train_start = time.time()

        for _ in tqdm(range(int(TRAIN_ITERATION_NUM)), ncols=50):
            for agent in range(1):  # 一人のみのデータで学習する場合
                # for agent in range(all_agent_num): #全員分のデータで学習する場合
                s, a, r, s_prime, done_mask = memory.get_batch(
                    agent, BATCH_SIZE
                )  # bufferには全unitの情報が蓄積されているが、get_batchでunit_id=indexのunit情報のみを抽出する。

                # 今のモデルにおける各状態のQ値（Q値は状態と行動の関連性においてQualityの高さを示す）
                q_out = q(s)
                # print(f"q_out : {q_out}")

                # 今のモデルにおいて実際にした選択(行動)のQ値
                q_a = torch.gather(input=q_out, dim=1, index=torch.argmax(a, dim=2)).to(DEVICE)
                # print(f"q_a : {q_a}")

                # 正解だった行動のQ値（∵ s_prime(次の状態)を入力し、最も高いQ値を抽出しているため）
                max_q_prime = q_target(s_prime).max(1)[0].unsqueeze(1)
                # print(f"max_q_prime : {max_q_prime}")

                # ベルマン方程式（即時報酬 + 将来報酬）により狙うべきQ値を算出
                target = r + GAMMA * max_q_prime * done_mask
                # print(f"target : {target}")

                # loss計算：期待していたQ値と実際の行動結果のQ値の差から損失計算
                loss = F.smooth_l1_loss(q_a, target)  # .to(DEVICE)

                # 傾きを初期化
                # optimizer.zero_grad()

                # 逆伝搬
                loss.backward()

                # q.parameterを更新
                optimizer.step()

        logs["train time"] = time.time() - train_start
        logs["train loss"] = loss.detach().cpu().item()  # 最後のlossのみを記録

        return logs

    def eval(q):

        logs = dict()

        q.eval()
        q.to(device=DEVICE)

        eval_start = time.time()
        score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0
        act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")
        onehot_obs = np.zeros(shape=(all_agent_num, total_encode_dim, height, width))
        rotate_obs = np.zeros(shape=(all_agent_num, total_encode_dim, int(area**0.5), int(area**0.5)))
        flat_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))
        pre_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))

        for _ in range(int(EVAL_ITERATION_NUM)):
            # for _ in range(1):  # 一人のみのデータで評価する場合
            # for index in range(all_agent_num):
            with torch.no_grad():

                states, rewards, done, _ = env.reset()

                for a in range(all_agent_num):
                    self_pos = np.where(states[a][enc_self, :, :] == 1)  # 自分の位置(np,array(x), np.array(y))を取得
                    self_dir = states[a][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得
                    onehot_obs[a] = obs_onehot_encode(states[a])
                    rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
                    flat_obs[a] = rotate_obs[a].flatten()

                # 仲間のobsを連結
                for t in range(team_num):
                    for a in range(agent_num):
                        args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                        pre_obs[t * agent_num + a] = np.concatenate(args, axis=0)

                while not done:
                    if EVAL_VIEW:
                        env.render(mode="human", highlight=True)
                        time.sleep(SLEEP_TIME)

                    # actionの有効indexを指定してランダムに選択
                    act_indices = [np.where(act_mask[a] == 1)[0] for a in range(all_agent_num)]
                    actions = [
                        torch.from_numpy(act_onehot_encode(np.random.choice(act_indices[a])))
                        for a in range(all_agent_num)
                    ]

                    state_t = torch.from_numpy(pre_obs).to(device=DEVICE)

                    actions[UNIT_ID] = q.sample_action(state_t[UNIT_ID].to(dtype=torch.float32))

                    # ts_action = temperature_softmax(actions[UNIT_ID], torch.tensor(0.01))
                    # max_idx = torch.multinomial(ts_action, num_samples=1).item()
                    max_idx = torch.argmax(actions[UNIT_ID])
                    actions[UNIT_ID] = torch.zeros_like(actions[UNIT_ID])
                    actions[UNIT_ID][max_idx] = 1

                    for a in range(all_agent_num):
                        actions[a] = actions[a].to("cpu").detach().numpy().copy().astype("uint8")

                    input_actions = [np.argmax(actions[i]) for i in range(all_agent_num)]

                    if target_goal:
                        for i in range(all_agent_num):
                            if i != UNIT_ID:
                                input_actions[i] = 0

                    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
                    next_states, rewards, done, info = env.step(input_actions)
                    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

                    if EVAL_VIEW:
                        print(f"act:{input_actions[UNIT_ID]}, reward:{rewards[UNIT_ID]}")

                    # done_mask = [0 if done else 1 for _ in range(all_agent_num)]
                    act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")

                    for a in range(all_agent_num):
                        act_mask[a] = prohibit_action(next_states[a])

                        self_pos = np.where(next_states[a][enc_self, :, :] == 1)
                        self_dir = next_states[a][enc_dir, self_pos[0], self_pos[1]]
                        onehot_obs[a] = obs_onehot_encode(next_states[a])
                        rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
                        flat_obs[a] = rotate_obs[a].flatten()

                    # 仲間のobsと連結
                    for t in range(team_num):
                        for a in range(agent_num):
                            args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                            post_obs[t * agent_num + a] = np.concatenate(args, axis=0)

                    pre_obs = post_obs.copy()

                    score += rewards[UNIT_ID]

                    if done:
                        if info["win_team_id"] == None:
                            timeout += 1
                        elif info["win_team_id"] == UNIT_ID // agent_num:
                            win += 1
                        elif info["win_team_id"] != UNIT_ID // agent_num:
                            lose += 1
                        else:
                            unknown += 1
                        break

        logs["eval time"] = time.time() - eval_start
        logs["eval score ave"] = score / int(EVAL_ITERATION_NUM)

        logs["win"] = win
        logs["lose"] = lose
        logs["timeout"] = timeout
        logs["unknown"] = unknown

        return logs

    ########################################
    # start iteration
    ########################################

    start_time = time.time()
    continue_num = 0

    with trange(EPISODES, ncols=70) as progress_bar:

        num_episode = 0

        while num_episode < EPISODES:

            step_count = 0

            if LOAD:
                temperature = np.float64(0.01)
            else:
                temperature = TEMP_TOP * np.exp(-(np.log(TEMP_TOP / TEMP_BOT) / (EPISODES - 1)) * num_episode)

            next_states, _, done, _ = env.reset()

            for a in range(all_agent_num):
                self_pos = np.where(next_states[a][enc_self, :, :] == 1)  # 自分の位置(np,array(x), np.array(y))を取得
                self_dir = next_states[a][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

                onehot_obs[a] = obs_onehot_encode(next_states[a])
                rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
                flat_obs[a] = rotate_obs[a].flatten()

            # 仲間のobsと連結
            for t in range(team_num):
                for a in range(agent_num):
                    args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                    pre_obs[t * agent_num + a] = np.concatenate(args, axis=0)

            pre_obs = flat_obs.copy()

            while not done:
                if TRAIN_VIEW or LOAD:
                    env.render(mode="human", highlight=True)
                    time.sleep(SLEEP_TIME)
                elif MANUAL_MODE and num_episode < 100:
                    env.render(mode="human", highlight=True)
                    time.sleep(SLEEP_TIME)

                act_indices = [np.where(act_mask[a] == 1)[0] for a in range(all_agent_num)]
                actions = [
                    torch.from_numpy(act_onehot_encode(np.random.choice(act_indices[a]))) for a in range(all_agent_num)
                ]
                
                states = next_states.copy()
                state_t = torch.from_numpy(pre_obs).to(device=DEVICE)
                
                if not DATASET_SAVE:
                    actions[UNIT_ID] = q.sample_action(state_t[UNIT_ID].to(dtype=torch.float32))
                    ts_action = temperature_softmax(actions[UNIT_ID], temperature)
                    max_idx = torch.multinomial(ts_action, num_samples=1).item()
                    actions[UNIT_ID] = torch.zeros_like(actions[UNIT_ID])
                    actions[UNIT_ID][max_idx] = 1

                for a in range(all_agent_num):
                    actions[a] = actions[a].to("cpu").detach().numpy().copy().astype("uint8")

                if RULE_BASE:
                    self_pos = np.where(next_states[UNIT_ID][enc_self, :, :] == 1)  # 自分の位置(np,array(y), np.array(x))を取得
                    self_dir = next_states[UNIT_ID][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

                    if self_dir == 1:
                        front_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                        back_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]
                        right_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                        left_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                    elif self_dir == 3:
                        front_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                        back_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                        right_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]
                        left_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                    elif self_dir == 5:
                        front_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]
                        back_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                        right_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                        left_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                    elif self_dir == 7:
                        front_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                        back_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                        right_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                        left_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]

                    if front_obj == 11 or right_obj == 11 or left_obj == 11:
                        actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                        actions[UNIT_ID][4] = 1
                    elif front_obj == 3:
                        if right_obj == 3 and left_obj != 3:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][1] = 1
                        elif right_obj != 3 and left_obj == 3:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][2] = 1
                        else:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][random.randint(1, 2)] = 1
                    elif front_obj == 2:
                        if back_obj == 3:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][3] = 1
                        elif left_obj == 2:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][random.choice([1, 3])] = 1
                        elif right_obj == 2:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][random.choice([2, 3])] = 1
                        else:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][3] = 1

                if MANUAL_MODE and num_episode < 100:
                    try:
                        while True:
                            char = get_key()
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])

                            if char == "\x1b[B":
                                actions[UNIT_ID][0] = 1
                                break
                            elif char == "\x1b[D":
                                actions[UNIT_ID][1] = 1
                                break
                            elif char == "\x1b[C":
                                actions[UNIT_ID][2] = 1
                                break
                            elif char == "\x1b[A":
                                actions[UNIT_ID][3] = 1
                                break
                            elif char == "f":
                                actions[UNIT_ID][4] = 1
                                break

                    except KeyboardInterrupt:
                        sys.exit(1)

                input_actions = [np.argmax(actions[i]) for i in range(all_agent_num)]

                if target_goal:
                    for i in range(all_agent_num):
                        if i != UNIT_ID:
                            input_actions[i] = 0
                
                # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
                next_states, rewards, done, info = env.step(input_actions)
                # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

                if TRAIN_VIEW or (MANUAL_MODE and num_episode < 100):
                    print(f"act:{input_actions[UNIT_ID]}, reward:{rewards[UNIT_ID]}")

                done_mask = [0 if done else 1 for _ in range(all_agent_num)]
                act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")

                for a in range(all_agent_num):
                    act_mask[a] = prohibit_action(next_states[a])

                    self_pos = np.where(next_states[a][enc_self, :, :] == 1)
                    self_dir = next_states[a][enc_dir, self_pos[0], self_pos[1]]
                    onehot_obs[a] = obs_onehot_encode(next_states[a])
                    rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
                    flat_obs[a] = rotate_obs[a].flatten()

                # 仲間のobsと連結
                for t in range(team_num):
                    for a in range(agent_num):
                        args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                        post_obs[t * agent_num + a] = np.concatenate(args, axis=0)

                post_obs = flat_obs.copy()
                
                if DATASET_SAVE:
                    num_episode += 1
                    progress_bar.update(1)
                    if info["win_team_id"] == None:
                        torch.save(
                            ((states, actions, rewards, next_states, done, info)),
                            Path(f"/media/mhiavio/Ubuntu_HDD/7x7_2v2_battle/timeout/{num_episode+00000}.pth"),
                        )
                    elif info["win_team_id"] == UNIT_ID // agent_num:
                        torch.save(
                            ((states, actions, rewards, next_states, done, info)),
                            Path(f"/media/mhiavio/Ubuntu_HDD/7x7_2v2_battle/win/{num_episode+00000}.pth"),
                        )
                    elif info["win_team_id"] != UNIT_ID // agent_num:
                        torch.save(
                            ((states, actions, rewards, next_states, done, info)),
                            Path(f"/media/mhiavio/Ubuntu_HDD/7x7_2v2_battle/lose/{num_episode+00000}.pth"),
                        )
                else:
                    memory.put((pre_obs, actions, rewards, post_obs, done_mask))

                step_count += 1
                pre_obs = post_obs.copy()

                if done:
                    if info["win_team_id"] == None:
                        timeout += 1
                    elif info["win_team_id"] == UNIT_ID // agent_num:
                        win += 1
                    elif info["win_team_id"] != UNIT_ID // agent_num:
                        lose += 1
                    else:
                        unknown += 1
                    break


            if info["win_team_id"] == None and random.random() < DISPOSE_RATE:  # Timeout(=None)の場合X%で破棄する。
                # if info["win_team_id"] != UNIT_ID // agent_num and random.random() < DISPOSE_RATE:
                memory.delete_from_new(step_count)
                continue
            else:
                score += rewards[UNIT_ID]

                num_episode += 1
                progress_bar.update(1)

            if (num_episode + 0) % int(PRINT_INTERVAL) == 0 and num_episode != 0:
                print(
                    f"SAMPLE : episode:{num_episode}, score ave:{score/PRINT_INTERVAL:.2f}, win:{win}, lose:{lose}, timeout:{timeout}, unknown:{unknown}, buffer:{memory.size()}, temperature:{temperature:.2f}"
                )
                csvlog["SAMPLE epi"] = num_episode
                csvlog["SAMPLE score ave"] = score / PRINT_INTERVAL
                csvlog["SAMPLE win"] = win
                csvlog["SAMPLE lose"] = lose
                csvlog["SAMPLE timeout"] = timeout
                csvlog["SAMPLE unknown"] = unknown
                csvlog["SAMPLE win rate"] = win / (win + lose + timeout + unknown)
                csvlog["SAMPLE buf size"] = memory.size()
                csvlog["SAMPLE temp"] = temperature

                score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0

            ### train
            if (num_episode + 0) % int(TRAIN_INTERVAL) == 0 and memory.size() + 1 >= TRAIN_START_SIZE:
                log = train(q, q_target, memory, optimizer)

                logs["train time"].append(log["train time"])
                logs["train loss"].append(log["train loss"])
                csvlog["train time"] = log["train time"]
                csvlog["train loss"] = log["train loss"]

                print(f"=== interim log report ===")
                print(f"elapsed time {time.time() - start_time}")
                print(f"train time {log['train time']}")
                print(f"train loss {log['train loss']}")

                ### save pth
                # if (num_episode + 0) % int(SAVE_INTERVAL) == 0 and num_episode != 0 and log["win"] > 80:
                # torch.save(q.state_dict(), f"{result_dir_path}/{str(num_episode + 0)}.pth")
                torch.save(q.state_dict(), f"{result_dir_path}/{str(num_episode + 0)}.pth")

            ### evaluation
            if (num_episode + 0) % int(EVAL_INTERVAL) == 0 and memory.size() + 0 >= TRAIN_START_SIZE:
                log = eval(q)

                logs["elapsed time"].append(time.time() - start_time)
                logs["eval time"].append(log["eval time"])
                logs["layer in max"].append(q.layer0.weight.to("cpu").detach().numpy().max())
                logs["layer out max"].append(q.layer99.weight.to("cpu").detach().numpy().max())
                logs["eval score ave"].append(log["eval score ave"])
                logs["eval win"].append(log["win"])
                logs["eval lose"].append(log["lose"])
                logs["eval timeout"].append(log["timeout"])
                logs["eval unknown"].append(log["unknown"])
                if log["win"] + log["lose"] != 0:
                    logs["eval win rate"].append(
                        log["win"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                    )
                logs["eval timeout rate"].append(
                    log["timeout"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                )

                csvlog["elapsed time"] = time.time() - start_time
                csvlog["eval time"] = log["eval time"]
                csvlog["eval score ave"] = log["eval score ave"]
                csvlog["layer in max"] = q.layer0.weight.to("cpu").detach().numpy().max()
                csvlog["layer out max"] = q.layer99.weight.to("cpu").detach().numpy().max()
                csvlog["eval win"] = log["win"]
                csvlog["eval lose"] = log["lose"]
                csvlog["eval timeout"] = log["timeout"]
                csvlog["eval unknown"] = log["unknown"]
                if log["win"] + log["lose"] != 0:
                    csvlog["eval win rate"] = log["win"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                csvlog["eval timeout rate"] = log["timeout"] / (
                    log["win"] + log["lose"] + log["timeout"] + log["unknown"]
                )

                print(f"eval time {log['eval time']}")
                print(f"layer in max {q.layer0.weight.to('cpu').detach().numpy().max()}")
                print(f"layer out max {q.layer99.weight.to('cpu').detach().numpy().max()}")
                print(
                    f'eval result : win:{log["win"]}, lose:{log["lose"]}, timeout:{log["timeout"]}, unknown:{log["unknown"]}'
                )
                print(f"eval score ave {log['eval score ave']}")

                print(result_dir_path)

                with open(filename, "a", newline="", encoding="utf-8") as csvfile:
                    writer = csv.DictWriter(csvfile, fieldnames=header)
                    writer.writerow(csvlog)

                ### save pth of eval
                if (
                    (num_episode + 0) % int(SAVE_INTERVAL) == 0
                    and num_episode != 0
                    and log["win"] / EVAL_ITERATION_NUM > 0.8
                ):
                    torch.save(q.state_dict(), f"{result_dir_path}/{str(num_episode + 1)}.pth")

            ### target update
            if (num_episode + 0) % int(TARGET_UPDATE_INTERVAL) == 0 and num_episode != 0:
                q_target.load_state_dict(q.state_dict())

    print(f"total elapsed time {time.time() - start_time}")

    # plot
    fig = plt.figure()
    ax1 = fig.subplots()
    ax2 = ax1.twinx()

    (line1,) = ax1.plot(logs["train loss"], label="training loss", color="blue")
    # (line2,) = ax2.plot(logs["eval score ave"], label="eval score ave", color="red")
    (line2,) = ax2.plot(logs["eval win rate"], label="eval win rate", color="red")

    # ax1.set_yscale("log")

    ax1.legend(handles=[line1], loc="upper left", bbox_to_anchor=(-0.1, 0.5))
    ax2.legend(handles=[line2], loc="upper right", bbox_to_anchor=(1.1, 0.5))

    plt.savefig(f"{result_dir_path}/learning_curve.png")
    plt.show()

    env.close()

    print(result_dir_path)


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="battlegame-v0")

    args = parser.parse_args()

    logging.info(vars(args)["env"])

    main(variant=vars(args))
