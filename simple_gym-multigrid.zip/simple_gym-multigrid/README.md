# SimpleBattleGrid
<br>

# Description
battlegridは、minigridないしgym-multigridをベースとした、対戦型のシミュレータです。
<br><br>
# Demo
- 敵味方がgrid上を進み、敵を発見し、敵を攻撃することで報酬を得るゲームです。
- 観測情報は、「エリア」と「視野」に分かれている。
- 「エリア」について、固定物（現状はwallのみ）はどの位置からでも観測できる。
- 「視野」は自分の位置を基準とした領域で、その中でのみ敵agentを観測できる。
- 味方同士は視野情報を共有している。
- 「視野」の形状はオプションで変更可能
- 攻撃は視野の中に敵agentが存在するときに有効です。視野内に敵がいないときでも攻撃は可能です。
<br><br>
# Requirement
- Ubuntu 20.04+
- Python 3.8+
- gym(gymnasium) 0.26.2+
- numpy 1.24.2+
- matplotlib 3.6.2+ 
<br><br>
# Test
```
python test_env.py
```
<br>
parsarは'--env'のみ。未入力の場合、battlegame-v0が実行されます。

```
python test_env.py --env battlegame-v6
```

<br><br>
--envは以下6通り
|||
|-|-|
|battlegame-v0|Debug用の環境。どうなっているか不明。|
|battlegame-v1|1vs1 battle game<br>battle area 5x5<br>view 3x3<br>max step 25<br>wall 20 %<br>|
|battlegame-v2|1vs1 battle game<br>battle area 7x7<br>view 3x3<br>max step 50<br>wall 20 %<br>|
|battlegame-v3|2vs2 battle game<br>battle area 9x9<br>view 5x5<br>max step 100<br>wall 20 %<br>|
|battlegame-v4|2vs2 battle game<br>battle area 11x11<br>view 5x5<br>max step 150<br>wall 20 %<br>|
|battlegame-v5|3vs3 battle game<br>battle area 13x13<br>view 7x7<br>max step 200<br>wall 20 %<br>|
|battlegame-v6|3vs3 battle game<br>battle area 15x15<br>view 7x7<br>max step 250<br>wall 20 %<br>|
|mazegame-v1|maze game<br>maze area 5x5<br>view 1x2<br>max step 25|
|mazegame-v2|maze game<br>maze area 7x7<br>view 1x2<br>max step 50|
|mazegame-v3|maze game<br>maze area 9x9<br>view 1x2<br>max step 100|
|mazegame-v4|maze game<br>maze area 11x11<br>view 1x2<br>max step 150|
|mazegame-v5|maze game<br>maze area 13x13<br>view 1x2<br>max step 200|

## Design1
以下はconstants.pyで設定を変更できるシミュレータの基本設定です。
<br><br>
### OBJECT
OBJECT_TO_IDXで定義され、不要なOBJECTはコメントアウトしてあります。
効果OBJECTについて、現在はwallのみですが、今後の改良で適宜追加可能です。
- "unseen":1
- "empty":2
- "wall":3
- "agent":11
<br><br>
### COLOR
COLOR_TO_IDXで定義され、不要なCOLORはコメントアウトしてあります。
"black"は基本的に使いません。
エージェントの色はteamごとに"blue"から順番に割り当てられます。
観測範囲は全エージェントで別に割り振られるため、COLORはエージェント数+2("black"と"dark_gray(:wall)")が必要です。
- "black":0
- "blue":1
- "red":2
- "lime":3
- "aqua":4
- "fuchsia":5
- "yellow":6
- "dark_gray":14
<br><br>
### DIRECTION
DIR_TO_IDXで定義されるエージェントの方向です。各向きのベクトルはDIR_TO_VECで変換されます。
右がXの正、下がYの正です。
- "right": 1,
- "rightdown": 2,
- "down": 3,
- "leftdown": 4,
- "left": 5,
- "leftup": 6,
- "up": 7,
- "rightup": 8,
<br><br>
### WHOM
MYSELF_TO_IDXで定義される、観測しているエージェントが自分か他人か、の判定に用いるパラメータです。
- "myself"
- "other"
<br><br>
## Design2
追加パラメータについて

|||
|-|-|
|target_goal|True : 目標を目的地とするモード。<br>観測範囲が局限され、敵は自分の位置のみを攻撃し続ける。敗北=勝利報酬となっているため、攻撃されても+報酬となる。<br><br>False : 対戦モード|
|init_pos_set_besides|True : 敵味方の初期位置を左右に分ける。左に味方(青)、右に敵(赤)。<br>ただし、左右の分割はエージェント数を二分しているため、チーム数3, エージェント数2の場合は、[青、青、赤] [赤、緑、緑]で分かれる。<br><br>False : 完全にランダムに配置される。
|simple_fov|True : 観測範囲、行動パターンが簡略化される。<br>観測範囲は正方形となる。<br>行動は待機、回転、前進、攻撃のみ。<br><br>False : 観測範囲が扇形になる。<br>行動は、前後斜めへの移動と後退が追加される。|
|agent_view_angle|simple_fovがFalseの場合の、観測範囲の角度[def]。<br>180とした場合は、±90degとなる。|
<br><br>
## Design3
以下はactions.pyで設定されたagentが選択可能な行動です。
|||
|-|-|
|still|何もしない|
|left|左に回る|
|right|右に回る|
|forward|前に進む|
|fire|攻撃する|
|back|後退する|
|forwardleft|左前方に進み角度が45度左に向く|
|forwardright|右前方に進み角度が45度右に向く|
|backleft|左後方に進み角度が45度右に向く|
|backright|右後方に進み角度が45度左に向く|
<br><br>
## Design4
stepについて
team_num = 2, agent_num = 1のケース
### input
|||
|-|-|
|actions|[int, int]<br>整数のlist型|
<br><br>
### output
|||
|-|-|
|observation|[[dim, height, width], [dim, height, width]]<br>元のgym-multigridとは次元の順番が変わっていることに注意。|
|rewards|[float, float]<br>1step内の報酬の合計|
|done|bool<br>エピソードが終了するとTrueとなる。|
|info|{'reward' : [[str, str], [str]], 'win_team_id' : int}<br>rewardに含まれるstrは以下のイベントを示す。<br>

#### info['reward']に含まれうるイベント情報
|||
|-|-|
|shot|当たった場合のみ|
|got_shot|当てられた場合のみ|
|win|チームが勝利|
|lose|チームが敗北|
|timeout|タイムアウト|

<br><br>
## Design memo
- 障害物含むMAP生成は、はじめに迷路を作ってから、障害物の割合がOBSTACLE_RATE以下となるまでランダムに減らす方式としています。  
その理由として、完全ランダムに障害物を設置すると、agentが初期位置から動けない状況が発生するためです。  
なお、OBSTACLE_RATE=100としておけば、迷路そのものができます。
<br><br>
- LOS計算を行っています。<br>LOSは障害物(wall)によって対象となるgridの中心が見えない場合に見えなくなります。<br>LOS計算を含まない場合分けは現状実装していません。<br>処理は極力軽くしたものの、もう少し軽くできるかもしれません。25x25で実行したところ、良心的な時間で終了したので、最低限使えるレベルかと思います。