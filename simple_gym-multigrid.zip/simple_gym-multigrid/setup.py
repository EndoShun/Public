from setuptools import find_packages, setup


def get_install_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as f:
        reqs = [x.strip() for x in f.read().splitlines()]
    reqs = [x for x in reqs if not x.startswith("#")]
    return reqs


setup(
    name="battlegrid",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.8, <4",
    install_requires=get_install_requirements(),
    include_package_data=True,
    zip_safe=False,
)
