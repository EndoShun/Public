# # # ref
# https://github.com/seungeunrho/minimalRL
# https://github.com/huggingface/transformers/blob/main/examples/research_projects/decision_transformer/run_decision_transformer.py
# pyenv python 3.10.9 in mhiavio PC

# import wandb
import argparse
import collections
import csv
import datetime
import importlib
import logging
import math
import pickle
import random
import shutil
import sys
import termios
import time
import tty
import warnings
from itertools import count
from logging import DEBUG, WARN, FileHandler, Formatter, StreamHandler, basicConfig, getLogger
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.transforms as T
import transformers
from battlegrid import make
from battlegrid.core.custom_env import CustomSimpleActions, CustomWorld
from battlegrid.envs.custom_battlegrid import (
    BattleGame_1vs1_5x5_wall20,
    BattleGame_1vs1_7x7_wall20,
    BattleGame_2vs2_9x9_wall20,
    BattleGame_2vs2_11x11_wall20,
    BattleGame_3vs3_13x13_wall20,
    BattleGame_3vs3_15x15_wall20,
    BattleGame_debug,
    MazeGame_1vs1_5x5,
    MazeGame_1vs1_7x7,
    MazeGame_1vs1_9x9,
    MazeGame_1vs1_11x11,
    MazeGame_1vs1_13x13,
)
from decision_transformer.models.trajectory_gpt2 import GPT2Model
from learn_setting import LOAD, LOAD_DIR, LOAD_FILE
from PIL import Image
from tqdm import tqdm, trange

if LOAD:
    module = importlib.import_module(f"{LOAD_DIR}.learn_setting")

    ACTIVATION_FUNC = module.ACTIVATION_FUNC
    BATCH_SIZE = module.BATCH_SIZE
    BUFFER_LIMIT_DT = module.BUFFER_LIMIT_DT
    DATASET_LOAD = module.DATASET_LOAD
    DATASET_SAVE = module.DATASET_SAVE
    DEVICE = module.DEVICE
    DISPOSE_RATE = module.DISPOSE_RATE
    DROPOUT = module.DROPOUT
    EMBED_DIM = module.EMBED_DIM
    ENV_TARGETS = module.ENV_TARGETS
    EPISODES = module.EPISODES
    EVAL_ITERATION_NUM = module.EVAL_ITERATION_NUM
    EVAL_VIEW = True
    GAMMA = module.GAMMA
    ITERATION_NUM = module.ITERATION_NUM
    DEFAULT_LEARNING_RATE = module.DEFAULT_LEARNING_RATE
    LOG_TO_WANDB = module.LOG_TO_WANDB
    MANUAL_MODE = module.MANUAL_MODE
    MAX_LEN = module.MAX_LEN
    N_HEAD = module.N_HEAD
    N_LAYER = module.N_LAYER
    N_POSITIONS = module.N_POSITIONS
    EMBED_DIM = module.EMBED_DIM
    PCT_TRAJECTORY = module.PCT_TRAJECTORY
    PRINT_INTERVAL = module.PRINT_INTERVAL
    RULE_BASE = module.RULE_BASE
    SAVE_INTERVAL = module.SAVE_INTERVAL
    SCALE = module.SCALE
    SLEEP_TIME = module.SLEEP_TIME
    TARGET_UPDATE_INTERVAL = module.TARGET_UPDATE_INTERVAL
    TEMP_BOT = module.TEMP_BOT
    TEMP_TOP = module.TEMP_TOP
    TRAIN_INTERVAL = module.TRAIN_INTERVAL
    TRAIN_ITERATION_NUM = module.TRAIN_ITERATION_NUM
    TRAIN_START_SIZE = module.TRAIN_START_SIZE
    TRAIN_VIEW = True
    UNIT_ID = module.UNIT_ID
    WARMUP_STEP = module.WARMUP_STEP
    WEIGHT_DECAY = module.WEIGHT_DECAY
else:
    from learn_setting import (
        ACTIVATION_FUNC,
        BATCH_SIZE,
        BUFFER_LIMIT_DT,
        DATASET_LOAD,
        DATASET_SAVE,
        DEFAULT_LEARNING_RATE,
        DEVICE,
        DISPOSE_RATE,
        DROPOUT,
        EMBED_DIM,
        ENV_TARGETS,
        EPISODES,
        EVAL_ITERATION_NUM,
        EVAL_VIEW,
        GAMMA,
        ITERATION_NUM,
        LOAD,
        LOAD_DIR,
        LOAD_FILE,
        LOG_TO_WANDB,
        MANUAL_MODE,
        MAX_LEN,
        N_HEAD,
        N_LAYER,
        N_POSITIONS,
        PCT_TRAJECTORY,
        PRINT_INTERVAL,
        RULE_BASE,
        SAVE_INTERVAL,
        SCALE,
        SLEEP_TIME,
        TARGET_UPDATE_INTERVAL,
        TEMP_BOT,
        TEMP_TOP,
        TRAIN_INTERVAL,
        TRAIN_ITERATION_NUM,
        TRAIN_START_SIZE,
        TRAIN_VIEW,
        UNIT_ID,
        WARMUP_STEP,
        WEIGHT_DECAY,
    )

# with open("data/mem.pickle", "rb") as f:
#     traj = pickle.load(f)

warnings.filterwarnings("ignore", category=DeprecationWarning)

sys.path.append("../")

result_dir_path = Path(f'./data/result/{datetime.datetime.now().strftime("%H%M%S")}')
if not result_dir_path.exists():
    result_dir_path.mkdir(parents=True)
    shutil.copy("./learn_setting.py", result_dir_path)
    shutil.copy("./endo_dt.py", result_dir_path)
    dataset_path = Path(f"{result_dir_path}/memory")
    if not dataset_path.exists():
        dataset_path.mkdir(parents=True)
    print(result_dir_path)

logging.basicConfig(filename=f"{result_dir_path}/dt_log.txt", level=logging.INFO)


def temperature_softmax(logits, temperature=1.0):

    """Softmax with Temperature function
    Args:
        logits(Tensor array) : array of action
        temperature(float) : temperature

    Returns:
        softmax_probs

    Note:
        温度Tが1より大きいとき: 低い確率を強調
        温度Tが1より小さいとき: 高い確率を強調
        y=e(x)はxが大きくなると飛躍的にyが大きくなるのでTが小さい→xが大きくなる→高い確率が強調される

        https://qiita.com/nkriskeeic/items/db3b4b5e835e63a7f243
    """
    scaled_logits = logits / temperature
    softmax_probs = torch.softmax(scaled_logits, dim=-1)
    return softmax_probs


def evaluate_episode_rtg(
    env,
    obs_dim,
    act_dim,
    model,
    max_ep_len=1000,
    scale=1000.0,
    state_mean=0.0,
    state_std=1.0,
    device="cuda",
    target_return=None,
    mode="normal",
):

    """summary
    Args:
        hoge

    Returns:
        fuga

    Notes:
        evaluate_episode_rtgでは1エピソードのみ。
    """

    model.eval()
    model.to(device=DEVICE)

    onehot_obs = np.zeros(shape=(all_agent_num, total_encode_dim, height, width))
    rotate_obs = np.zeros(shape=(all_agent_num, total_encode_dim, int(area**0.5), int(area**0.5)))
    flat_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))
    pre_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))
    post_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))

    act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")

    team_rewards = [0 for _ in range(all_agent_num)]

    states, rewards, done, _ = env.reset()

    # init obs
    for a in range(all_agent_num):
        self_pos = np.where(states[a][enc_self, :, :] == 1)  # 自分の位置(np,array(x), np.array(y))を取得
        self_dir = states[a][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

        onehot_obs[a] = obs_onehot_encode(states[a])
        rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
        flat_obs[a] = rotate_obs[a].flatten()

        act_mask[a] = prohibit_action(states[a])

    # 仲間のobsと連結
    for t in range(team_num):
        for a in range(agent_num):
            args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
            pre_obs[t * agent_num + a] = np.concatenate(args, axis=0)

    states_t = torch.from_numpy(pre_obs[UNIT_ID]).to(device=DEVICE).reshape(1, obs_dim * agent_num)
    actions_t = torch.zeros((0, act_dim), device=DEVICE, dtype=torch.float32)
    rewards_t = torch.zeros(0, device=DEVICE, dtype=torch.float32)

    # ep_return = target_return
    ep_return = env_targets / scale
    target_return = torch.tensor(ep_return, device=DEVICE, dtype=torch.float32).reshape(1, 1)
    timesteps = torch.tensor(0, device=DEVICE, dtype=torch.long).reshape(1, 1)

    step_count = 0
    while not done:
        if EVAL_VIEW:
            env.render(mode="human", highlight=True)
            time.sleep(SLEEP_TIME)

        # add padding
        actions_t = torch.cat([actions_t, torch.zeros((1, act_dim), device=DEVICE)], dim=0)
        rewards_t = torch.cat([rewards_t, torch.zeros(1, device=DEVICE)])

        act_indices = [np.where(act_mask[a] == 1)[0] for a in range(all_agent_num)]
        actions = [
            torch.from_numpy(act_onehot_encode(np.random.choice(act_indices[a]))) for a in range(all_agent_num)
        ]  # とりあえず全agentのactionをmaskした上でランダムに決定

        actions[UNIT_ID] = model.sample_action(
            (states_t.to(dtype=torch.float32)),
            actions_t.to(dtype=torch.float32),
            rewards_t.to(dtype=torch.float32),
            target_return.to(dtype=torch.float32),
            timesteps.to(dtype=torch.long),
        )
        # ts_action = temperature_softmax(actions[UNIT_ID], torch.tensor(0.0001))
        # max_idx = torch.multinomial(ts_action, num_samples=1).item()
        max_idx = torch.argmax(actions[UNIT_ID])
        actions[UNIT_ID] = torch.zeros_like(actions[UNIT_ID])
        actions[UNIT_ID][max_idx] = 1

        for a in range(all_agent_num):
            actions[a] = actions[a].to("cpu").detach().numpy().copy().astype("uint8")

        input_actions = [np.argmax(actions[i]) for i in range(all_agent_num)]

        if target_goal:
            for i in range(all_agent_num):
                if i != UNIT_ID:
                    input_actions[i] = 0

        # actionsに格納するのは、推測したaction値（小数）ではなく、onehotにした値。
        actions_t[-1] = torch.from_numpy(actions[UNIT_ID]).to(device=DEVICE)

        # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
        next_states, rewards, done, info = env.step(input_actions)
        # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

        if EVAL_VIEW:
            print(f"act:{input_actions[UNIT_ID]}, reward:{rewards[UNIT_ID]}")

        act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")

        for a in range(all_agent_num):
            self_pos = np.where(next_states[a][enc_self, :, :] == 1)  # 自分の位置(np,array(x), np.array(y))を取得
            self_dir = next_states[a][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

            onehot_obs[a] = obs_onehot_encode(next_states[a])
            rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
            flat_obs[a] = rotate_obs[a].flatten()

            act_mask[a] = prohibit_action(next_states[a])

        # 仲間のobsと連結
        for t in range(team_num):
            for a in range(agent_num):
                args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                post_obs[t * agent_num + a] = np.concatenate(args, axis=0)

        next_state_t = torch.from_numpy(post_obs[UNIT_ID]).to(device=DEVICE).reshape(1, obs_dim * agent_num)
        states_t = torch.cat([states_t, next_state_t], dim=0)

        act_mask = [prohibit_action(next_states[a]) for a in range(all_agent_num)]

        rewards_t[-1] = torch.from_numpy(np.array(rewards[UNIT_ID]))

        pred_return = target_return[0, -1] - (rewards[UNIT_ID] / scale)
        target_return = torch.cat([target_return, pred_return.reshape(1, 1)], dim=1)
        timesteps = torch.cat(
            [timesteps, torch.ones((1, 1), device=DEVICE, dtype=torch.long) * (step_count + 1)],
            dim=1,
        )
        step_count += 1

        team_rewards = rewards.copy()

    return info, team_rewards


def obs_onehot_encode(obs):
    onehot_obs = np.zeros((total_encode_dim, height, width), dtype=np.float32)

    if encode_dim == 6:
        channel_nums = [
            list(OBJECT_TO_IDX.values()),
            list(COLOR_TO_IDX.values()),
            list(OBJECT_TO_IDX.values()),
            list(COLOR_TO_IDX.values()),
            list(DIR_TO_IDX.values()),
            list(MYSELF_TO_IDX.values()),  # 0:null, 1:myself, 2:other
        ]
    elif encode_dim == 4:
        channel_nums = [
            list(OBJECT_TO_IDX.values()),
            list(COLOR_TO_IDX.values()),
            list(DIR_TO_IDX.values()),
            list(MYSELF_TO_IDX.values()),  # 0:null, 1:myself, 2:other
        ]
    count_num = 0

    for ch_idx, channel_num in enumerate(channel_nums):
        for obj_idx in channel_num:
            onehot_obs[count_num, :, :][np.where(obs[ch_idx, :, :] == obj_idx)] = 1
            count_num += 1

    return onehot_obs


def obs_rotate_encode(onehot_obs, pos, dir):
    side = max(height, width) * 2 - 1
    norm_obs = np.zeros((total_encode_dim, side, side), dtype=np.float32)  # "+2はcurrent_agentの0と1。"
    norm_obs[
        :,
        int((side + 1) / 2 - pos[0][0] - 1) : int((side + 1) / 2 - pos[0][0] + height - 1),
        int((side + 1) / 2 - pos[1][0] - 1) : int((side + 1) / 2 - pos[1][0] + width - 1),
    ] = onehot_obs

    if dir == 1:
        rotate_obs = np.rot90(norm_obs, 1, axes=(1, 2))
    elif dir == 3:
        rotate_obs = np.rot90(norm_obs, 2, axes=(1, 2))
    elif dir == 5:
        rotate_obs = np.rot90(norm_obs, 3, axes=(1, 2))
    elif dir == 7:
        rotate_obs = np.rot90(norm_obs, 4, axes=(1, 2))
    else:
        assert dir % 2 == 1, "dir = {dir} : simple_fov = False is not still supported"

    return rotate_obs


def act_onehot_encode(act):
    onehot_act = np.identity(act_dim, dtype=np.uint8)
    onehot_act = np.array(onehot_act[act])
    return onehot_act


def act_discrete_encode(onehot_act_np):
    return np.where(onehot_act_np == 1)[0]


def prohibit_action(obs):
    """prohibit wasteful actions

    args:
        observation (np.array(dim, height, width): agent's observation
    return:
        action mask (list): valid action is one, invalid action is zero.

    - assume the agent_view_angle = 180deg
    - ex) NOT to rotate like as narrowing the visible area.
    - ex) NOT to go ahead for the wall.
    """

    act_mask = np.ones(shape=(act_dim), dtype="int8")

    self_pos = np.where(obs[enc_self, :, :] == 1)  # 自分の位置(np,array(y), np.array(x))を取得
    self_dir = obs[enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

    if self_dir == 1:  # 右
        front_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
        left_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] - 0]
        right_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
        back_obj = obs[enc_obj, self_pos[0][0] - 0, self_pos[1][0] - 1]
    elif self_dir == 3:  # 下
        front_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
        left_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
        right_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] - 1]
        back_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] + 0]
    elif self_dir == 5:  # 左
        front_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] - 1]
        left_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
        right_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] + 0]
        back_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
    elif self_dir == 7:  # 上
        front_obj = obs[enc_obj, self_pos[0][0] - 1, self_pos[1][0] + 0]
        left_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] - 1]
        right_obj = obs[enc_obj, self_pos[0][0] + 0, self_pos[1][0] + 1]
        back_obj = obs[enc_obj, self_pos[0][0] + 1, self_pos[1][0] + 0]
    else:
        assert self_dir % 2 == 1, "dir = {dir} : 'simple_fov = False' is not still supported now"

    if front_obj == OBJECT_TO_IDX["wall"]:  # 前が壁の場合
        if left_obj == OBJECT_TO_IDX["wall"] and right_obj == OBJECT_TO_IDX["wall"]:  # 前と左と右だけが壁の場合
            act_mask[CustomSimpleActions.forward] = 0
            act_mask[CustomSimpleActions.still] = 0
        elif left_obj == OBJECT_TO_IDX["wall"]:  # 前と左だけが壁の場合
            act_mask[CustomSimpleActions.forward] = 0
            act_mask[CustomSimpleActions.still] = 0
            act_mask[CustomSimpleActions.left] = 0
        elif right_obj == OBJECT_TO_IDX["wall"]:  # 前と右だけが壁の場合
            act_mask[CustomSimpleActions.forward] = 0
            act_mask[CustomSimpleActions.still] = 0
            act_mask[CustomSimpleActions.right] = 0
        else:  # 前だけが壁の場合
            act_mask[CustomSimpleActions.forward] = 0
    elif left_obj == OBJECT_TO_IDX["wall"] and right_obj == OBJECT_TO_IDX["wall"]:
        if back_obj == OBJECT_TO_IDX["wall"]:  # 左と右と後だけが壁の場合
            act_mask[CustomSimpleActions.left] = 0
            act_mask[CustomSimpleActions.right] = 0
        else:  # 左と右だけが壁の場合
            pass
    elif left_obj == OBJECT_TO_IDX["wall"] and right_obj != OBJECT_TO_IDX["wall"]:  # 左が壁の場合
        act_mask[CustomSimpleActions.left] = 0
    elif left_obj != OBJECT_TO_IDX["wall"] and right_obj == OBJECT_TO_IDX["wall"]:  # 右が壁の場合
        act_mask[CustomSimpleActions.right] = 0

    return act_mask


def discount_cumsum(x, gamma):
    discount_cumsum = np.zeros_like(x)
    discount_cumsum[-1] = x[-1]
    for t in reversed(range(x.shape[0] - 1)):
        discount_cumsum[t] = x[t] + gamma * discount_cumsum[t + 1]
    return discount_cumsum


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        char = sys.stdin.read(1)
        if char == "\x1b":  # エスケープシーケンスの場合、矢印キーとして処理
            char += sys.stdin.read(2)  # 残りの2文字を読み込む
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return char


class ReplayBuffer:  # Bufferはnumpy形式、batchのreturnはtensor形式(GPU)。
    def __init__(self):
        self.buffer = collections.deque(maxlen=BUFFER_LIMIT_DT)  # deque型（ところてん型）のオブジェクト。最大長がBUFFER_LIMIT
        self.num_trajectories = len(self.buffer)

    def dataset_load(self):

        self.buffer.clear()
        self.num_trajectories = len(self.buffer)

        for _ in range(BATCH_SIZE):
            # self.buffer.extend(torch.load(f"/media/mhiavio/Ubuntu_HDD/DT_5x5_battle/dt_ep{random.randint(1, EPISODES)}.pth"))
            self.buffer.append(
                torch.load(f"/media/mhiavio/Ubuntu_HDD/DT_5x5_battle/dt_ep{random.randint(1, 10000)}.pth")
            )

    def put(self, trajectories):
        self.buffer.append(trajectories)  # bufferにはtransitionが格納されていく。

    def size(self):
        return len(self.buffer)

    def traj_lens_and_returns(self):
        traj_lens, returns = [], []
        for traj in self.buffer:
            traj_lens.append(len(traj["observations"]))
            traj_reward0 = [traj["rewards"][i][UNIT_ID] for i in range(len(traj["rewards"]))]
            returns.append(np.array(traj_reward0).sum())
        return np.array(traj_lens), np.array(returns)

    def get_batch(self):

        # torch.cuda.empty_cache()

        traj_lens, returns = self.traj_lens_and_returns()
        num_timesteps = sum(traj_lens)
        max_len = MAX_LEN

        # only train on top pct_traj trajectories (for %BC experiment)
        num_timesteps = max(int(PCT_TRAJECTORY * num_timesteps), 1)
        sorted_inds = np.argsort(returns)  # lowest to highest
        num_trajectories = 1
        timesteps = traj_lens[sorted_inds[-1]]
        ind = self.size() - 2
        while ind >= 0 and timesteps + traj_lens[sorted_inds[ind]] <= num_timesteps:
            timesteps += traj_lens[sorted_inds[ind]]
            num_trajectories += 1
            ind -= 1
        sorted_inds = sorted_inds[-num_trajectories:]

        # used to reweight sampling so we sample according to timesteps instead of trajectories
        p_sample = traj_lens[sorted_inds] / sum(traj_lens[sorted_inds])

        batch_inds = np.random.choice(
            np.arange(num_trajectories),
            size=min(BATCH_SIZE, len(self.buffer)),
            replace=True,
            p=p_sample,  # reweights so we sample according to timesteps
        )
        s, a, r, d, rtg, timesteps, mask = [], [], [], [], [], [], []

        buffer0 = []  # unitのbufferのみをを抽出
        for ep_n in range(len(self.buffer)):  # episode num
            buffer0.append(
                {
                    "observations": [],
                    "next_observations": [],
                    "actions": [],
                    "rewards": [],
                    "terminals": [],
                }
            )
            for st_n in range(len(self.buffer[ep_n]["observations"])):  # step num
                buffer0[ep_n]["observations"].append(np.array(self.buffer[ep_n]["observations"][st_n][UNIT_ID]))
                buffer0[ep_n]["next_observations"].append(
                    np.array(self.buffer[ep_n]["next_observations"][st_n][UNIT_ID])
                )

                buffer0[ep_n]["actions"].append(np.array(self.buffer[ep_n]["actions"][st_n][UNIT_ID]))
                buffer0[ep_n]["rewards"].append(np.array(self.buffer[ep_n]["rewards"][st_n][UNIT_ID]))
                buffer0[ep_n]["terminals"].append(np.array(self.buffer[ep_n]["terminals"][st_n][UNIT_ID]))

            buffer0[ep_n]["observations"] = np.array(buffer0[ep_n]["observations"])
            buffer0[ep_n]["next_observations"] = np.array(buffer0[ep_n]["next_observations"])
            buffer0[ep_n]["actions"] = np.array(buffer0[ep_n]["actions"])
            buffer0[ep_n]["rewards"] = np.array(buffer0[ep_n]["rewards"])
            buffer0[ep_n]["terminals"] = np.array(buffer0[ep_n]["terminals"])

        for bs in range(min(BATCH_SIZE, len(self.buffer))):  # bs:batch_size

            traj = buffer0[int(sorted_inds[batch_inds[bs]])]

            si = random.randint(0, traj["rewards"].shape[0] - 1)  # step index
            last_si = min(max_len, len(traj["observations"]) - si)

            # get sequences from dataset
            obs0 = np.array([traj["observations"][s] for s in range(si, si + last_si)])
            s.append(obs0.reshape(1, -1, obs_dim_ext * agent_num))

            act0 = np.array([traj["actions"][s] for s in range(si, si + last_si)])
            a.append(act0.reshape(1, -1, act_dim))

            r.append(traj["rewards"][si : si + max_len].reshape(1, -1, 1))

            if "terminals" in traj:
                d.append(traj["terminals"][si : si + max_len].reshape(1, -1))
            else:
                d.append(traj["dones"][si : si + max_len].reshape(1, -1))

            timesteps.append(np.arange(si, si + s[-1].shape[1]).reshape(1, -1))
            timesteps[-1][timesteps[-1] >= max_ep_len] = max_ep_len - 1  # padding cutoff

            rtg.append(discount_cumsum(traj["rewards"][si:], gamma=GAMMA)[: s[-1].shape[1] + 1].reshape(1, -1, 1))
            # rtg.append(discount_cumsum(traj["rewards"][si:], gamma=1.)[: s[-1].shape[1] + 1].reshape(1, -1, 1)) # original
            if rtg[-1].shape[1] <= s[-1].shape[1]:
                rtg[-1] = np.concatenate([rtg[-1], np.zeros((1, 1, 1))], axis=1)

            # padding and state + reward normalization
            tlen = s[-1].shape[1]
            s[-1] = np.concatenate([np.zeros((1, max_len - tlen, obs_dim_ext * agent_num)), s[-1]], axis=1)
            # s[-1] = (s[-1] - state_mean) / state_std
            a[-1] = np.concatenate([np.ones((1, max_len - tlen, act_dim)) * -10.0, a[-1]], axis=1)
            r[-1] = np.concatenate([np.zeros((1, max_len - tlen, 1)), r[-1]], axis=1)
            d[-1] = np.concatenate([np.ones((1, max_len - tlen)) * 2, d[-1]], axis=1)
            rtg[-1] = np.concatenate([np.zeros((1, max_len - tlen, 1)), rtg[-1]], axis=1) / scale
            timesteps[-1] = np.concatenate([np.zeros((1, max_len - tlen)), timesteps[-1]], axis=1)
            mask.append(np.concatenate([np.zeros((1, max_len - tlen)), np.ones((1, tlen))], axis=1))

        s = torch.from_numpy(np.concatenate(s, axis=0)).to(dtype=torch.float32, device=DEVICE)
        a = torch.from_numpy(np.concatenate(a, axis=0)).to(dtype=torch.float32, device=DEVICE)
        r = torch.from_numpy(np.concatenate(r, axis=0)).to(dtype=torch.float32, device=DEVICE)
        d = torch.from_numpy(np.concatenate(d, axis=0)).to(dtype=torch.long, device=DEVICE)
        rtg = torch.from_numpy(np.concatenate(rtg, axis=0)).to(dtype=torch.float32, device=DEVICE)
        timesteps = torch.from_numpy(np.concatenate(timesteps, axis=0)).to(dtype=torch.long, device=DEVICE)
        mask = torch.from_numpy(np.concatenate(mask, axis=0)).to(device=DEVICE)

        return s, a, r, d, rtg, timesteps, mask


class TrajectoryModel(nn.Module):
    def __init__(self, obs_dim, act_dim, max_length=None):
        super().__init__()

        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.max_length = max_length

    def forward(self, states, actions, rewards, masks=None, attention_mask=None):
        # "masked" tokens or unspecified inputs can be passed in as None
        return None, None, None

    def sample_action(self, states, actions, rewards, **kwargs):
        # these will come as tensors on the correct device
        return torch.zeros_like(actions[-1])


class DecisionTransformer(TrajectoryModel):

    """
    This model uses GPT to model (Return_1, state_1, action_1, Return_2, state_2, ...)
    """

    def __init__(
        self,
        obs_dim,
        act_dim,
        hidden_size,
        max_length=None,
        max_ep_len=4096,
        action_tanh=True,
        **kwargs,
    ):
        super().__init__(obs_dim, act_dim, max_length=max_length)

        self.hidden_size = hidden_size
        config = transformers.GPT2Config(
            vocab_size=1,  # doesn't matter -- we don't use the vocab
            n_embd=hidden_size,
            **kwargs,
        )

        # note: the only difference between this GPT2Model and the default Huggingface version
        # is that the positional embeddings are removed (since we'll add those ourselves)
        self.transformer = GPT2Model(config)

        self.embed_state = torch.nn.Linear(self.obs_dim, hidden_size)
        self.embed_return = torch.nn.Linear(1, hidden_size)
        self.embed_action = torch.nn.Linear(self.act_dim, hidden_size)
        self.embed_timestep = nn.Embedding(max_ep_len, hidden_size)
        self.embed_ln = nn.LayerNorm(hidden_size)

        # note: we don't predict states or returns for the paper
        self.predict_state = torch.nn.Linear(hidden_size, self.obs_dim)
        self.predict_action = nn.Sequential(
            *([nn.Linear(hidden_size, self.act_dim)] + ([nn.Tanh()] if action_tanh else []))
        )
        self.predict_return = torch.nn.Linear(hidden_size, 1)

    def forward(self, states, actions, rewards, returns_to_go, timesteps, attention_mask=None):

        batch_size, seq_length = states.shape[0], states.shape[1]

        if attention_mask is None:
            # attention mask for GPT: 1 if can be attended to, 0 if not
            attention_mask = torch.ones((batch_size, seq_length), dtype=torch.long)

        # embed each modality with a different head
        state_embeddings = self.embed_state(states)
        action_embeddings = self.embed_action(actions)
        returns_embeddings = self.embed_return(returns_to_go)
        time_embeddings = self.embed_timestep(timesteps)

        # time embeddings are treated similar to positional embeddings
        state_embeddings = state_embeddings + time_embeddings
        action_embeddings = action_embeddings + time_embeddings
        returns_embeddings = returns_embeddings + time_embeddings

        # this makes the sequence look like (R_1, s_1, a_1, R_2, s_2, a_2, ...)
        # which works nice in an autoregressive sense since states predict actions
        stacked_inputs = (
            torch.stack((returns_embeddings, state_embeddings, action_embeddings), dim=1)
            .permute(0, 2, 1, 3)
            .reshape(batch_size, 3 * seq_length, self.hidden_size)
        )
        stacked_inputs = self.embed_ln(stacked_inputs)

        # to make the attention mask fit the stacked inputs, have to stack it as well
        stacked_attention_mask = (
            torch.stack((attention_mask, attention_mask, attention_mask), dim=1)
            .permute(0, 2, 1)
            .reshape(batch_size, 3 * seq_length)
        )

        # we feed in the input embeddings (not word indices as in NLP) to the model
        transformer_outputs = self.transformer(
            inputs_embeds=stacked_inputs,
            attention_mask=stacked_attention_mask,
        )
        x = transformer_outputs["last_hidden_state"]

        # reshape x so that the second dimension corresponds to the original
        # returns (0), states (1), or actions (2); i.e. x[:,1,t] is the token for s_t
        x = x.reshape(batch_size, seq_length, 3, self.hidden_size).permute(0, 2, 1, 3)

        # get predictions
        return_preds = self.predict_return(x[:, 2])  # predict next return given state and action
        state_preds = self.predict_state(x[:, 2])  # predict next state given state and action
        action_preds = self.predict_action(x[:, 1])  # predict next action given state

        return state_preds, action_preds, return_preds

    def sample_action(self, states, actions, rewards, returns_to_go, timesteps, **kwargs):
        # we don't care about the past rewards in this model
        states = states.reshape(1, -1, self.obs_dim)
        actions = actions.reshape(1, -1, self.act_dim)
        returns_to_go = returns_to_go.reshape(1, -1, 1)
        timesteps = timesteps.reshape(1, -1)

        if self.max_length is not None:
            states = states[:, -self.max_length :]
            actions = actions[:, -self.max_length :]
            returns_to_go = returns_to_go[:, -self.max_length :]
            timesteps = timesteps[:, -self.max_length :]

            # pad all tokens to sequence length
            attention_mask = torch.cat(
                [
                    torch.zeros(self.max_length - states.shape[1]),
                    torch.ones(states.shape[1]),
                ]
            )
            attention_mask = attention_mask.to(dtype=torch.long, device=states.device).reshape(1, -1)
            states = torch.cat(
                [
                    torch.zeros(
                        (
                            states.shape[0],
                            self.max_length - states.shape[1],
                            self.obs_dim,
                        ),
                        device=states.device,
                    ),
                    states,
                ],
                dim=1,
            ).to(dtype=torch.float32)
            actions = torch.cat(
                [
                    torch.zeros(
                        (
                            actions.shape[0],
                            self.max_length - actions.shape[1],
                            self.act_dim,
                        ),
                        device=actions.device,
                    ),
                    actions,
                ],
                dim=1,
            ).to(dtype=torch.float32)
            returns_to_go = torch.cat(
                [
                    torch.zeros(
                        (
                            returns_to_go.shape[0],
                            self.max_length - returns_to_go.shape[1],
                            1,
                        ),
                        device=returns_to_go.device,
                    ),
                    returns_to_go,
                ],
                dim=1,
            ).to(dtype=torch.float32)
            timesteps = torch.cat(
                [
                    torch.zeros(
                        (timesteps.shape[0], self.max_length - timesteps.shape[1]),
                        device=timesteps.device,
                    ),
                    timesteps,
                ],
                dim=1,
            ).to(dtype=torch.long)
        else:
            attention_mask = None

        states = states.to(DEVICE)
        actions = actions.to(DEVICE)
        returns_to_go = returns_to_go.to(DEVICE)
        timesteps = timesteps.to(DEVICE)
        attention_mask = attention_mask.to(DEVICE)

        _, action_preds, return_preds = self.forward(
            states,
            actions,
            None,
            returns_to_go,
            timesteps,
            attention_mask=attention_mask,
            **kwargs,
        )

        return action_preds[0, -1]


class Trainer:
    def __init__(
        self,
        model,
        optimizer,
        batch_size,
        get_batch,
        loss_fn,
        scheduler=None,
        eval_fns=None,
    ):
        self.model = model
        self.optimizer = optimizer
        self.batch_size = batch_size
        self.get_batch = get_batch
        self.loss_fn = loss_fn
        self.scheduler = scheduler
        self.eval_fns = [] if eval_fns is None else eval_fns
        self.diagnostics = dict()

        self.start_time = time.time()

    def train_iteration(self, num_steps, iter_num, print_logs):

        log = dict()

        # 学習モード（＝推論モデルづくり）
        self.model.train()
        self.model.to(device=DEVICE)
        train_start = time.time()

        for _ in tqdm(range(num_steps), ncols=50):
            train_loss = self.train_step()
            if self.scheduler is not None:
                self.scheduler.step()

        log["train time"] = time.time() - train_start
        log["train loss"] = train_loss  # 最後のlossのみを記録

        # 推論モード（＝推論モデルの評価）
        eval_start = time.time()

        score, eval_log = self.eval_fns(self.model)

        log["eval time"] = time.time() - eval_start
        log["eval score ave"] = score / EVAL_ITERATION_NUM
        log["win"] = eval_log["win"]
        log["lose"] = eval_log["lose"]
        log["timeout"] = eval_log["timeout"]
        log["unknown"] = eval_log["unknown"]

        # for k in self.diagnostics:
        #     logs[k] = self.diagnostics[k]

        # if print_logs:
        #     # print('=' * 80)
        #     print(f'Iteration {iter_num}')
        #     for k, v in logs.items():
        #         None
        #         # print(f'{k}: {v}')

        return log

    # def train_step(self): #こっちのtrain_stepは使われない

    #     states, actions, rewards, dones, attention_mask, returns = self.get_batch()
    #     state_target, action_target, reward_target = torch.clone(states), torch.clone(actions), torch.clone(rewards)

    #     state_preds, action_preds, reward_preds = self.model.forward(
    #         states, actions, rewards, masks=None, attention_mask=attention_mask, target_return=returns,
    #     )

    #     # note: currently indexing & masking is not fully correct
    #     loss = self.loss_fn(
    #         state_preds, action_preds, reward_preds,
    #         state_target[:,1:], action_target, reward_target[:,1:],
    #     )
    #     self.optimizer.zero_grad()
    #     loss.backward()
    #     self.optimizer.step()

    #     return loss.detach().cpu().item()


class SequenceTrainer(Trainer):
    def train_step(self):
        (
            states,
            actions,
            rewards,
            dones,
            rtg,
            timesteps,
            attention_mask,
        ) = self.get_batch()
        action_target = torch.clone(actions)

        state_preds, action_preds, reward_preds = self.model.forward(
            states,
            actions,
            rewards,
            rtg[:, :-1],
            timesteps,
            attention_mask=attention_mask,
        )

        act_dim = action_preds.shape[2]
        action_preds = action_preds.reshape(-1, act_dim)[attention_mask.reshape(-1) > 0]
        action_target = action_target.reshape(-1, act_dim)[attention_mask.reshape(-1) > 0]
        loss = self.loss_fn(
            None,
            action_preds,
            None,
            None,
            action_target,
            None,
        )
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.25)
        self.optimizer.step()  # モデル更新

        with torch.no_grad():
            self.diagnostics["training/action_error"] = (
                torch.mean((action_preds - action_target) ** 2).detach().cpu().item()
            )

        return loss.detach().cpu().item()


def main(variant):
    def eval_episodes(target_rew):
        def fn(model):

            score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0

            log = dict()

            for _ in range(EVAL_ITERATION_NUM):
                with torch.no_grad():
                    # ret, length, info = evaluate_episode_rtg(
                    info, team_rewards = evaluate_episode_rtg(
                        env,
                        obs_dim_ext,
                        act_dim,
                        model,
                        max_ep_len=max_ep_len,
                        scale=scale,
                        target_return=target_rew / scale,
                        mode="normal",
                        state_mean=0,
                        state_std=1,
                        device=DEVICE,
                    )

                    if info["win_team_id"] == None:
                        timeout += 1
                    elif info["win_team_id"] == UNIT_ID // agent_num:
                        win += 1
                    elif info["win_team_id"] != UNIT_ID // agent_num:
                        lose += 1
                    else:
                        unknown += 1

                score += team_rewards[UNIT_ID]  # 全チームの報酬が帰ってくるので、[0]チームだけの報酬を合算。

            log["win"] = win
            log["lose"] = lose
            log["timeout"] = timeout
            log["unknown"] = unknown

            return score, log
            # return {
            #     f'target_{target_rew}_return_mean': np.mean(returns),
            #     f'target_{target_rew}_return_std': np.std(returns),
            #     f'target_{target_rew}_length_mean': np.mean(lengths),
            #     f'target_{target_rew}_length_std': np.std(lengths),
            # }

        return fn

    # end of def

    global height, width, area
    global team_num, agent_num, all_agent_num
    global enc_obj, enc_dir, enc_self
    global encode_dim, total_encode_dim
    global OBJECT_TO_IDX, COLOR_TO_IDX, DIR_TO_IDX, MYSELF_TO_IDX
    global act_dim, obs_dim_ext
    global max_ep_len, env_targets, scale
    global target_goal
    # HACK: 大量のglobal変数作成は苦肉の策として実装したものなので、適宜修正すること。

    env_name = variant["env"]
    env = make(env_name)
    print(env_name)

    if env_name == "battlegame-v0":
        game = BattleGame_debug()
    elif env_name == "battlegame-v1":
        game = BattleGame_1vs1_5x5_wall20()
    elif env_name == "battlegame-v2":
        game = BattleGame_1vs1_7x7_wall20()
    elif env_name == "battlegame-v3":
        game = BattleGame_2vs2_9x9_wall20()
    elif env_name == "battlegame-v4":
        game = BattleGame_2vs2_11x11_wall20()
    elif env_name == "battlegame-v5":
        game = BattleGame_3vs3_13x13_wall20()
    elif env_name == "battlegame-v6":
        game = BattleGame_3vs3_15x15_wall20()
    elif env_name == "mazegame-v1":
        game = MazeGame_1vs1_5x5()
    elif env_name == "mazegame-v2":
        game = MazeGame_1vs1_7x7()
    elif env_name == "mazegame-v3":
        game = MazeGame_1vs1_9x9()
    elif env_name == "mazegame-v4":
        game = MazeGame_1vs1_11x11()
    elif env_name == "mazegame-v5":
        game = MazeGame_1vs1_13x13()

    logging.info(vars(env))
    logging.info(vars(game))

    height = game.height
    width = game.width

    team_num = game.team_num
    agent_num = game.agent_num
    all_agent_num = team_num * agent_num

    target_goal = game.target_goal

    encode_dim = CustomWorld.encode_dim
    enc_obj = CustomWorld.ENC_OBJ
    enc_col = CustomWorld.ENC_COL
    enc_carobj = CustomWorld.ENC_CAROBJ
    enc_carcol = CustomWorld.ENC_CARCOL
    enc_dir = CustomWorld.ENC_DIR
    enc_self = CustomWorld.ENC_SELF
    total_encode_dim = CustomWorld.total_encode_dim

    COLOR_TO_IDX = CustomWorld.COLOR_TO_IDX
    OBJECT_TO_IDX = CustomWorld.OBJECT_TO_IDX
    DIR_TO_IDX = CustomWorld.DIR_TO_IDX
    MYSELF_TO_IDX = CustomWorld.MYSELF_TO_IDX

    encode_dim = CustomWorld.encode_dim
    total_encode_dim = CustomWorld.total_encode_dim

    area = (max(env.height, env.width) * 2 - 1) ** 2  # observation正規化後の面積
    memory = ReplayBuffer()

    obs_dim = np.prod(env.observation_space.shape)  # encode_dim×縦×横
    obs_dim_ext = area * total_encode_dim  # 拡張後の観測範囲 #total_encode_dim×正規化辺長**2
    act_dim = env.action_space.n

    score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0
    act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")
    onehot_obs = np.zeros(shape=(all_agent_num, total_encode_dim, height, width))
    rotate_obs = np.zeros(shape=(all_agent_num, total_encode_dim, int(area**0.5), int(area**0.5)))
    flat_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))
    pre_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))
    post_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))

    max_ep_len = 1000  # とりあえず
    env_targets = ENV_TARGETS
    scale = SCALE  # normalization for rewards/returns

    memory = ReplayBuffer()

    model = DecisionTransformer(
        obs_dim=obs_dim_ext * agent_num,
        act_dim=act_dim,
        max_length=MAX_LEN,
        max_ep_len=max_ep_len,
        hidden_size=EMBED_DIM,
        n_layer=N_LAYER,
        n_head=N_HEAD,
        n_inner=4 * EMBED_DIM,
        activation_function=ACTIVATION_FUNC,
        n_positions=N_POSITIONS,
        resid_pdrop=DROPOUT,
        attn_pdrop=DROPOUT,
    )
    logging.info(model)
    model = model.to(device=DEVICE)
    model.eval()

    if LOAD:
        path_dir = Path(LOAD_DIR.replace(".", "/"))
        model.load_state_dict(torch.load(path_dir / LOAD_FILE))

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=DEFAULT_LEARNING_RATE * BATCH_SIZE * MAX_LEN,
        weight_decay=WEIGHT_DECAY,
    )
    print(f"lr = {DEFAULT_LEARNING_RATE * BATCH_SIZE * MAX_LEN}")
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda steps: min((steps + 1) / WARMUP_STEP, 1))

    # if log_to_wandb:
    #     wandb.init(
    #         name=exp_prefix,
    #         # group=group_name,
    #         project='decision-transformer',
    #         config=variant
    #     )
    # wandb.watch(model)  # wandb has some bug

    logs = {
        "elapsed time": [],
        "SAMPLE epi": [],
        "SAMPLE score ave": [],
        "SAMPLE win": [],
        "SAMPLE lose": [],
        "SAMPLE timeout": [],
        "SAMPLE unknown": [],
        "SAMPLE win rate": [],
        "SAMPLE buf size": [],
        "SAMPLE temp": [],
        "train time": [],
        "train loss": [],
        "layer in max": [],
        "layer out max": [],
        "eval time": [],
        "eval score ave": [],
        "eval win": [],
        "eval lose": [],
        "eval timeout": [],
        "eval unknown": [],
        "eval win rate": [],
        "eval timeout rate": [],
    }

    csvlog = logs.copy()

    # csvファイル生成
    header = list(logs.keys())
    filename = f"{result_dir_path}/output.csv"
    try:
        with open(filename, mode="x", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(header)
    except FileExistsError:
        pass

    score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0
    act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")
    onehot_obs = np.zeros(shape=(all_agent_num, total_encode_dim, height, width))
    rotate_obs = np.zeros(
        shape=(
            all_agent_num,
            total_encode_dim,
            int(area**0.5),
            int(area**0.5),
        )
    )
    flat_obs = np.zeros(shape=(all_agent_num, obs_dim_ext))
    pre_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))
    post_obs = np.zeros(shape=(all_agent_num, obs_dim_ext * agent_num))

    team_rewards = [0 for _ in range(all_agent_num)]

    dataset = {
        "observations": 0,
        "next_observations": 0,
        "actions": 0,
        "rewards": 0,
        "terminals": 0,
    }

    start_time = time.time()
    continue_num = 0

    if DATASET_LOAD:
        with trange(EPISODES, ncols=70) as progress_bar:
            num_episode = 0
            while num_episode < EPISODES:
                num_episode += 1
                progress_bar.update(1)

                ### train
                if (num_episode + 0) % TRAIN_INTERVAL == 0 and num_episode > 1:
                    timer1 = time.time()
                    memory.dataset_load()
                    print(f"data loading time : {time.time() - timer1}")

                    trainer = SequenceTrainer(
                        model=model,
                        optimizer=optimizer,
                        batch_size=BATCH_SIZE,
                        get_batch=memory.get_batch,
                        loss_fn=lambda s_hat, a_hat, r_hat, s, a, r: torch.mean((a_hat - a) ** 2),
                        scheduler=scheduler,
                        eval_fns=eval_episodes(env_targets),
                    )

                    for iter in range(ITERATION_NUM):

                        log = trainer.train_iteration(
                            num_steps=TRAIN_ITERATION_NUM,
                            iter_num=iter + 1,
                            print_logs=True,
                        )

                        logs["elapsed time"].append(time.time() - start_time)
                        logs["train time"].append(log["train time"])
                        logs["train loss"].append(log["train loss"])
                        logs["eval time"].append(log["eval time"])
                        logs["eval score ave"].append(log["eval score ave"])
                        logs["eval win"].append(log["win"])
                        logs["eval lose"].append(log["lose"])
                        logs["eval timeout"].append(log["timeout"])
                        logs["eval unknown"].append(log["unknown"])
                        if log["win"] + log["lose"] != 0:
                            logs["eval win rate"].append(
                                log["win"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                            )
                        logs["eval timeout rate"].append(
                            log["timeout"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                        )

                        csvlog["train time"] = log["train time"]
                        csvlog["train loss"] = log["train loss"]

                        csvlog["elapsed time"] = time.time() - start_time
                        csvlog["eval time"] = log["eval time"]
                        csvlog["eval score ave"] = log["eval score ave"]
                        csvlog["eval win"] = log["win"]
                        csvlog["eval lose"] = log["lose"]
                        csvlog["eval timeout"] = log["timeout"]
                        csvlog["eval unknown"] = log["unknown"]
                        if log["win"] + log["lose"] != 0:
                            csvlog["eval win rate"] = log["win"] / (
                                log["win"] + log["lose"] + log["timeout"] + log["unknown"]
                            )
                        csvlog["eval timeout rate"] = log["timeout"] / (
                            log["win"] + log["lose"] + log["timeout"] + log["unknown"]
                        )

                        print(f"=== interim log report ===")
                        print(f"elapsed time {time.time() - start_time}")
                        print(f"train time {log['train time']}")
                        print(f"train loss {log['train loss']}")
                        print(f"eval time {log['eval time']}")
                        print(
                            f'eval result : win:{log["win"]}, lose:{log["lose"]}, timeout:{log["timeout"]}, unknown:{log["unknown"]}'
                        )
                        print(f"eval score ave {log['eval score ave']}")

                        print(result_dir_path)

                        with open(filename, "a", newline="", encoding="utf-8") as csvfile:
                            writer = csv.DictWriter(csvfile, fieldnames=header)
                            writer.writerow(csvlog)

                    if (
                        (num_episode + 0) % SAVE_INTERVAL == 0
                        and num_episode != 0
                        and log["win"] / EVAL_ITERATION_NUM > 0.0
                    ):
                        torch.save(
                            model.state_dict(),
                            f"{result_dir_path}/{str(num_episode+0)}.pth",
                        )
    else:
        with trange(EPISODES, ncols=70) as progress_bar:

            num_episode = 0

            while num_episode < EPISODES:

                # 全部[step][unit]の順
                states_list, next_states_list, actions_list, rewards_list, dones_list = (
                    [],
                    [],
                    [],
                    [],
                    [],
                )

                if LOAD:
                    temperature = np.float64(0.001)
                else:
                    temperature = TEMP_TOP * np.exp(-(np.log(TEMP_TOP / TEMP_BOT) / (EPISODES - 1)) * num_episode)

                # get init obs
                next_states, _, done, _ = env.reset()

                for a in range(all_agent_num):
                    self_pos = np.where(next_states[a][enc_self, :, :] == 1)  # 自分の位置(np,array(x), np.array(y))を取得
                    self_dir = next_states[a][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

                    onehot_obs[a] = obs_onehot_encode(next_states[a])
                    rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
                    flat_obs[a] = rotate_obs[a].flatten()

                # 仲間のobsと連結
                for t in range(team_num):
                    for a in range(agent_num):
                        args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                        pre_obs[t * agent_num + a] = np.concatenate(args, axis=0)

                ep_return = env_targets / scale
                target_return = torch.tensor(ep_return, device=DEVICE, dtype=torch.float32).reshape(1, 1)
                timesteps = torch.tensor(0, device=DEVICE, dtype=torch.long).reshape(1, 1)

                step_count = 0
                while not done:
                    if TRAIN_VIEW:
                        env.render(mode="human", highlight=True)
                        time.sleep(SLEEP_TIME)

                    act_indices = [np.where(act_mask[a] == 1)[0] for a in range(all_agent_num)]
                    actions = [
                        torch.from_numpy(act_onehot_encode(np.random.choice(act_indices[a])))
                        for a in range(all_agent_num)
                    ]

                    states_list.append(pre_obs)

                    states_l = [states_list[s][UNIT_ID] for s in range(len(states_list))]
                    states_n = np.array(states_l)
                    states_t = torch.from_numpy(states_n).to(device=DEVICE)

                    actions_l = [actions_list[a][UNIT_ID] for a in range(len(actions_list))]
                    actions_n = np.array(actions_l)
                    actions_t = torch.from_numpy(actions_n).to(device=DEVICE)

                    rewards_l = [rewards_list[r][UNIT_ID] for r in range(len(rewards_list))]
                    rewards_n = np.array(rewards_l)
                    rewards_t = torch.from_numpy(rewards_n).to(device=DEVICE)

                    # add padding
                    actions_t = torch.cat([actions_t, torch.zeros((1, act_dim), device=DEVICE)], dim=0)
                    rewards_t = torch.cat([rewards_t, torch.zeros(1, device=DEVICE)])

                    actions[UNIT_ID] = model.sample_action(
                        states_t.to(dtype=torch.float32),
                        actions_t.to(dtype=torch.float32),
                        rewards_t.to(dtype=torch.float32),
                        target_return.to(dtype=torch.float32),
                        timesteps.to(dtype=torch.long),
                    )  # OPTIMIZE: this takes 10x time more than DQN.

                    ts_action = temperature_softmax(actions[UNIT_ID], temperature)
                    max_idx = torch.multinomial(ts_action, num_samples=1).item()
                    actions[UNIT_ID] = torch.zeros_like(actions[UNIT_ID])
                    actions[UNIT_ID][max_idx] = 1

                    for a in range(all_agent_num):
                        actions[a] = actions[a].to("cpu").detach().numpy().copy().astype("uint8")

                    if RULE_BASE:
                        self_pos = np.where(
                            next_states[UNIT_ID][enc_self, :, :] == 1
                        )  # 自分の位置(np,array(y), np.array(x))を取得
                        self_dir = next_states[UNIT_ID][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得

                        if self_dir == 1:
                            front_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                            back_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]
                            right_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                            left_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                        elif self_dir == 3:
                            front_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                            back_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                            right_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]
                            left_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                        elif self_dir == 5:
                            front_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]
                            back_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                            right_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                            left_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                        elif self_dir == 7:
                            front_obj = next_states[UNIT_ID][enc_obj, self_pos[0] - 1, self_pos[1]]
                            back_obj = next_states[UNIT_ID][enc_obj, self_pos[0] + 1, self_pos[1]]
                            right_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] + 1]
                            left_obj = next_states[UNIT_ID][enc_obj, self_pos[0], self_pos[1] - 1]

                        if front_obj == 11 or right_obj == 11 or left_obj == 11:
                            actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                            actions[UNIT_ID][4] = 1
                        elif front_obj == 3:
                            if right_obj == 3 and left_obj != 3:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][1] = 1
                            elif right_obj != 3 and left_obj == 3:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][2] = 1
                            else:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][random.randint(1, 2)] = 1
                        elif front_obj == 2:
                            if back_obj == 3:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][3] = 1
                            elif left_obj == 2:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][random.choice([1, 3])] = 1
                            elif right_obj == 2:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][random.choice([2, 3])] = 1
                            else:
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])
                                actions[UNIT_ID][3] = 1

                    if MANUAL_MODE and num_episode < 100:
                        try:
                            while True:
                                char = get_key()
                                actions[UNIT_ID] = np.zeros_like(actions[UNIT_ID])

                                if char == "\x1b[B":
                                    actions[UNIT_ID][0] = 1
                                    break
                                elif char == "\x1b[D":
                                    actions[UNIT_ID][1] = 1
                                    break
                                elif char == "\x1b[C":
                                    actions[UNIT_ID][2] = 1
                                    break
                                elif char == "\x1b[A":
                                    actions[UNIT_ID][3] = 1
                                    break
                                elif char == "f":
                                    actions[UNIT_ID][4] = 1
                                    break

                        except KeyboardInterrupt:
                            sys.exit(1)

                    input_actions = [np.argmax(actions[i]) for i in range(all_agent_num)]

                    if target_goal:
                        for i in range(all_agent_num):
                            if i != UNIT_ID:
                                input_actions[i] = 0

                    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
                    next_states, rewards, done, info = env.step(input_actions)
                    # ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

                    if TRAIN_VIEW:
                        print(f"act:{input_actions[UNIT_ID]}, reward:{rewards[UNIT_ID]}")

                    done_mask = [0 if done else 1 for _ in range(all_agent_num)]
                    act_mask = np.ones(shape=(all_agent_num, act_dim), dtype="int8")

                    for a in range(all_agent_num):
                        act_mask[a] = prohibit_action(next_states[a])

                        self_pos = np.where(next_states[a][enc_self, :, :] == 1)  # 自分の位置(np,array(x), np.array(y))を取得
                        self_dir = next_states[a][enc_dir, self_pos[0], self_pos[1]]  # 自分の向きを取得
                        onehot_obs[a] = obs_onehot_encode(next_states[a])
                        rotate_obs[a] = obs_rotate_encode(onehot_obs[a], self_pos, self_dir)
                        flat_obs[a] = rotate_obs[a].flatten()

                    # 仲間のobsと連結
                    for t in range(team_num):
                        for a in range(agent_num):
                            args = tuple(flat_obs[t * agent_num + aa] for aa in range(agent_num))
                            post_obs[t * agent_num + a] = np.concatenate(args, axis=0)

                    # states_list.append(pre_obs)
                    next_states_list.append(post_obs)
                    actions_list.append(actions)
                    rewards_list.append(rewards)
                    dones_list.append(done_mask)

                    pred_return = target_return[0, -1] - (rewards[UNIT_ID] / scale)
                    target_return = torch.cat([target_return, pred_return.reshape(1, 1)], dim=1)
                    timesteps = torch.cat(
                        [timesteps, torch.ones((1, 1), device=DEVICE, dtype=torch.long) * (step_count + 1)], dim=1
                    )

                    step_count += 1
                    pre_obs = post_obs.copy()

                    if done:
                        if info["win_team_id"] == None:
                            timeout += 1
                        elif info["win_team_id"] == UNIT_ID // agent_num:
                            win += 1
                        elif info["win_team_id"] != UNIT_ID // agent_num:
                            lose += 1
                        else:
                            unknown += 1
                        break

                dataset["observations"] = np.array(states_list)
                dataset["next_observations"] = np.array(next_states_list)
                dataset["actions"] = np.array(actions_list)
                dataset["rewards"] = np.array(rewards_list)
                dataset["terminals"] = np.array(dones_list)

                # CHANGED: Decision Transformerは勝ちばっかりが良さそう。DQNは負けもそれなりにあったほうが良さそう。
                if DATASET_SAVE:
                    num_episode += 1
                    progress_bar.update(1)
                    if info["win_team_id"] == None:
                        torch.save(
                            (states, actions, rewards, next_states, done, info),
                            Path(f"/media/mhiavio/Ubuntu_HDD/7x7_2v2_battle/timeout/{num_episode+0000}.pth"),
                        )
                    elif info["win_team_id"] == UNIT_ID // agent_num:
                        torch.save(
                            dataset,
                            Path(f"/media/mhiavio/Ubuntu_HDD/7x7_2v2_battle/win/{num_episode+0000}.pth"),
                        )
                    elif info["win_team_id"] != UNIT_ID // agent_num:
                        torch.save(
                            dataset,
                            Path(f"/media/mhiavio/Ubuntu_HDD/7x7_2v2_battle/lose/{num_episode+0000}.pth"),
                        )
                else:
                    if info["win_team_id"] == None and random.random() < DISPOSE_RATE * 1.1:  # Timeout
                        continue
                    elif info["win_team_id"] != UNIT_ID // agent_num and random.random() < DISPOSE_RATE:  # 負け
                        continue
                    else:
                        score += rewards[UNIT_ID]

                        memory.put(dataset)

                        num_episode += 1
                        progress_bar.update(1)

                if (num_episode + 0) % PRINT_INTERVAL == 0 and num_episode != 0:
                    print(
                        f"SAMPLE : episode:{num_episode}, score ave:{score/PRINT_INTERVAL:.2f}, win:{win}, lose:{lose}, timeout:{timeout}, unknown:{unknown}, buffer:{memory.size()}, temperature:{temperature:.2f}"
                    )
                    csvlog["SAMPLE epi"] = num_episode
                    csvlog["SAMPLE score ave"] = score / PRINT_INTERVAL
                    csvlog["SAMPLE win"] = win
                    csvlog["SAMPLE lose"] = lose
                    csvlog["SAMPLE timeout"] = timeout
                    csvlog["SAMPLE unknown"] = unknown
                    csvlog["SAMPLE win rate"] = win / (win + lose + timeout + unknown)
                    csvlog["SAMPLE buf size"] = memory.size()
                    csvlog["SAMPLE temp"] = temperature

                    score, win, lose, timeout, unknown = 0.0, 0, 0, 0, 0
                    print(result_dir_path)

                ### train
                if (num_episode + 0) % TRAIN_INTERVAL == 0 and memory.size() + 0 >= TRAIN_START_SIZE:
                    trainer = SequenceTrainer(
                        model=model,
                        optimizer=optimizer,
                        batch_size=BATCH_SIZE,
                        get_batch=memory.get_batch,
                        loss_fn=lambda s_hat, a_hat, r_hat, s, a, r: torch.mean((a_hat - a) ** 2),
                        scheduler=scheduler,
                        eval_fns=eval_episodes(env_targets),
                    )

                    for iter in range(ITERATION_NUM):

                        log = trainer.train_iteration(
                            num_steps=TRAIN_ITERATION_NUM,
                            iter_num=iter + 1,
                            print_logs=True,
                        )

                        logs["elapsed time"].append(time.time() - start_time)
                        logs["train time"].append(log["train time"])
                        logs["train loss"].append(log["train loss"])
                        logs["eval time"].append(log["eval time"])
                        logs["eval score ave"].append(log["eval score ave"])
                        logs["eval win"].append(log["win"])
                        logs["eval lose"].append(log["lose"])
                        logs["eval timeout"].append(log["timeout"])
                        logs["eval unknown"].append(log["unknown"])
                        if log["win"] + log["lose"] != 0:
                            logs["eval win rate"].append(
                                log["win"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                            )
                        logs["eval timeout rate"].append(
                            log["timeout"] / (log["win"] + log["lose"] + log["timeout"] + log["unknown"])
                        )

                        csvlog["train time"] = log["train time"]
                        csvlog["train loss"] = log["train loss"]

                        csvlog["elapsed time"] = time.time() - start_time
                        csvlog["eval time"] = log["eval time"]
                        csvlog["eval score ave"] = log["eval score ave"]
                        csvlog["eval win"] = log["win"]
                        csvlog["eval lose"] = log["lose"]
                        csvlog["eval timeout"] = log["timeout"]
                        csvlog["eval unknown"] = log["unknown"]
                        if log["win"] + log["lose"] != 0:
                            csvlog["eval win rate"] = log["win"] / (
                                log["win"] + log["lose"] + log["timeout"] + log["unknown"]
                            )
                        csvlog["eval timeout rate"] = log["timeout"] / (
                            log["win"] + log["lose"] + log["timeout"] + log["unknown"]
                        )

                        print(f"=== interim log report ===")
                        print(f"elapsed time {time.time() - start_time}")
                        print(f"train time {log['train time']}")
                        print(f"train loss {log['train loss']}")
                        print(f"eval time {log['eval time']}")
                        print(
                            f'eval result : win:{log["win"]}, lose:{log["lose"]}, timeout:{log["timeout"]}, unknown:{log["unknown"]}'
                        )
                        print(f"eval score ave {log['eval score ave']}")

                        print(result_dir_path)

                        with open(filename, "a", newline="", encoding="utf-8") as csvfile:
                            writer = csv.DictWriter(csvfile, fieldnames=header)
                            writer.writerow(csvlog)

                if (
                    (num_episode + 0) % SAVE_INTERVAL == 0
                    and num_episode != 0
                    and log["win"] / EVAL_ITERATION_NUM > 0.0
                ):
                    torch.save(
                        model.state_dict(),
                        f"{result_dir_path}/{str(num_episode+0)}.pth",
                    )

    print(f"total elapsed time {time.time() - start_time}")

    # plot
    fig = plt.figure()
    ax1 = fig.subplots()
    ax2 = ax1.twinx()

    (line1,) = ax1.plot(logs["train loss"], label="training loss", color="blue")
    # (line2,) = ax2.plot(logs["eval score ave"], label="eval score ave", color="red")
    (line2,) = ax2.plot(logs["eval win rate"], label="eval win rate", color="red")

    # ax1.set_yscale("log")

    ax1.legend(handles=[line1], loc="upper left", bbox_to_anchor=(-0.1, 0.5))
    ax2.legend(handles=[line2], loc="upper right", bbox_to_anchor=(1.1, 0.5))

    plt.savefig(f"{result_dir_path}/learning_curve.png")
    plt.show()

    env.close()

    print(result_dir_path)


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="battlegame-v0")

    args = parser.parse_args()

    logging.info(vars(args)["env"])

    main(variant=vars(args))
