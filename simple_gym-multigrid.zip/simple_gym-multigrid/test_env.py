import argparse
import random

from battlegrid import make


def main(variant):

    env_name = variant["env"]
    env = make(env_name)
    print(env_name)

    # print(env.params)

    obs, _, done, _ = env.reset()
    nb_agents = len(env.agents)

    # while not done:
    for s in range(100):
        # env.render(mode="human", highlight=True)
        act = [env.action_space.sample() for _ in range(nb_agents)]
        # act = [random.randint(1, 3) for _ in range(nb_agents)]
        obs, rewards, done, info = env.step(act)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="battlegame-v0")

    args = parser.parse_args()

    main(variant=vars(args))
