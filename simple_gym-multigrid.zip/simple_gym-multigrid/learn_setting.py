import datetime
import random
import shutil
from pathlib import Path

import numpy as np
import torch

### shared param

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# DEVICE = torch.device("cpu")

# simulation param
EPISODES = 100

# INTERVAL
TRAIN_INTERVAL = 10
EVAL_INTERVAL = 10  # for DQN only
PRINT_INTERVAL = 10
SAVE_INTERVAL = 10

# NUM
ITERATION_NUM = 1  # 学習・評価のセットの繰り返し回数(Iteration)
TRAIN_ITERATION_NUM = 1  # Iterationあたりのtrain回数 DDQN
EVAL_ITERATION_NUM = 10  # Iterationあたりのeval回数

TRAIN_START_SIZE = 1

# target update cycle for DQN
TARGET_UPDATE_INTERVAL = 20

# BUFFER_LIMIT > TRAIN_START_SIZE, BATCH_SIZE
BUFFER_LIMIT_DQN = 1000
BUFFER_LIMIT_DT = 300
BATCH_SIZE = 2**7  # TRAIN_ITERATION_NUM * 1  # GPUのメモリと使用率に一番効いてくる。
assert BUFFER_LIMIT_DQN > BATCH_SIZE, "DQN BATCH_SIZE is over buffer"
assert BUFFER_LIMIT_DT > BATCH_SIZE, "Decision Transformer BATCH_SIZE is over buffer"

# param for stemperature softmax
TEMP_TOP = 10  # 10
TEMP_BOT = 0.1  # 0.1

# TIMEOUTとなったゲームをbufferに貯めずに破棄する確率。破棄された場合はepisodeにカウントしない。0.7なら70%を破棄する。
DISPOSE_RATE = 0.0
# 学習対象となるunitのid。とりあえずid=0のみ。
UNIT_ID = 0

DEBUG = False
TRAIN_VIEW = False
EVAL_VIEW = False
SLEEP_TIME = 0.2

LOAD = False
LOAD_DIR = "data.result.180739"
LOAD_FILE = "3400.pth"  # .pth file
if LOAD:
    DEVICE = torch.device("cpu")

# for imitation learning
MANUAL_MODE = False
RULE_BASE = False
DATASET_LOAD = False
DATASET_SAVE = False

# override
if DATASET_SAVE:
    # INTERVAL
    TRAIN_INTERVAL = EPISODES
    EVAL_INTERVAL = EPISODES
    PRINT_INTERVAL = EPISODES
    SAVE_INTERVAL = EPISODES

    # NUM
    ITERATION_NUM = 1  # 学習・評価のセットの繰り返し回数(Iteration)
    TRAIN_ITERATION_NUM = 1  # Iterationあたりのtrain回数 DDQN
    EVAL_ITERATION_NUM = 1  # Iterationあたりのeval回数

    # target update cycle for DQN
    TARGET_UPDATE_INTERVAL = EPISODES

    # BUFFER_LIMIT > TRAIN_START_SIZE, BATCH_SIZE
    BUFFER_LIMIT_DQN = 1
    BUFFER_LIMIT_DT = 1
    BATCH_SIZE = 1  # TRAIN_ITERATION_NUM * 1  # GPUのメモリと使用率に一番効いてくる。

    TRAIN_START_SIZE = EPISODES

    # param for stemperature softmax
    TEMP_TOP = 1000  # 10
    TEMP_BOT = 1000  # 0.1


# general learning parameters
GAMMA = 0.9  # 0.8  # 割引率 : 1に近いほど将来得られるであろう報酬を優先する
DEFAULT_LEARNING_RATE = 3e-8  # 3e-8  # 学習率 : 現在のQ値と未来のQ値のどちらを優先するか。学習率αが大きいほど未来を優先する。

# parser.add_argument('--weight_decay', '-wd', type=float, default=1e-4) #本来は1e-4だけど、handyrlでは1e-5を使っているからそっちにしてみる。 小さいと過学習なりやすく、大きいと性能が低下しやすい。
WEIGHT_DECAY = 1e-4

# parser.add_argument('--embed_dim', type=int, default=128) #  Dimensionality of the embeddings and hidden states.
EMBED_DIM = 2**8


### DT param : reference https://huggingface.co/docs/transformers/model_doc/gpt2
# parser.add_argument('--K', type=int, default=20)
MAX_LEN = 20

# parser.add_argument('--pct_traj', type=float, default=1.)
PCT_TRAJECTORY = 1.0

# parser.add_argument('--n_layer', type=int, default=3) # Number of hidden layers in the Transformer encoder.
N_LAYER = 2**2

# parser.add_argument('--n_head', type=int, default=1) # Number of attention heads for each attention layer in the Transformer encoder.
N_HEAD = 2**0
assert EMBED_DIM % N_HEAD == 0, "EMBED_DIM or N_HEAD are needed to change."

# parser.add_argument('--activation_function', type=str, default='relu')
ACTIVATION_FUNC = "relu"

# n_positions=1024, # The maximum sequence length that this model might ever be used with. Typically set this to something large just in case (e.g., 512 or 1024 or 2048). https://huggingface.co/docs/transformers/model_doc/gpt2
N_POSITIONS = 2**10

# parser.add_argument('--dropout', type=float, default=0.1) 通常0.2~0.5。小さいと過学習なりやすく、大きいと性能が低下しやすい。
DROPOUT = 0.1

# parser.add_argument('--warmup_steps', type=int, default=10000)
WARMUP_STEP = 1

# target value used in evaluation. original : 2 list like [3600, 1800] or [2000, 1000].
ENV_TARGETS = 1

# scale. original : 1000
SCALE = 1

# parser.add_argument('--log_to_wandb', '-w', type=bool, default=False)
LOG_TO_WANDB = False


### Conv param
BLOCKS = 12
CHANNELS = 32
